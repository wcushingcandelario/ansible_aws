package dynamic.posMServer.model.commQueue.CommQueueRestAction;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.nio.charset.StandardCharsets;

import com.oneview.util.StreamHelper;

import java.security.KeyManagementException;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NodeList;
import org.glassfish.jersey.client.authentication.HttpAuthenticationFeature;
import org.glassfish.jersey.jackson.JacksonFeature;
import org.json.JSONObject;
import org.xml.sax.InputSource;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.util.StreamHelper;




public class Action implements DynamicClass{

	public static Map<String, Object> outputParams = new HashMap<String, Object>();
	
	@SuppressWarnings("unused")
	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) throws DynamicExecuterException
	{
		/*
		DOCOauthClient client = new DOCOauthClient();
		DOCDefaultCapacity capacity = client.getFulfilmentCentre();
		String basketId = client.postBasket(inputParams);
		 */
		String contentType = (String)inputParams.get("contentType");
		String url = (String)inputParams.get("url");
		if(contentType.contains("application/json") ){
			outputParams = doJSONRequest(inputParams);
		}else if(contentType.contains("application/xml")){
			doXMLRequest(inputParams);
		}

		return outputParams;
	}


	private Map<String, Object> doXMLRequest(Map<String, Object> inputParams) throws DynamicExecuterException {

		String xmlRequest = (String)inputParams.get("requestPayload");
		String username = (String)inputParams.get("username");
		String password = (String)inputParams.get("password");
		String url = (String)inputParams.get("url");
		//disableCertificateValidation();
		Client client = getClientWithAuth(username, password);

		WebTarget webTarget = client.target(url);
		//sysouts

		Invocation.Builder requestBuilder = webTarget.request(new MediaType[] { MediaType.APPLICATION_XML_TYPE });

		Response response = requestBuilder.put(Entity.entity(xmlRequest, MediaType.APPLICATION_XML_TYPE));


		String strResponse = null;
		try (InputStream is = response.readEntity(InputStream.class);
		     Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
			strResponse = StreamHelper.read(r, false);
		} catch (IOException ioe) {
			throw new DynamicExecuterException(ioe, null, null);
		}

		//String orderCode = null;
		String status = null;
		String message = null;
		JSONObject jsonObj = null;
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder;
		InputSource is;
		try {
			builder = factory.newDocumentBuilder();
			is = new InputSource(new StringReader(strResponse));
			Document doc = builder.parse(is);
			NodeList list = doc.getElementsByTagName("status");
			message = list.item(0).getNodeValue();
			if (message != null && !"".equals(message)) {
				status = ""+response.getStatus();
				message = list.item(0).getNodeValue().toString();
			} else {
				status = ""+response.getStatus();
				message = "Failed";
			}
		}catch (Exception e) {
			throw new DynamicExecuterException("Error parsing json response: " + strResponse, e, null, null);
		}

		outputParams.put("status", status);
		outputParams.put("message", message);
		outputParams.put("strResponse", strResponse);

		return outputParams;
	}


	public static Client getClientWithAuth(String username, String password) {

		Client client = null;
		System.setProperty("jsse.enableSNIExtension", "false");
		ClientBuilder clientBuilder = ClientBuilder.newBuilder();
		clientBuilder.register(HttpsURLConnection.class);
		// disableCertificateValidation();
		// Create a trust manager that does not validate certificate chains
		TrustManager[] trustAllCerts = new TrustManager[] { new X509TrustManager() {
			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}

			public void checkClientTrusted(X509Certificate[] certs,
			                               String authType) {
			}

			public void checkServerTrusted(X509Certificate[] certs,
			                               String authType) {
			}
		} };
		// Ignore differences between given hostname and certificate hostname
		HostnameVerifier hv = new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		};

		// Install the all-trusting trust manager
		try {
			SSLContext sc = SSLContext.getInstance("SSL");
			sc.init(null, trustAllCerts, new SecureRandom());
			HttpsURLConnection
					.setDefaultSSLSocketFactory(sc.getSocketFactory());
			HttpsURLConnection.setDefaultHostnameVerifier(hv);

			//enable authentication
			HttpAuthenticationFeature authFeature = HttpAuthenticationFeature
					.basic(username, password);
			clientBuilder.register(authFeature);
			client = ((ClientBuilder) clientBuilder
					.register(JacksonFeature.class)).build();

		} catch (Exception e) {

		}
		return client;
	}

	public static Map<String, Object> doJSONRequest(Map<String, Object> inputParams) throws DynamicExecuterException {


		JSONObject jsonObject = (JSONObject)inputParams.get("requestPayload");
		String username = (String)inputParams.get("username");
		String password = (String)inputParams.get("password");
		String url = (String)inputParams.get("url");
		String method = (String)inputParams.get("method");
		//disableCertificateValidation();
		Client client = getClientWithAuth(username, password);

		WebTarget webTarget = client.target(url);

		Invocation.Builder requestBuilder = webTarget.request(new MediaType[] { MediaType.APPLICATION_JSON_TYPE });
		Response response = null;

		try{
			if("GET".equalsIgnoreCase(method))
				response =requestBuilder.get();
			else
				response = requestBuilder.post(Entity.entity(jsonObject.toString(), MediaType.APPLICATION_JSON_TYPE));
		}catch(Exception e){
			throw new DynamicExecuterException(e.getLocalizedMessage(), null, null);
		}


		String strResponse = null;
		try (InputStream is = response.readEntity(InputStream.class);
		     Reader r = new InputStreamReader(is, StandardCharsets.UTF_8)) {
			strResponse = StreamHelper.read(r, false);
		} catch (IOException ioe) {
			throw new DynamicExecuterException(ioe, null, null);
		}

		//String orderCode = null;
		String status = null;
		Object message = null;
		JSONObject jsonObj = null;
		try {
			// Get the JSON object and make sure it is UTF-8
			jsonObj = new JSONObject(strResponse);
			status = ""+response.getStatus();
			if (status !=null && !"".equals(status) && (status.equals("200") ||status.equals("201"))){
				message = jsonObj;
			}else {
				message = "Failed";
			}
		} catch (Exception e) {
			throw new DynamicExecuterException("Error parsing json response: " + strResponse, e, null, null);
		}

/*		if (message != null) {
			throw new DynamicExecuterException(message, null, null);
		}*/

		outputParams.put("status", status);
		outputParams.put("message", message);
		outputParams.put("strResponse", strResponse);

		return outputParams;
	}

}
