package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.tools.parsers.ObjectParser;
import com.oneview.tools.parsers.TaxRateGroupMappingParser;
import com.oneview.tools.parsers.TaxRateProductMappingParser;

public class ImportProductTaxRateMapping implements DynamicClass{

	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		try{
			// Build the xml document
			Document importXML = DocumentHelper.createDocument();
	
			Element root = importXML.addElement("TaxRateMappings");
			root.addAttribute("locationId", "posMClient-grp-all");
			root.addAttribute("retailerId", (String)processMem.getInputParams().get("retailerId"));
	
			@SuppressWarnings("unchecked")
			Map<String, String>PrdTaxRateIdMap = (Map<String, String>) processMem.get("prcMemPrdTaxRateIdMap");
			for (String skuId : PrdTaxRateIdMap.keySet()) {
				Element type = root.addElement("TaxRateMapping");
	
				type.addElement("TaxRateId").setText(PrdTaxRateIdMap.get(skuId));
				type.addElement("GroupId");
				type.addElement("SKU").setText(skuId);
				Element startDate = type.addElement("StartDate");
				startDate.addAttribute("f", "1");
				startDate.setText("20120222");
	
				Element endDate = type.addElement("EndDate");
				endDate.addAttribute("f", "1");
				endDate.setText("50009999");
			}
	
			// Add the import xml to the output params
			outputParams.put("importXML", importXML);
			//System.out.println("product tax rate xml --> "+importXML.asXML());
			// Add the parsers for this xml import document
			List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
			parsers.add(TaxRateGroupMappingParser.class);
			parsers.add(TaxRateProductMappingParser.class);
	
			// Add the parsers to the output params
			outputParams.put("parsers", parsers);
		}catch(Exception e){
			e.printStackTrace();
		}
		return outputParams;
	}

}
