package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.json.JSONArray;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;

public class IfProductsHasPrices implements DynamicClass{

	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem)
			throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		boolean isPriceAvailable = false;		
		try{
			JSONArray productsListArray = (JSONArray) processMem.get("productPageJSONArray");

			for (int i=0; i<productsListArray.length(); i++){
		
				ObjectMapper om = new ObjectMapper();
				Map<String, Object> productDetailsMap = (Map<String, Object>) om.readValue(productsListArray.get(i).toString(), Map.class);
				
				List<Map<String, Object>> skuList = (ArrayList<Map<String, Object>>) productDetailsMap.get("skus");
				if(CollectionUtils.isNotEmpty(skuList)) {
					for (Map<String, Object> skuMap : skuList) {
						List<Map<String, Object>> priceList = (List<Map<String, Object>>)(skuMap.get("price"));
						if(CollectionUtils.isNotEmpty(priceList)){
							isPriceAvailable = true;
							break;
						}else if(CollectionUtils.isNotEmpty((List<Map<String, Object>>)(productDetailsMap.get("price")))){
							isPriceAvailable = true;
							break;
						}					
					}
				}
				else {
					List<Map<String, Object>> priceList = (List<Map<String, Object>>)(productDetailsMap.get("price"));
					if(CollectionUtils.isNotEmpty(priceList)){
						isPriceAvailable = true;
						break;
					} 
				}
				if(isPriceAvailable){
					break;
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		outputParams.put("condition", isPriceAvailable );
		return outputParams;
	}
}
