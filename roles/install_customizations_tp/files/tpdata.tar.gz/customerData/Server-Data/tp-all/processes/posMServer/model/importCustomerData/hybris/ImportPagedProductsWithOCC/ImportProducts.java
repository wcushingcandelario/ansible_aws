package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;
import com.oneview.tools.parsers.ObjectParser;
import com.oneview.tools.parsers.ProductLocationParser;
import com.oneview.tools.parsers.ProductMerchandisingGroupParser;
import com.oneview.tools.parsers.ProductParser;
import com.oneview.tools.parsers.ProductPropertyParser;
import com.oneview.tools.parsers.ProductSkuBarcodeParser;
import com.oneview.tools.parsers.ProductSkuParser;
import com.oneview.tools.parsers.ProductVariantParser;
import com.oneview.tools.posmclient.xsd.XsdValidation;
import com.oneview.util.ImportUtil;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.*;

public class ImportProducts implements DynamicClass {

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();

		String[] propertyNames = null;
		String[]  productPropertyValues = null;
		try {
			JSONObject config = ConfigManager.getConfigObject("posMServer/hybrisImportQueries.ovccfg", "posMClient-grp-all");
            JSONObject propertiesJson = config.getJSONObject("productProperties");
            propertyNames = JSONObject.getNames(propertiesJson);
            
            
            if(propertyNames != null && propertyNames.length >0){
              productPropertyValues = new String[propertyNames.length];
              for(int i = 0; i < propertyNames.length; i++){
                productPropertyValues[i] = propertiesJson.getString(propertyNames[i]);
              }
            }
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		try{
			// Build the xml document
			Document importXML = DocumentHelper.createDocument();
	
			Element root = importXML.addElement("Products");
			root.addAttribute("locationId", "posMClient-grp-all");

			JSONArray productsListArray = (JSONArray) inputParams.get("productPageJSONArray");
			inputParams.put("productPageJSONArray", null);
			processMem.put("productPageJSONArray", productsListArray);
			
			String retailerId = (String)processMem.getInputParams().get("retailerId");
			
			Map<String,  String> prdTaxRateIdMap = new HashMap<String, String>();
			
			if(productsListArray != null) {
				for (int i=0; i<productsListArray.length(); i++){
				//for (Map<String, Object> productMap : productsMapList) {
		
					ObjectMapper om = new ObjectMapper();
					Map<String, Object> productDetailsMap = (Map<String, Object>) om.readValue(productsListArray.get(i).toString(), Map.class);
					String productCode = (String) productDetailsMap.get("productCode");
					String name = productDetailsMap.get("name") != null ? (String) productDetailsMap.get("name") : "";
					
					String description = (String)productDetailsMap.get("description");
					
					if(StringUtils.isBlank(description)){
						description = (String) productDetailsMap.get("name");
					}
					String imageURL = productDetailsMap.get("imageURL") != null ? (String) productDetailsMap.get("imageURL") : "";
					String thumbnail = productDetailsMap.get("thumbnail") != null ? (String) productDetailsMap.get("thumbnail") : "";
					
					//Root element
					Element productElement = root.addElement("Product");
		
					productElement.addAttribute("id", UUID.nameUUIDFromBytes((retailerId+productCode).getBytes()).toString());
		
					//base product elements start --- //
					productElement.addElement("RetailerId").setText(retailerId);
					productElement.addElement("ProductCode").setText(productCode);
					productElement.addElement("Name").setText(name);
					productElement.addElement("Desc").setText(description);
					productElement.addElement("Style");
					productElement.addElement("ProductURL").setText(thumbnail);
					productElement.addElement("MainImageId").setText(imageURL);
		
					List<Map<String,Object>> merchGroupList = (List<Map<String,Object>>)productDetailsMap.get("categories");
					Element merchGroups = productElement.addElement("MerchandiseGroups");
					if(merchGroupList != null){
						for(Map<String,Object> merchGroup : merchGroupList){
							merchGroups.addElement("MerchandiseGroup").setText((String)merchGroup.get("categoryId"));
						}
					}
					String productType = ImportUtil.getProductType(merchGroupList);
					if(productType != null) {
						productElement.addElement("ProductType").setText(productType);
					}else{
						//defaulting to Merchandise
						productElement.addElement("ProductType").setText("Merchandise");
					}
					
					//collect TP product properties
					
					String brandName = (String)productDetailsMap.get("brandName");
					String gpid = (String)productDetailsMap.get("gpid");
					String fulfilmentType = (String)productDetailsMap.get("fulfilmentType");
					String certificationsMet = (String)productDetailsMap.get("certificationsMet");
					String challengeScheme= null;
					String explosivesPoisons = "";
					String ageRestriction = "";
					explosivesPoisons = String.valueOf(productDetailsMap.get("explosivesPoisons"));
					ageRestriction = String.valueOf(productDetailsMap.get("ageRestriction"));
					String multipackItems = "";
							
					//base product elements end --- //
					

					//sku elements start --- //
					List<Map<String, Object>> skuList = (ArrayList<Map<String, Object>>) productDetailsMap.get("skus");
		
					if(CollectionUtils.isNotEmpty(skuList)) {
						for (Map<String, Object> skuMap : skuList) {
							Element productSkus = productElement.addElement("ProductSkus");
			
							Element productSku = productSkus.addElement("Sku");
							productSku.addAttribute("id", (String)skuMap.get("skuId"));
			
							productSku.addElement("Name").setText((String)skuMap.get("name"));
							productSku.addElement("Desc").setText((String)skuMap.get("name"));
							if(skuMap.get("imageURL") != null) {
								productSku.addElement("ProductURL").setText((String)skuMap.get("imageURL"));
							}
							//add sku variant --- //
							Element variants = productSku.addElement("Variants");
			
							List<Map<String, Object>> variantList = (List<Map<String, Object>>) skuMap.get("variants");
							if(CollectionUtils.isNotEmpty(variantList)){
								for(Map<String, Object> variantMap :variantList){
									if(variantMap.containsKey("value")){
										Element varType = variants.addElement("type");
										varType.addAttribute("id", (String) variantMap.get("type"));
										varType.addElement("value").setText((String)variantMap.get("value"));
									}
								}
							}
			
							//add sku barcode --- //
			
							Element barcodes = productSku.addElement("Barcodes");
			
							List<Map<String, Object>> barcodeList = (List<Map<String, Object>>) skuMap.get("barcodes");
							if(CollectionUtils.isNotEmpty(barcodeList)){
								for(Map<String, Object> barcodeMap :barcodeList){
									if(barcodeMap.containsKey("value")){
										Element barcodeType = barcodes.addElement("type");
										barcodeType.addAttribute("id", (String) barcodeMap.get("type"));
										barcodeType.addElement("value").setText((String)barcodeMap.get("value"));
									}
								}
							}
							//collect tax rate ids for tax rate import process
							if(skuMap.get("taxCode") != null){
								String taxRateId = !"".equals(skuMap.get("taxCode")) ? (String) skuMap.get("taxCode") : "uk-vat-zero";
								prdTaxRateIdMap.put((String)skuMap.get("skuId"), taxRateId);
							}else if(productDetailsMap.get("taxCode") != null){
								String taxRateId = !"".equals(productDetailsMap.get("taxCode")) ? (String) productDetailsMap.get("taxCode") : "uk-vat-zero";
								prdTaxRateIdMap.put((String)skuMap.get("skuId"), taxRateId);
							}else{
								prdTaxRateIdMap.put((String)skuMap.get("skuId"), "uk-vat-zero");
							}
						}
					}
					else {
						Element productSkus = productElement.addElement("ProductSkus");
						
						Element productSku = productSkus.addElement("Sku");
						productSku.addAttribute("id", productCode);
		
						productSku.addElement("Name").setText(name);
						productSku.addElement("Desc").setText(name);
						productSku.addElement("ProductURL").setText(imageURL);
						
						//add barcode --- //
						Element barcodes = productSku.addElement("Barcodes");
						List<Map<String, Object>> barcodeList = (List<Map<String, Object>>) productDetailsMap.get("barcodes");
						if(CollectionUtils.isNotEmpty(barcodeList)){
							for(Map<String, Object> barcodeMap :barcodeList){
								if(barcodeMap.containsKey("value")){
									Element barcodeType = barcodes.addElement("type");
									barcodeType.addAttribute("id", (String) barcodeMap.get("type"));
									barcodeType.addElement("value").setText((String)barcodeMap.get("value"));
								}else{
									//add product code as barcode --- //
									Element barcodeType = barcodes.addElement("type");
									barcodeType.addAttribute("id", "ProductCode");
									barcodeType.addElement("value").setText(productCode);
									//break;
								}
							}
						}else{
							//add product code as barcode --- //
							Element barcodeType = barcodes.addElement("type");
							barcodeType.addAttribute("id", "ProductCode");
							barcodeType.addElement("value").setText(productCode);
						}
						
						//collect tax rate ids for tax rate import process
						if(productDetailsMap.get("taxCode") != null){
							String taxRateId = !"".equals(productDetailsMap.get("taxCode")) ? (String) productDetailsMap.get("taxCode") : "uk-vat-zero";
							prdTaxRateIdMap.put(productCode, taxRateId);
						}else{
							prdTaxRateIdMap.put(productCode, "uk-vat-zero");
						}
						/*
						 * Add product properties at sku level.
						 * Since TP has no sku data, add product code as SKU
						 * and all properties to the same SKU/Product Code
						 */
						
						Element productSkuProperties = productSku.addElement("Properties");	
						//get brandName
						if(StringUtils.isNotBlank(brandName)){
							Element brandNameProperty = productSkuProperties.addElement("property");
							brandNameProperty.addAttribute("id", "brandName");
							brandNameProperty.addAttribute("name", "brandName");
							brandNameProperty.addAttribute("type", "text");
							brandNameProperty.setText(brandName);
						}
						
						//get gpid
						if(StringUtils.isNotBlank(gpid)){
							Element gpidProperty = productSkuProperties.addElement("property");
							gpidProperty.addAttribute("id", "gpid");
							gpidProperty.addAttribute("name", "gpid");
							gpidProperty.addAttribute("type", "text");
							gpidProperty.setText(gpid);
						}
						
						//get fulfilmentType
						if(StringUtils.isNotBlank(fulfilmentType)){
							Element fulfilmentTypeProperty = productSkuProperties.addElement("property");
							fulfilmentTypeProperty.addAttribute("id", "fulfilmentType");
							fulfilmentTypeProperty.addAttribute("name", "fulfilmentType");
							fulfilmentTypeProperty.addAttribute("type", "text");
							fulfilmentTypeProperty.setText(fulfilmentType);
						}
						
						//get FSC
						if(StringUtils.isNotBlank(certificationsMet)){
							Element certificationsMetProperty = productSkuProperties.addElement("property");
							certificationsMetProperty.addAttribute("id", "certificationsMet");
							certificationsMetProperty.addAttribute("name", "certificationsMet");
							certificationsMetProperty.addAttribute("type", "text");
							certificationsMetProperty.setText(certificationsMet);
						}
						
						//get item challenges flag (explosivesPoisons or ageRestriction)
						if(StringUtils.isNotBlank(explosivesPoisons) && explosivesPoisons != null && !"null".equals(explosivesPoisons)){
							Element challengeSchemeProperty = productSkuProperties.addElement("property");
							challengeSchemeProperty.addAttribute("id", "explosivesPoisons");
							challengeSchemeProperty.addAttribute("name", "explosivesPoisons");
							challengeSchemeProperty.addAttribute("type", "text");
							challengeSchemeProperty.setText(explosivesPoisons);
							
						}if(StringUtils.isNotBlank(ageRestriction) && ageRestriction != null && !"null".equals(ageRestriction)){
							Element challengeSchemeProperty = productSkuProperties.addElement("property");
							challengeSchemeProperty.addAttribute("id", "ageRestriction");
							challengeSchemeProperty.addAttribute("name", "ageRestriction");
							challengeSchemeProperty.addAttribute("type", "text");
							challengeSchemeProperty.setText(ageRestriction);
						}
						
						//add multipack
						
						Map<String, Object> multipackMap = (Map<String, Object>) productDetailsMap.get("multipack");
						
						if(multipackMap != null){
							List<Map<String, Object>> multiPackItemList = (List<Map<String, Object>>) multipackMap.get("items");
							
							if(CollectionUtils.isNotEmpty(multiPackItemList)){
								for(Map<String, Object> multipackItem :multiPackItemList){
									if(StringUtils.isNotBlank((String)multipackItem.get("productCode"))){
										if("".equals(multipackItems))
											multipackItems =  (String)multipackItem.get("productCode");
										else
											multipackItems = multipackItems + "," +multipackItem.get("productCode");
									}
								}
							}
							if(StringUtils.isNotBlank((String)multipackMap.get("productCode"))){
								if("".equals(multipackItems))
									multipackItems =  (String)multipackMap.get("productCode");
								else
									multipackItems = multipackItems + "," +multipackMap.get("productCode");
							}
						}
						if(!"".equals(multipackItems)){
							Element multipackItemsProperty = productSkuProperties.addElement("property");
							multipackItemsProperty.addAttribute("id", "multipackItems");
							multipackItemsProperty.addAttribute("name", "multipackItems");
							multipackItemsProperty.addAttribute("type", "text");
							multipackItemsProperty.setText(multipackItems);
						}
						//End of product sku properties
					}
		
					Element propertiesJson = productElement.addElement("propertiesJson");
					Element productProperty = propertiesJson.addElement("product");
					if(propertyNames != null && propertyNames.length >0){
						  for(int j = 0; j < propertyNames.length; j++){
						    productProperty.addElement(propertyNames[j]).setText(productPropertyValues[j]);
						  }
						}
					
					/* Start of product json for product properties
					 * TODO Build the product JSON for old structure
					 * This has to phase out and should be moved to product properties only
					 */
					if(!"".equals(multipackItems)){
						productProperty.addElement("multipack").setText(multipackItems);
					}
					if(StringUtils.isNotBlank(fulfilmentType)){
						productProperty.addElement("fulfilmentType").setText(fulfilmentType);
					}
					if(StringUtils.isNotBlank(gpid)){
						productProperty.addElement("gpid").setText(gpid);
					}
					if(StringUtils.isNotBlank(certificationsMet)){
						productProperty.addElement("certificationsMet").setText(certificationsMet);
					}

					if(StringUtils.isNotBlank(explosivesPoisons) && explosivesPoisons != null 
							&& !"null".equals(explosivesPoisons) 
							&& "true".equalsIgnoreCase(explosivesPoisons)){
						challengeScheme = "explosivesPoisons";
					}else if(StringUtils.isNotBlank(ageRestriction) && ageRestriction != null 
							&& !"null".equals(ageRestriction)
							&& "true".equalsIgnoreCase(ageRestriction)){
						challengeScheme = "ageRestriction";
					}
					if(StringUtils.isNotBlank(challengeScheme)){
						productProperty.addElement("challengeScheme").setText(challengeScheme);
					}
					// End of product JSON
					
					productElement.addElement("AllowDiscounts").setText("1");
					productElement.addElement("Status").setText("2");
					productElement.addElement("IsDeleted").setText("0");
		
					//defaulting to the layaway and taxexempt flag as 1 until we find the corresponding Hybris fields...
					productElement.addElement("IsLayawayable").setText("1");
					productElement.addElement("IsTaxExemptible").setText("1");
				}
			}
			// Add the import xml to the output params
			outputParams.put("importXML", importXML);
			//System.out.println("product xml --> "+importXML.asXML().toString());
			// Add the parsers for this xml import document
	
			//XsdValidation.validateWithXsd(importXML);
	
			List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
			parsers.add(ProductParser.class);
			//parsers.add(ProductLocationParser.class);
			parsers.add(ProductMerchandisingGroupParser.class);
			parsers.add(ProductSkuParser.class);
			parsers.add(ProductSkuBarcodeParser.class);
			parsers.add(ProductVariantParser.class);
			parsers.add(ProductPropertyParser.class);
			
			// Add the parsers to the output params
			outputParams.put("parsers", parsers);
			
			//save the tax rate id map to process memory
			processMem.put("prcMemPrdTaxRateIdMap", prdTaxRateIdMap);
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return outputParams;
	}

}
