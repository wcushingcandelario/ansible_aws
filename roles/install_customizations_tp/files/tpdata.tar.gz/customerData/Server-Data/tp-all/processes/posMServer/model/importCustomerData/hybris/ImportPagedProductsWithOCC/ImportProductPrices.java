package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.tools.parsers.ObjectParser;
import com.oneview.tools.parsers.ProductPriceParser;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONArray;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImportProductPrices implements DynamicClass {

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) {
		Map<String, Object> outputParams = new HashMap<String, Object>();

		// Build the xml document
		Document importXML = DocumentHelper.createDocument();
		String startDateVal = "";
		String endDateVal = "";
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");
		SimpleDateFormat formatSdf = new SimpleDateFormat("yyyyMMdd");
		try{
			String retailerId = (String)processMem.getInputParams().get("retailerId");
			
			Element root = importXML.addElement("ProductPrices");
			
			root.addAttribute("locationId", "posMClient-grp-all");
			
			//product price import starts---//
			
			JSONArray productsListArray = (JSONArray) processMem.get("productPageJSONArray");
			
			processMem.put("productPageJSONArray", null);
			//List<Map<String, Object>> productsMapList = (List<Map<String, Object>>) processMem.get("productMapList");	
			
			for (int i=0; i<productsListArray.length(); i++){
				//for (Map<String, Object> productMap : productsMapList) {
		
				ObjectMapper om = new ObjectMapper();
				Map<String, Object> productDetailsMap = (Map<String, Object>) om.readValue(productsListArray.get(i).toString(), Map.class);
				
				final String productCode = (String)productDetailsMap.get("productCode");
				
				List<Map<String, Object>> skuList = (ArrayList<Map<String, Object>>) productDetailsMap.get("skus");
				if(CollectionUtils.isNotEmpty(skuList)) {
					for (Map<String, Object> skuMap : skuList) {
						List<Map<String, Object>> priceList = (List<Map<String, Object>>)(skuMap.get("price"));
						if(CollectionUtils.isEmpty(priceList)){
							// No sku level prices? Get prices from baseProduct
							priceList = (List<Map<String, Object>>)(productDetailsMap.get("price"));
						}
						
	//					System.out.println("******PRICES*********");
	//					System.out.println("skuMap :::: "+skuMap.get("price"));
	//					System.out.println("prodMap ::: "+productDetailsMap.get("price"));
	//					System.out.println("******PRICES*********");
	//					System.out.println("******PRICELIST*********");
	//					System.out.println("priceList::: " + priceList);
	//					System.out.println("******PRICELIST*********");
	
						final String sku = (String)skuMap.get("skuId");
						
						populatePrice(sdf, formatSdf, retailerId, root, productCode, sku, priceList);
					}
				}
				else {
					List<Map<String, Object>> priceList = (List<Map<String, Object>>)(productDetailsMap.get("price"));
					populatePrice(sdf, formatSdf, retailerId, root,productCode, productCode, priceList);
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		// Add the import xml to the output params
		outputParams.put("importXML", importXML);
		//System.out.println("product price xml --> "+importXML.asXML().toString());
		// Add the parsers for this xml import document
		List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
		parsers.add(ProductPriceParser.class);

		// Add the parsers to the output params
		outputParams.put("parsers", parsers);

		return outputParams;
	}

	private void populatePrice(SimpleDateFormat sdf, SimpleDateFormat formatSdf, String retailerId, Element root,
			String productCode, String sku, List<Map<String, Object>> priceList)
			throws ParseException {
		
		if (CollectionUtils.isNotEmpty(priceList)) {
			for (Map<String, Object> priceMap : priceList) {
				Element productElement = root.addElement("ProductPrice");
				productElement.addElement("Type").setText("1");
				productElement.addElement("RetailerId").setText(retailerId);
				productElement.addElement("SKU").setText(sku);
				Element productCodeElement = productElement.addElement("ProductCode");
				productCodeElement.addAttribute("type", "base");
				productCodeElement.setText(productCode);

				Element startDate = productElement.addElement("StartDate");
				startDate.addAttribute("f", "1");
				String startDateVal = StringUtils.defaultIfBlank((String)(priceMap.get("startDate")),"2000-01-01T00:00:00+0000");
				startDate.setText(formatSdf.format(sdf.parse(startDateVal)));

				Element endDate = productElement.addElement("EndDate");
				endDate.addAttribute("f", "1");
				
				String endDateVal = (String)(priceMap.get("endDate"));
				if(endDateVal.contains("9999-12-31"))
					endDateVal = "2099-12-31T23:59:59+0000";

				endDate.setText(formatSdf.format(sdf.parse(endDateVal)));
				
				productElement.addElement("currencyId").setText((String) priceMap.get("currencyIso"));
				productElement.addElement("amount").setText(priceMap.get("value").toString());
				
				if(StringUtils.isNotBlank(""+priceMap.get("minQuantity"))){
					productElement.addElement("minQty").setText(""+priceMap.get("minQuantity"));
				}else{
					productElement.addElement("minQty").setText("1");
				}			
			}
		}
	}

}
