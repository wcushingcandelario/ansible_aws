package dynamic.posMServer.model.importCustomerData.hybris.ImportAllWithOCC;

import java.util.HashMap;
import java.util.Map;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;

public class CallImportProductProcess implements DynamicClass{

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams,
			ProcessMem processMem) throws DynamicExecuterException {
		// TODO Auto-generated method stub
		Map<String, Object> outputParams = new HashMap<String, Object>();
		processMem.put("empByStoreList", null);
		outputParams.put("storeList", processMem.get("storeList"));
		outputParams.put("hybrisBaseSiteId", (String)processMem.getInputParams().get("hybrisBaseSiteId"));
		outputParams.put("retailerId", (String)processMem.getInputParams().get("retailerId"));

		return outputParams;
	}

}
