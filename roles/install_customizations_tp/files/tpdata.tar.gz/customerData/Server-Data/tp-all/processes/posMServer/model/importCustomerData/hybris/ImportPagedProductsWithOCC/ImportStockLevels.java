package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;
import com.oneview.tools.parsers.ObjectParser;
import com.oneview.tools.parsers.ProductLocationStockParser;
// import com.oneview.tools.parsers.ProductLocationStockParser;
import com.oneview.tools.parsers.ProductStockParser;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImportStockLevels implements DynamicClass {

	private static String DEFAULT_LOCATION = "posMClient-grp-all";
	private static String OCC_CONFIG_FILE = "posMServer/occHybrisConfig.ovccfg";
	private static String OCC_OBJECT = "stockObj";
	private static String OCC_RESPONSE_ROOT = "responseRoot";

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();

		
		try {
			// Set the storeList in process memory for the loop input
			
			// Build the xml document
			Document importXML = DocumentHelper.createDocument();

			Element root = importXML.addElement("ProductStockLevels");
			root.addAttribute("locationId", "posMClient-grp-all");
			Map<String, String>PrdTaxRateIdMap = (Map<String, String>) processMem.get("prcMemPrdTaxRateIdMap");
			if(PrdTaxRateIdMap != null) {
				for (String skuId : PrdTaxRateIdMap.keySet()) {
					Element level = root.addElement("ProductStockLevel");
					level.addAttribute("retailerId", (String)processMem.getInputParams().get("retailerId"));
					level.addAttribute("sku", skuId);
					level.addAttribute("warehouseId", "posMClient-grp-all");
					level.setText("100");
				}
			}

			// Add the import xml to the output params
			outputParams.put("importXML", importXML);
			// System.out.println("product stock xml --> "+importXML.asXML().toString());
			// Add the parsers for this xml import document
			List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
			parsers.add(ProductStockParser.class);
			parsers.add(ProductLocationStockParser.class);

			// Add the parsers to the output params
			outputParams.put("parsers", parsers);
		} catch (Exception e) {
			throw new DynamicExecuterException(String.format("Unable to load %s config: %s", OCC_CONFIG_FILE, e.getMessage()), e, null, null);
		}
		

		return outputParams;
	}

}
