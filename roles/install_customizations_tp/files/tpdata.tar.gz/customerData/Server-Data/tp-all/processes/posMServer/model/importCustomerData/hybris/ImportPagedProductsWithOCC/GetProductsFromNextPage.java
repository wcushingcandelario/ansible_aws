package dynamic.posMServer.model.importCustomerData.hybris.ImportPagedProductsWithOCC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;

public class GetProductsFromNextPage implements DynamicClass {

	private static String OCC_CONFIG_FILE = "posMServer/occHybrisConfig.ovccfg";
	private static String DEFAULT_LOCATION = "posMClient-grp-all";
	//product response root
	private static String OCC_PROD_OBJECT = "productObj";
	private static String OCC_RESPONSE_ROOT = "responseRoot";

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams,
			ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		
		try{
			JSONObject occConfig = ConfigManager.getConfigObject(OCC_CONFIG_FILE, DEFAULT_LOCATION);
			JSONObject occProdObject = occConfig.getJSONObject(OCC_PROD_OBJECT);
			
			String responseRoot = occProdObject.getString(OCC_RESPONSE_ROOT);
			JSONObject dataMessage = (JSONObject) inputParams.get("results");
			JSONArray productPageJSONArray = dataMessage.optJSONArray(responseRoot);
			
			outputParams.put("productPageJSONArray", productPageJSONArray);
			
			processMem.put("totalPageCount", dataMessage.getInt("totalPageCount"));

		}catch(Exception e){
			e.printStackTrace();
		}
		
		return outputParams;
	}
}
