package dynamic.posMServer.model.importCustomerData.hybris.ImportAllWithOCC;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.apache.commons.lang3.StringUtils;
import org.json.JSONArray;
import org.json.JSONObject;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;

public class GetHybrisStores implements DynamicClass {

	/* Logger instance for this class */
	private static final Logger lOGGER = LoggerFactory.getLogger(GetHybrisStores.class);
	private static String CONFIG_FILE = "posMServer/locationWhiteList.ovccfg";
	private static String DEFAULT_LOCATION = "posMClient-grp-all";

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		String locationId = (String)processMem.getInputParams().get("locationId");
		JSONObject storeIdsJson = new JSONObject();
		JSONArray storeArray = new JSONArray();
		ArrayList<String> storeList = new ArrayList<String>();
		try {

			if(StringUtils.isNotBlank(locationId)){
				storeArray.put(locationId);
			}
			//create store list from whitelist
			else{
				JSONObject locWhiteList = ConfigManager.getConfigObject(CONFIG_FILE, DEFAULT_LOCATION);
				ObjectMapper om = new ObjectMapper();
				Map<String, Object> storesMap = (Map<String, Object>) om.readValue(locWhiteList.toString(), Map.class);

				for(String store : storesMap.keySet()){
					if((Integer)storesMap.get(store) == 1){
						storeArray.put(store);
						storeList.add(store);
					}
				}
			}
			storeIdsJson.put("storeIds", storeArray);

			processMem.put("storeIdsJson", storeIdsJson);
			processMem.put("storeList", storeList);

		} catch (Exception e) {
			logger.error("Error occurred in getting hybris store with occ",e);
		}

		return outputParams;
	}

}
