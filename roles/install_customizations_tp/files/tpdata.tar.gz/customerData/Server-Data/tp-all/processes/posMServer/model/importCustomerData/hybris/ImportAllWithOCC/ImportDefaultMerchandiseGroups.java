package dynamic.posMServer.model.importCustomerData.hybris.ImportAllWithOCC;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.tools.parsers.GroupLocationParser;
import com.oneview.tools.parsers.GroupParser;
import com.oneview.tools.parsers.GroupRelationParser;
import com.oneview.tools.parsers.ObjectParser;

import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImportDefaultMerchandiseGroups implements DynamicClass {

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) {
		Map<String, Object> outputParams = new HashMap<String, Object>();

		// Build the xml document
		Document importXML = DocumentHelper.createDocument();

		Element root = importXML.addElement("MerchandiseGroups");
		root.addAttribute("locationId", "posMClient-grp-all");

		List<Map<String, Object>> groups = (List<Map<String, Object>>) inputParams.get("results");
		for (Map<String, Object> merchandiseGroup : groups) {
			Element group = root.addElement("Group");
			group.addAttribute("id", (String)merchandiseGroup.get("id"));
			group.addAttribute("type", (String)merchandiseGroup.get("groupType"));
			group.addElement("Name").setText((String)merchandiseGroup.get("name"));
			group.addElement("ParentId").setText((String)merchandiseGroup.get("parentId"));
			group.addElement("IsDeleted").setText("0");
		}

		// Add the import xml to the output params
		outputParams.put("importXML", importXML);

		// Add the parsers for this xml import document
		List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
		parsers.add(GroupParser.class);
		parsers.add(GroupLocationParser.class);
		parsers.add(GroupRelationParser.class);

		// Add the parsers to the output params
		outputParams.put("parsers", parsers);

		return outputParams;
	}

}
