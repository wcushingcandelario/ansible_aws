package dynamic.posMServer.model.importCustomerData.hybris.ImportStoreStockLevelsWithOCC;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.json.JSONArray;
import org.json.JSONObject;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;

public class GetHybrisStock implements DynamicClass {

	private static String CONFIG_FILE = "posMServer/commerceServer.ovccfg";
	private static String CONFIG_VALUE = "baseCommerceServer";
	private static String OCC_CONFIG_FILE = "posMServer/occHybrisConfig.ovccfg";
	private static String DEFAULT_LOCATION = "posMClient-grp-all";
	private static String OCC_STOCK_OBJECT = "stockObj";
	private static String OCC_END_POINT = "endPoint";
	private static String STORE_VALUE = "store";
	private static String OCC_METHOD = "method";
	private static String CONFIG_VALUE_USER = "usernameOVC";
	private static String CONFIG_VALUE_PWD = "passwordOVC";

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams,
			ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		
		String authUserName="";
		String authUserPwd="";
		String method="";
		String targetServerUrl="";
		JSONObject storeIdJson = new JSONObject();
		
		try{
			
			JSONObject config = ConfigManager.getConfigObject(CONFIG_FILE, DEFAULT_LOCATION);
			JSONObject occConfig = ConfigManager.getConfigObject(OCC_CONFIG_FILE, DEFAULT_LOCATION);
			
			//call stock service
			String baseSiteId = (String)processMem.getInputParams().get("hybrisBaseSiteId");
			JSONObject occStockObject = occConfig.getJSONObject(OCC_STOCK_OBJECT);
			
			String endPoint = occStockObject.getString(OCC_END_POINT);
			String storeId = occStockObject.getString(STORE_VALUE);
			method=occStockObject.getString(OCC_METHOD);
			
			endPoint = endPoint.replace("{baseSite}", baseSiteId);
			targetServerUrl = config.getString(CONFIG_VALUE);
			authUserName = config.getString(CONFIG_VALUE_USER);
			authUserPwd = config.getString(CONFIG_VALUE_PWD);
			
			// Add the controller endpoint
			targetServerUrl += endPoint+"/"+storeId;

			String hybrisStoreId = (String) inputParams.get("current");
			processMem.put("currentStore", hybrisStoreId);
			
			storeIdJson.put("storeIds", Collections.singletonList(hybrisStoreId));
		}catch(Exception e){
			e.printStackTrace();
		}
		
		outputParams.put("url", targetServerUrl);
		outputParams.put("username", authUserName);
		outputParams.put("password", authUserPwd);
		outputParams.put("method", method);
		outputParams.put("contentType", "application/json; charset=uft-8");
		outputParams.put("requestPayload", storeIdJson);
		outputParams.put("isOCCEnabled", "true");
		
		return outputParams;
	}
}
