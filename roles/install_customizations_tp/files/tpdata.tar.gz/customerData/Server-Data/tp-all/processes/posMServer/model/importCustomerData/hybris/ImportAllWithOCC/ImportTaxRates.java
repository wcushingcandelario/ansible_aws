package dynamic.posMServer.model.importCustomerData.hybris.ImportAllWithOCC;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.tools.parsers.ObjectParser;
import com.oneview.tools.parsers.TaxRateNLSParser;
import com.oneview.tools.parsers.TaxRateParser;
import com.oneview.tools.parsers.TaxRateRangeParser;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ImportTaxRates implements DynamicClass {

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) {
		Map<String, Object> outputParams = new HashMap<String, Object>();

		// Build the xml document
		Document importXML = DocumentHelper.createDocument();

		List<Map<String, List<Map<String, Object>>>> taxAreas = (List<Map<String, List<Map<String, Object>>>>)inputParams.get("results");
		for (Map<String, List<Map<String, Object>>> taxArea : taxAreas) {
			for (String area : taxArea.keySet()) {
				Element root = importXML.addElement("TaxRates");
				root.addAttribute("area", area);
				List<Map<String, Object>> taxRates = (List<Map<String, Object>>) taxArea.get(area);
				for (Map<String, Object> taxRate : taxRates) {
					Element rate = root.addElement("TaxRate");
					rate.addAttribute("id", (String)taxRate.get("id"));

					Element desc = rate.addElement("Desc");
					List<Map<String, Object>> taxRateDescriptions = (List<Map<String, Object>>)taxRate.get("taxRateDescriptions");
					for (Map<String, Object> taxRateDescription : taxRateDescriptions) {
						Element lang = desc.addElement("Lang");
						lang.addAttribute("id", (String)taxRateDescription.get("langId"));
						lang.setText((String)taxRateDescription.get("desc"));
					}

					Element displayCode = rate.addElement("DisplayCode");
					List<Map<String, Object>> taxRateDisplayCodes = (List<Map<String, Object>>)taxRate.get("taxRateDisplayCodes");
					for (Map<String, Object> taxRateDisplayCode : taxRateDisplayCodes) {
						Element lang = displayCode.addElement("Lang");
						lang.addAttribute("id", (String)taxRateDisplayCode.get("langId"));
						lang.setText((String)taxRateDisplayCode.get("displayCode"));
					}

					Element startDate = rate.addElement("StartDate");
					startDate.addAttribute("f", (String)taxRate.get("startDateFormat"));
					startDate.setText((String)taxRate.get("startDate"));

					Element endDate = rate.addElement("EndDate");
					endDate.addAttribute("f", (String)taxRate.get("endDateFormat"));
					endDate.setText((String)taxRate.get("endDate"));

					rate.addElement("DefaultPercentage").setText(((Double)taxRate.get("defaultPercentage")).toString());

					Element percentageRanges = rate.addElement("PercentageRanges");
					List<Map<String, Object>> taxRatePercentageRanges = (List<Map<String, Object>>)taxRate.get("taxRatePercentageRanges");
					for (Map<String, Object> taxRatePercentageRange : taxRatePercentageRanges) {
						Element range = percentageRanges.addElement("Range");
						range.addAttribute("fromPrice", (String)taxRatePercentageRange.get("fromPrice"));
						range.addAttribute("upToPrice", (String)taxRatePercentageRange.get("upToPrice"));
						range.setText(((Double)taxRatePercentageRange.get("percentage")).toString());
					}

					rate.addElement("currency").setText((String)taxRate.get("currency"));

					Element isVAT = rate.addElement("IsVAT");
					isVAT.setText(Integer.toString((int)taxRate.get("isVAT")));
				}
			}
		}

		// Add the import xml to the output params
		outputParams.put("importXML", importXML);

		// Add the parsers for this xml import document
		List<Class<? extends ObjectParser>> parsers = new ArrayList<Class<? extends ObjectParser>>();
		parsers.add(TaxRateParser.class);
		parsers.add(TaxRateNLSParser.class);
		parsers.add(TaxRateRangeParser.class);

		// Add the parsers to the output params
		outputParams.put("parsers", parsers);

		return outputParams;
	}

}
