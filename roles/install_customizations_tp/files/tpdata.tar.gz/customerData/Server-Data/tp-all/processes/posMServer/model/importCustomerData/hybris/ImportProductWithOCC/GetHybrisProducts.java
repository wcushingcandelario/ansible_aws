package dynamic.posMServer.model.importCustomerData.hybris.ImportProductWithOCC;

import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.json.JSONObject;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.executer.DynamicClass;
import com.oneview.server.process.util.ConfigManager;

public class GetHybrisProducts implements DynamicClass {
	
	private static String CONFIG_FILE = "posMServer/commerceServer.ovccfg";
	private static String CONFIG_VALUE = "baseCommerceServer";
	private static String OCC_CONFIG_FILE = "posMServer/occHybrisConfig.ovccfg";
	private static String DEFAULT_LOCATION = "posMClient-grp-all";
	private static String OCC_OBJECT = "productObj";
	private static String OCC_END_POINT = "endPoint";
	private static String CURRENCY_VALUE = "currency";
	private static String OCC_METHOD = "method";
	private static String CONFIG_VALUE_USER = "usernameOVC";
	private static String CONFIG_VALUE_PWD = "passwordOVC";
	
	/* Logger instance for this class */
	private static final Logger lOGGER = LoggerFactory.getLogger(GetHybrisProducts.class);
	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams, ProcessMem processMem) {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		String targetUrl = "";
		String authUserName="";
		String authUserPwd="";
		String method="";
		String baseSiteId = (String)processMem.getInputParams().get("hybrisBaseSiteId");		
		
		try {
			JSONObject config = ConfigManager.getConfigObject(CONFIG_FILE, DEFAULT_LOCATION);
			JSONObject occConfig = ConfigManager.getConfigObject(OCC_CONFIG_FILE, DEFAULT_LOCATION);
			
			JSONObject occObject = occConfig.getJSONObject(OCC_OBJECT);
			String endPoint = occObject.getString(OCC_END_POINT);
			method=occObject.getString(OCC_METHOD);
			
			endPoint = endPoint.replace("{baseSite}", baseSiteId);
			targetUrl = config.getString(CONFIG_VALUE);
			authUserName = config.getString(CONFIG_VALUE_USER);
			authUserPwd = config.getString(CONFIG_VALUE_PWD);
			
			// Add the controller endpoint
			if (!targetUrl.endsWith("/")) {
				targetUrl += "/";
			}
			
			targetUrl += endPoint+"/paginated";
			targetUrl += "?pageSize=" + inputParams.get("itemsPerPage") + "&fields=FULL";
			
		} catch (Exception e) {	
			logger.error("Invalid JSON value found:",e);
			
		}
		
		outputParams.put("url", targetUrl);
		outputParams.put("username", authUserName);
		outputParams.put("password", authUserPwd);
		outputParams.put("method", method);
		outputParams.put("contentType", "application/json; charset=uft-8");
		outputParams.put("requestPayload", new JSONObject());
		outputParams.put("isOCCEnabled", "true");
		
		return outputParams;
	}

}