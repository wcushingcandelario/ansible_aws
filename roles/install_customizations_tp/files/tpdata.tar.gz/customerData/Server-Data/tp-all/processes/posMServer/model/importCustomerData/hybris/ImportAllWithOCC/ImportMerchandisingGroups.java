package dynamic.posMServer.model.importCustomerData.hybris.ImportAllWithOCC;

import java.util.HashMap;
import java.util.Map;

import com.oneview.server.process.ProcessMem;
import com.oneview.server.process.exception.DynamicExecuterException;
import com.oneview.server.process.executer.DynamicClass;

public class ImportMerchandisingGroups implements DynamicClass {

	@Override
	public Map<String, Object> execute(Map<String, Object> inputParams,
			ProcessMem processMem) throws DynamicExecuterException {
		Map<String, Object> outputParams = new HashMap<String, Object>();
		outputParams.put("hybrisBaseSiteId", processMem.getInputParams().get("hybrisBaseSiteId"));
		outputParams.put("locationGroupId", processMem.getInputParams().get("locationGroupId"));
		outputParams.put("retailerId", processMem.getInputParams().get("retailerId"));

		return outputParams;
	}

}
