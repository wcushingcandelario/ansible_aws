define([], function () {

	function isLayaway(scope) {
		scope.discount.disabled = true;
		scope["void"].disabled = false;
		scope.itemModifiers.disabled = true;
		scope.deliveryOption.disabled = false;
		scope.noSale.disabled = true;
		scope.refund.disabled = true;
		scope.layaway.disabled = true;
		scope.suspendTransaction.disabled = true;
		scope.resumeTransaction.disabled = true;
		scope.retrieveQuote.disabled = true;
		scope.createQuote.disabled = true;
		scope.deleteQuote.disabled = true;
	}

	function transactionEmpty(scope) {
		scope.discount.disabled = true;
		scope["void"].disabled = true;
		scope.itemModifiers.disabled = true;
		scope.deliveryOption.disabled = true;
		scope.managerKey.disabled = false;
		scope.tandAManager.disabled = false;
		scope.refund.disabled = false;
		scope.noSale.disabled = false;
		scope.layaway.disabled = false;
		scope.suspendTransaction.disabled = false;
		scope.resumeTransaction.disabled = false;
		scope.checkoutAvailable = false;
		scope.retrieveQuote.disabled = false;
		scope.createQuote.disabled = true;
		scope.deleteQuote.disabled = true;
		scope.loyalty.disabled = false;
 	}

	function transactionNotEmpty(scope) {
		scope.noSale.disabled = true;
		scope.layaway.disabled = true;
		scope.tandAManager.disabled = true;
		scope["void"].disabled = false;
		scope.checkoutAvailable = true;
		scope.suspendTransaction.disabled = false;
		scope.resumeTransaction.disabled = true;
		scope.retrieveQuote.disabled = true;
		scope.createQuote.disabled = false;
		scope.deleteQuote.disabled = false;
		scope.loyalty.disabled = false;
		scope.deliveryOption.disabled = false;
	}
	
	function hideAllMenus(scope) {
		scope.lookup.hidden = true;
		scope.discount.hidden = true;
		scope["void"].hidden = true;
		scope.layaway.hidden = true;
		scope.itemModifiers.hidden = true;
		scope.deliveryOption.hidden = true;
		scope.suspendTransaction.hidden = true;
		scope.tandAManager.hidden = true;
		scope.refund.hidden = true;
		scope.noSale.hidden = true;
		scope.site.hidden = true;
		scope.loyalty.hidden = true;
		scope.taxExemption.hidden = true;
		scope.resumeTransaction.hidden = true;
		scope.retrieveQuote.hidden = true;
		scope.createQuote.hidden = true;
		scope.deleteQuote.hidden = true;
		//scope.checkoutAvailable = false;
		scope.managerKey.hidden = true;
		scope.giftCertificate.hidden = true;
		scope.giftCard.hidden = true;
		scope.lockTill.hidden = true;
		scope.feeItem.hidden = true;
	}
	
	function showHideMenuByPerm(permId, scope){
		switch(permId){
			case "viewLookup":
				scope.lookup.hidden = false;
				break;
			case "viewItemDiscount":
			case "viewTransactionDiscount":
				scope.discount.hidden = false;
				break;
			case "viewTransactionVoid":
				scope["void"].hidden = false;
				break;
			case "viewLayaway":
				scope.layaway.hidden = false;
				break;
			case "viewItemModifiers":
				scope.itemModifiers.hidden = false;
				break;
			case "viewSuspendTransaction":
				if(!scope.suspendTransaction.disabled){
					scope.suspendTransaction.hidden = false;
				}
				break;
			case "viewTandAManager":
				scope.tandAManager.hidden = false;
				break;	
			case "viewReturn":
				scope.refund.hidden = false;
				break;
			case "viewNoSale":
				scope.noSale.hidden = false;
				break;
			case "viewSite":
				scope.site.hidden = false;
				break;
			case "viewLoyalty":
				scope.loyalty.hidden = false;
				break;
			case "viewTaxExempt":
				scope.taxExemption.hidden = false;
				break;	
			case "viewResumeTransaction":
				if(!scope.resumeTransaction.disabled){
					scope.resumeTransaction.hidden = false;
				}
				break;	
			case "viewDeliveryOption": 
				scope.deliveryOption.hidden = false;
				break;	
			case "viewRetrieveQuote":
				scope.retrieveQuote.hidden = false;
				break;
			case "viewCreateQuote":
				scope.createQuote.hidden = false;
				break;
			case "viewManagerKey":
				scope.managerKey.hidden = false;
				break;
			case "viewDeleteQuote":
				scope.deleteQuote.hidden = false;
				break; 
			case "viewGiftCert":
				scope.giftCertificate.hidden = false;
				break;
			case "viewGiftCard":
				scope.giftCard.hidden = false;
				break;
			case "viewLockTill":
				scope.lockTill.hidden = false;
				break;
			case "viewFeeItem":
				scope.feeItem.hidden = false;
				break;
			default:
				//default behavior
		}
	}

	return {

		isLayaway: isLayaway,
		
		hideAllMenus: hideAllMenus,

		isEmptyLayaway: function (scope) {
			isLayaway(scope);
			scope["void"].disabled = true;
		},
		
		isLayawayEdit: function (scope) {
			isLayaway(scope);
			scope.layaway.disabled = false;
			scope.loyalty.hidden = true;
			scope.giftCertificate.hidden = true;
		},
		
		isLayawaySale: function (scope) {
			isLayaway(scope);
			scope.suspendTransaction.disabled = false;
		},

		transactionEmpty: function (scope) {
			transactionEmpty(scope);
			scope.suspendTransaction.disabled = true;
			scope.resumeTransaction.disabled = false;
		},

		transactionEmptyWithLoyalty: function (scope) {
			transactionEmpty(scope);
			scope.suspendTransaction.disabled = false;
			scope.resumeTransaction.disabled = true;
		},
		
		transactionWithLoyaltyAndProducts : function(scope){
			transactionNotEmpty(scope);
			scope.suspendTransaction.disabled = false;
			scope.resumeTransaction.disabled = true;
		},

		transactionNotEmpty: transactionNotEmpty,

		nothingSelected: function (scope) {
			transactionNotEmpty(scope);
			scope.discount.disabled = false;
			scope.itemModifiers.disabled = true; 
		},
		  
		refundWithDiscountSelected : function (scope) { 
			transactionNotEmpty(scope);
			scope.discount.disabled = false;
			scope.itemModifiers.disabled = true; 
		},

		discountOrVoidSelected: function (scope) { 
			transactionNotEmpty(scope);
			scope.discount.disabled = true;
			scope.itemModifiers.disabled = true; 
		},

		otherItemSelected: function (scope) { 
			transactionNotEmpty(scope);
			scope.discount.disabled = false;
			scope.itemModifiers.disabled = false; 
		},
		
		otherItemSelectedWithoutDiscount: function (scope) { 
			transactionNotEmpty(scope);
			scope.discount.disabled = true;
			scope.itemModifiers.disabled = false; 
		},
		
		giftCertSelected: function (scope) {
			transactionNotEmpty(scope);
			scope.discount.disabled = true;
			scope.itemModifiers.disabled = true; 
		},
		
		disableSuspendResume: function(scope){
			scope.suspendTransaction.disabled = true;
			scope.resumeTransaction.disabled = true;
		},
		
		disableCreateQuote: function(scope){ 
			scope.createQuote.disabled = true;  
		},
		
		disableDeleteQuote: function(scope){ 
			scope.deleteQuote.disabled = true;  
		},

		disableRetrieveQuote: function(scope){
			scope.retrieveQuote.disabled = true;
		},

		disableLoyalty: function(scope) {
			scope.loyalty.disabled = true;
		},

		getButtonPropObject: function (resourceKey) {
			return {
				label: ResourceManager.getValue(resourceKey),
				hidden: false,
				disabled: false
			};
		},
		
		disableEndlessIsleMenu: function(scope, disable) {
            scope.site.disabled = disable;
		},
		
		disableDeliveryOption: function(scope, disable) {
            scope.deliveryOption.disabled = disable;
		},

		filterByPermissions: function (scope, role) {
			// use _.forOwn since we need to pass the key to showHideMenuByPerm()
			var permissionsMap = localStorage.getObject('rolePerms')[role];
			_.forOwn(permissionsMap, function (value, permId) {
				showHideMenuByPerm(permId,scope);
			});
		}
		
	};
});
