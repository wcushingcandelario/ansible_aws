define([
	"./OVCPosSubMenu.module",
	"./OVCPosSubMenu.states",
	"dojo/text!./OVCPosSubMenu.widget.html",
	"generic/ResourceManager",
	"dijit/registry",
	'generic/RolePermissionsUtils'
], function (module,
             states,
             templateString,
             ResourceManager,
             registry,
             RolePermissionsUtils) {

	function showHideMenuByPerm(menuObj, eligiblePermissions) {
		if (typeof menuObj.viewPermission != 'undefined') {
			menuObj.hidden = typeof eligiblePermissions[menuObj.viewPermission] == 'undefined';
		}
	}

	function onClickEvent(menuItem) {
		if (typeof menuItem.executePermission != 'undefined') {
			var defered = RolePermissionsUtils.validateExecutePermission(menuItem.id, menuItem.executePermission);
			require('dojo/when')(defered).then(function (res) {
				if (typeof res != 'undefined' && res === true) {
					if (menuItem.onClick) {
						(new Function(menuItem.onClick))();
					} else if (menuItem.invokeProcess) {
						menuItem.inputParams && eval("var menuParams = " + menuItem.inputParams);
						var params = menuParams;
						return require('ovc/ProcessEngine').invokeProcess(menuItem.invokeProcess, params);
					}
				}
			});

		} else {
			if (menuItem.onClick) {
				(new Function(menuItem.onClick))();
			} else if (menuItem.invokeProcess) {
				menuItem.inputParams && eval("var menuParams = " + menuItem.inputParams);
				var params = menuParams;
				return require('ovc/ProcessEngine').invokeProcess(menuItem.invokeProcess, params);
			}
		}
	}

	function reset(scope, backTransition) {
		states.statuses = [];
		scope.showComplete = false;
		scope.fromOnBack = false;
		registry.byId("subMenuView").performTransition("mainMenuView", -1, backTransition);
	}

	function onBackFunction(scope, backTransition, fromBack, onBackCallback, params) {
		controller = angular.element("ovc-sub-menu").controller("ovcSubMenu");
		if (states.statuses.length == 1) {
			reset(scope, backTransition);
		}
		else if (states.statuses.length > 0) {
			scope.showComplete = false;
			states.statuses.pop();
			menuJson = states.statuses[states.statuses.length - 1];
			scope.fromOnBack = fromBack;
			var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
			if(localStorage.getObject("origTendersForReturn") != undefined &&
					localStorage.getObject("origTendersForReturn") != null){
				menuJson.menu[0].hidden = "true"
			}
			else{
				if(tranObj.getTotalRefundItems() > 0 && menuJson.menuId == 'posReturnMenuView'){
					// already refund items present, must be without receipt- so hide with receipt.
					menuJson.menu[1].hidden = "true";
					menuJson.menu[2].hidden = "true";
				}
			}
			
			if (menuJson != null)
				controller.show(menuJson);
		}
		onBackCallback && onBackCallback(params);
	}

	function controller($scope, $timeout, $sce) {
		$scope.mainHeadingLabel = ResourceManager.getValue("pos.mainHeading");
		$scope.menus = [];
		$scope.completeLabel = ResourceManager.getValue("pos.close");
		$scope.showComplete = false;
		$scope.backLabel = "< " + ResourceManager.getValue("pos.back");
		$scope.closeLabel = "< " + ResourceManager.getValue("pos.mainHeading");
		$scope.onBack = null;
		$scope.onClose = null;
		$scope.showBack = true;
		$scope.showAction = false;
		$scope.actionMethod = null;
		$scope.covered = false;
		$scope.visible = false;

		this.cover = function () {
			$timeout(function () {
				$scope.covered = true;
			});
		};

		this.clearNavBar = function () {
			$timeout(function () {
				$scope.backLabel = "";
				$scope.closeLabel = "";
			});
		};

		this.enableDisableComplete = function (enable) {
			$timeout(function () {
				$scope.showComplete = enable;
			});
		};

		this.setTextBox = function (val, fireEvent) {
			$timeout(function () {
				$scope.code = val;
				if(fireEvent){
					$scope.scanBoxOnClick();
				}
			});
		};
		
		this.clearTextBox = function () {
			$timeout(function () {
				$scope.code = "";
			});
		};

		this.goBack = function () {
			$timeout(function () {
				onBackFunction($scope, "slide", true);
			});
		};

		this.close = function () {
			$timeout(function () {
				reset($scope, "slide");
			});
		};

		this.show = function (menuJson, fromMainMenu) {
			$timeout(function () {
				$scope.mainHeadingLabel = ResourceManager.getValue(menuJson.title);
				$scope.closeBtnOverRide = menuJson.overRideCloseBtn || '';
				$scope.overRideCloseBtnFunction = menuJson.overRideCloseBtnFunction;

				if (fromMainMenu && fromMainMenu == true) {
					$scope.showComplete = false;
				}
				if (menuJson.completeProcess) {
					$scope.completeLabel = menuJson.completeProcess.label;
					$scope.showComplete = menuJson.enableCompleteButton;
					if (menuJson.completeProcess.label.indexOf('RSRC') != -1) {
						var matches = menuJson.completeProcess.label.match(/^RSRC\(([^\)]+)\)$/);
						var resource = matches && matches[1];

						if (resource) {
							$scope.completeLabel = ResourceManager.getValue(resource);
						}
					}
					menuJson.onCompleteFunction = function () {
						require('ovc/ProcessEngine').invokeProcess(menuJson.completeProcess.invokeProcess, menuJson.completeProcess.inputParams || {});
					};
				} else if (menuJson.completeLabel) {
					$scope.completeLabel = menuJson.completeLabel;
					$scope.showComplete = true;
				} else {
					$scope.completeLabel = "Close";
				}
				var listTitle = menuJson.listTitle;
				if (listTitle && listTitle != null) {
					$scope.showReasonTitle = true;
					$scope.reasonTitle = listTitle;
				} else {
					$scope.showReasonTitle = false;
					$scope.reasonTitle = "";
				}

				$scope.identity = menuJson.menuId;
				$scope.onBack = function () {
					require("posmclient/OVCPosMainMenu.actions").setCheckoutClicked(false);
					var params = {};
					if (menuJson.onBackFunction && menuJson.onBackFunction != null &&
						menuJson.onBackFunction.inputParams && menuJson.onBackFunction.inputParams != null) {
						params = menuJson.onBackFunction.inputParams;
					}
					onBackFunction($scope, menuJson.backTransition, true, menuJson.onBackFunction, params);
				};

				if (menuJson.backLabel != undefined && menuJson.backLabel != null) {
					$scope.backLabel = menuJson.backLabel;
					if (menuJson.backLabel == "") {
						$scope.onBack = function () {
						};
					}
					$scope.onBack = menuJson.backLabelAction;
				} else {
					$scope.backLabel = "< " + ResourceManager.getValue("pos.back");
				}

				$scope.onClose = function () {
					require("posmclient/OVCPosMainMenu.actions").setCheckoutClicked(false);
					reset($scope, menuJson.backTransition);
					menuJson.onCloseFunction && menuJson.onCloseFunction();
				};
				
				$scope.onComplete = function () {
					if ($scope.closeBtnOverRide === 'back') {
						$scope.onBack();
						if($scope.overRideCloseBtnFunction){
							$scope.overRideCloseBtnFunction();
						}
					} else {
						$scope.onClose();
						$scope.showComplete = false;
						menuJson.onCompleteFunction && menuJson.onCompleteFunction();
					}
				};
				if (menuJson.closeLabel != undefined && menuJson.closeLabel != null) {
					$scope.closeLabel = menuJson.closeLabel;
					if (menuJson.closeLabel == "") {
						$scope.onClose = function () {
						};
					}
				} else {
					$scope.closeLabel = "< " + ResourceManager.getValue("pos.mainHeading");
				}
				if (fromMainMenu && fromMainMenu == true) {
					states.statuses.push(menuJson);
				}
				for (i in menuJson.menu) {
					if (menuJson.menu.hasOwnProperty(i)) {
						// Add a list item resource
						if (menuJson.menu[i].label.indexOf('RSRC') != -1) {
							var labelMatches = menuJson.menu[i].label.match(/^RSRC\(([^\)]+)\)$/);
							var labelResource = labelMatches && labelMatches[1];



							if (!labelResource) {
								var err = "Menu label is not a resource definition";
								alert(err);
								return;
							}
							menuJson.menu[i].label = ResourceManager.getValue(labelResource);
							if (menuJson.menu[i].validate) {
								menuJson.menu[i].label = (new Function(menuJson.menu[i].validate))();
							}
							var menuId = menuJson.menu[i].id;

							// Hide card payment tenders if offline
							if (states.isPaymentDeviceReady() === false && (menuId == "23" || menuId == "manualCardEntry")) {
								menuJson.menu[i].hidden = true;
								menuJson.menu[i].disabled = true;
							} else {
								menuJson.menu[i].hidden = false;
								menuJson.menu[i].disabled = false;
							}

							//hide the menus based on logged in user (global variable uObj) permissions
							var eligiblePermissions = uObj.permissions;
							showHideMenuByPerm(menuJson.menu[i], eligiblePermissions);

							for (var removeNode = 0, removeLen = menuJson.removeIdsArr.length; removeNode < removeLen; removeNode++) {
								if (menuId == menuJson.removeIdsArr[removeNode]) {
									menuJson.menu[i].hidden = true;
								}
							}

							for (var disableNode = 0, disableLen = menuJson.disableIdsArr.length; disableNode < disableLen; disableNode++) {
								if (menuId == menuJson.disableIdsArr[disableNode]) {
									menuJson.menu[i].disabled = true;
								}
							}
						}
					}
				}
				if (menuJson.textBox != undefined && menuJson.textBox != null) {
					$scope.showScanBox = true;
					//$scope.scanBoxId = menuJson.textBox.id;
					$scope.scanBoxValue = menuJson.textBox.value;
					$scope.scanBoxPlaceHolder = menuJson.textBox.placeHolder;
					$scope.scanBoxOnClick = menuJson.textBox.onClick;
				} else {
					$scope.showScanBox = false;
				}
				if (menuJson.receiptData != undefined && menuJson.receiptData != null) {
					$scope.receiptNodeHtml = $sce.trustAsHtml(menuJson.receiptData);
				}
				else {
					$scope.receiptNodeHtml = "";
				}
				$scope.actionMethod = onClickEvent;
				$scope.menus = menuJson.menu;
				$scope.visible = true;
			});
		};

		this.uncover = function () {
			$timeout(function () {
				$scope.covered = false;
			});
		};
	}

	angular.module(module)
		.directive('ovcSubMenu', function () {
			return {
				restrict: 'E',
				template: templateString,
				controller: ["$scope", "$timeout", "$sce", controller],
				scope: {
					statusNew: '='
				},
				link: function (scope, elt, attrs, navigationBarCtrl) {
				}
			};
		});
});
