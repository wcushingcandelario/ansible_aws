define([
	"./OVCSplashScreen.module",
	"./OVCSplashScreen.states",
	"dojo/text!./OVCSplashScreen.widget.html",
	"generic/ResourceManager",
	"ovc/ConfigManager",
	"ovc/ProcessEngine",
	"dijit/registry",
	"dojo/_base/lang",
	"dojo/dom",
	"dojo/dom-style",
	"dojo/when",
	"ovc/IndexView"
], function (module,
             states,
             templateString,
             ResourceManager,
             ConfigManager,
             ProcessEngine,
             registry,
             lang,
             dom,
             domStyle,
             when,
             IndexView) {

	function onClickEvent(menuItem) {
		if (menuItem.onClick) {
			(new Function(menuItem.onClick))();
		} else if (menuItem.invokeProcess) {
			menuItem.inputParams && eval("var menuParams = " + menuItem.inputParams);
			var params = menuParams;
			var returnVal = require('ovc/ProcessEngine').invokeProcess(menuItem.invokeProcess, params);
			return returnVal;
		}
	};

	function dojoTransitions(newView) { 
		var clickableImage = require("dojo/dom").byId("ovcPOSAndSplash");
		console.log(clickableImage.activeView);
		if(clickableImage.activeView === undefined){
			clickableImage.activeView = "ovcPOSContentAndHeader"; 
		}
		registry.byId(clickableImage.activeView).performTransition(newView, -1, "slidev", function () {
		    if( lang.exists("ovcHeaderToolsView") ){ 
		    	//CSP-1358
		    	var ovcHeaderToolsViewNode = dom.byId("ovcHeaderToolsView");
		    	if(ovcHeaderToolsViewNode != null &&
		    			ovcHeaderToolsViewNode.sytle != null && 
		    			ovcHeaderToolsViewNode.sytle.display != "none"){
		    		domStyle.set(dom.byId('posContent'), "top", "110px");
		    	}
		    }
		});
		clickableImage.activeView = newView;
	}

	function reset() {
		states.statuses = [];
		dojoTransitions("ovcSplashScreenView");

	};

	function onBackFunction(scope, onBackCallback, params) {
		dojoTransitions("ovcSplashScreenView")
		onBackCallback && onBackCallback(params);
	};

	function controller($scope, $timeout) {
		$scope.user = {};

		$scope.showError = false;
		$scope.lockedUserName = null;
		
		$scope.unlockBtn = getButtonPropObject("pos.splashScreen.unlock").label;
		$scope.logoffBtn = getButtonPropObject("pos.splashScreen.logoff").label;
		$scope.usernameLabel = getButtonPropObject("pos.splashScreen.username").label;
		$scope.passwordLabel = getButtonPropObject("pos.splashScreen.password").label;
		$scope.errorMessage = getButtonPropObject("pos.splashScreen.invalidUser").label;
		$scope.errorCounter = 1;

		//removing overlapping banner logo for TP
		//$scope.bannerLogo = base + '/../../dynamicblob/posMClient/banner_logo.png';
		$scope.banner = base + '/../../dynamicblob/posMClient/banner.jpg';

		this.goBack = function () {
			$timeout(function () {
				onBackFunction($scope);
			});
		};

		this.close = function () {
			$timeout(function () {
				reset();
			});
		};

		this.show = function (mode, lockedUserName, errorMsg) {
			$timeout(function () {
				if(uObj!=null){
					uObj.isLocked = true;
				}
				
				$scope.mode = mode;
				$scope.zIndex = 100000;
				$scope.user.username = username;
				$scope.user.password = '';
				$scope.errorCounter = 1;
				$scope.showError = false;
				
				if(mode == "login"){
					$scope.showError = true;
					if(lockedUserName!=null){
						$scope.lockedUserName = lockedUserName;
					}
					if(errorMsg!=null){
						$scope.errorMessage = errorMsg;
					}else{
						$scope.errorMessage = ResourceManager.getValue("pos.splashScreen.userLocked");
					}
					$("#passwordsplash").focus();
				}

			});
		};

		$scope.splashAction = function (action) {
			//$scope.showError	=	false;
			if (action == "logoff") {
				$scope.zIndex = 1;
				//domStyle.set(dom.byId('ovcSplashScreenView'),"z-index","1");
				var tillLogOffPrompt = require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").tillLogOffPrompt;
				if(tillLogOffPrompt == 1){
					ProcessEngine.invokeProcess("posMClient/SignOff.ovcprc", {});
				}else{	
					ProcessEngine.invokeProcess("posMClient/SignOff.ovcprc", { prompt: false });
				}
			} else {
				$scope.zIndex = 100000;
				//domStyle.set(dom.byId('ovcSplashScreenView'),"z-index","100000");

				var username = $scope.user.username,
					password = $scope.user.password;
				if (( !username || username.length == 0) || ( !password || password.length == 0)) {
					$scope.showError = true;
					$scope.errorMessage = getButtonPropObject("pos.splashScreen.required").label;
				}
				else if (action == "unlock") {
					if($scope.mode=="pos"){
						when(ProcessEngine.invokeProcess("posMClient/Till/UnlockTill.ovcprc", {
							"errorCounter": $scope.errorCounter,
							"txtUserName": username,
							"txtPassword": password
						})).then(
							function (result) {
								if (result && result.condition == true) {
									document.getElementById("passwordsplash").blur();
	
									uObj.isLocked = false;
									dojoTransitions("ovcPOSContentAndHeader");
								} else {
									//document.getElementById("password").focus();
									$scope.errorCounter = $scope.errorCounter + 1;
									$scope.errorMessage = result.errorMessage;
									$scope.showError = true;
								}
							});
					}else{
						IndexView.login(null,require("posmclient/OVCSplashScreen.widget").showOfflineSplash, $scope.lockedUserName);
					}
				}
			}
		};
	}

	function getButtonPropObject(resourceKey) {
		return {
			label: ResourceManager.getValue(resourceKey),
			hidden: false,
			disabled: false
		};
	}

	angular.module(module)
		.directive('ovcSplashScreen', function () {
			return {
				restrict: 'E',
				template: templateString,
				controller: ["$scope", "$timeout", controller],
				scope: {
					statusNew: '='
				},
				link: function (scope, elt, attrs) {
				}

			};
		});

});
