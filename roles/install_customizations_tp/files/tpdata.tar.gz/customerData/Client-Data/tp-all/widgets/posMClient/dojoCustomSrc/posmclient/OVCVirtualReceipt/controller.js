define(["dojo/_base/declare",
		"dojo/_base/lang",
		"dojo/dom",
		"dojo/when",
		"dijit/registry",
		"generic/ResourceManager",
		"ovc/ConfigManager",
		"generic/StringUtils",
		"posmclient/OVCVirtualReceipt.event",
		"posmclient/RetailTransactionHelper",
		"ovc/Util",
		"ovc/ProcessEngine",
		"generic/OVCAlertDialog.widget",
		"generic/Constants",
		"generic/RolePermissionsUtils"],
	function (declare,
	          lang,
	          dom,
	          when,
	          registry,
	          ResourceManager,
	          ConfigManager,
	          StringUtils,
	          Event,
	          RetailTransactionHelper,
	          util,
	          ProcessEngine,
	          OVCAlertDialog,
	          Constants,
	          RolePermissionsUtils) {

		function addRecordIdentifier(record, id) {
			return lang.mixin({recordId: id}, record);
		}

		function move (arr, from, to) {
			arr.splice(to, 0, arr.splice(from, 1)[0]);
		}

		function showInvalidPriceAlert(errorMessage) {
			var alertDlg = new OVCAlertDialog({
				title: '',
				message: errorMessage,
				okBtnLabel: ResourceManager.getValue("searchCenter.okButtonLabel"),
				maxHeight: 100,
				zIndex: 100
			});
			alertDlg.placeAt(document.body);
			alertDlg.startup();
			alertDlg.show();

			alertDlg.on("ok", function (e) {
				console.log(e);
				alertDlg.hide();
				alertDlg.destroyRecursive(false);
			});
		}
		
		function priceOverride(e){
			var newPrice = e.target.value;
			newPrice = newPrice.replace('-', "");
			
			if(e.path && e.path!=null && e.path.length > 5 && e.path[4] != null){
				var grid = this.getGrid();
				 
				_.forEach(grid.selection, function(value, key) {
					grid.deselect(grid.row(key))
				});
				grid.select(e.path[4]); 
			}
			var priceOverrideValue = 0;
			var validPrice = false;
			var currencySymbol = ResourceManager.getValue('currency.symbol');
			var itemIdx = this.getSelectedTranItemIdx();
			var selectedItem = RetailTransactionHelper.getCurrentTranObj();
			var tranItem = selectedItem.getTranItemByIdx(itemIdx);
			var errorMessage = '';
			if (newPrice != null && newPrice.length > 0 && newPrice.indexOf(currencySymbol) === 0 && !isNaN(newPrice.substring(1))) {//If it has currency symbol in the value
				validPrice = true;
				priceOverrideValue = parseFloat(newPrice.substring(1));
			} else if (!isNaN(newPrice) && parseFloat(newPrice) >= 0) {
				validPrice = true;
				priceOverrideValue = parseFloat(newPrice);
			}

			var allowPriceOverrideGreater = ConfigManager.getConfigObject("posMClient/sales.ovccfg").allowPriceOverrideGreater;
			if (!allowPriceOverrideGreater && tranItem.getCalcAmount() < priceOverrideValue) { //If user enters a price greater than or equal to the current price
				validPrice = false;
				errorMessage = ResourceManager.getValue("menus.itemModifiers.invalidPrice");
			} else if (tranItem.getCalcAmount() === priceOverrideValue) {
				validPrice = false;
				errorMessage = ResourceManager.getValue("menus.itemModifiers.invalidAmountErrMsg");
			}

			if (validPrice) {
				var Json = tranItem.getProduct().getProductJson();
				var minPrice = parseInt(Json.products.minPrice);
				var maxPrice = parseInt(Json.products.maxPrice);
				if (priceOverrideValue < minPrice) {
					errorMessage = ResourceManager.getValue("errorMessages.priceBelowMinPrice");
					validPrice = false;
				}
				else if (priceOverrideValue > maxPrice) {
					errorMessage = ResourceManager.getValue("errorMessages.priceExceedsMaxPrice");
					validPrice = false;
				}
			}

			if (validPrice) {
				var dialogTitle = ResourceManager.getValue("menus.itemModifiers.priceOverride");
				var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmPriceOverride;
				var dialogMsg = ResourceManager.getValue("menus.itemModifiers.priceOverrideReasonDialogMsg");
				if (showConfirmation != undefined && showConfirmation != null) {
					if (showConfirmation === 1) {
						dialogMsg = ResourceManager.getValue("menus.itemModifiers.priceOverrideReasonDialogMsg");
					}
					else {
						dialogMsg = ResourceManager.getValue("menus.itemModifiers.priceOverrideReasonDialogMsgGeneric");
					}
				}
				var confirmationMsg = ResourceManager.getValue("menus.itemModifiers.priceOverrideConfirmMsg");
				when(ProcessEngine.invokeProcess("posMClient/OpenReasonCodeAngularJS.ovcprc", {
					reasonCodeType: 'priceChange',
					newPrice: priceOverrideValue,
					dialogTitle: dialogTitle,
					dialogMsg: dialogMsg,
					showConfirmation: showConfirmation,
					confirmationMsg: confirmationMsg,
					origProductPrice: tranItem.getCalcAmount(),
					productTaxRate: tranItem.getProduct().getTaxRates(),
					itemIdx: itemIdx
				})).then(function (response) {
					if (response && response.error && response.error.length > 0) {
						//Reset the unit price back to the previous value
						var decimalPrecision = ResourceManager.getValue("currency.precision");
						if(e.path && e.path!=null && e.path.length > 5 && e.path[4] != null){
							var grid = this.getGrid();
							 
							_.forEach(grid.selection, function(value, key) {
								grid.deselect(grid.row(key))
							});
							grid.select(e.path[4]); 
						}
						e.target.value = StringUtils.numberToCurrencyString(tranItem.getCalcAmount(), decimalPrecision, true);
					}
				});
			} else {
				//Reset the unit price back to the previous value
				if (typeof errorMessage === 'undefined' || errorMessage === '') {
					errorMessage = ResourceManager.getValue("menus.itemModifiers.invalidPrice");
				}
				showInvalidPriceAlert(errorMessage);
				var decimalPrecision = ResourceManager.getValue("currency.precision");
				e.target.value = StringUtils.numberToCurrencyString(tranItem.getCalcAmount(), decimalPrecision, true);
			}
		}
		

		function processReceiptObj(outputParams) {
			var data = [];
			var nextId = 0;

			function identifyRecord(record) {
				data.push(addRecordIdentifier(record, "" + nextId++));
			}

			var receiptObj = outputParams.receiptObj;

			var item, i, j, nviLen, len;

			nviLen = receiptObj.allItems ? receiptObj.allItems.length : 0;

			var hideVoidItem = false;
			var itemVoidAppearance = ConfigManager.getConfigObject("posMClient/sales.ovccfg").itemVoidAppearance;
			var showPriceOverride = ConfigManager.getConfigObject("posMClient/sales.ovccfg").showPriceOverride;
			var showZeroStoreCredit = ConfigManager.getConfigObject("posMClient/app.ovccfg").showZeroStoreCredit;

			if (itemVoidAppearance != null && itemVoidAppearance.trim().toUpperCase() === 'DISAPPEAR') {
				hideVoidItem = true;
			}
			

			_.forEach(data, function (itemI, i) {debugger;
				if (itemI.itemType == Constants.ITEM_TY_DELIVERY_OPTION) {
					_.forEach(data, function (itemJ, j) {
						if (itemJ.itemType == Constants.ITEM_TY_ADD_PRODUCT &&
							itemI.refItemIdx == itemJ.tranItemIdx) {
							var from = parseInt(i);
							var to = parseInt(j) + 1;
							if (from != to) {
								move(data, from, to);
							}
							return false;
						}
					});
				}else if(itemI.itemType == Constants.ITEM_TY_STORE_COLLECT_OPTION) {
					_.forEach(data, function (itemJ, j) {
						if (itemJ.itemType == Constants.ITEM_TY_ADD_PRODUCT &&
							itemI.refItemIdx == itemJ.tranItemIdx) {
							var from = parseInt(i);
							var to = parseInt(j) + 1;
							if (from != to) {
								move(data, from, to);
							}
							return false;
						}
					});
				}
			});

			for (i = 0; i < nviLen; i++) {
				item = receiptObj.allItems[i];
				if (item.isVoid && hideVoidItem) {
					continue;
				}
				identifyRecord(item);
				if (item.promos) {
					for (var promoId in item.promos) {
						if (item.promos.hasOwnProperty(promoId)) {
							identifyRecord(item.promos[promoId]);
						}
					}
				}

				len = item.discounts ? item.discounts.length : 0;
				for (j = 0; j < len; j++) {
					if (item.discounts[j] != null && item.discounts[j].isVoid && hideVoidItem) {
						continue;
					}
					identifyRecord(item.discounts[j]);
				}

				len = item.txnDiscounts ? item.txnDiscounts.length : 0;
				for (j = 0; j < len; j++) {
					identifyRecord(item.txnDiscounts[j]);
				}

				len = item.priceOverrides ? item.priceOverrides.length : 0;
				if (showPriceOverride === 1) {
					for (j = 0; j < len; j++) {
						identifyRecord(item.priceOverrides[j]);
					}
				}
				
				len = item.BBASEntries ? item.BBASEntries.length : 0;
				for (j = 0; j < len; j++) {
					identifyRecord(item.BBASEntries[j]);
				}
			}

			// only process summary data if there are items
			if (receiptObj.summary.totalItems > 0) {
				// prefixStr will only display once before the first item's first alert
				var prefixStr = '<u>' + ResourceManager.getValue("pos.unusedPromoSavings") + ':</u><br/>';
				var layawayPrefixStr = '<u>' + ResourceManager.getValue("pos.layawayAlert") + ':</u><br/>';
				var layawayExpiredPromotions = '<u>' + ResourceManager.getValue("pos.layawayExpiredPromotions") + ':</u><br/>';

				// mark each alert item using this indicator
				var indicatorStr = ResourceManager.getValue("pos.unusedPromoSavingsItemIndicator");
				var layawayIndicatorStr = ResourceManager.getValue("pos.layawayItemIndicator");

				// List the unused promotion savings
				len = receiptObj.alertsByPromo ? receiptObj.alertsByPromo.length : 0;
				for (j = 0; j < len; j++) {
					identifyRecord({
						alert: prefixStr + indicatorStr + receiptObj.alertsByPromo[j]
					});
					prefixStr = "";
				}
				
				//List the bundle alerts
				len = receiptObj.alertsByBundle ? receiptObj.alertsByBundle.length : 0;
				for (j = 0; j < len; j++) {
					identifyRecord({
						alert: receiptObj.alertsByBundle[j]
					});
				}
				
				// List the layaway requirements
				len = receiptObj.alertsByLayaway ? receiptObj.alertsByLayaway.length : 0;
				for (j = 0; j < len; j++) {
					if (j > 0) {
						layawayPrefixStr = "";
					}
					identifyRecord({
						alert: layawayPrefixStr + layawayIndicatorStr + receiptObj.alertsByLayaway[j]
					});
					prefixStr = "";
				}

				// List the Layaway Promotion History
				len = receiptObj.alertsByLayawayPromotions ? receiptObj.alertsByLayawayPromotions.length : 0;
				for (j = 0; j < len; j++) {
					if (j > 0) {
						layawayExpiredPromotions = "";
					}
					identifyRecord({
						alert: layawayExpiredPromotions + layawayIndicatorStr + receiptObj.alertsByLayawayPromotions[j]
					});
					prefixStr = "";
				}

				identifyRecord({
					merchTotal: receiptObj.summary.merchTotal,
					itemCount: receiptObj.summary.totalItems
				});

				if (receiptObj.summary.promoSavings) {
					identifyRecord({
						promoSavings: receiptObj.summary.promoSavings
					});
				}

				len = receiptObj.summary.taxes ? receiptObj.summary.taxes.length : 0;
				for (i = 0; i < len; i++) {
					identifyRecord(receiptObj.summary.taxes[i]);
				}

				var totalBBASSavings;
				var isShowTotalBBASSavingsOnVR = ConfigManager.getConfigObject("posMClient/pos.ovccfg").showTotalBBASSavingsOnVR;
				
				if(RetailTransactionHelper.getCurrentTranObj().calcBBASSavings() != null &&
						RetailTransactionHelper.getCurrentTranObj().calcBBASSavings() != undefined &&
						RetailTransactionHelper.getCurrentTranObj().calcBBASSavings() > 0 && isShowTotalBBASSavingsOnVR == 1){
						
					totalBBASSavings = ResourceManager.getValue("pos.bbas.bbasSavingsOnTran") + ResourceManager.getValue("currency.symbol") + 
										parseFloat(RetailTransactionHelper.getCurrentTranObj().calcBBASSavings()).toFixed(2);
					
				}
				
				identifyRecord({
					total: receiptObj.summary.total,
					totalBBASSavings: totalBBASSavings || ""
				});

				len = receiptObj.tenders ? receiptObj.tenders.length : 0;
				for (i = 0; i < len; i++) {
					identifyRecord(receiptObj.tenders[i]);
				}
				if (parseFloat(receiptObj.summary.storeCreditBalance) === 0) {
					if (showZeroStoreCredit != null && showZeroStoreCredit === 1) {
						identifyRecord({
							storeCreditBalance: receiptObj.summary.storeCreditBalance
						});
					}
				} else if (parseFloat(receiptObj.summary.storeCreditBalance) > 0) {
					identifyRecord({
						storeCreditBalance: receiptObj.summary.storeCreditBalance
					});
				}
				else if (receiptObj.summary.giftCardAdjustment != undefined){
					identifyRecord({
						giftCardAdjustment: receiptObj.summary.giftCardAdjustment
					})
				}
			}
			if(localStorage.getObject("origTendersForReturn") != undefined &&
					localStorage.getObject("origTendersForReturn") != null &&
					localStorage.getObject("origTendersForReturn").length > 1){
				identifyRecord({
					purchaseTenders: localStorage.getObject("origTendersForReturn")
				});
			}
			//console.log("OVCVirtualReceipt.controller.processReceiptObj() returning:", data);
			return data;
		}

		function createStore() {
			//console.log("OVCVirtualReceipt.controller.createStore() called");

			return when(ProcessEngine.invokeProcess("posMClient/model/receipt/BuildReceiptObjFromTransaction.ovcprc", {})).then(processReceiptObj);
		}

		return declare(null, {
			constructor: function (widget) {
				//console.log("OVCVirtualReceipt.controller: constructor called:", widget);

				// listen for events from this widget
				this.widget = widget;
				
				this.widget.on(Event.QTY_VALUE_CHANGE, lang.hitch(this, function (e) {
					var newQty = e.target.value; 
					if(e.path && e.path!=null && e.path.length > 5 && e.path[4] != null){
						var grid = this.getGrid();
						 
						_.forEach(grid.selection, function(value, key) {
							grid.deselect(grid.row(key))
						});
						grid.select(e.path[4]); 
					}
					//console.log("OVCVirtualReceipt.controller: got a " + Event.QTY_VALUE_CHANGE + " event", newQty);
					if (newQty.length > 0) {
						var itemIdx = this.getSelectedTranItemIdx();
						var selectedItem = RetailTransactionHelper.getCurrentTranObj();
						var tranItem = selectedItem.getTranItemByIdx(itemIdx);
						newQty = parseInt(newQty);
						if (tranItem && tranItem.getQty() !== newQty) {
							//Introduce new config to make the quantity to zero
							var allowZeroQtyOnVR = ConfigManager.getConfigObject("posMClient/pos.ovccfg").allowZeroQtyOnVR;
							var allowZeroQtyOnVRProduct = tranItem.getAllowZeroQtyOnVR();
							if (newQty > 0 || (newQty == 0 && allowZeroQtyOnVR === 1 && allowZeroQtyOnVRProduct === '1')) {
								var Json = tranItem.getProduct().getProductJson();
								if (Json && Json != null) {
									var min = parseInt(Json.products.minimum);
									var max = parseInt(Json.products.maximum);
									var qty = parseInt(newQty);
									if(newQty === 0){
										if(tranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT){
											when(require("posmclient/BBASUtil").getBulkPriceForSku(tranItem.getSku(), newQty, itemIdx)).then(
													function (response) {selectedItem.changeItemQty(itemIdx, newQty)}
											);
										}
										else{
											selectedItem.changeItemQty(itemIdx, newQty)
										}
									} else if ((min && min != null) && (min <= qty && qty <= max)) {
										// update obj and re-render receipt if qty changed
										if(tranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT){
											when(require("posmclient/BBASUtil").getBulkPriceForSku(tranItem.getSku(), newQty, itemIdx)).then(
													function (response) {selectedItem.changeItemQty(itemIdx, newQty)}
											);
										}
										else{
											selectedItem.changeItemQty(itemIdx, newQty)
										}
									} else if ((min && min != null) && (min >= qty)) {
										showInvalidQtyError(ResourceManager.getValue("pos.invalidQtyMinMsg"),tranItem.getQty());
									} else if ((min && min != null) && (qty >= max)) {
										showInvalidQtyError(ResourceManager.getValue("pos.invalidQtyMaxMsg"),tranItem.getQty());
									} else {
										if(tranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT){
											when(require("posmclient/BBASUtil").getBulkPriceForSku(tranItem.getSku(), newQty, itemIdx)).then(
													function (response) {selectedItem.changeItemQty(itemIdx, newQty)}
											);
										}
										else{
											selectedItem.changeItemQty(itemIdx, newQty)
										}
									}
								} else {
									if(tranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT){
										when(require("posmclient/BBASUtil").getBulkPriceForSku(tranItem.getSku(), newQty, itemIdx)).then(
												function (response) {selectedItem.changeItemQty(itemIdx, newQty)}
										);
									}
									else{
										selectedItem.changeItemQty(itemIdx, newQty)
									}
								}
								this.renderReceipt();
							} else {
								showInvalidQtyError(ResourceManager.getValue("pos.invalidQtyValueMsg"),tranItem.getQty());
							}
						}

						function showInvalidQtyError(message, oldQty) {
							// don't allow qty less than 1
							var alertDlg = new OVCAlertDialog({
								title: ResourceManager.getValue("pos.invalidQtyValueTitle"),
								message: message,
								okBtnLabel: ResourceManager.getValue("searchCenter.okButtonLabel"),
								maxHeight: 100,
								zIndex: 100
							});
							alertDlg.placeAt(document.body);
							alertDlg.startup();
							alertDlg.show();

							alertDlg.on("ok", function (e) {
								//console.log(e);
								alertDlg.hide();
								alertDlg.destroyRecursive(false);
							});
							
							//CMP-3633
							e.target.value = oldQty;
						}
					}
				}));

				this.widget.on(Event.QTY_PRICE_OVERRIDE, lang.hitch(this, priceOverride));

				//noinspection JSDeprecatedSymbols
				this.widget.on(Event.SELECT, lang.hitch(this, function (/*e*/) {
					//noinspection JSDeprecatedSymbols
					//console.log("OVCVirtualReceipt.controller: got a " + Event.SELECT + " event", e);

					if (this.getGrid()) {
						require("posmclient/OVCPosMainMenu.widget").enableDisablePOSButtons();
					}
				}));

				this.widget.on(Event.DESELECT, lang.hitch(this, function (/*e*/) {
					//console.log("OVCVirtualReceipt.controller: got a " + Event.DESELECT + " event", e);

					if (this.getGrid()) {
						require("posmclient/OVCPosMainMenu.widget").enableDisablePOSButtons();
					}
				}));

				this.widget.on(Event.REFRESH, function (e) {
					//console.log("OVCVirtualReceipt.controller: got a " + Event.REFRESH + " event", e);
				});

				//noinspection JSDeprecatedSymbols
				this.widget.on(Event.ERROR, function (e) {
					//noinspection JSDeprecatedSymbols
					//console.log("OVCVirtualReceipt.controller: got a " + Event.ERROR + " event", e);
				});

				registry.byId("posView").on("AfterTransitionIn", lang.hitch(this.widget, function (e) {
					// resize the widget
					console.log("OVCVirtualReceipt.controller: got a AfterTransitionIn event", e);
					this.resize();
				}));

			},

			getSelectedTranItemIdx: function () {
				//console.log("OVCVirtualReceipt.controller.getSelectedTranItemIdx() called");
				try {
					var selectedTranItemIdx = null;
					var grid = this.getGrid();
					if (grid) {
						var selection = grid.selection;
						var store = this.getStore();
						var data = store.query({});
						if(data !== undefined && data !== null && data.length > 0){
							// use _.forOwn since rowIdx is the key, the value is a boolean
							_.forOwn(selection, function (value, rowIdx) {
								if (rowIdx != -1 && data[rowIdx] !== undefined) {
									selectedTranItemIdx = data[rowIdx].tranItemIdx;
									return false;
								}
							});
						}
						
					}
					//console.log("OVCVirtualReceipt.controller.getSelectedTranItemIdx() returning:", selectedTranItemIdx);
					return selectedTranItemIdx;
				} catch (e) {
					throw util.rethrow(e, 'OVCVirtualReceipt.getSelectedTranItemIdx');
				}
			},

			getSelectedProductId: function () {
				//console.log("OVCVirtualReceipt.controller.getSelectedProductId() called");
				try {
					var productId;
					var itemIdx = this.getSelectedTranItemIdx();
					if (itemIdx != null) {
						var tranItm = RetailTransactionHelper.getCurrentTranObj().getTranItemByIdx(itemIdx);
						if (tranItm) {
							//productId = tranItm.getProductId();
							productId = tranItm.getProduct().getSku();
						}
					}
					//console.log("OVCVirtualReceipt.controller.getSelectedProductId() returning:", productId);
					return productId;
				} catch (e) {
					throw util.rethrow(e, 'OVCVirtualReceipt.controller.getSelectedProductId');
				}
			},

			getSelectedProductCodeOrId: function () {
				//console.log("OVCVirtualReceipt.controller.getSelectedProductCodeOrId() called");
				try {
					var productCodeOrId;
					var itemIdx = this.getSelectedTranItemIdx();
					if (itemIdx) {
						var tranItem = RetailTransactionHelper.getCurrentTranObj().getTranItemByIdx(itemIdx);
						productCodeOrId = tranItem.getProduct().getProductCode();
						if (productCodeOrId === null || util.trim(productCodeOrId) === '') {
							productCodeOrId = tranItem.getProductId();
						}
					}
					//console.log("OVCVirtualReceipt.controller.getSelectedProductCodeOrId() returning:", productCodeOrId);
					return productCodeOrId;
				} catch (e) {
					throw util.rethrow(e, 'OVCVirtualReceipt.controller.getSelectedProductCodeOrId');
				}
			},

			selectRowByTranItemIdx: function (itemIdx) {
				//console.log("OVCVirtualReceipt.controller.selectRowByTranItemIdx() called:", itemIdx);

				var grid = this.getGrid();
				if (grid) {
					var rowNum;
					var store = this.getStore();
					var data = store.query({});
					var found = false;
					for (var index = 0, length = data.length; index < length; index++) {
						if (itemIdx == data[index].tranItemIdx) {
							rowNum = index;
							found = true;
							break;
						}
					}
					if (found) {  
						_.forEach(grid.selection, function(value, key) {
 								grid.deselect(grid.row(key))
						});
						var row = grid.row(rowNum);
						if (row && row != null){
							grid.select(row);
							row.element.scrollIntoView(); 
						}
					}
				}
			},

			renderReceipt: function (keepPosition) {
				//console.log("OVCVirtualReceipt.controller.renderReceipt() called:", keepPosition);
				try {
					// Clean the grid
					var grid = this.getGrid();
					if (grid) {  
						// re-populate the new store
						var createStorePromise = this.createStore(true, createStore());
  
						var tranObj = RetailTransactionHelper.getCurrentTranObj();
						// balance
						var balanceStr = '';
						if (tranObj.getBalance() < 0) {
							balanceStr = ResourceManager.getValue('currency.symbol') + (-Math.round(tranObj.getBalance() * 100) / 100);
							dom.byId('posBalanceLbl').innerHTML = ResourceManager.getValue('pos.return');
						} else {
							balanceStr = ResourceManager.getValue('currency.symbol') + Math.round(tranObj.getBalance() * 100) / 100;
							dom.byId('posBalanceLbl').innerHTML = ResourceManager.getValue('pos.balance');
						}

						if (balanceStr.indexOf('.') < 0) {
							balanceStr = balanceStr + '.00';
						} else if (balanceStr.indexOf('.') == balanceStr.length - 2) {
							balanceStr = balanceStr + '0';
						}

						dom.byId('posReceiptBalance').innerHTML = balanceStr;
						
						var controller;
						if(registry.byId("receiptGrid")){
							controller = registry.byId("receiptGrid").getController();
						}
						var totalActiveLineItems = tranObj.getTotalLineItemsExceptDiscounts();
						var showTranVoidIcon = (controller && !controller.isEmpty() && totalActiveLineItems === 0);

						if ((!tranObj._isLocked() || tranObj.isLayaway()) && (tranObj.getBalance() != 0 || (tranObj.getBalance() === 0 && (tranObj.getTotalItems() > 0 || showTranVoidIcon)))) {
							var dialogTitle = ResourceManager.getValue("menus.voids.transaction");
							var dialogMsg = ResourceManager.getValue("menus.voids.tranVoidReasonDialogMsg");
							var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmTransVoid;
							var confirmationMsg = ResourceManager.getValue("menus.voids.tranVoidConfirmMsg");

							dom.byId('posReceiptBalance').innerHTML = balanceStr;

							if (tranObj.getReceiptJSON().tenders.length < 1 || tranObj.isLayaway()) {
								if(RolePermissionsUtils.doesLoggerInUserHaveViewPermission("viewTransactionVoid")){
									var contentStr = "<img  width=\"45\" height=\"45\"onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialog.ovcprc',{ reasonCodeType: 'void', scopeType: '2', dialogTitle :'" + dialogTitle + "', dialogMsg : '" + dialogMsg + "',showConfirmation : '" + showConfirmation + "', confirmationMsg : '" + confirmationMsg + "'});\" src=" + base + "/../../dynamicblob/posMClient/voidIcon.png>";
									dom.byId('posReceiptBalance').innerHTML = balanceStr + contentStr;
								}
							}
						}
 
						var refQuoteTranId = tranObj.getQuoteRefTranId();

						if (tranObj._isLocked() || dom.byId('loyaltyUserName').innerHTML == '&nbsp;' || dom.byId('loyaltyUserName').innerHTML == '') {
							dom.byId('loyaltyUserVoid').innerHTML = '&nbsp;';
						} else if (refQuoteTranId &&
							refQuoteTranId != null) {
							dom.byId('loyaltyUserVoid').innerHTML = '&nbsp;';
						} else if (tranObj.getReceiptJSON() &&
							tranObj.getReceiptJSON().tenders &&
							tranObj.getReceiptJSON().tenders.length > 0) {
							dom.byId('loyaltyUserVoid').innerHTML = '&nbsp;';
						}
						
						require("dojo/query")("input[class='mblTextBox ovc-t w18 vrUnitPriceTextBox product']").on
						("keyup",  lang.hitch(this, function(e) {  
								var currencySymbol = ResourceManager.getValue('currency.symbol');
								var currentValWithOutSymbol = e.currentTarget.value.replace(currencySymbol, "");
								//console.log("Got a textbox keyup() event: ", e.target.value); 
 									if(isNaN(currentValWithOutSymbol)){
										if(e.keyIdentifier != "U+0008") {
											if(e.currentTarget._lasReportedValue != null){
												e.currentTarget.value = e.currentTarget._lasReportedValue;
											}
											else{
												e.currentTarget.value = e.currentTarget.defaultValue; 
											}
										}else{
											e.currentTarget.value = "";
										}
										return;
									}
									var displayedValue = ""+currentValWithOutSymbol;
									if(e.currentTarget.value &&
											e.currentTarget.value != ""){
										var whereIsTheDot = displayedValue.indexOf(".")
										var value = displayedValue;
										if(whereIsTheDot != -1){
											value = value.slice(0, whereIsTheDot) + value.slice(whereIsTheDot+1, value.length);
										}
										var len = value.length; 
										if(len > 2){
											e.currentTarget.value = currencySymbol + value.substring(0, len - 2).replace(/^0+/, '') + "." + value.substring(len - 2, len);
											e.currentTarget._lasReportedValue = e.currentTarget.value;
										}
										else{
											e.currentTarget.value =  currencySymbol + parseFloat("0."+value);
											e.currentTarget._lasReportedValue = e.currentTarget.value;
										} 
									}
									
									if(e.keyIdentifier == "Enter"){ 
										lang.hitch(this, priceOverride, e)();
									} 
								 
							}));
 
						return createStorePromise;
					}
				} catch (e) {
					throw util.rethrow(e, 'OVCVirtualReceipt.controller.renderReceipt');
				}
			},

			isEmpty: function () {
				//console.log("OVCVirtualReceipt.controller.isEmpty() called");

				// assume no transaction
				var retVal = true;

				var tranObj = RetailTransactionHelper.getCurrentTranObj();
				if (tranObj) {
					_.forEach(tranObj.getCalculatedTranItems(), function (calculatedTranItem) {
						var itemType = calculatedTranItem.getItemType();
						// TODO: is range checking of item types a good idea here?
						if ((itemType >= Constants.ITEM_TY_ADD_PRODUCT &&
							itemType <= Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT) ||
							itemType == Constants.ITEM_TY_APPOINTMENT ||
	 						itemType == Constants.ITEM_TY_PAYIN_SALE ||
	 						itemType == Constants.ITEM_TY_PAYIN_CORR_SALE ||
	 						itemType == Constants.ITEM_TY_PAYOUT_SALE ||
	 						itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE || 
	 						itemType == Constants.ITEM_TY_GIFT_CARD_SALE ||
	 						itemType == Constants.ITEM_TY_GIFT_CARD_TOPUP ||
	 						itemType == Constants.ITEM_TY_GIFT_CARD_REFUND){
							retVal = false;
							return false;
						}
					});
				}
				return retVal;
			},

			getGrid: function () {
				//console.log("OVCVirtualReceipt.controller.getGrid() called");
				return this.widget.getGrid();
			},

			getStore: function () {
				//console.log("OVCVirtualReceipt.controller.getStore() called");
				return this.widget.getStore();
			},

			createStore: function (updateGrid, newData) {
				//console.log("OVCVirtualReceipt.controller.createStore() called");
				return when(newData).then(lang.hitch(this.widget, this.widget.createStore, updateGrid));
			}
		});
	});
