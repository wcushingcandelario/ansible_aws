define([
	"ovc/ProcessEngine",
	"generic/ResourceManager",
	"posmclient/OVCPosSubMenu.widget",
	"dojo/dom-style",
	"posmclient/LayawayUtil",
	"generic/RolePermissionsUtils",
	"posmclient/RetailTransactionHelper"
], function (ProcessEngine,
             ResourceManager,
             OVCPosSubMenu,
             domStyle,
             LayawayUtil,
             RolePermissionsUtils,
             RetailTransactionHelper) {
	var TaxExemptClicked = false;
	var CheckoutClicked = false;
	
	function handleAction(actionId) {
		switch (actionId) {
			case 'addProduct':
				//removing the permission check for Add product as we coudn't think of a use-case for restricting this.
//				if(!RolePermissionsUtils.validateExecutePermission(actionId)){
//					return;
//				}
				console.log("Adding item");
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/receipt/AddItemByRetailerIdAndCodeOrSKU.ovcprc',
					{
						productId: require("dojo/dom").byId('scanProductTxtBox').value,
						quantity: 1
					});
				break;
			case 'lookup':
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/OpenProductLookupDialog.ovcprc', {});
				break;
			case 'refund':
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/SetScanTarget.ovcprc', {page: 'returnWithReceipt'});
				var removeIdsArr = [];
				if(localStorage.getObject("origTendersForReturn") != undefined &&
						localStorage.getObject("origTendersForReturn") != null){
					// return with receipt. Hide return without receipt.
					removeIdsArr.push("withoutReceiptMenuBtn");
				}
				else{
					var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
					if(tranObj.getTotalRefundItems() > 0){
						// already refund items present, must be without receipt- so hide with receipt.
						removeIdsArr.push("withReceiptMenuBtn");
						removeIdsArr.push("orderSearch");
					}
				}
				ProcessEngine.invokeProcess('generic/OpenMenuView.ovcprc', {menuId: 'posMClient/pos_return.ovcmnu', removeIdsArr: removeIdsArr});
				break;
			case 'discount':
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/OpenDiscountMenu.ovcprc', {});
				break;
			case 'void':
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/VoidTranOrOpenVoidMenu.ovcprc', {});
				break;
			case 'itemModifiers':
				ProcessEngine.invokeProcess('posMClient/OpenItemModifiersMenu.ovcprc', {});
				break;
			case 'resumeTransaction':
				ProcessEngine.invokeProcess('posMClient/view/OpenSuspendedSearchView.ovcprc', {});
				break;
			case 'suspendTransaction':
				ProcessEngine.invokeProcess('posMClient/OpenReasonCodeMenuView.ovcprc', {
					moveFromId: "mainMenuView",
					moveToId: 'suspendReasonCodesView',
					viewTitle: 'Suspend',
					listTitle: 'Reason:',
					reasonCodeType: 'suspend',
					targetProcess: 'posMClient/model/pos/suspendResume/Suspend.ovcprc'
				});
				break;
			case 'noSale':
				ProcessEngine.invokeProcess('posMClient/OpenReasonCodeMenuView.ovcprc', {
					moveFromId: "mainMenuView",
					moveToId: 'noSaleReasonCodesView',
					viewTitle: ResourceManager.getValue("pos.noSale"),
					listTitle: 'Reason:',
					reasonCodeType: 'noSale',
					targetProcess: 'posMClient/NoSaleTransaction.ovcprc'
				});
				break;
			case 'layaway':
				var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
				var removeIdsArr = [];
				if (tranObj.isLayaway()) {
					removeIdsArr = LayawayUtil.getRemoveMenuArrayForLayaway();
				} else {
					removeIdsArr.push("makePaymentLayawayMenuBtn");
					removeIdsArr.push("closeLayawayMenuBtn");
					removeIdsArr.push("finalizeLayawayMenuBtn");
				}
				ProcessEngine.invokeProcess('generic/OpenMenuView.ovcprc', {
					menuId: 'posMClient/pos_layaway.ovcmnu',
					removeIdsArr: removeIdsArr
				});
				break;
			case 'site':
				console.log("endless aisle");
				var registry = require("dijit/registry");
				// TODO: Should be converted to a process
				var virtualReceipt = registry.byId("receiptGrid").getController();
				if (navigator.notification != null) {
					navigator.notification.vibrate(50);
				}

				var productId = virtualReceipt.getSelectedProductId();
				var storeId = localStorage.getObject(dUUID).storeId;
				var commerceSiteConfig = require("ovc/ConfigManager").getConfigObject("posMClient/commerceServer.ovccfg");
				var url = commerceSiteConfig.baseCommerceServer + commerceSiteConfig.context;
				if (url != null && url.indexOf('?') == -1) {
					url += '?';
				} else {
					url += '&';
				}
				url += 'ovcdid=' + dUUID + '&ovcsid=' + storeId;
				var loyaltyId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getLoyaltyId();
				if (loyaltyId != null) {
					url += '&ovclid=' + loyaltyId;
				}

				// At this point, add the mediaCode from local storage to the url
				var mediaCode = localStorage.getObject("location").mediaCode;
				url += '&ID=' + mediaCode;

				if (productId == null) {
					var done = ResourceManager.getValue("browser.doneButton");
					if (navigator.userAgent.toLowerCase().indexOf('chrome') > -1) {
						domStyle.set(registry.byId('loginContent').domNode, "display", "none");
						domStyle.set(registry.byId('chromeInnerFrame').domNode, "display", "block");
						domStyle.set(registry.byId('chromeInnerFrame').domNode, "height", "100%");
						domStyle.set(require("dijit/registry").byId('innerFramePane').domNode, "height", "100%");
						require("dojo/dom").byId('innerFrame').src = url;//'http://fashion.ovcdemo.com/yacceleratorstorefront/?ovcdid=d7db7e4b-1c88-412f-ad7e-419b599aa5f2&ovcsid=OvcStore&ID=OvcStore';
						require("dojo/dom").byId('closeInnerFrameBtn').innerHTML = done;
					} else {
						require("posmclient/CometdDemo").siteOpened(
							window.open(encodeURI(url),
								"_blank",
								'location = no, closebuttoncaption = ' + done));
					}
				} else {
					//alert('(commerceSiteConfig.context):'+(commerceSiteConfig.context));
					if ((commerceSiteConfig.context).indexOf('?') == -1) {
						//alert('came in here context without ?');
						url = commerceSiteConfig.baseCommerceServer + commerceSiteConfig.context + commerceSiteConfig.endPoints.product + productId;
					} else {
						//alert('came in here context with ?');
						var contextArr = (commerceSiteConfig.context).split('?');
						//alert('context split into : '+contextArr[0]+' and '+contextArr[1]);
						url = commerceSiteConfig.baseCommerceServer + contextArr[0] + commerceSiteConfig.endPoints.product + productId + '?' + contextArr[1];
					}
					if (url != null && url.indexOf('?') == -1) {
						url += '?';
					} else {
						url += '&';
					}
					url += 'ovcdid=' + dUUID + '&ovcsid=' + storeId;
					if (loyaltyId != null) {
						url += '&ovclid=' + loyaltyId;
					}
					var mediaCode = localStorage.getObject("location").mediaCode;
					url += '&ID=' + mediaCode;
					ProcessEngine.invokeProcess('posMClient/OpenProductSite.ovcprc', {
						productId: productId,
						loyaltyId: loyaltyId,
						fallback: encodeURI(url)
					});
				}
				break;
			case 'loyalty':
				document.activeElement.blur();
				ProcessEngine.invokeProcess('posMClient/OpenLoyaltyLookupDialog.ovcprc', {});
				break;
			case 'managerKey':
				ProcessEngine.invokeProcess('posMClient/OpenManagerKeyMenu.ovcprc', {});
				break;
			case 'createQuote':
				var customerRequired = require("ovc/ConfigManager").getConfigObject("posMClient/Quotes.ovccfg").quoteCustomerRequired;
				ProcessEngine.invokeProcess('posMClient/Quote/CreateQuoteWithPop.ovcprc', {needCustomer: customerRequired});
				break;
			case 'deleteQuote':
				var quoteRefTranId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getQuoteRefTranId();

				var deleteQuoteConfirmation = require("ovc/ConfigManager").getConfigObject('posMClient/Quotes.ovccfg').deleteQuoteConfirmation;

				if (quoteRefTranId != null) {
					ProcessEngine.invokeProcess("posMClient/OpenReasonCodeDialogWithOutTextBox.ovcprc", {
						"invokeProcess": "posMClient/Quote/DeleteQuoteById.ovcprc",
						"params": {quoteTranId: quoteRefTranId},
						"reasonCodeType": "deleteQuote",
						"dialogTitle": ResourceManager.getValue("pos.dialogTitle"),
						"dialogMsg": ResourceManager.getValue("pos.dialogMsg"),
						"yesBtnLabel": ResourceManager.getValue("pos.yesBtnLabel"),
						"noBtnLabel": ResourceManager.getValue("pos.noBtnLabel"),
						"showConfirmation": deleteQuoteConfirmation,
						"confirmationMsg": ResourceManager.getValue("pos.confirmationMsg"),
						"dialogMsgNoReasonCode": ResourceManager.getValue("pos.dialogMsgNoReasonCode")
					});
				}
				break;
			case 'tandAManager':
				var clickableImage = $("#headingLogoLeft")[0];
				ProcessEngine.invokeProcess('generic/TransitionView.ovcprc',
					{
						fromViewId: clickableImage.activeView,
						ToViewId: "tandAManagerView",
						transitionDir: -1,
						transition: "zoomOut",
						destroyRecursive: 1
					});
				clickableImage.activeView = "tandAManagerView";
				break;
			case 'taxExemption':
				TaxExemptClicked = true;
				
				var loyaltyDetails = require("posmclient/RetailTransactionHelper").getCurrentTranObj()._loyaltyUser;

				if (loyaltyDetails && loyaltyDetails.loyaltyId != null) {
						ProcessEngine.invokeProcess('posMClient/model/customer/GetCustomerTaxExemptionInfo.ovcprc', {
							customerDetails: loyaltyDetails
						});
				}else{
					ProcessEngine.invokeProcess('posMClient/OpenLoyaltyLookupDialog.ovcprc', {});
				}
				break;
			
			case 'giftCertificate':
				ProcessEngine.invokeProcess('posMClient/GiftCertificate.ovcprc', {});
				break;
			case 'giftCard':
				ProcessEngine.invokeProcess('generic/OpenMenuView.ovcprc', { menuId: 'posMClient/pos_gift_card.ovcmnu',
						removeIdsArr : [] });
				break;
			case 'retrieveQuote':

				var loyaltyDetails = require("posmclient/RetailTransactionHelper").getCurrentTranObj()._loyaltyUser;
				if (loyaltyDetails && loyaltyDetails.loyaltyId != null) {
					ProcessEngine.invokeProcess('posMClient/model/customer/AddCustomerQuotes.ovcprc',
						{
							customerDetails: loyaltyDetails
						});
					return;
				}

				var removeIdsArr = [];
				// TP is not saving customers, hence do not show Search Quote by Customer.
				ProcessEngine.invokeProcess('generic/OpenMenuView.ovcprc', {
					menuId: 'posMClient/pos_retrieve_quote_no_loyalty.ovcmnu',
					removeIdsArr: removeIdsArr
				});
				break;
			case 'deliveryOption':
				ProcessEngine.invokeProcess('posMClient/DeliveryOptions/OpenDeliveryKeyMenu.ovcprc', {});
				break;
			case 'orderSearch':
				//ProcessEngine.invokeProcess('posMClient/OrderSearch.ovcprc', {});
				ordersButtonClicked();
				break;
			case 'signOut':
				ProcessEngine.invokeProcess('posMClient/SignOff.ovcprc', {});
				break;
			case 'checkOut':
				CheckoutClicked = true;
				require('ovc/ProcessEngine').invokeProcess('posMClient/SetScanTarget.ovcprc', {page: 'stopScan'});
				ProcessEngine.invokeProcess('posMClient/Checkout/OpenCheckoutMenu.ovcprc', {});
				break;
			case 'lockTill':
				ProcessEngine.invokeProcess('posMClient/Till/LockTill.ovcprc', {});
				break;
			case 'feeItem':
				ProcessEngine.invokeProcess('posMClient/OpenFeeMenuView.ovcprc',{ moveFromId: 'posItemModifiersMenuView', moveToId: 'feeMenuView', viewTitle: 'Fee', listTitle: 'Fees:', targetProcess: 'posMClient/receipt/AddItemByRetailerIdAndCodeOrSKU.ovcprc' });
				break;
			default:
			//default behavior
		}
	}
 
	return {
 		setTaxExemptClicked: function(value){
			TaxExemptClicked = value;
		},
		
		isTaxExemptClicked: function(){
			return TaxExemptClicked;
		},
		setCheckoutClicked: function(value){
			CheckoutClicked = value;
			if(value == false){
				        	require("ovc/ProcessEngine").invokeProcess("posMClient/SetScanTarget.ovcprc", {page:'pos'});
						}
		},
		isCheckoutClicked: function(){
			return CheckoutClicked;
		},
		//permissions for different actions are defined in RolePermissionsUtils js file...
		executeAction: function (actionId, value) {  
			return function () {
				var defered = RolePermissionsUtils.validateExecutePermission(actionId);
				require('dojo/when')(defered).then(function (res) {
					if (typeof res != 'undefined' && res === true) {
						handleAction(actionId);
					}
				});
			}
		}
	};
});
