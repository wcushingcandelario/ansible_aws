define([
	"./OVCPosMainMenu.module",
	"./OVCPosMainMenu.states",
	"./OVCPosMainMenu.actions",
	"dojo/text!./OVCPosMainMenu.widget.html",
	"generic/ResourceManager",
	"generic/Constants",
	"posmclient/RetailTransactionHelper",
	"ovc/ConfigManager",
	"dijit/registry"
], function (module,
             states,
             actions,
             templateString,
             ResourceManager,
             Constants,
             RetailTransactionHelper,
             ConfigManager,
             registry) {
	
	function hidePOSMenuFunctions(scope){
		var hiddenFunctions = ConfigManager.getConfigObject("posMClient/pos.ovccfg").hiddenFunctions;
		for(var i=0; i<hiddenFunctions.length; i++){
			if(hiddenFunctions[i]){
				scope[hiddenFunctions[i]].hidden = true;
			}
		}
	}

	function controller($scope, $timeout) {

		$scope.mainHeadingLabel = ResourceManager.getValue("pos.mainHeading");
		$scope.textBoxMsg = ResourceManager.getValue("pos.textBoxMsg");
		$scope.textBoxHint = ResourceManager.getValue("pos.textBoxHint");
		$scope.signOffLabel = ResourceManager.getValue("pos.signOff");
		$scope.checkoutLabel = ResourceManager.getValue("pos.checkout");

		initializeButtons($scope);
		hidePOSMenuFunctions($scope);
		
		$scope.covered = false;

		this.cover = function () {
			$timeout(function () {
				$scope.covered = true;
			});
		};

		this.uncover = function () {
			$timeout(function () {
				$scope.covered = false;
			});
		};

		this.clearTextBox = function () {
			$timeout(function () {
				$scope.code = "";
			});
		};
		
		this.disableEndlessIsleMenu = function (disable) {
			$timeout(function () {
				states.disableEndlessIsleMenu($scope, disable);
			});
			 
		},
		 
		this.enableDisablePOSButtons = function () {
			$timeout(function () {

				var controller;
				if(registry.byId("receiptGrid")){
					controller = registry.byId("receiptGrid").getController();
				}
				var selectedRow = controller && controller.getSelectedTranItemIdx();
				var tranObj = RetailTransactionHelper.getCurrentTranObj();
				var selectedItem = tranObj.getTranItemByIdx(selectedRow);
				var selectedItemProduct = selectedItem ? selectedItem.getProduct() : null;
				var itemType = selectedItem && selectedItem.getItemType();
				
				var totalActiveLineItems = tranObj.getTotalLineItemsExceptDiscounts();
				
				var state; 
				var empty = controller && ( controller.isEmpty() || totalActiveLineItems === 0);
				var loyaltyId = tranObj && tranObj.getLoyaltyId();
				var discountAllowedForReturns = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').discountAllowedForReturns;
 
 				if (empty || empty==null) {
					state = loyaltyId ? states.transactionEmptyWithLoyalty : 
										states.transactionEmpty;
				} else if (selectedRow == null || selectedItem == null) {
					if(loyaltyId){
						if(empty){
							state = states.transactionEmptyWithLoyalty;
						}else{
							state = states.transactionWithLoyaltyAndProducts;
						}
					}else{
						state = states.nothingSelected;
					} 
				} else if (itemType === Constants.ITEM_TY_DISCOUNT_TXN ||
					itemType === Constants.ITEM_TY_DISCOUNT_ITEM ||
					tranObj.isItemVoidByIdx(selectedRow)
				) { 
					state = states.discountOrVoidSelected;
				} else if(selectedItemProduct && 
						selectedItemProduct.getProductType() == "GiftCertificate") {
					state = states.giftCertSelected;
				} else if (itemType === Constants.ITEM_TY_REFUND_PRODUCT) { 
					if(discountAllowedForReturns == 0){
						state = states.discountOrVoidSelected;
					}
					else{
						state = states.refundWithDiscountSelected;
					}
				} else if(tranObj.hasItemDiscount(selectedRow)){
					state = states.otherItemSelected;
				}else{
					state = states.otherItemSelectedWithoutDiscount;
				} 
 				state($scope); 

 				//filter based on rolePermissions
				var userObj = localStorage.getObject(username);
				if (userObj && userObj != null && userObj.roles.length > 0) {
					state = states.hideAllMenus;
					state($scope, role);

					for (var idx = 0, length = userObj.roles.length; idx < length; idx++) {
						var role = userObj.roles[idx];
						state = states.filterByPermissions;
						state($scope, role);
					}
				}
				
              	if(tranObj.getReceiptJSON() && 
              		tranObj.getReceiptJSON().tenders && 
              		tranObj.getReceiptJSON().tenders.length > 0){
					states.disableSuspendResume($scope);	
				}
				if (tranObj.whichDeliveryOptionPresent()) {
					states.disableDeliveryOption($scope, true);
				}
				if(tranObj.isItemTypePresent(Constants.ITEM_TY_STORE_COLLECT_OPTION)){
					if(tranObj.hasAddProductsWithoutStoreCollectOption()) {
						states.disableDeliveryOption($scope, false);
					}
					else
						states.disableDeliveryOption($scope, true);
				}
				//no delivery options when refund items are present on the VR
				if(tranObj.getTotalRefundItems() > 0 && tranObj.getTotalItems() === 0){
					states.disableDeliveryOption($scope, true);

					/*
					only refund items: 
					do not allow creating quote with a refund item.
					Quote is only for buying stuff, and if customer is returning 
					something, they dont have to "Quote" it.
					*/
					states.disableCreateQuote($scope, true);
				}
				else if(tranObj.getTotalRefundItems() > 0){
					// mixed bag
					//states.disableSuspendResume($scope, true);
					states.disableCreateQuote($scope, true);
				}
 				
              	var refQuoteTranId = tranObj.getQuoteRefTranId();
              	if(refQuoteTranId == undefined || 
              		refQuoteTranId == null ){
					states.disableDeleteQuote($scope);	
				}else{
					states.disableLoyalty($scope);	 
				}
				document.getElementById("scanProductTxtBox").disabled = false;
				if (tranObj.isLayaway()) {
					if(tranObj.isLayawaySale()){
						empty ? states.isEmptyLayaway($scope) : states.isLayawaySale($scope);
					}else{
						states.isLayawayEdit($scope);
						document.getElementById("scanProductTxtBox").disabled = true;
					}
				}
				
				if (tranObj.getTranTypeId() == Constants.TX_TY_PAYINTRAN ||
					tranObj.getTranTypeId() == Constants.TX_TY_PAYOUTTRAN ||
					tranObj.getTranTypeId() == Constants.TX_TY_PAYINCORRTRAN ||
					tranObj.getTranTypeId() == Constants.TX_TY_PAYOUTCORRTRAN){
					states.hideAllMenus($scope);
					document.getElementById("scanProductTxtBox").disabled = true;
				}
				// If found a gift card adjustment item, then all items are
				// paid for and the only remaining part is the store giving
				// back the adjustment amount to the customer. So, don't let 
				// them add products or alter the receipt in any way.
				if(tranObj.getGiftCardAdjItemIdx() != -1){
					states.hideAllMenus($scope);
					document.getElementById("scanProductTxtBox").disabled = true;
				}
			});
		};

		$scope.addProduct = actions.executeAction('addProduct');
		$scope.orderSearch.action = actions.executeAction('orderSearch');
		$scope.lookup.action = actions.executeAction('lookup'); 
		$scope.refund.action = actions.executeAction('refund');
		$scope.discount.action = actions.executeAction('discount');
		$scope["void"].action = actions.executeAction('void');
		$scope.itemModifiers.action = actions.executeAction('itemModifiers');
		$scope.resumeTransaction.action = actions.executeAction('resumeTransaction');
		$scope.suspendTransaction.action = actions.executeAction('suspendTransaction');
		$scope.noSale.action = actions.executeAction('noSale');
		$scope.layaway.action = actions.executeAction('layaway');
		$scope.site.action = actions.executeAction('site');
		$scope.loyalty.action = actions.executeAction('loyalty');
		$scope.retrieveQuote.action = actions.executeAction('retrieveQuote');
		$scope.createQuote.action = actions.executeAction('createQuote');
		$scope.deleteQuote.action = actions.executeAction('deleteQuote'); 
		$scope.managerKey.action = actions.executeAction('managerKey');
		$scope.tandAManager.action = actions.executeAction('tandAManager');
		$scope.deliveryOption.action = actions.executeAction('deliveryOption');
		$scope.taxExemption.action = actions.executeAction('taxExemption');
		$scope.giftCertificate.action = actions.executeAction('giftCertificate');
		$scope.giftCard.action = actions.executeAction('giftCard');
		$scope.signOut = actions.executeAction('signOut');
		$scope.checkOut = actions.executeAction('checkOut');
		$scope.lockTill.action = actions.executeAction('lockTill');
		$scope.feeItem.action = actions.executeAction('feeItem');
	}

	function initializeButtons(scope) {
		scope.orderSearch = getButtonPropObject("pos.transactionSearch");
		scope.lookup = getButtonPropObject("pos.lookup"); 
		scope.refund = getButtonPropObject("pos.refund");
		scope.discount = getButtonPropObject("pos.discount");
		scope["void"] = getButtonPropObject("pos.void");
		scope.itemModifiers = getButtonPropObject("pos.itemModifiers");
		scope.resumeTransaction = getButtonPropObject("pos.resumeTransaction");
		scope.suspendTransaction = getButtonPropObject("pos.suspendTransaction");
		scope.noSale = getButtonPropObject("pos.noSale");
		scope.layaway = getButtonPropObject("pos.layaway");
		scope.site = getButtonPropObject("pos.site");
		scope.loyalty = getButtonPropObject("pos.loyalty");
		scope.managerKey = getButtonPropObject("pos.managerKey");
		scope.retrieveQuote = getButtonPropObject("pos.retrieveQuote");
		scope.createQuote = getButtonPropObject("pos.createQuote");
		scope.deleteQuote = getButtonPropObject("pos.deleteQuote");
		scope.tandAManager = getButtonPropObject("pos.tandAManager");
		scope.deliveryOption = getButtonPropObject("pos.deliveryOption");
		scope.taxExemption = getButtonPropObject("pos.taxExemption");
		scope.giftCertificate = getButtonPropObject("pos.giftCertificate");
		scope.giftCard = getButtonPropObject("pos.giftCard");
		scope.lockTill = getButtonPropObject("pos.lockTill");
		scope.feeItem = getButtonPropObject("pos.feeItem");
	}

	function getButtonPropObject(resourceKey) {
		return {
			label: ResourceManager.getValue(resourceKey),
			hidden: false,
			disabled: false
		};
	}

	angular.module(module)
		.directive('ovcMainMenu', function () {
			return {
				restrict: 'E',
				template: templateString,
				controller: ["$scope", "$timeout", controller]
			}
		});
});
