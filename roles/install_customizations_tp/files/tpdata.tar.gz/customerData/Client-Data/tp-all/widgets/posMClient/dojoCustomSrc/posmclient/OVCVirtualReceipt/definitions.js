define(["dojo/_base/lang",
        "dojo/Deferred",
        "dojo/when",
        "generic/StringUtils",
		"generic/ResourceManager",
		"dojo/store/Memory",
		"generic/Constants",
		"ovc/ConfigManager",
		"ovc/ProcessEngine",
		"posmclient/RetailTransactionHelper",
		"generic/PermissionsManager"
	],
	function (lang, Deferred, when, StringUtils, ResourceManager, Memory, Constants, ConfigManager, ProcessEngine, RetailTransactionHelper, PermissionsManager) {

		var viewItemDiscountPerm = PermissionsManager.validatePermission("viewItemDiscount");
		var viewTransactionDiscountPerm = PermissionsManager.validatePermission("viewTransactionDiscount");
		var viewPriceOverridePerm = PermissionsManager.validatePermission("viewPriceOverride");
		var viewItemVoidPerm = PermissionsManager.validatePermission("viewItemVoid");
		var viewDiscountVoidPerm = PermissionsManager.validatePermission("viewDiscountVoid");
		var viewDeliveryOptionVoidPerm = PermissionsManager.validatePermission("viewDeliveryOptionVoid");
		var viewPriceOverrideVoidPerm = PermissionsManager.validatePermission("viewPriceOverrideVoid");

		function getProductClasses(itemType, isVoid) {
			//console.log("OVCVirtualReceipt.definition.getProductClasses called:", itemType, isVoid);
			var classStr;
			if (itemType) {
				switch (itemType) {
					case Constants.ITEM_TY_REFUND_PRODUCT:
					case Constants.ITEM_TY_GIFT_CARD_REFUND:
						classStr = "refund";
						break;
					case Constants.ITEM_TY_DISCOUNT_ITEM:
					case Constants.ITEM_TY_DELIVERY_OPTION:
					case Constants.ITEM_TY_STORE_COLLECT_OPTION:
					case Constants.ITEM_TY_DISCOUNT_TXN:
						classStr = "discount";
						break;
					case Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT:
						classStr = "paid";
						break;
					case Constants.ITEM_TY_PROMO:
						classStr = "promo";
						break;
					default:
						classStr = "product";
						break;
				}

				if (isVoid) {
					classStr += " voided";
				}
			} else {
				classStr = "summary";
			}

			//console.log("OVCVirtualReceipt.definition.getProductClasses returned:", classStr);
			return classStr;
		}

		function createSpan(contentStr, classStr, onclickEvent) {
			var returnStr =  "<span class=\"" + classStr + "\">" + contentStr + "</span>";
			if(onclickEvent && onclickEvent!=null){
				returnStr = "<span class=\"tranDiscount-link\" onclick=\""+onclickEvent+"\">" + contentStr + "</span>";
			}
			return returnStr;
		}

		function createDiv(contentStr, classStr) {
			return "<div class=\"" + classStr + "\">" + contentStr + "</div>";
		}

		function negate(str) {
			return "-" + str;
		}

		function isNegative(str) {
			// return true only if a valid number that is negative
			return parseFloat(str) < 0;
		}

		function toCurrency(str, forceNegative) {
			var notPositive = isNegative(str);

			if (notPositive) {
				// strip off '-'
				str = str.substring(1);
			}

			var currencyStr = addCurrency(str);
			if (notPositive || forceNegative) {
				currencyStr = negate(currencyStr);
			}
			return currencyStr;
		}

		function addCurrency(str) {
			return ResourceManager.getValue("currency.symbol") + str;
		}

		function toPercent(str, forceNegative) {
			var notPositive = isNegative(str);

			if (notPositive) {
				// strip off '-'
				str = str.substring(1);
			}

			var percentStr = addPercent(str);
			if (notPositive || forceNegative) {
				percentStr = negate(percentStr);
			}
			return percentStr;
		}

		function addPercent(str) {
			return str + "%";
		}

		function formatItemColumn(item) {
			//console.log("OVCVirtualReceipt.definitions: formatItemColumn() called:", item);
			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
			var onclickEvent = null;
			if (item.itemNum) {
				var dialogTitle = ResourceManager.getValue('menus.discounts.item');
  				var dialogMsg = ResourceManager.getValue('menus.discounts.tranDiscountReasonDialogMsg');
  				var targetProcess = 'posMClient/Discount.ovcprc';
  				var selectedTranItemIdx = item.tranItemIdx;
   				var tranObj = RetailTransactionHelper.getCurrentTranObj();
   				
   				
   				var itemIdx = item.tranItemIdx;
				var tranItem = tranObj.getTranItemByIdx(itemIdx);
				var isChildProduct = (tranItem != null && tranItem.getParentProductIdx() != null && tranItem.getParentProductIdx() != undefined && tranItem.getParentProductIdx() != -1 && tranItem.getParentProductIdx() >= 0);
   				
 				if (!tranObj._isLocked() && tranObj.hasItemDiscount(selectedTranItemIdx) && tranObj.isLayawayDiscountable() && item.qty !== 0 && !isChildProduct) {
					if (viewItemDiscountPerm.isViewable == 1) {
 						onclickEvent = "require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeThroughDialog.ovcprc',{ reasonCodeType: 'discount', scopeType: '1',  showAmountTextBox: true, invokeProcess :'"+targetProcess+"', dialogTitle :'"+dialogTitle+"', dialogMsg : '"+dialogMsg+"'});";
						contentStr = item.itemNum;
 					}
				} 
   				contentStr = item.itemNum;
			} else if (item.type) {
				//contentStr = item.type;
			}else if (item.itemType === Constants.ITEM_TY_STORECREDIT_SALE) {
					contentStr = ResourceManager.getValue('pos.storeCredit');

			}else {

				/*var resourceKey = "receipts.";

				if (item.merchTotal) {
					resourceKey += "merchTotal";
					classStr += " total";
				} else if (item.promoSavings) {
					resourceKey += "promoSavings";
				} else if (item.total) {
					resourceKey += "total";
					classStr += " total";
				} else if (item.alert || item.promoType || item.discType || (item.initialPrice && item.newPrice >= 0)) {
					// contentStr will end up being an empty string
					resourceKey = "";
				} else {
					resourceKey = "";
					alert("formatItemColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
				}
				contentStr = resourceKey && ResourceManager.getValue(resourceKey);*/
			}

			var spanStr = createSpan(contentStr, classStr, onclickEvent);
			//console.log("OVCVirtualReceipt.definitions: formatItemColumn() returning:", spanStr);
			return spanStr;
		}

		function shrinkText(content, reasoncode){
			var lengthValue = 60;
			var maxLength = 48;
			if(dUUID && dUUID!=null && dUUID.indexOf('iPad') != -1){
				lengthValue = 44;
			}
			if(reasoncode){
				lengthValue = lengthValue/2;
				maxLength = maxLength/2;
			}
			if(content && content.length > maxLength){
 				if(content.indexOf("Auth")==-1 &&
					content.indexOf("Store Collect:")==-1 &&
 					content.indexOf("Price Match")==-1 &&
				    content.indexOf("Expected Delivery")==-1 &&
				    content.indexOf(ResourceManager.getValue("pos.unusedPromoSavings")) == -1 ){
					content = content.slice(0,maxLength) + "...";
				}
			}
			return content;
		}

		var refundProdCls = '';

		function formatNameColumn(item) {
			//console.log("OVCVirtualReceipt.definitions: formatNameColumn() called:", item);
			var tranObj = RetailTransactionHelper.getCurrentTranObj();

			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
			var salesConfig = ConfigManager.getConfigObject("posMClient/sales.ovccfg");
			if (item.initialPrice && item.newPrice >= 0) {
				// some kind of price override
				classStr = "discount";
				contentStr = item.reasonCodeDesc;
			}
			if(item.itemType == Constants.ITEM_TY_BBAS){
				classStr = "discount";
				contentStr = item.reasonCodeDesc;
			}

			if(item.totalBBASSavings != null){
				classStr = "alert";
				contentStr = item.totalBBASSavings;
			}

			if(item.priceOverrides != undefined || item.discounts != undefined){
				refundProdCls = getProductClasses(item.itemType, item.isVoid);
			}

			if (item.initialPrice && item.newPrice >= 0) {
 				classStr = "discount";
				if(item.specialType ==null){
					contentStr = item.reasonCodeDesc;
				}else if(item.specialType == "priceOverride"){
					if(refundProdCls == 'refund'){
						classStr += " "+refundProdCls;
					}
					// some kind of price override
 					contentStr = item.reasonCodeDesc + "<br\> ["+item.priceChangeApplied+"]";
 					if(item.isVoid)
 						contentStr = contentStr.strike();
				}
			} else if (item.discType) {
				if(item.specialType != "discount"){
					contentStr = item.reasonCodeDesc;
				}else {
					if(refundProdCls == 'refund'){
						classStr += " "+refundProdCls;
					}
					if (item.discType == Constants.DISC_TYPE_AMOUNT) {
						contentStr = item.reasonCodeDesc + "<br\> ["+toCurrency(item.discValue.toFixed(2), true)+"]";
					} else if (item.discType == Constants.DISC_TYPE_PERCENT) {
						contentStr = item.reasonCodeDesc + "<br\> ["+toPercent(item.discValue.toFixed(2), true)+"]";
					}
				}
			} else if (item.name) {
				// product
				contentStr = item.name;

				if (item.origPrice && item.price) {
					var origPriceF = Math.round(parseFloat(item.origPrice)*parseFloat(item.qty)*100)/100;
					var priceF = parseFloat(item.price);
					if (priceF < origPriceF) {
						// add the original price of the product under the product name
						var spanStr1 = createSpan(shrinkText(contentStr), classStr);
						if (salesConfig.showPriceOverride === 1) {
							var negSet = false;
							if(classStr == 'refund'){
								negSet = true;
							}
							var spanStr2 = createSpan(ResourceManager.getValue("receipts.origPrice")  +" "+ toCurrency(item.origPrice,negSet), classStr + " discount");
							return spanStr1 + '<br>' + spanStr2;
						}
						else {
							return spanStr1;
						}
					}else  if((Constants.ITEM_TY_REFUND_PRODUCT == item.itemType || Constants.ITEM_TY_GIFT_CARD_REFUND == item.itemType) && (item.reasonCode && item.reasonCode != null)){
						var spanStr1 = createSpan(shrinkText(contentStr), classStr);
						var reasonDesc = item.reasonCode;
						if (item.reasonCodeDesc != null && item.reasonCodeDesc != "") {
							reasonDesc = item.reasonCodeDesc;
						}
						var spanStr2 = createSpan(shrinkText("Reason: "  + reasonDesc, true), classStr + " discount");

						var spanStr3 = "";
						if (item.promoId && item.promoId !== "") {
							spanStr3 = createSpan("Promo: "  + item.promoId, classStr);
						}

						return spanStr1 + '<br>' + spanStr2 + '<br>' + spanStr3;
					}
				}
			} else if (item.description) {

				// promo
				// if the promo has not been applied then we want to strike out the text
				contentStr = item.description;
				if (tranObj._appliedToLayaway === 0 && (tranObj.isLayawayFinalize() || tranObj.isLayawayPayment() || tranObj.isLayawaySale()) ) {
					contentStr = contentStr.strike();
				}

			} else if (item.alert) {
				contentStr = item.alert;
				classStr = "alert";
			} else if(item.tenderDate){
				contentStr = item.tenderDate;
			} else if (item.merchTotal) {
				//contentStr =
					//ResourceManager.getValue("receipts.itemCount.before") +
					//item.itemCount +
					//(item.itemCount == 1 ? ResourceManager.getValue("receipts.itemCount.afterSingular") : ResourceManager.getValue("receipts.itemCount.afterPlural"));
			} else if (item.type || item.promoSavings || item.storeCreditBalance || item.total) {
				// do nothing
			} else {
				//alert("formatNameColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
			}

			var spanStr;
			if(item.itemType === Constants.ITEM_TY_PROMO) {
				contentStr += ' ['+ item.qty +']';
				spanStr = createSpan(contentStr, classStr);
			} else {
				spanStr = createSpan(shrinkText(contentStr), classStr);
			}


			//console.log("OVCVirtualReceipt.definitions: formatNameColumn() returning:", spanStr);
			return spanStr;
		}

		function formatQtyColumn(item) {
			//console.log("OVCVirtualReceipt.definitions: formatQtyColumn() called:", item);
			var tranObj = RetailTransactionHelper.getCurrentTranObj();

			var isTranLocked = tranObj.isTransactionLocked();
			var isLayawayTran = tranObj.isLayawayPayment() || tranObj.isLayawayFinalize();

			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
			var config = ConfigManager.getConfigObject("posMClient/pos.ovccfg");
			var isQtyEditable = (config.editableQuantities && config.editableQuantities!=null && config.editableQuantities===1);
			var isPIPO = false;
			if(item.itemType == Constants.ITEM_TY_PAYIN_SALE || item.itemType == Constants.ITEM_TY_PAYIN_CORR_SALE
					|| item.itemType == Constants.ITEM_TY_PAYOUT_SALE || item.itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
				isPIPO = true;
			}
			
			var tranItemForChk = tranObj.getTranItemByIdx(item.tranItemIdx);
			var isReturnFromReceipt = (tranItemForChk != null && (tranItemForChk.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT || tranItemForChk.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND) && tranItemForChk.getRefTranId() != null && tranItemForChk.getRefTranId() != "") ? true :false;
			var IsProductQuantityEditable =  ( tranItemForChk === null || tranItemForChk.getIsQuantityEditable() === '1');
			var isEditable =
				!isLayawayTran &&
				!isTranLocked &&
				isQtyEditable &&
				IsProductQuantityEditable &&
				!item.isVoid &&
				!item.isFee &&
				!isReturnFromReceipt &&
				item.itemType !== Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT &&
				item.itemType !== Constants.ITEM_TY_PROMO &&
				item.itemType !== Constants.ITEM_TY_DISCOUNT_ITEM &&
				item.itemType !== Constants.ITEM_TY_DELIVERY_OPTION &&
				item.itemType !== Constants.ITEM_TY_STORE_COLLECT_OPTION &&
				item.itemType !== Constants.ITEM_TY_DISCOUNT_TXN &&
				item.itemType !== Constants.ITEM_TY_NO_SALE &&
				isPIPO == false &&
				item.itemType !== Constants.ITEM_TY_GIFT_CARD_SALE &&
				item.itemType !== Constants.ITEM_TY_GIFT_CARD_TOPUP &&
				((item.giftCardAdjustment != undefined && item.giftCardAdjustment.itemType !== Constants.ITEM_TY_GIFT_CARD_ADJ ) || item.giftCardAdjustment == undefined) &&
				item.itemType !== Constants.ITEM_TY_STORECREDIT_SALE;
			if (item.qty || item.itemType === Constants.ITEM_TY_NO_SALE || item.itemType === Constants.ITEM_TY_STORECREDIT_SALE
					|| isPIPO || item.itemType === Constants.ITEM_TY_GIFT_CARD_SALE || item.itemType === Constants.ITEM_TY_GIFT_CARD_TOPUP) {
				if(item.itemType !== Constants.ITEM_TY_PROMO){
					contentStr = item.qty;
				}
			} else if (item.storeCreditBalance || item.type || item.merchTotal || item.total || item.promoSavings || item.alert || item.discType || (item.initialPrice && item.newPrice >= 0)) {
				// do nothing

				var resourceKey = "receipts.";
				var onclickEvent = null;
				if (item.merchTotal) {
					isEditable = false;
					resourceKey += "merchTotal";
					classStr += " total";
					resourceKey = resourceKey && ResourceManager.getValue(resourceKey);
					resourceKey += " " + ResourceManager.getValue("receipts.itemCount.before") +
								item.itemCount + (item.itemCount == 1 ? ResourceManager.getValue("receipts.itemCount.afterSingular") : ResourceManager.getValue("receipts.itemCount.afterPlural"));

				} else if (item.type) {
					isEditable = false;
					resourceKey = item.type;
					resourceKey = resourceKey && ResourceManager.getValue(resourceKey);
					if (item.itemType === Constants.ITEM_TY_TAX_EXEMPT) {
						classStr = "taxExempt";
					}
					else if (item.itemType === Constants.ITEM_TY_NET_TAX) {
						classStr = "netTax";
					}
				} else if (item.promoSavings) {
					isEditable = false;
					resourceKey += "promoSavings";
					resourceKey = resourceKey && ResourceManager.getValue(resourceKey);
					if (item.promoSavings.indexOf("strike") > 0) {
						resourceKey = resourceKey.strike();
					}


				} else if (item.total) {
					var tranObj = RetailTransactionHelper.getCurrentTranObj();
					isEditable = false;
					resourceKey += "total";
					resourceKey = resourceKey && ResourceManager.getValue(resourceKey);
					classStr += " total";
					var tranDiscValid = false;
					tranDiscValid = tranObj.hasItemsCanHaveTranDiscount();
					if(!tranObj._isLocked() && tranDiscValid){
						var dialogTitle = ResourceManager.getValue("menus.discounts.transaction");
						var dialogMsg = ResourceManager.getValue("menus.discounts.tranDiscountReasonDialogMsg");
						var targetProcess = 'posMClient/Discount.ovcprc';
						if (tranObj.hasAnyItemAndNoTransDiscount() && !tranObj.hasGCOnly() && tranObj.isLayawayDiscountable()) {
							if (viewTransactionDiscountPerm.isViewable == 1) {
								onclickEvent = "require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeThroughDialog.ovcprc',{ reasonCodeType: 'discount', scopeType: '2',  showAmountTextBox: true, invokeProcess :'" + targetProcess + "', dialogTitle :'" + dialogTitle + "', dialogMsg : '" + dialogMsg + "'});";
							}
						}
					}
					contentStr += resourceKey && ResourceManager.getValue(resourceKey);
				} else if(item.storeCreditBalance) {
					isEditable = false;
					resourceKey += "storeCreditBalance";
					resourceKey = resourceKey && ResourceManager.getValue(resourceKey);
					classStr += " total";
				} else if (item.alert || item.promoType || item.discType || (item.initialPrice && item.newPrice >= 0)) {
					// contentStr will end up being an empty string
					resourceKey = "";
				} else {
					resourceKey = "";
					alert("formatItemColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
				}
				if (!item.total){
					contentStr += resourceKey && ResourceManager.getValue(resourceKey);
				}

			}
			else if(item.purchaseTenders && tranObj.getTranItems().length > 0){
				var spanHeader = createSpan(shrinkText(ResourceManager.getValue("receipts.purchaseTenders")), 'purchaseTenderHeader');
				var spanTender = '';
				_.forEach(item.purchaseTenders, function (tenders) {
					if(tenders.tenderDetails && tenders.tenderDetails.payload){
						var parsedPayload = JSON.parse(tenders.tenderDetails.payload);
						var maskedCardNumber = parsedPayload.maskedCardNumber.substr(parsedPayload.maskedCardNumber.length - 5);
						spanTender += createSpan(shrinkText('<br>' +parsedPayload.cardType +'&ensp;'+maskedCardNumber),'purchaseTenders');
					}else if(tenders.tenderDetails && tenders.tenderDetails.description){
						spanTender += createSpan(shrinkText('<br>' +(tenders.tenderDetails.description).capitalizeFirstLetter()),'purchaseTenders');
					}
				});
				return spanHeader+ spanTender;
			}
			else if(item.giftCardAdjustment != undefined){
				classStr += " total";
				contentStr = item.giftCardAdjustment.description;
			}
			else {
				//alert("formatQtyColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
			}
			return createSpanForQtyColumn(isEditable, contentStr, classStr, onclickEvent);
		}

		function createSpanForQtyColumn(isEditable, contentStr, classStr, onclickEvent){
			var columnStr;
			if (isEditable && (contentStr || contentStr === 0) ) {
				columnStr = "<input data-dojo-type='dijit/form/NumberTextBox' onclick='this.setSelectionRange(0, 9999);' data-dojo-props='constraints:{min:0,places:0}' class='mblTextBox ovc-t w18 vrQtyTextBox' autocomplete='off' value='" + contentStr + "'>";
			} else {
				columnStr = createSpan(contentStr, classStr, onclickEvent);
			}

			//console.log("OVCVirtualReceipt.definitions: formatItemColumn() returning:", columnStr);
			return columnStr;
		}

		function formatItemUnitPriceColumn(item) {
			//console.log("OVCVirtualReceipt.definitions: formatItemUnitPriceColumn() called:", item);
			var isPIPO = false;
			if(item.itemType == Constants.ITEM_TY_PAYIN_SALE || item.itemType == Constants.ITEM_TY_PAYIN_CORR_SALE
					|| item.itemType == Constants.ITEM_TY_PAYOUT_SALE || item.itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
				isPIPO = true;
			}

			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
			var tranObj = RetailTransactionHelper.getCurrentTranObj();
			var priceOverridden = false;
			if(item.discType){  
				if(item.specialType !== null){
					contentStr = "";
				}else{
					if (item.discType == Constants.DISC_TYPE_AMOUNT) {
						contentStr = toCurrency(item.discValue.toFixed(2), true);
					} else if (item.discType == Constants.DISC_TYPE_PERCENT) {
						contentStr =  toPercent(item.discValue.toFixed(2), true);
					}
				}
			} 
			else if (item.qty === 0 || item.qty > 1) {
				var value = item.itemType == Constants.ITEM_TY_PROMO ? item.value : item.unitPrice;
				var negSet = false;
				if(classStr == 'refund'){
					negSet = true;
				}

				if(value && value!=null)
					contentStr = "";
				var itemIdx = item.tranItemIdx;
				var tranItem = tranObj.getTranItemByIdx(itemIdx);
				var isChildProduct = (tranItem != null && tranItem.getParentProductIdx() != null && tranItem.getParentProductIdx() != undefined && tranItem.getParentProductIdx() != -1 && tranItem.getParentProductIdx() >= 0);
				
				if(item.qty !== 0 && !isChildProduct && (item.itemType === Constants.ITEM_TY_ADD_PRODUCT || item.itemType === Constants.ITEM_TY_REFUND_PRODUCT || item.itemType === Constants.ITEM_TY_GIFT_CARD_REFUND || item.itemType === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
	  					item.itemType === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT)){

					var isPriceOverridable = tranItem.getIsPriceOverridable();
					if (!tranObj._isLocked() && (typeof isPriceOverridable === 'undefined' || isPriceOverridable === '1') && !tranObj.isGCItem(itemIdx) && !item.isVoid) {
						if (viewPriceOverridePerm.isViewable == 1) {
							contentStr = "<input data-dojo-type='dojox/mobile/TextBox' data-dojo-props='constraints:{min:0}' class='mblTextBox ovc-t w18 vrUnitPriceTextBox " + classStr + "' autocomplete='off' value='" + toCurrency(value, negSet) + "'>";
							priceOverridden = true;
						}
					}
				}

			} else if (item.itemType === Constants.ITEM_TY_NO_SALE ||
					item.itemType === Constants.ITEM_TY_STORECREDIT_SALE ||
					isPIPO || item.itemType === Constants.ITEM_TY_GIFT_CARD_SALE || item.itemType === Constants.ITEM_TY_GIFT_CARD_TOPUP ||
					item.qty || item.type || item.merchTotal ||
					item.total || item.promoSavings || item.alert || item.discType ||
					(item.initialPrice && item.newPrice >= 0) || item.storeCreditBalance) {
				// do nothing???
			}
			else if(item.purchaseTenders && tranObj.getTranItems().length > 0){
				var spanTender = '<br>';

				_.forEach(item.purchaseTenders, function (tenders) {
					spanTender += createSpan(shrinkText('<br>'+addCurrency(StringUtils.numberToCurrencyString(tenders.amount))),'purchaseTenders');

				});
				return  spanTender;
			}
			else {
				//alert("formatItemUnitPriceColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
			}

			return createSpanStrForItemPrice(contentStr, classStr, tranObj, item, priceOverridden);
		}

		function createSpanStrForItemPrice(contentStr, classStr, tranObj, item, priceOverridden){
			var spanStr = createSpan(contentStr, classStr);
			if (!tranObj._isLocked() && (item.qty === 0 ||  item.qty > 1) && !item.isVoid){
				//spanStr = contentStr;
				spanStr = createSpan(contentStr, classStr);
			}else if(item.itemType === Constants.ITEM_TY_REFUND_PRODUCT || item.itemType === Constants.ITEM_TY_GIFT_CARD_REFUND) {
				if(priceOverridden == true){
					spanStr = contentStr;
				}else{
					spanStr = createSpan(contentStr, classStr);
				}
			}else {
				spanStr = createSpan(contentStr, classStr);
			}
			return spanStr;
		}

		function formatTotalItemPriceColumn(item) {
			//console.log("OVCVirtualReceipt.definitions: formatTotalItemPriceColumn() called:", item);
			var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
 			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
			var priceOverridden = false;
			var value;
			var isPIPO = false;
			if(item.itemType == Constants.ITEM_TY_PAYIN_SALE || item.itemType == Constants.ITEM_TY_PAYIN_CORR_SALE
					|| item.itemType == Constants.ITEM_TY_PAYOUT_SALE || item.itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
				isPIPO = true;
			}

			if (item.initialPrice && item.newPrice >= 0) {
				if(item.specialType ==null){
					// some kind of price override
					classStr = "discount";
					contentStr = toCurrency(((item.newPrice - item.initialPrice)*item.quantity).toFixed(2), false);
				}
			} else if (item.qty &&
					item.itemType !== Constants.ITEM_TY_PROMO &&
					 item.qty === 1) {
					var negSet = false;
					if(classStr == 'refund'){
						negSet = true;
					}
					contentStr = toCurrency((item.price || item.origPrice), negSet);

					var itemIdx = item.tranItemIdx;
					var selectedItem = RetailTransactionHelper.getCurrentTranObj();
					var tranItem = selectedItem.getTranItemByIdx(itemIdx);
					var isChildProduct = (tranItem != null && tranItem.getParentProductIdx() != null && tranItem.getParentProductIdx() != undefined && tranItem.getParentProductIdx() != -1 && tranItem.getParentProductIdx() >= 0);
					
					if(!isChildProduct && (item.itemType === Constants.ITEM_TY_ADD_PRODUCT || item.itemType === Constants.ITEM_TY_REFUND_PRODUCT || item.itemType === Constants.ITEM_TY_GIFT_CARD_REFUND || item.itemType === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
		  			   item.itemType === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT)){

						var isPriceOverridable = tranItem.getIsPriceOverridable();
						if(item.qty && item.qty === 1 && !tranObj._isLocked() && (typeof isPriceOverridable === 'undefined' || isPriceOverridable === '1') && 
								tranItem.getProduct()._productType && tranItem.getProduct()._productType !== "GiftCertificate" && !item.isVoid){
						if (viewPriceOverridePerm.isViewable == 1) {
		 						contentStr = "<input data-dojo-type='dojox/mobile/TextBox' data-dojo-props='constraints:{min:0}' class='mblTextBox ovc-t w18 vrUnitPriceTextBox "+classStr+"' autocomplete='off' value='" + contentStr + "'>";
								priceOverridden = true;
		 					}
						}
				}

			} else if (item.qty &&
					item.itemType !== Constants.ITEM_TY_PROMO &&
					item.itemType !== Constants.ITEM_TY_REFUND_PRODUCT &&
					item.itemType !== Constants.ITEM_TY_GIFT_CARD_REFUND && item.qty > 1){
				contentStr = toCurrency(item.price || item.origPrice);
			} else if (item.qty) {
				// if promo or refund
				contentStr = toCurrency(item.price || item.totalValue, true);
				if (tranObj._appliedToLayaway === 0 && (tranObj.isLayawayFinalize() || tranObj.isLayawayPayment() || tranObj.isLayawaySale()) ) {
					contentStr = contentStr.strike();
				}
			}else if (item.type || item.itemType === Constants.ITEM_TY_NO_SALE
					|| item.itemType === Constants.ITEM_TY_STORECREDIT_SALE || isPIPO ||
					item.itemType === Constants.ITEM_TY_GIFT_CARD_SALE ||
					item.itemType === Constants.ITEM_TY_GIFT_CARD_TOPUP) {
				if (item.itemType === Constants.ITEM_TY_STORECREDIT_SALE) {
					contentStr = toCurrency(item.amount.toFixed(2), false);
					contentStr = contentStr.substring(1);//to Strip the negative sign as per desk check.

				}else{
					contentStr = toCurrency(""+item.amount);
	 				if (item.itemType === Constants.ITEM_TY_TAX_EXEMPT) {
						classStr = "taxExempt";
						contentStr = ResourceManager.getValue("receipts.taxes.leftBrace") + contentStr + ResourceManager.getValue("receipts.taxes.rightBrace");
	 				}
	 				else if (item.itemType === Constants.ITEM_TY_NET_TAX) {
	 					classStr = "netTax";
	 				}
				}
			} else if ((value = (item.merchTotal || item.total || item.promoSavings || item.storeCreditBalance))) {

				if (item.merchTotal || item.total) {
					classStr += " lineAbove";
				}
				contentStr = toCurrency(value);
			} else if (item.alert || item.discType) {
				// do nothing
			} else if(item.itemType === Constants.ITEM_TY_DELIVERY_OPTION){
				contentStr = item.amount; 
			}
			else if(item.giftCardAdjustment != undefined){
				contentStr = StringUtils.numberToCurrencyString(parseFloat(item.giftCardAdjustment.amount), 2, ResourceManager.getValue("currency.symbol"));
			}
			else {
				//alert("formatTotalItemPriceColumn(): assertion failed: unknown item in virtual receipt store " + JSON.stringify(item));
			}

			return createSpanStrForTotalItemPrice(classStr,contentStr,tranObj,item,priceOverridden);
		}

		function createSpanStrForTotalItemPrice(classStr,contentStr,tranObj,item,priceOverridden){
			var spanStr = (classStr.indexOf("lineAbove") > 0) ? createDiv(contentStr, classStr) : createSpan(contentStr, classStr);
			if (!tranObj._isLocked() && item.qty &&
					item.itemType !== Constants.ITEM_TY_PROMO  && item.qty === 1 && !item.isVoid) {
				//spanStr = contentStr;
				spanStr = createSpan(contentStr, classStr);
			} else if(item.itemType === Constants.ITEM_TY_REFUND_PRODUCT || item.itemType === Constants.ITEM_TY_GIFT_CARD_REFUND) {
				if(priceOverridden == true){
					spanStr = contentStr;
				}else{
					spanStr = (classStr.indexOf("lineAbove") > 0) ? createDiv(contentStr, classStr) : createSpan(contentStr, classStr);
				}
			}else {
				spanStr = (classStr.indexOf("lineAbove") > 0) ? createDiv(contentStr, classStr) : createSpan(contentStr, classStr);
			}
			//console.log("OVCVirtualReceipt.definitions: formatTotalItemPriceColumn() returning:", spanStr);
			return spanStr;
		}

		function formatTaxableItemIndicatorColumn(item) {

			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
  			if(item.tax != undefined && item.tax !=null){
  				contentStr = item.tax;
			}

			var spanStr = createSpan(contentStr, classStr);
			//console.log("OVCVirtualReceipt.definitions: formatTaxableItemIndicatorColumn() returning:", spanStr);
			return spanStr;
		}

		function formatSalesPersonColumn(item) {
			var classStr = getProductClasses(item.itemType, item.isVoid);
			var contentStr = "";
  			if(item.salesPerson != undefined && item.salesPerson !=null && item.salesPerson != ''){

  				var existingUsers = localStorage.getObject("users") || {};
  				var toolTip = existingUsers[item.salesPerson].firstName+' '+existingUsers[item.salesPerson].lastName
  				contentStr = "<span class=\"salesPerson-avatar-img\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/SalesPerson/PromptForSalesPerson.ovcprc',{ override: 'true'});\" style=\"background-color: "+item.backGroundColor+";\"><a  title=\""+toolTip+"\" ><text style=\"color:white;\">"+(existingUsers[item.salesPerson].firstName).charAt(0).toUpperCase()+"</text></a></span>";
			} else if(item.itemType === Constants.ITEM_TY_ADD_PRODUCT){
				contentStr = "<span class=\"salesPerson-avatar-img\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/SalesPerson/PromptForSalesPerson.ovcprc',{ override: 'true'});\" style=\"background-color:#666666;\"><a><text style=\"color:white;\"></text></a></span>";
			}

			var spanStr = createSpan(contentStr, classStr);
			return spanStr;
		}

		function formatVoidIcon(item) {
			var classStr = getProductClasses(item.itemType, false);
			var contentStr = "";
			var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
			var imageIcon = 'voidIcon.png';
			if (tranObj.getReceiptJSON() &&
					tranObj.getReceiptJSON().tenders &&
					tranObj.getReceiptJSON().tenders.length > 0){

			}
			else if(!tranObj._isLocked() && (item.itemType === Constants.ITEM_TY_ADD_PRODUCT || item.itemType === Constants.ITEM_TY_REFUND_PRODUCT || item.itemType === Constants.ITEM_TY_GIFT_CARD_REFUND || item.itemType === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
  					item.itemType === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT || item.itemType === Constants.ITEM_TY_APPOINTMENT || item.itemType === Constants.ITEM_TY_GIFT_CARD_SALE
  					|| item.itemType === Constants.ITEM_TY_GIFT_CARD_TOPUP)
  					&& tranObj.getTotalLineItemsExceptDiscounts() > 1 && !item.isVoid){
  				//if(!item.isFee && ((tranObj.getTotalLineItemsExceptDiscounts() - tranObj.getTotalFeeItemsCount() == 1) || item.qty === 0)){
					/*
					 * if there is ONLY ONE item (non-voided product/pickup/appt/refund),
					 * and multiple fees associated to that item, then add void icon only for the fees.
					 * If all fees are voided for the product, only a tran-void can be performed.
					 * If the item itself needs to be voided, tran-void can be performed since it is
					 * the only "product" on the receipt.
					 * */
				//}
				//else{
					var dialogTitle = ResourceManager.getValue("menus.voids.item");
	  				var dialogMsg = ResourceManager.getValue("menus.voids.itemVoidReasonDialogMsg");
				var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmItemVoid;
	  				var confirmationMsg = ResourceManager.getValue("menus.voids.itemVoidConfirmMsg");

				if (viewItemVoidPerm.isViewable == 1) {
					contentStr = "<img  width=\"45\" height=\"45\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialog.ovcprc',{ reasonCodeType: 'void', scopeType: '1', dialogTitle :'"+dialogTitle+"', dialogMsg : '"+dialogMsg+"',showConfirmation : '"+showConfirmation+"', confirmationMsg : '"+confirmationMsg+"'});\" src="+base + "/../../dynamicblob/posMClient/"+imageIcon+">";
					}
				//}

			} else if(!tranObj._isLocked() && (item.itemType === Constants.ITEM_TY_DISCOUNT_ITEM || item.itemType === Constants.ITEM_TY_DISCOUNT_TXN) && !item.isVoid ){
				var dialogTitle = ResourceManager.getValue("menus.voids.discount");
  				var dialogMsg = ResourceManager.getValue("menus.voids.discountVoidReasonDialogMsg");
				var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmItemVoid;
  				var confirmationMsg = ResourceManager.getValue("menus.voids.discountVoidConfirmMsg");
				if (viewDiscountVoidPerm.isViewable == 1) {
	  				contentStr = "<img width=\"45\" height=\"45\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialog.ovcprc',{ reasonCodeType: 'void', scopeType: '4', dialogTitle :'"+dialogTitle+"', dialogMsg : '"+dialogMsg+"',showConfirmation : '"+showConfirmation+"', confirmationMsg : '"+confirmationMsg+"'});\" src="+base + "/../../dynamicblob/posMClient/"+imageIcon+">";
				}
			}else if(!tranObj._isLocked() && (item.itemType === Constants.ITEM_TY_STORE_COLLECT_OPTION || item.itemType === Constants.ITEM_TY_DELIVERY_OPTION) && !item.isVoid ){
				var dialogTitle = ResourceManager.getValue("menus.voids.deliveryVoid");
  				var dialogMsg = ResourceManager.getValue("menus.voids.itemVoidReasonDialogMsg");
				var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmItemVoid;
  				var confirmationMsg = ResourceManager.getValue("menus.voids.itemVoidConfirmMsg");
				if (viewDeliveryOptionVoidPerm.isViewable == 1) {
	  				contentStr = "<img  width=\"45\" height=\"45\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialog.ovcprc',{ reasonCodeType: 'void', scopeType: '4', dialogTitle :'"+dialogTitle+"', dialogMsg : '"+dialogMsg+"',showConfirmation : '"+showConfirmation+"', confirmationMsg : '"+confirmationMsg+"'});\" src="+base + "/../../dynamicblob/posMClient/"+imageIcon+">";
  				}
			}else if(!tranObj._isLocked() && item.specialType === "priceOverride" && !item.isVoid ){

 				var dialogTitle = ResourceManager.getValue("menus.voids.item");
  				var dialogMsg = ResourceManager.getValue("menus.voids.itemVoidReasonDialogMsg");
				var showConfirmation = ConfigManager.getConfigObject("posMClient/sales.ovccfg").confirmItemVoid;
  				var confirmationMsg = ResourceManager.getValue("menus.voids.itemVoidConfirmMsg");
				if (viewPriceOverrideVoidPerm.isViewable == 1) {
	  				contentStr = "<img  width=\"45\" height=\"45\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialog.ovcprc',{ reasonCodeType: 'void', scopeType: '4', dialogTitle :'"+dialogTitle+"', dialogMsg : '"+dialogMsg+"',showConfirmation : '"+showConfirmation+"', confirmationMsg : '"+confirmationMsg+"'});\" src="+base + "/../../dynamicblob/posMClient/"+imageIcon+">";
  				}
			}


			var spanStr = createSpan(contentStr, classStr);
			return spanStr;

		}

		String.prototype.capitalizeFirstLetter = function() {
		    return this.charAt(0).toUpperCase() + this.slice(1);
		}
		function getVRGridColumns() {
			var columns = {

					itemNum: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnItem"),
						sortable: false,
						formatter: formatItemColumn
					},
					description: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnName"),
						sortable: false,
						formatter: formatNameColumn
					},
//					style: {
//						field: "_item",
//						label: ResourceManager.getValue("virtualReceipt.style"),
//						soratble: false,
//						formatter: formatStyleColumn
//					},
					qty: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnQty"),
						sortable: false,
						formatter: formatQtyColumn
					},
					unitPrice: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnItemUnitPrice"),
						sortable: false,
						formatter: formatItemUnitPriceColumn
					},
					price: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnItemTotalPrice"),
						sortable: false,
						formatter: formatTotalItemPriceColumn
					},
					tax: {
						field: "_item", // get whole item for use by formatter
						label: ResourceManager.getValue("virtualReceipt.columnTaxableItemIndicator"),
						sortable: false,
						formatter: formatTaxableItemIndicatorColumn
					}
			};

			var promptForSalesPerson = ConfigManager.getConfigObject("posMClient/app.ovccfg").promptForSalesPerson;
			var showSalesPersonAvatar = ConfigManager.getConfigObject("posMClient/app.ovccfg").showSalesPersonAvatar;
			if (promptForSalesPerson === 1 && showSalesPersonAvatar === 1) {
				var salesPerson = {
					field: "_item", // get whole item for use by formatter
					label: ResourceManager.getValue("virtualReceipt.columnSalesPerson"),
					sortable: false,
					formatter: formatSalesPersonColumn
				};
				columns.salesPerson = salesPerson;
			}

 			// Add the feature configuration here for void icon visibility in VR
			if(true){
				var voidIcon = {
					field: "_item", // get whole item for use by formatter
					label: '',
					sortable: false,
					formatter: formatVoidIcon
				};
				columns.voidIcon = voidIcon;
			}

			return columns;

		}

		return {
			gridDefinition: {
				store: new Memory({idProperty: "recordId"}),
				loadingMessage: ResourceManager.getValue("virtualReceipt.loadingTransactionData"),
				noDataMessage: ResourceManager.getValue("virtualReceipt.noTransactionData"),
				keepScrollPosition: true,
				selectionMode: "single",
				deselectOnRefresh: false,
				cellNavigation: false,
				columns: getVRGridColumns()
			}
		};
	});
