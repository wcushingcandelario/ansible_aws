define([
	"dojo/dom",
	"dojo/_base/declare",
	"dojo/_base/lang",
	"dojo/dom-class",
	"dojo/dom-construct",
	"dojo/dom-style",
	"dojo/dom-geometry",
	"dojo/json",
	"dojo/has!testing?dojo/text!./definitions.json:dojo/text!./OVCSearchCenter.definitions.json",
	"dojo/store/Memory",
	"dojo/store/Observable",
	"dijit/registry",
	"dijit/_WidgetBase",
	"dijit/_TemplatedMixin",
	"dijit/_OnDijitClickMixin",
	"dijit/_WidgetsInTemplateMixin",
	"dojo/has!testing?dojo/text!./widget.html:dojo/text!./OVCSearchCenter.widget.html",
	"generic/OVCDialogMenuButton.widget",
	"generic/ResourceManager",
	"generic/StringUtils",
	"dojox/mobile/TabBarButton",
	"dojox/mobile/View",
	"dojox/mobile/SearchBox",
	"dojox/mobile/CheckBox",
	"dojox/mobile/RadioButton",
	"dojox/mobile/Switch",
	"dijit/form/FilteringSelect",
	"dojox/mobile/Container",
	"dgrid/OnDemandGrid",
	"dgrid/Selection",
	"dojox/mobile/Button",
	"dojox/mobile/TabBar",
	"dojox/mobile/ToolBarButton",
	"dojox/mobile/Button",
	"dojox/mobile/SimpleDialog",
	"dojox/mobile/ListItem",
	"dojox/mobile/EdgeToEdgeList",
	"dojo/_base/declare",
	"dojox/mobile/EdgeToEdgeCategory",
	"dojo/query"
], function (dom,
             declare,
             lang,
             domClass,
             domConstruct,
             domStyle,
             domGeometry,
             JSON,
             jsonData,
             Memory,
             Observable,
             registry,
             _WidgetBase,
             _TemplatedMixin,
             _OnDijitClickMixin,
             _WidgetsInTemplateMixin,
             template,
             OVCDialogMenuButton,
             ResourceManager,
             StringUtils,
             TabBarButton,
             View,
             SearchBox,
             CheckBox,
             RadioButton,
             Switch,
             FilteringSelect,
             Container,
             OnDemandGrid,
             Selection,
             Button) {

	// This function has a local copy of the variables it was passed
	// so the values will not change as the loop iterates
	function makeButtonEvent(eventType, captureData, context) {
		return lang.hitch(context, function () {
			this._buttonClick(eventType, captureData);
		});
	}
	  
	function successfulMerchLookup(filteringSelect, res){
		var merchResults = res.resultSet;
		merchResults.push({"id":"default","name":"Please select category"});
		filteringSelect.set("store",new Observable(new Memory({data: merchResults})));
		//filteringSelect.refresh();
	}

	function buildButtonContainer(buttonDefinitions) {
		var buttonContainerNode =
			domConstruct.create("div", { class: "buttonContainer" });

		for (var i = 0; i < buttonDefinitions.length; i++) {
			var buttonDefinition = buttonDefinitions[i];
			var label = ResourceManager.getValue(buttonDefinition.label);

			var eventType = buttonDefinition.eventType;
					
			var enableStylematrix = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").enableStylematrix;
						
			if((eventType == 'showStyleMatrix') && (enableStylematrix == 0 || enableStylematrix == undefined)){
				continue;
			}
			// captureData is always true for submit events
			var captureData = buttonDefinition.captureData;
			if (eventType == "submit" && !captureData) {
				captureData = true;
			}

			var type = eventType === "Submit" ? "submit" : "button";
			var button = new Button({
				class: "searchButton",
				label: label,
				type: type,
				name: (buttonDefinition.identifier)?buttonDefinition.identifier:""
			}).placeAt(buttonContainerNode);
			button.startup();

			// use a function to pass the correct values of the params as we process the array
			// @see makeButtonEvent()
			if (type !== "submit") {
				button.on(require("dojo/touch").press, makeButtonEvent(eventType, captureData, this));
			}
		}
		return buttonContainerNode;
	}
	
	function formatRetailPriceColumn(item) {
		
		return StringUtils.numberToCurrencyString(item.iPrice,ResourceManager.getValue("currency.precision"),true);
	}

	function buildGrid(json, searchType) {
		/* * == required field
		 *columns
		 *store
		 loadingMessage
		 noDataMessage
		 */
		// all controls go inside the form
		// create the specified widget, with options, and place it "last" in the formLayout
		
		var configuredColumns = [];
		var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");
		switch (searchType){
			
//			case ResourceManager.getValue("searchCenter.productsSearchType"):
//				if (posConfig.searchCenterProductsGridColumns && posConfig.searchCenterProductsGridColumns != null){
//					configuredColumns = posConfig.searchCenterProductsGridColumns.split(',');
//				}
//			break;
		
			case ResourceManager.getValue("searchCenter.ordersSearchType"):
				if (posConfig.searchCenterOrdersGridColumns && posConfig.searchCenterOrdersGridColumns != null){
					configuredColumns = posConfig.searchCenterOrdersGridColumns.split(',');
				}
			break;
			
			case ResourceManager.getValue("searchCenter.customersSearchType"):
				if (posConfig.searchCenterCustomersGridColumns && posConfig.searchCenterCustomersGridColumns != null){
					configuredColumns = posConfig.searchCenterCustomersGridColumns.split(',');
				}
			break;
			
			case ResourceManager.getValue("searchCenter.suspendedSearchType"):
				if (posConfig.searchCenterSuspendedGridColumns && posConfig.searchCenterSuspendedGridColumns != null){
					configuredColumns = posConfig.searchCenterSuspendedGridColumns.split(',');
				}
			break;
			
			case ResourceManager.getValue("searchCenter.layawaySearchType"):
				if (posConfig.searchCenterLayawayGridColumns && posConfig.searchCenterLayawayGridColumns != null){
					configuredColumns = posConfig.searchCenterLayawayGridColumns.split(',');
				}
			break;

			case ResourceManager.getValue("searchCenter.quoteSearchType"):
				if (posConfig.searchCenterQuoteGridColumns && posConfig.searchCenterQuoteGridColumns != null){
					configuredColumns = posConfig.searchCenterQuoteGridColumns.split(',');
				}
				break;
				
			case ResourceManager.getValue("searchCenter.receiptSearchType"):
				if (posConfig.searchCenterReceiptGridColumns && posConfig.searchCenterReceiptGridColumns != null){
					configuredColumns = posConfig.searchCenterReceiptGridColumns.split(',');
				}
				break;
		}
		
		// lookup json resource file column names before creating the grid
		var resourceColumnNames = {};
		for (var column in json.columns) {
			if (configuredColumns && configuredColumns != null && configuredColumns.length>0){
				if (json.columns.hasOwnProperty(column) && configuredColumns.indexOf(column) != -1) {
					if(column === 'iPrice'){
						
						resourceColumnNames[column] = { field: "_item", // get whole item for use by formatter
														label: ResourceManager.getValue(json.columns[column]),
														formatter: formatRetailPriceColumn
													  };
						
					} else {
					resourceColumnNames[column] = ResourceManager.getValue(json.columns[column]);
					}
				}
				else {
					if(json.uniqueId == column){
						//if column is uniqueId in the definitions.json, display it.
						// unique (id) columns must always be shown as the first column to enable selecting.
						resourceColumnNames[column] = ResourceManager.getValue(json.columns[column]);
					}
				}
			}
			else{
				if (json.columns.hasOwnProperty(column)) {
					if(column === 'iPrice'){
						resourceColumnNames[column] = { field: "_item", // get whole item for use by formatter
														label: ResourceManager.getValue(json.columns[column]),
														formatter: formatRetailPriceColumn
													  };
						
					} else {
						resourceColumnNames[column] = ResourceManager.getValue(json.columns[column]);
					}
				}
			}
		}

		var grid = new (declare([OnDemandGrid, Selection]))({
				columns: resourceColumnNames,
				store: json.store,
				loadingMessage: ResourceManager.getValue(json.loadingMessage),
				noDataMessage: ResourceManager.getValue(json.noDataMessage),
				keepScrollPosition: true,
				deselectOnRefresh: false, // refresh should not clear selection
				cellNavigation: false  // for Keyboard; allow only row-level keyboard navigation
			}, "grid");
		grid.startup();
		
		grid.on("dgrid-refresh-complete", function(event) {
			if (grid.store.data.length > 0){
				grid.noDataMessage = "";
			}
			else{
				grid.noDataMessage = ResourceManager.getValue(json.noDataMessage);
			}
		});
		
		grid.on(".dgrid-row:click",  function (event) {
			//console.log("Got a .dgrid-row:click: ", event);
			
			var clickedRow = grid.row(this);

			// toggle dom class for UI selection indicator
			var rowNode = clickedRow.element;
			//console.log("Clicked row node: ", rowNode);
			domClass.toggle(rowNode, "selectedGridRow");
//			domClass.toggle(rowNode, "dgrid-selected");

			var idCell = this.children[0].children[0].children[0];
			var selectedId = idCell.innerHTML;
			//console.log("this.children[0].children[0].children[0]: ", idCell);

			// find the store data for the "uniqueId" value
			var query = {};
			query[json.uniqueId] = selectedId;
			var selectedData = grid.store.query(query);

			// toggle selected flag for model data
			selectedData[0].selected = !selectedData[0].selected;
			//console.log("Clicked row data: ", selectedData[0]);
			
			

			if (json.selectionMode === "single") {
				// only allow single selection
				if (selectedData[0].selected) {
					// selected a new row, so clean up the previous selected row
					if (grid.lastSelectedRow) {
						grid.lastSelectedRow.selected = false;
						domClass.toggle(grid.lastSelectedRowNode, "selectedGridRow");
						domClass.toggle(grid.lastSelectedRowNode, "dgrid-selected");
					}

					// save the newly-selected row
					grid.lastSelectedRow = selectedData[0];
					grid.lastSelectedRowNode = rowNode; 
				} else {
					// un-selected the last selected row, so reset the tracking vars
					grid.lastSelectedRow = undefined;
					grid.lastSelectedRowNode = undefined;
				}
			}
			
			//hiding the style matrix button if product is not eligible....
			if(selectedData[0] && selectedData[0].productType){
				var nodes = require("dojo/query")(".OVCSearchCenter .buttonContainer")[0].children;
				var styleMatrixNode;
				for (var idx = 0, length = nodes.length; idx < length; idx++) {
					if (nodes[idx].name == "matrix") {
						styleMatrixNode = nodes[idx];
					}
				}
			var enableStylematrix = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").enableStylematrix;
			if(styleMatrixNode && enableStylematrix === 1){
					if(selectedData[0].productType != "StyleSizeColor"){
						domStyle.set(styleMatrixNode, "display", "none");
					}else{
						domStyle.set(styleMatrixNode, "display", "initial");
					}
				}else{
						domStyle.set(styleMatrixNode, "display", "none");
				 	}		 				
			}
		});

		return grid;
	}

	var widget = declare("posmclient/OVCSearchCenter/widget", [ _WidgetBase, _TemplatedMixin, _OnDijitClickMixin, _WidgetsInTemplateMixin ], {

		// Our template - important!
		templateString: template,

		views: null,
		tabBarButtons: null,
		defaultView: null,

		constructor: function () {
			this.views = {};
			this.tabBarButtons = {};
		},
		
		buildRendering: function () {
			this.inherited(arguments);

			//console.log("OVCSearchCenter.buildRendering() called");

			// parse the json and process the resulting object to build the UI
			var selected = true; // default to viewing the first definition
			var definitions = JSON.parse(jsonData);
			var searchViewsCount = definitions.searchViews.length;
			var searchView;
			var tabBarButton;
			var tabView;
			var searchToolBar;
			var searchType;
			var searchFilter;
			var searchBox;
			var checkBox;
			var radioButton;
			var toggleSwitch;
			var filteringSelect;
			var grid;
			var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");
			var SearchFieldsUI = [];
			
			// save the default view (see enableNavigation() for usage)
			this.defaultView = ResourceManager.getValue(definitions.defaultView);

			for (var i = 0; i < searchViewsCount; i++) {
				
				searchView = definitions.searchViews[i];
				searchType = ResourceManager.getValue(searchView.searchType);
				//console.log("  processing '" + searchType + "' view");

				// create a View and a TabBarButton (to "moveTo" the view) for this searchView
				tabView = new View({
					id: searchType,
					selected: selected
				}).placeAt(this.searchViewsContainer);
				// label-to-tabView collection
				this.views[searchType] = tabView;

				tabBarButton = new TabBarButton({
					label: searchType,
					moveTo: tabView.get("id"),
					selected: selected,
					display: "inline",
					tabIndex: i
				}).placeAt(this.searchTabBar);
				tabBarButton.startup();
				
				// set visibility of the tab bar button
				var tabBarButtonNode = tabBarButton.domNode;
				if (!searchView.visible) {
					domStyle.set(tabBarButtonNode, "display", "none");
				} else {
					domStyle.set(tabBarButtonNode, "display", "initial");
				}

				// label-to-tabButton collection
				this.tabBarButtons[searchType] = tabBarButton;

				/*----- Start Search Toolbar -----*/
				// only create the search toolbar if specified
				if (searchView.searchFilterList.length > 0) {
					// container search widgets
					searchToolBar = new Container({
						class: "searchToolBar"
					}).placeAt(tabView);
					searchToolBar.startup();
					tabView.searchToolBar = searchToolBar;
					switch (searchType){
//						case "Products":
//							SearchFieldsUI = posConfig.productSearchFields.split(',');
//							break;
						case "Orders":
							SearchFieldsUI = posConfig.orderSearchFields.split(',');
							break;
						case "Customers":
							SearchFieldsUI = posConfig.customerSearchFields.split(',');
							break;
						case "Layaway":
							SearchFieldsUI = posConfig.layawaySearchFields.split(',');
							break;
						case "Quotes":
							SearchFieldsUI = posConfig.quoteSearchFields.split(',');
							break;
						case "Suspended":
							SearchFieldsUI = posConfig.suspendResumeSearchFields.split(',');
							break;
					}
					
					for (var j = 0; j < definitions.searchViews[i].searchFields.length; j++) {
						// Only show search fields that is configured 
						if (SearchFieldsUI != null && SearchFieldsUI.indexOf(definitions.searchViews[i].searchFields[j].id)!=-1){
							
							var type = definitions.searchViews[i].searchFields[j].type;
							switch (type) {
								case "TextBox":
									searchBox = new SearchBox({
										id: definitions.searchViews[i].searchFields[j].id,
										placeHolder: ResourceManager.getValue(definitions.searchViews[i].searchFields[j].placeHolder),
										type: "search",
										onChange: lang.hitch(this, function (evt) {
											this.emit('searchBoxChanged',{evt:evt});
										})
									}).placeAt(searchToolBar);

									searchBox.startup();
									tabView.searchBox = searchBox;
									
									searchBox.on("input", lang.hitch(this, function(e){
										if(e.keyCode == 13 && e.type == "keydown" && e.keyIdentifier == "Enter"){
											document.activeElement.blur(); //
					 					}
									}));
									break;
								case "CheckBox":
									checkBox = new CheckBox({
										id: definitions.searchViews[i].searchFields[j].id,
										checked: definitions.searchViews[i].searchFields[j] || false,
										onChange: lang.hitch(this, function (evt) {
											this.emit('searchBoxChanged',{evt:evt});
										})
									}).placeAt(searchToolBar);
									tabView.checkBox = checkBox;
									domConstruct.create("label", {innerHTML: definitions.searchViews[i].searchFields[j].label || ""}, searchToolBar);
									break;
								case "RadioButton":
									radioButton = new RadioButton({
										id: definitions.searchViews[i].searchFields[j].id,
										checked: definitions.searchViews[i].searchFields[j].checked || false,
										onChange: lang.hitch(this, function (evt) {
											this.emit('searchBoxChanged',{evt:evt});
										})
									}).placeAt(searchToolBar);
									tabView.radioButton = radioButton;
									domConstruct.create("label", {innerHTML: definitions.searchViews[i].searchFields[j].label || ""}, searchToolBar);
									break;
								case "Switch":
									toggleSwitch = new Switch({
										id: definitions.searchViews[i].searchFields[j].id,
										leftLabel: definitions.searchViews[i].searchFields[j].leftLabel || "",
										rightLabel: definitions.searchViews[i].searchFields[j].rightLabel || "",
										shape: definitions.searchViews[i].searchFields[j].shape || "mblSwDefaultShape"
									}).placeAt(searchToolBar);
									tabView.toggleSwitch = toggleSwitch;
									domConstruct.create("label", {innerHTML: definitions.searchViews[i].searchFields[j].label || ""}, searchToolBar);
									break;
								case "FilteringSelect":
									var merchResults = [{"id":"default",
														"name":ResourceManager.getValue(definitions.searchViews[i].searchFields[j].placeHolder)}];
									var merchStore = new Observable(new Memory({data: merchResults}));
									filteringSelect = new FilteringSelect({
										id: definitions.searchViews[i].searchFields[j].id,
										name: ResourceManager.getValue(definitions.searchViews[i].searchFields[j].placeHolder),
										value: "default",
										store: merchStore,
										searchAttr: "name",
										pageSize: 15,
										onChange: lang.hitch(this, function (evt) {
											this.emit('searchBoxChanged',{evt:evt});
										})
									}).placeAt(searchToolBar);
									tabView.filteringSelect = filteringSelect;
									
									require(["dojo/when"], function (when) {
										when(require("ovc/ProcessEngine").invokeProcess(
										'posMClient/GetAllMerchandiseGroups.ovcprc',
										{}), lang.partial(successfulMerchLookup,filteringSelect));
									});
									
									break;
							}							
						}
					}

				} else {
					//console.log("No search criteria specified for: " + searchType);
				}
				/*----- End Search Toolbar -----*/

				grid = buildGrid(searchView.gridDefinitions, searchType);
				domConstruct.place(grid.domNode, tabView.domNode);
				tabView.grid = grid;

				// use hitch to get the proper "this" for buildButtonContainer
				buttonsContainerNode = (lang.hitch(this, buildButtonContainer))(searchView.buttonDefinitions);
				domConstruct.place(buttonsContainerNode, tabView.domNode);
				tabView.buttonsContainerNode = buttonsContainerNode;

				// after the first view, all subsequent views are not selected
				if (selected) {
					selected = false;
				}

				function resizeGrid() {
					//console.log("resizeGrid: ", grid);
					var searchCenter = registry.byId("searchCenter");

					// get height of searchCenter
					var searchCenterH = domGeometry.getMarginSize(searchCenter.domNode).h;
					//console.log("searchCenterH: " + searchCenterH);

					var tabView;
					for (var searchType in searchCenter.views) {
						if (searchCenter.views.hasOwnProperty(searchType)) {
							tabView = searchCenter.views[searchType];
							
							if (tabView.isVisible(false)) {
								var grid = tabView.grid;
									// get height of searchTabBar (@see widget.html)
								var searchTabBarH = domGeometry.getMarginSize(dom.byId("searchTabBar")).h;
								//console.log("searchTabBarH: " + searchTabBarH);

								// get height of searchToolBar
								var searchToolBarH = 0;
								if (tabView.searchToolBar) {
									searchToolBarH = domGeometry.getMarginSize(tabView.searchToolBar.domNode).h;
									//console.log("searchToolBarH: " + searchToolBarH);
								}

								// get height of buttonContainer
								var buttonContainerH = domGeometry.getMarginSize(tabView.buttonsContainerNode).h;
								//console.log("buttonContainerH: " + buttonContainerH);

								var gridH = searchCenterH - (searchTabBarH + searchToolBarH + buttonContainerH);
								//console.log("gridH: " + gridH);

								// adjust the grid to fill the remaining screen height
								domStyle.set(grid.domNode, "height", gridH/16 + "em");
 								if(grid.domNode && grid.domNode != null &&
 								   grid.domNode.childNodes && grid.domNode.childNodes != null &&
 								   grid.domNode.childNodes.length > 1){
 									domStyle.set(grid.domNode.childNodes[1], "overflow-y", "auto"); 
 									domStyle.set(grid.domNode.childNodes[1], "max-height", gridH/16 + "em");
 								}

								grid.resize();

								return;
							}
						}
					}

					//console.log("resizeGrid(): did not find a view containing the grid: ", grid);
				}

				
				tabView.on("AfterTransitionIn", resizeGrid);
			}
			registry.byId('searchCenterView').on("AfterTransitionIn", resizeGrid);
		},

		postCreate: function () {
			this.inherited(arguments);

			//console.log("OVCSearchCenter.postCreate() called");
		},

		startup: function () {
			this.inherited(arguments);
			//console.log("OVCSearchCenter.startup() called");

			// need to pull in the controller
			require(["posmclient/OVCSearchCenter.controller"]);
			this.resize();
		},

		resize: function () {
			this.inherited(arguments);
			//console.log("OVCSearchCenter.resize() called: ", arguments);
		},

		_submit: function (e) {
			e.preventDefault();
			this._buttonClick("Submit", true);
		},
		
		_buttonClick: function (eventType, captureData) {
			//console.log("_buttonClick called for event: " + eventType + ", captureData: " + captureData);

			// object to emit
			var event = {};

			// emit eventType
			
			this.emit(eventType, event);
		},

		// activeTab: tab to leave hidden
		enableNavigation: function (activeTab) {
			for (var view in this.tabBarButtons) {
				if (this.tabBarButtons.hasOwnProperty(view)) {
					var tabBarButton = this.tabBarButtons[view];

//					if (!this._lastSelected || this._lastSelected === activeTab) {
//						// if no last selected tab or the active tab is being hidden, re-select the default tab
//						this._lastSelected = this.defaultView;
//					}

					var tabBarButtonNode = tabBarButton.domNode;
					
					if (view === activeTab) {
						// hide this tab
						domStyle.set(tabBarButtonNode, "display", "none");
					} else {
						// show this tab
						domStyle.set(tabBarButtonNode, "display", "initial");
					}

					// re-select the last selected view
//					if (this._lastSelected === view) {
//						tabBarButton.defaultClickAction({clientX: 0, clientY: 0});
//					}
				}
			}

			// reset
			//this._lastSelected = undefined;
		},

		// activeTab: tab to leave visible
		disableNavigation: function (activeTab) {
			for (var view in this.tabBarButtons) {
				if (this.tabBarButtons.hasOwnProperty(view)) {
					var tabBarButton = this.tabBarButtons[view];

//					if (tabBarButton.get('selected')) {
//						// save off the selected tab to re-selected during enableNavigation()
//						this._lastSelected = view;
//					}
					
					var tabBarButtonNode = tabBarButton.domNode;
					if (view !== activeTab) {
						// hide this tab
						domStyle.set(tabBarButtonNode, "display", "none");
					} else {
						// reset the grid, show the tab and select it
						this.views[view].grid.set("store", null);
						domStyle.set(tabBarButtonNode, "display", "initial");
						domStyle.set(tabBarButtonNode, "margin-left", "15%");
						tabBarButton.defaultClickAction({clientX: 0, clientY: 0});
					}
				}
			}
		}
	});

	widget.buildGrid = buildGrid;

	return widget;
});

