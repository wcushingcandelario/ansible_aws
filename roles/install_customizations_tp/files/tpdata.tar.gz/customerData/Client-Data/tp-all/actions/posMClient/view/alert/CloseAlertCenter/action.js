require(["dijit/registry", "dojo/dom", "ovc/ProcessEngine"],
 		function (registry, dom, ProcessEngine){
 			/*var clickableImage = dom.byId("headingLogoMenu");
			registry.byId(clickableImage.activeView).performTransition("posView", -1, "slidev");
			clickableImage.activeView = "posView";
			ProcessEngine.invokeProcess('posMClient/SetScanTarget.ovcprc', { page: 'pos' });*/
			var clickableImage = dom.byId("headingLogoLeft");
			if(!processMem.inputParams.VRcustomerPOP || processMem.inputParams.VRcustomerPOP == undefined){
				if(registry.byId(clickableImage.activeView) != "posView"){
					registry.byId(clickableImage.activeView).performTransition("posView", -1, "slidev");
				}
			}
			
			clickableImage.activeView = "posView";
			ProcessEngine.invokeProcess('posMClient/SetScanTarget.ovcprc', { page: 'pos' });
		});

 
return {};