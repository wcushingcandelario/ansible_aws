//debugger;//BuildReceiptFromTransaction action.js in Tp
var deferred = new Deferred();

//TODO : convert this action to a process with multiple actions to handle the different calculations of the receipt
require(["generic/Constants", "generic/StringUtils", "generic/GenericUtils", "ovc/ConfigManager", "generic/ResourceManager"],
	function (Constants, StringUtils, GenericUtils, configManager, ResourceManager) {
		var tranObj = inputParams.tranObj;
		var totalDiscountsValue = 0.0;
		var receiptObj = buildReceiptFromTransaction(tranObj);
		deferred.resolve(receiptObj);


		function buildReceiptFromTransaction(tranObj) {
			var isTraining = tranObj.getTraining();
			var currencyId = tranObj.getCurrencyId();
			var tranItemList = tranObj.getTranItems();
			var receiptData = {};
			var allData = []; // all items for the virtual receipt
			var nonVoidData = []; // just non-void items for printed receipts
			var summary = {
				merchTotal: "0.00",
				totalItems: 0,
				purchasedItems: 0,
				returnedItems: 0,
				balance: "0.00",
				change: "0.00",
				storeCreditBalance: null,
				oldStoreCreditBalance: null,
				usedStoreCreditBalance: null

			};
			var tenders = [];
			var totalPayment = 0;

			var tranItem;
			var noOfTranItems = tranItemList.length;

			var calculatedTranItemsHistory = tranObj.getCalculatedTranItemsHistory();

			var giftCardItems = [];
			var BBASMap = {};
			var customerName = {
					name: null
			};
			
			// efficient deep copy of the alerts
			var calculatedAlerts = {};
			if (tranObj.getCalculatedAlerts()) {
				calculatedAlerts = JSON.parse(JSON.stringify(tranObj.getCalculatedAlerts()));
			}

			for (var i = 0; i < noOfTranItems; i++) {
				tranItem = tranItemList[i];
				var itemType = tranItem.getItemType();
				// add, refund or pickup
				if (itemType == Constants.ITEM_TY_ADD_PRODUCT ||
					itemType == Constants.ITEM_TY_REFUND_PRODUCT ||
					itemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
					itemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
					itemType == Constants.ITEM_TY_APPOINTMENT) {
					// process all product-related items (including voids)
					(itemType == Constants.ITEM_TY_REFUND_PRODUCT) ? (summary.returnedItems += 1) : (summary.purchasedItems += 1);
//					var isProductExempt = tranItem.getProduct().getTaxRates()[0].getTaxRateId();
//					var isCustomerTaxExempt = tranObj.getCustomerTaxExempt() ? true: false;
//					var isTaxValueT = false;
//					if((isProductExempt === tranObj.getDefaultTaxRate()) && (isCustomerTaxExempt != undefined && isCustomerTaxExempt != null && isCustomerTaxExempt) ){
//						isTaxValueT = true;
//					}
//					if(itemType == Constants.ITEM_TY_REFUND_PRODUCT){
//						isTaxValueT = false;
//					}
					var isTaxExempt = tranObj.isCustomerTaxExempt();

					var record = getItemJsonRecord(tranItem, isTaxExempt);
					var nonVoidRecord = null;
					var productAlert = calculatedAlerts[tranItem.getProductId()];
					if (productAlert) {
						productAlert.index = allData.length;
					}

					// history could be undefined
					var calculatedTranItemHistory = calculatedTranItemsHistory[i];

					var history = calculatedTranItemHistory && calculatedTranItemHistory.history;
					var histLen = history ? history.length : 0;

					var isItemVoid = tranObj.isTranItemVoid(tranObj.getTranItems(), tranItem, false);
					if (isItemVoid) {
						record.isVoid = true;
						allData.push(record);
					} else {
						var itemDiscounts = [];
						var nonVoidItemDiscounts = [];
						var nonVoidDiscForEachItem = [];
						var nonVoidPriceOverrides = [];
						var txnDiscounts = [];
						var priceOverrides = [];
						var BBASEntries = [];
						var promos = {};
						var avlPromos = {};
						var discForEachItem = [];
						for (var j = 0; j < histLen; j++) {
							var historyItem = history[j];
							if (!historyItem.isPromo) {
								var histTranItem = tranItemList[historyItem.itemIdxKey];
								if (histTranItem && histTranItem != null) {
									var histTranItemItemType = histTranItem.getItemType();
									// discounts
									if (histTranItemItemType == Constants.ITEM_TY_DISCOUNT_ITEM) {
										itemDiscounts.push(buildDiscObj(histTranItem, tranItem));
									}
									else if (histTranItemItemType == Constants.ITEM_TY_VOID_DISCOUNT_ITEM && itemDiscounts != null) {//Based on the RefItmIdx - void flag will be set on "Item discount object"
										setVoidItemDiscount(histTranItem.getRefItemIdx(), itemDiscounts, tranItem.getItemIdx());
									}
									else if (histTranItemItemType == Constants.ITEM_TY_PRICE_CHANGE) {
										priceOverrides.push(buildPriceOverrideObj(histTranItem, tranItem));
									}
									else if (histTranItemItemType == Constants.ITEM_TY_BBAS) {
										var BBASObj = buildBBASObj(histTranItem, tranItem, BBASMap);
										if(BBASObj != null){
											BBASEntries.push(BBASObj);
										}
									}
									else if (histTranItemItemType == Constants.ITEM_TY_DISCOUNT_TXN) {
										discForEachItem.push(buildDiscObj(histTranItem, tranItem));
									}
								}
							} else {
								var promoJson = historyItem.promoJson;
								var id = promoJson.id;

								// use the existing promos or populate a new one
								if (historyItem.timesKickedInAfterThisTranItem > 0) {
									var promoValue = parseFloat(historyItem.savingsAmount);
									promos[id] = {
										qty: historyItem.timesKickedInAfterThisTranItem,
										amountType: promoJson.amountType,
										value: StringUtils.numberToCurrencyString(promoValue),
										totalValue: StringUtils.numberToCurrencyString(promoValue * historyItem.timesKickedInAfterThisTranItem),
										description: ResourceManager.getValue("pos."+promoJson.description),
										promoType: promoJson.type,
										promoId: promoJson.id,
										itemType: Constants.ITEM_TY_PROMO,
										appliedToLayaway: promoJson.appliedToLayaway
									};
								}
								var sku = tranItem.getProduct().getSku();
									avlPromos[sku] = {
											isPromo: historyItem.isPromo,
											promoAmount: historyItem.promoAmount,
											savingsAmount: historyItem.savingsAmount,
											promoName: historyItem.promoJson.alert
										};

							}
						}

						if (itemDiscounts != null && itemDiscounts.length > 0) {
							record.discounts = itemDiscounts;
							//Identify Voided discounts
							for (var d = 0; d < itemDiscounts.length; d++) {
								if (itemDiscounts[d] != null && (itemDiscounts[d].isVoid === undefined || itemDiscounts[d].isVoid != true)) {
									nonVoidItemDiscounts.push(itemDiscounts[d]);
								}
							}
						}

						if (txnDiscounts != null && txnDiscounts.length > 0) {
							record.txnDiscounts = txnDiscounts;
						}

						if (priceOverrides != null && priceOverrides.length > 0) {
							record.priceOverrides = priceOverrides; 
							for (var td = 0; td < priceOverrides.length; td++) { 
								if (priceOverrides[td] != null && (priceOverrides[td].isVoid === undefined || priceOverrides[td].isVoid != true)) {
									nonVoidPriceOverrides.push(priceOverrides[td]);
								}
							}
						}
						
						if (BBASEntries != null && BBASEntries.length > 0) {
							record.BBASEntries = BBASEntries;
						}

						if (promos != null && Object.keys(promos).length !== 0) {
							record.promos = promos;
						}

						if (avlPromos != null && Object.keys(avlPromos).length !== 0) {
							record.avlPromos = avlPromos;
						}

						if (discForEachItem != null && discForEachItem.length > 0) {
							record.discForEachItem = discForEachItem;
							//Identify Voided transaction discounts
							for (var td = 0; td < discForEachItem.length; td++) {
								if (discForEachItem[td] != null && (discForEachItem[td].isVoid === undefined || discForEachItem[td].isVoid != true)) {
									nonVoidDiscForEachItem.push(discForEachItem[td]);
								}
							}
						}
						allData.push(record);
						nonVoidRecord = _.cloneDeep(record);
						if (nonVoidItemDiscounts != null && nonVoidItemDiscounts.length > 0)
							nonVoidRecord.discounts = nonVoidItemDiscounts;
						else
							nonVoidRecord.discounts = null;
						
						if (nonVoidDiscForEachItem != null && nonVoidDiscForEachItem.length > 0)
							nonVoidRecord.discForEachItem = nonVoidDiscForEachItem;
						else
							nonVoidRecord.discForEachItem = null; 
						if (nonVoidPriceOverrides != null && nonVoidPriceOverrides.length > 0)
							nonVoidRecord.priceOverrides = nonVoidPriceOverrides;
						else
							nonVoidRecord.priceOverrides = null;
						nonVoidData.push(nonVoidRecord);

					}
				}
				else if (itemType == Constants.ITEM_TY_DELIVERY_OPTION) {
					var props = tranItem.getTenderDetails().propertiesJson;
					if (props.deliveryData && props.deliveryData != null) {
						record = buildDeliveryOptionObj(tranItem, "Expected Delivery " + props.deliveryData.slotDescription, props.deliveryData.receiptLabel);
					} else {
						var deliverTime = tranItem.getTenderDetails().propertiesJson.deliveryTime;
						var selector = null;
						if(configManager.getConfigObject("posMClient/pos.ovccfg").enableDeliveryTime != undefined &&
							configManager.getConfigObject("posMClient/pos.ovccfg").enableDeliveryTime != null &&
							configManager.getConfigObject("posMClient/pos.ovccfg").enableDeliveryTime == 0){
							selector = "date";
						}
						record = buildDeliveryOptionObj(tranItem, "Expected Delivery " + StringUtils.getLocaleDateFormat(deliverTime, selector), "Delivery " + deliverTime);
					}
					record.isDeliveryOptions = true;
					move = function (arr, from, to) {
						arr.splice(to, 0, arr.splice(from, 1)[0]);
					};

					if (tranItem.getRefItemIdx() != -1){	 
						nonVoidData.push(record);
						_.forEach(nonVoidData, function (itemJ, j) { 
							if (itemJ.itemType == Constants.ITEM_TY_ADD_PRODUCT &&
								tranItem.getRefItemIdx() == itemJ.tranItemIdx) {
								var from = parseInt(tranItem.getItemIdx());
								var to = parseInt(j) + 1;
								if (from != to) {
									move(nonVoidData, from, to);
								}
								return false;
							}
						});
					}
					allData.push(record);
				}else if (itemType == Constants.ITEM_TY_STORE_COLLECT_OPTION) {
					var propertiesJson = tranItem.getTenderDetails();
					var Indices = "";
					if(propertiesJson && propertiesJson != null){
						Indices += tranItem.getTenderDetails().propertiesJson.skus;
					}
					var date = tranItem.getTenderDetails().propertiesJson.deliveryDate;
					addSeperator = function(date, seperator){
						var defDateFormats = require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").dateFormat || "MMMM dd, yyyy";
						if(seperator)
					 		return "Store Collect: "+ Indices + seperator + require("dojo/date/locale").format(new Date(date), { datePattern: defDateFormats, selector:"date"});
					 	else 
					 		return ["Store Collect: "+ Indices, require("dojo/date/locale").format(new Date(date), { datePattern: defDateFormats, selector:"date"})];
					};
					record = buildDeliveryOptionObj(tranItem,  addSeperator(date, "<br\>"), addSeperator(date));
					record.isStoreCollectOption = true;
					record.itemTypeString = '1';
					move = function (arr, from, to) {
						arr.splice(to, 0, arr.splice(from, 1)[0]);
					};

					if (tranItem.getRefItemIdx() != -1){	 
						nonVoidData.push(record);
						var posOfStoreCollect = nonVoidData.length-1;
						_.forEach(nonVoidData, function (itemJ, j) { 
							if (itemJ.itemType == Constants.ITEM_TY_ADD_PRODUCT &&
									record.refItemIdx == itemJ.tranItemIdx) {
								var from = parseInt(posOfStoreCollect);
								var to = parseInt(j) + 1;
								if (from != to) {
									move(nonVoidData, from, to);
								}
								return false;
							}
						});
					}				
					allData.push(record);
				}
				else if (itemType == Constants.ITEM_TY_DISCOUNT_TXN) {
					record = buildDiscObj(tranItem); 

					if (tranItem.getRefItemIdx() == -1)
						nonVoidData.push(record);
					
					allData.push(record);
				}
				else if (itemType == Constants.ITEM_TY_PHYSICAL_TENDER ||
					itemType == Constants.ITEM_TY_UNKNOWN_TENDER ||
					itemType == Constants.ITEM_TY_EINTEGRATED_TENDER ||
					itemType == Constants.ITEM_TY_EINTERNAL_TENDER ||
					itemType == Constants.ITEM_TY_EEXTERNAL_TENDER ||
					itemType == Constants.ITEM_TY_CHECK_TENDER ||
					itemType == Constants.ITEM_TY_PENNY_ROUNDING_TENDER) {

					totalPayment += parseFloat(tranItem.getCalcAmount());
					var tenderPrefix = "";
					var tenderDate = null;

					if (tranObj.isLayaway()) {
						if (tranItem.getCalcAmount() < 0) {//if it is a return change(cash)
							tenderPrefix += ResourceManager.getValue("pos.layawayTenderReturnPrefix");
						} else {//check if it is a deposit or payment...
							if (tranItem.getReasonCodeId() && tranItem.getReasonCodeId() != null
								&& tranItem.getReasonCodeId() === "deposit") {
								tenderPrefix += ResourceManager.getValue("pos.layawayTenderDepositPrefix");
							} else {
								if (tranObj.isLayawaySale() && tranObj.getLayawayMinimum() > 0) {
									tenderPrefix += ResourceManager.getValue("pos.layawayTenderDepositPrefix");
								} else {
									tenderPrefix += ResourceManager.getValue("pos.layawayTenderPaymentPrefix");
								}
							}
						}
						//date for the payment or deposit
						if (!tranObj.isLayawaySale()) {
							tenderDate = require("dojo/date/locale").format(new Date(tranItem.getItemDate()), {
								selector: "date",
								datePattern: "MM/dd/yyyy"
							});
						}
					}
					tenders.push(buildTenderObj(tranItem, tenderPrefix, tenderDate));
				}
				else if (itemType == Constants.ITEM_TY_CHANGE_TENDER) {
					summary.change = StringUtils.numberToCurrencyString(parseFloat(tranItem.getCalcAmount()));
				}
				else if (itemType == Constants.ITEM_TY_NO_SALE) {
					var noSale = buildNoSale(tranItem);
					receiptData.noSaleText = "NO SALE";
					allData.push(noSale);
					nonVoidData.push(noSale);
				} else if (itemType == Constants.ITEM_TY_STORECREDIT_SALE) {
					var storeCreditSale = buildStoreCreditSale(tranItem);
					allData.push(storeCreditSale);
					nonVoidData.push(storeCreditSale);
				} else if (itemType == Constants.ITEM_TY_PAYIN_SALE || itemType == Constants.ITEM_TY_PAYIN_CORR_SALE
						|| itemType == Constants.ITEM_TY_PAYOUT_SALE || itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
					var pipoSale = buildPIPOSale(tranItem);
					allData.push(pipoSale);
					nonVoidData.push(pipoSale);
				}
				else if (itemType == Constants.ITEM_TY_GIFT_CARD_SALE || 
						itemType == Constants.ITEM_TY_GIFT_CARD_TOPUP){
					var giftCardSale = buildGiftCardSale(tranItem);
					allData.push(giftCardSale);
					if (tranItem.getItemIdx() != tranItem.getRefItemIdx()){
						nonVoidData.push(giftCardSale);
					}
					
					giftCardItems.push(tranItem);
				}
				else if(itemType == Constants.ITEM_TY_GIFT_CARD_ADJ){
					var giftCardAdjustment = buildGiftCardAdjustment(tranItem);
					//allData.push(giftCardAdjustment);
					//nonVoidData.push(giftCardAdjustment);
					//giftCardItems.push(giftCardAdjustment);
					//record.giftCardAdjustment = giftCardAdjustment;
					summary.giftCardAdjustment = giftCardAdjustment;
				}
				else if(itemType == Constants.ITEM_TY_GIFT_CARD_REFUND){
					var giftCardRefund = buildGiftCardRefund(tranItem);
					allData.push(giftCardRefund);
					if (tranItem.getItemIdx() != tranItem.getRefItemIdx()){
						nonVoidData.push(giftCardRefund);
					}
				}
			}
// TODO May not be required 
			// process alerts
			var alertsByPromo = _.map(calculatedAlerts.byPromo, function (alertKey) {
				return ResourceManager.getValue("pos." + alertKey);
			});

			var alertsByBundle = [];
			if(calculatedAlerts.byBundle){
				_.forEach(calculatedAlerts.byBundle, function (bundleAlert) {
					// cache the alert text
					alertsByBundle.push(bundleAlert);
				});
			}

			//process alerts for layaway
			var alertsByLayaway = getLayawayAlerts(tranObj);
			var alertsByLaywayPromotions = getLayawayPromotionsAlerts(tranObj);

			// tran tax rates
			var tranTaxRates = tranObj.getTranTaxArrByTaxRateId();
			if (tranTaxRates && tranTaxRates.length > 0) {
				receiptData.taxRates = tranTaxRates;
			}

			//summary
			summary.merchTotal = StringUtils.numberToCurrencyString(parseFloat(tranObj.getMerchTotal()));
			summary.merchTotalWithoutDiscount = StringUtils.numberToCurrencyString(parseFloat(tranObj.getMerchTotal()) + totalDiscountsValue);

			if (totalDiscountsValue != 0) {
				summary.totalDiscount = StringUtils.numberToCurrencyString(-totalDiscountsValue);
			}

			summary.totalItems = tranObj.getTotalItems() + tranObj.getTotalRefundItems();
			if (tranObj.getPromoTotal() != null && parseFloat(tranObj.getPromoTotal()) < 0 && parseFloat(tranObj.getCalculatedPromos().totalValue) < 0) {
				summary.promoSavings = StringUtils.numberToCurrencyString(parseFloat(tranObj.getPromoTotal()));
				if (tranObj.isLayaway() && tranObj.getBalance() > 0 && tranObj._appliedToLayaway == 0) {
					summary.promoSavings = summary.promoSavings.strike();
				}
			}

			summary.taxes = buildTaxes(tranObj);
// 			summary.taxExempt = tranObj.getTaxExempt();

			summary.total = StringUtils.numberToCurrencyString(parseFloat(tranObj.getTotal()));

			if (parseFloat(tranObj.getTotal()) < 0) {
				summary.receiptType = "Refund";
			}
			if(summary.receiptType == "Refund"){
				if(tranObj.getLoyaltyUser() != null){
					customerName.name = tranObj.getLoyaltyUser().loyaltyFName +" "+tranObj.getLoyaltyUser().loyaltyLName;
				}
				
			}

			summary.totalPayment = StringUtils.numberToCurrencyString(parseFloat(totalPayment));
			if (tranObj.isLayaway()) {
				summary.layawayBalance = StringUtils.numberToCurrencyString(parseFloat(tranObj.getLayawayBalance()));
			}
			summary.balance = StringUtils.numberToCurrencyString(parseFloat(tranObj.getBalance()));
			var useStoreCreditBalanceIfPresent = configManager.getConfigObject("posMClient/app.ovccfg").useStoreCreditBalanceIfPresent;
			var isStoreCreditAllowed = configManager.getConfigObject("posMClient/app.ovccfg").isStoreCreditAllowed;
			if (isStoreCreditAllowed && isStoreCreditAllowed === 1 && tranObj.getLoyaltyUser()) {
				var calculatedTranItems = tranObj.getCalculatedTranItems();
				var usedStoreCreditBalance = 0;
				_.forEach(calculatedTranItems, function (calculatedTranItem) {
					var tenderId = calculatedTranItem.getTenderId();
					var tenderDetails = calculatedTranItem.getTenderDetails();
					if (tenderId != undefined &&
						tenderId != null &&
						tenderId == Constants.ITEM_TY_STORECREDIT_TENDER &&
						calculatedTranItem.getIsStoreCreditApplied() !== 1) {
						usedStoreCreditBalance += calculatedTranItem.getAmount();
					}
					if (tranObj.getLoyaltyUser().storeCreditBalance) {
						summary.oldStoreCreditBalance = tranObj.getLoyaltyUser().storeCreditBalance;
					}
					else {
						summary.oldStoreCreditBalance = StringUtils.numberToCurrencyString(0);
					}

					summary.oldStoreCreditBalance = StringUtils.numberToCurrencyString(summary.oldStoreCreditBalance);
					summary.storeCreditBalance = (tranObj.getLoyaltyUser().storeCreditBalance - usedStoreCreditBalance) > 0 ? (tranObj.getLoyaltyUser().storeCreditBalance - usedStoreCreditBalance) : 0.00;
					summary.storeCreditBalance = StringUtils.numberToCurrencyString(summary.storeCreditBalance);
					summary.usedStoreCreditBalance = usedStoreCreditBalance;
					summary.usedStoreCreditBalance = StringUtils.numberToCurrencyString(summary.usedStoreCreditBalance);
				});
			}
			receiptData.allItems = allData;
			receiptData.nonVoidItems = nonVoidData;
			receiptData.alertsByPromo = alertsByPromo; //TODO SET ALERT MSG HERE
			receiptData.alertsByBundle = alertsByBundle;
			receiptData.alertsByLayaway = alertsByLayaway;
			receiptData.alertsByLayawayPromotions = alertsByLaywayPromotions;
			receiptData.summary = summary;
			receiptData.tenders = tenders;
			receiptData.tranNo = tranObj.getTranNo();
			receiptData.storeId = tranObj.getStoreId();
			receiptData.barcode = tranObj.getBarcode();
			if (tranObj.getTranTypeId() == Constants.TX_TY_QUOTE) {
				receiptData.quoteId = tranObj.getQuoteId();
				receiptData.quoteIndicator = ResourceManager.getValue("pos.quoteHeader");
			}
			receiptData.registerId = localStorage.getObject(dUUID).alias;
			receiptData.tillId = tranObj.getTillId();
			//add tranType to receiptObj --
			receiptData.tranTypeId = tranObj.getTranTypeId();
			receiptData.customerName = customerName;

			//add isTrainingMode to receiptObj.
			if (isTraining) {
				receiptData.trainingMode = ResourceManager.getValue("pos.trainingModeHeader");
			}
			else {
				receiptData.trainingMode = "";
			}
			if (currencyId) {
				receiptData.currencyId = currencyId;
			}
			else {
				receiptData.currencyId = "";
			}
			//add layawayHeader to receiptData
			if (tranObj.isLayaway()) {
				if (tranObj.isLayawayFinalize()) {
					receiptData.layawayIndicator = ResourceManager.getValue("pos.layawayFinalizeHeader");
				} else if (tranObj.isLayawayPayment()) {
					receiptData.layawayIndicator = ResourceManager.getValue("pos.layawayPaymentHeader");
				} else if (tranObj.isLayawaySale()) {
					receiptData.layawayIndicator = ResourceManager.getValue("pos.layawayHeader");
				} else {
					receiptData.layawayIndicator = ResourceManager.getValue("pos.layawayRefundHeader");
				}
			}

			var configPositionValue = configManager.getConfigObject("posMClient/payment.ovccfg").overflowPositionForSplitDiscounts;

			if (configPositionValue != null) {
				var record = null;
				if (configPositionValue == "first") {
					position = 0;
					var i = 0;
					//Assuming allitems are ordered properly as shown in VR
					while (i < receiptData.allItems.length) {
						record = receiptData.allItems[i];
						if (record.itemType == Constants.ITEM_TY_ADD_PRODUCT) {
							break;
						}
						i++;
					}
				} else if (configPositionValue == "last") {
					position = receiptData.nonVoidItems.length - 1;
					var i = receiptData.allItems.length - 1;
					//Assuming allitems are ordered properly as shown in VR
					while (i > 0) {
						record = receiptData.allItems[i];
						if (record.itemType == Constants.ITEM_TY_ADD_PRODUCT) {
							break;
						}
						i--;
					}
				}

				var discrepancy = tranObj.getDiscrepancy();
				receiptData.summary._discrepancy = discrepancy;
				record = applyDiscrepancy(receiptData.allItems, record, discrepancy);
				var recordNonVoid = receiptData.nonVoidItems[position];
				recordNonVoid = applyDiscrepancy(receiptData.nonVoidItems, recordNonVoid, discrepancy);
			}

			var userObj = localStorage.getObject('username');
			if (userObj) {
				receiptData.userName = userObj.firstName + " " + userObj.lastName;
			}

			var loyaltyUser = tranObj.getLoyaltyUser();
			if (loyaltyUser && loyaltyUser != null && loyaltyUser.taxExemptInfo) {
				if (loyaltyUser.taxExemptInfo && loyaltyUser.taxExemptInfo.taxId) {
					receiptData.taxId = require("generic/ResourceManager").getValue("pos.TaxIdLabel") + loyaltyUser.taxExemptInfo.taxId;
				}
			}

			var taxExemptReasonCodeFromTran = tranObj.getCustomerTaxExemptReasonCode();
			if (taxExemptReasonCodeFromTran) {
				receiptData.taxExemptReasonCode = ResourceManager.getValue("pos.taxExemptLabelStart") + taxExemptReasonCodeFromTran + ResourceManager.getValue("pos.taxExemptLabelClose");
			}

			// Before returning, lets also store our newly created receipt object back into the transaction. This is so we
			// can store it in the receiptJSON column of the tran_tbl.
			tranObj.setReceiptJSON(receiptData);

			return {receiptObj: receiptData};
		}

		function applyDiscrepancy(recordList, record, discrepancy) {
			if (discrepancy && discrepancy != null &&
				record != null &&
				recordList != null &&
				Object.keys(recordList).length > 0) {
				var totalPrice = parseFloat(record.price);
				record.price = StringUtils.numberToCurrencyString(totalPrice + discrepancy);
			}
			return record;
		}

		function setVoidItemDiscount(refItmIdx, itemDiscounts, discountedItemIdx) {
			for (var i = 0; i < itemDiscounts.length; i++) {
				if (itemDiscounts[i] != null && itemDiscounts[i].tranItemIdx == refItmIdx) {
					//itemDiscounts.splice(i,1);
					itemDiscounts[i].isVoid = true;

					var discountedItemHistory = inputParams.tranObj.getSpecificItemHistory(discountedItemIdx).history;
					if (discountedItemHistory != null && discountedItemHistory.length > 0) {
						for (var k = 0; k < discountedItemHistory.length; k++) {
							if (discountedItemHistory[k].itemIdxKey === refItmIdx)
								totalDiscountsValue -= discountedItemHistory[k].calcAmount;
						}

					}

					break;
				}

			}

		}
		
		function voidGiftCardSale(currentItemIdx, giftCardItems, refItemIdx){
			for (var i = 0; i < giftCardItems.length; i++) {
				if (giftCardItems[i] != null && giftCardItems[i].getItemIdx() == refItemIdx) {
					giftCardItems[i].isVoid = true;
				}
			}
		}

		function clone(obj) {
			if (null == obj || "object" != typeof obj) return obj;
			var copy = obj.constructor();
			_.forEach(obj, function (attr) {
				copy[attr] = attr;
			});
			return copy;
		}


		function getItemJsonRecord(tranItem, isTaxExempt) {
			var record = {};
			record.tranItemIdx = tranItem.getItemIdx();
				record.itemNum = tranItem.getProduct().getSku() ;
				record.propertiesJson = tranItem.getProduct().getProductJson();
				record.mmGroupId = tranItem.getProduct().getMMGroupId();
				record.isFee = (tranItem.getProduct().getProductType() && tranItem.getProduct().getProductType() != null && "Fees" == tranItem.getProduct().getProductType());
			record.qty = record.isFee ? 1 : tranItem.getQty();
			record.description = "";
			record.name = "";
			record.origPrice = "";
			record.tax = "";
			record.salesPerson = "";
			record.backGroundColor = "";
			record.reasonCode = tranItem.getReasonCodeId();
			record.reasonCodeDesc = tranItem.getReasonCodeDesc();
			record.itemType = tranItem.getItemType();
			record.isGC = (tranItem.getProduct().getProductType() && tranItem.getProduct().getProductType() != null && "GiftCertificate" == tranItem.getProduct().getProductType());
			record.cardAccountNumber = record.isGC ? tranItem.getTenderDetails().giftCertificateNumber : -1;
			record.expiryDate = record.isGC ? tranItem.getTenderDetails().expiryDate : "";
			
			if (tranItem.getProduct()) {
				record.description = tranItem.getProduct().getDescription();
				record.name = tranItem.getProduct().getName();
				record.origPrice = StringUtils.numberToCurrencyString(parseFloat(tranItem.getProduct().getInitialPrice()));
				record.promoId = tranItem._promoId;
				if (typeof tranItem.getSalesPerson() != 'undefined' && tranItem.getSalesPerson() != null) {
					record.salesPerson = tranItem.getSalesPerson();
					if (tranObj.salesPersonBgColor && tranObj.salesPersonBgColor[record.salesPerson])
						record.backGroundColor = tranObj.salesPersonBgColor[record.salesPerson];
				}

				var itemTaxRates = tranItem.getProduct().getTaxRates();
  				if (itemTaxRates && itemTaxRates.length > 0 && !record.isGC) {
 					var taxIndicatorStr = ResourceManager.getValue("receipts.taxes.indicator");
					for (var j = 0; j < itemTaxRates.length; j = j + 1) {
						var currentRate = itemTaxRates[j].getTaxRateId();
 						if (itemTaxRates[j].getIsVAT() === 1) { 
							taxIndicatorStr = ResourceManager.getValue("receipts.taxes.vatTaxIndicator");
						} else if (itemTaxRates[j].getIsVAT() === 2) {
							if (isTaxExempt && tranItem.getProduct().isTaxExemptible()) {
								taxIndicatorStr = ResourceManager.getValue("receipts.taxes.taxExemptIndicator");
							}else{ 
								var taxIndicatorStr = ResourceManager.getValue("receipts.taxes.VATAddonIndicator");
							}
						}else {
							if (isTaxExempt && tranItem.getProduct().isTaxExemptible()) {
								taxIndicatorStr = ResourceManager.getValue("receipts.taxes.taxExemptIndicator");
							}
						} 
					}
					record.tax = taxIndicatorStr;
				}
			} else {
				console.log("getItemJsonRecord(): tranItem missing product info: ", tranItem);
			}

			var unitPrice;
			var totalPrice;
			var calcTotal = tranItem.getCalcAmount() * tranItem.getQty();
			if (tranItem.getItemType() == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT) {
				var tranItemProduct = tranItem.getProduct();
				unitPrice = tranItemProduct.getPickupBasePrice();
				totalPrice = (tranItemProduct.getPickupTotalPrice() >= calcTotal) ? calcTotal : tranItemProduct.getPickupTotalPrice();
			} else {
				unitPrice = tranItem.getCalcAmount();
				totalPrice = calcTotal;
			}
			record.unitPrice = StringUtils.numberToCurrencyString(parseFloat(unitPrice));
			record.price = StringUtils.numberToCurrencyString(parseFloat(totalPrice));

			if (parseFloat(record.price) < 0) {
				record.qty = -parseInt(record.qty);
			}
			return record;
		}

		function buildDeliveryOptionObj(discTranItem, contentStr, receiptDescription) {
			var discObj = {};
			discObj.tranItemIdx = discTranItem.getItemIdx();
			discObj.itemType = discTranItem.getItemType();
			discObj.refItemIdx = discTranItem.getRefItemIdx();
			discObj.amount = StringUtils.numberToCurrencyString(discTranItem.getAmount(), 2, true);
			discObj.description =  contentStr;
			discObj.receiptDescription =  receiptDescription;
			var tenderDetails =  discTranItem.getTenderDetails();
			if(tenderDetails && tenderDetails!=null && 
			tenderDetails.propertiesJson && tenderDetails.propertiesJson != null &&
			tenderDetails.propertiesJson.address && tenderDetails.propertiesJson.address!=null){
				discObj.shippingAddress = tenderDetails.propertiesJson.address;
				 discObj.deliveryNotes =  tenderDetails.propertiesJson.deliveryNotes;
			}
			
			//discObj.discValue = discTranItem.getDiscValue();
			if (discTranItem.getRefItemIdx() == -1) {
				discObj.isVoid = true;
			}
			return discObj;
		}

		function buildDiscObj(discTranItem, tranItem) {
			var discObj = {};
			var activeDiscount = true;
			discObj.tranItemIdx = discTranItem.getItemIdx();
			discObj.itemType = discTranItem.getItemType();
			discObj.discType = discTranItem.getDiscType();
			discObj.reasonCode = discTranItem.getReasonCodeId();
			discObj.reasonCodeDesc = discTranItem.getReasonCodeDesc();
			discObj.discValue = discTranItem.getDiscValue();
			
			if(discTranItem.getTenderDetails() != null && discTranItem.getTenderDetails() != undefined){
				if(discObj.itemType == Constants.ITEM_TY_DISCOUNT_TXN && discTranItem.getTenderDetails().propertiesJson.employeeId != undefined && discTranItem.getTenderDetails().propertiesJson.employeeId != null){
					discObj.employeeId = discTranItem.getTenderDetails().propertiesJson.employeeId;
				}
			}
			
			
			if (discTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN && discTranItem.getRefItemIdx() != -1) {
				discObj.isVoid = true;
				activeDiscount = false;
			}

			if (tranItem) {
				discObj.initialPrice = tranItem.getAmount();
				discObj.discountPrice = tranItem.getCalcAmount(); 

				discObj.discValue = discTranItem.getDiscValue()*tranItem.getQty();
				discObj.discountAmount = GenericUtils.currencyRound(discObj.discountPrice - discObj.initialPrice);

				/*if (parseInt(discObj.discType) === Constants.DISC_TYPE_AMOUNT) {
				 discObj.discountAmount = discObj.discountPrice;
				 }
				 else if (parseInt(discObj.discType) === Constants.DISC_TYPE_PERCENT) {
				 discObj.discountAmount = GenericUtils.currencyRound(discObj.discountPrice - discObj.initialPrice);
				 }*/
				if (activeDiscount) {
					var discountedItemHistory = inputParams.tranObj.getSpecificItemHistory(tranItem.getItemIdx()).history;
					if (discountedItemHistory != null && discountedItemHistory.length > 0) {
						for (var k = 0; k < discountedItemHistory.length; k++) {
							if (discountedItemHistory[k].itemIdxKey === discTranItem.getItemIdx())
								totalDiscountsValue += discountedItemHistory[k].calcAmount;
						}

					}
				}
			} 
			discObj.specialType = "discount";
			return discObj;
		}

		function buildPriceOverrideObj(priceOverrideTranItem, tranItem) {
			var priceOverrideObj = {};
			priceOverrideObj.tranItemIdx = priceOverrideTranItem.getItemIdx();
			priceOverrideObj.reasonCode = priceOverrideTranItem.getReasonCodeId();
			priceOverrideObj.reasonCodeDesc = priceOverrideTranItem.getReasonCodeDesc();
			var tenderDetails = priceOverrideTranItem.getTenderDetails();
 			if(tenderDetails) { 
 				if(tenderDetails.competitorName){
 					priceOverrideObj.reasonCodeDesc += " ["+tenderDetails.competitorName+"]";
 				} 
 				if (tenderDetails.priceChangeApplied && tenderDetails.priceChangeApplied !=null){ 
 					priceOverrideObj.priceChangeApplied = "-" + ResourceManager.getValue("currency.symbol") + (Number(tenderDetails.priceChangeApplied)*tranItem.getQty()).toFixed(2);
 				}else{
 					priceOverrideObj.priceChangeApplied = 0;
 				}
			}else{ 
				priceOverrideObj.priceChangeApplied = 0;
			} 
			priceOverrideObj.newPrice = priceOverrideTranItem.getNewPrice();
			priceOverrideObj.initialPrice = tranItem.getProduct().getInitialPrice();
			priceOverrideObj.quantity = tranItem.getQty();
			priceOverrideObj.specialType = "priceOverride";
 			if (priceOverrideTranItem.getRefItemIdx() == -1) {
				priceOverrideObj.isVoid = true;
			}

			return priceOverrideObj;
		}
		
		function buildBBASObj(BBASTranItem, tranItem, BBASMap) {
			var BBASObj = {};
			BBASObj.reasonCodeDesc = BBASTranItem.getReasonCodeDesc();
			BBASObj.itemType = Constants.ITEM_TY_BBAS;
			BBASObj.refItemIdx = BBASTranItem.getRefItemIdx();
			//If the map doesnt have the same BBAS savings message 
			// for the same item on the receipt, add it. This will help avoid
			// creating duplicate alert messages on the VR.
			if((BBASMap[BBASObj.refItemIdx] == null || BBASMap[BBASObj.refItemIdx] == undefined) && BBASObj.reasonCodeDesc != ""){
				BBASMap[BBASObj.refItemIdx] = BBASObj.reasonCodeDesc;
			}
			else if(BBASMap[BBASObj.refItemIdx] != null && BBASMap[BBASObj.refItemIdx] != undefined &&
					BBASMap[BBASObj.refItemIdx] != BBASObj.reasonCodeDesc && BBASObj.reasonCodeDesc != ""){
				BBASMap[BBASObj.refItemIdx] = BBASObj.reasonCodeDesc;
			}
			else if(BBASTranItem.getReasonCodeDesc() == ""){
 				BBASObj = null;
 			}
			else{
				BBASObj = null;
			}
			
			return BBASObj;
		}
		
		function buildTenderObj(tranItem, prefix, tenderDate) {
			var record = {
				amount: StringUtils.numberToCurrencyString(parseFloat(tranItem.getCalcAmount()))
			};
			if (tenderDate && tenderDate != null) {
				record.tenderDate = tenderDate;
			}
			var resources = ResourceManager.getValue; 
			var tenderDetails = tranItem.getTenderDetails();
			if(tenderDetails && tenderDetails.payload){ 
				var parsedPayload = JSON.parse(tenderDetails.payload); 
				record.type = prefix + parsedPayload.cardType; 
				record.itemNum = parsedPayload.cardEntryMode;				
				record.name = "Card : " + parsedPayload.maskedCardNumber;
				if(parsedPayload.authCode){
					record.name  +=  "<br\>Auth :  [" + parsedPayload.authCode + "]" ;
					record.authToken = "Auth : " + parsedPayload.authCode; 
				}
				else if (parsedPayload.transactionID){
					record.name  +=  "<br\>Auth :  [" + parsedPayload.transactionID + "]" ;
					record.authToken = "Auth : " + parsedPayload.transactionID;
				}
					
				/*printer messages*/	
				record.tenderMarker = 'cardPayment';
				record.cardNumber = parsedPayload.maskedCardNumber;
 			} 
			else{
				record.type = prefix + resources("receipts.tenders." + tranItem.getTenderDetails().description);
			}

			return record;
		}

		function buildTaxes(tranObj) {
			var taxes = [];
			var resources = ResourceManager.getValue;
			var config = require("ovc/ConfigManager").getConfigObject("posMClient/payment.ovccfg");
			var addonTaxAllowed = (config.addonTaxAlwaysInReceipt != null && config.addonTaxAlwaysInReceipt === 1);
			if (addonTaxAllowed) {
				var totalTax = tranObj.getTax();
				taxes.push({
					type: resources("receipts.taxes.addon"),
					amount: StringUtils.numberToCurrencyString(parseFloat(totalTax))
				});
			}

			var isTaxExempt = tranObj.isCustomerTaxExempt();
//			var isTaxExempt = tranObj.getLoyaltyUser() != null && tranObj.getLoyaltyUser().taxExemptInfo != null && tranObj.getLoyaltyUser().taxExemptInfo. != '';

			if (isTaxExempt != null && isTaxExempt == true) {
				var exemptTax = tranObj.getTaxExempt();
				if (totalTax > .009 || totalTax < -.009) {
					taxes.push({
						type: resources("receipts.taxes.taxExemptLbl"),
						itemType: Constants.ITEM_TY_TAX_EXEMPT,
						amount: StringUtils.numberToCurrencyString(parseFloat(exemptTax))
					});

					if (config.showNetTax && config.showNetTax != null && config.showNetTax === 1) {
						taxes.push({
							type: resources("receipts.taxes.netTax"),
							itemType: Constants.ITEM_TY_NET_TAX,
							amount: StringUtils.numberToCurrencyString(parseFloat(totalTax - exemptTax))
						});
					}
				}
			}

			var isVATAllowed = (config.VATAlwaysInReceipt && config.VATAlwaysInReceipt != null && config.VATAlwaysInReceipt === 1);
			var isAddonGreaterThanZero = false;
			if (isVATAllowed) {
				if(tranObj.getAddonVATTax() > .009 || tranObj.getAddonVATTax() < -.009) {
					isAddonGreaterThanZero = true;
					taxes.push({
						type: resources("receipts.taxes.VATAddon"),
						amount: StringUtils.numberToCurrencyString(parseFloat(tranObj.getAddonVATTax()))
					});
				}
			}
			if ((tranObj.getTotalVAT() === 0) && isAddonGreaterThanZero){
				//Dont want to show VAT when addon VAT is greater than zero
			} else if ((tranObj.getTotalVAT() > .009 || tranObj.getTotalVAT() < -.009) || isVATAllowed) {
				taxes.push({
					type: resources("receipts.taxes.VAT"),
					amount: StringUtils.numberToCurrencyString(parseFloat(tranObj.getTotalVAT()))
				});
			}
			
			return taxes;
		}

		function buildStoreCreditSale(tranItem) {
			var record = {};

			record.itemType = tranItem.getItemType();
			record.itemNum = ResourceManager.getValue("pos.noSaleItemNumber");
			record.description = ResourceManager.getValue("pos.noSaleItemDesc");
			record.qty = "";
			record.amount = tranItem.getAmount();

			return record;
		}


		function buildNoSale(tranItem) {
			var record = {};

			record.itemType = tranItem.getItemType();
			record.itemNum = ResourceManager.getValue("pos.noSale");
			record.description = tranItem.getReasonCodeDesc();
			record.qty = "";
			record.amount = "0.00";

			return record;
		}
		
		function buildPIPOSale(tranItem) {
			var record = {};
			var itemType = tranItem.getItemType();
			record.itemType = itemType;
			if(itemType == Constants.ITEM_TY_PAYIN_SALE){
				record.itemNum = ResourceManager.getValue("pos.payIn");
			}
			else if (itemType == Constants.ITEM_TY_PAYIN_CORR_SALE){
				record.itemNum = ResourceManager.getValue("pos.payInCorr");
			}
			else if (itemType == Constants.ITEM_TY_PAYOUT_SALE){
				record.itemNum = ResourceManager.getValue("pos.payOut");
			}
			else if (itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
				record.itemNum = ResourceManager.getValue("pos.payOutCorr");
			}
			record.description = tranItem.getReasonCodeDesc();
			record.qty = "";
			record.amount = tranItem.getAmount().toFixed(2);

			return record;
		}
		
		function buildGiftCardSale(tranItem){
			var record = {};
			var itemType = tranItem.getItemType();
			record.itemType = itemType;
			record.itemNum = tranItem.getReasonCodeId();
			record.description = tranItem.getReasonCodeDesc();
			record.qty = "";
			record.amount = tranItem.getAmount().toFixed(2);
			
			record.price = tranItem.getAmount().toFixed(2);
			record.origPrice = tranItem.getAmount().toFixed(2);

			record.tranItemIdx = tranItem.getItemIdx(); 
			if(tranItem.getRefItemIdx() != -1){
				record.isVoid = true;
			}
			return record;
		}
		
		function buildGiftCardAdjustment(tranItem){
			var record = {};
			var itemType = tranItem.getItemType();
			record.itemType = itemType;
			//record.itemNum = tranItem.getReasonCodeId();
			record.description = "Gift Card Adjustment: ";
			//record.qty = "";
			record.amount = tranItem.getAmount().toFixed(2);
			record.price = tranItem.getAmount().toFixed(2);
			record.origPrice = tranItem.getAmount().toFixed(2);
			record.tranItemIdx = tranItem.getItemIdx(); 
			record.isGiftCardAdj = true;
			if(tranItem.getRefItemIdx() != -1){
				record.isVoid = true;
			}
			return record;
		}
		
		function buildGiftCardRefund(tranItem){
			var record = {};
			var itemType = tranItem.getItemType();
			record.itemType = itemType;
			record.itemNum = tranItem.getReasonCodeId();
			record.description = "Gift Card"; //tranItem.getReasonCodeDesc();
			record.qty = tranItem.getQty();
			record.amount = tranItem.getAmount().toFixed(2);
			
			record.price = tranItem.getAmount().toFixed(2);
			record.origPrice = tranItem.getAmount().toFixed(2);

			record.tranItemIdx = tranItem.getItemIdx(); 
			if(tranItem.getRefItemIdx() != -1){
				record.isVoid = true;
			}
			return record;
		}
		
		function getLayawayAlerts(tranObj) {
			if (!tranObj.isLayaway()) {
				return [];
			}
			var alerts = [];

			var layawayConfig = require("ovc/ConfigManager").getConfigObject("posMClient/layaway.ovccfg");
			var layawayJSON = tranObj.getLayawayJSON();

			var alertStr = null;
			if (tranObj.isLayawaySale()) {
				if (layawayConfig.overrideDownPaymentRequirement != null && layawayConfig.overrideDownPaymentRequirement === 1) {
					if (layawayConfig && layawayConfig.minimumValueDown && layawayConfig.minimumValueDown > 0) {
						alertStr = ResourceManager.getValue("pos.layawayMinDepositPrefix") + ResourceManager.getValue("currency.symbol") +
							layawayConfig.minimumValueDown + ResourceManager.getValue("pos.layawayMinDepositSuffix");
					} else if (layawayConfig && layawayConfig.minimumPercentageDown && layawayConfig.minimumPercentageDown > 0) {
						alertStr = ResourceManager.getValue("pos.layawayMinDepositPrefix") +
							layawayConfig.minimumPercentageDown + "%" + ResourceManager.getValue("pos.layawayMinDepositSuffix");
					}
				} else {
					alertStr = ResourceManager.getValue("pos.layawayNoMinDepositReqd");
				}
			}
			if (alertStr != null) {
				alerts.push(alertStr);
			}

			if (layawayConfig.isMaximumExpirationDaysAllowedForExpiration != undefined && layawayConfig.isMaximumExpirationDaysAllowedForExpiration != null
				&& layawayConfig.isMaximumExpirationDaysAllowedForExpiration === 1) {
				if (layawayConfig.maximumExpirationDaysAllowedForExpiration != null) {
					var noOfDaysRemaining = layawayConfig.maximumExpirationDaysAllowedForExpiration;
					if (layawayJSON.layawayAgeInDays && layawayJSON.layawayAgeInDays > 0) {
						noOfDaysRemaining = Math.max((layawayConfig.maximumExpirationDaysAllowedForExpiration - layawayJSON.layawayAgeInDays), 0);
						layawayJSON.noOfDaysRemaining = noOfDaysRemaining;
					}
					alerts.push(ResourceManager.getValue("pos.layawayMaxExpiryAlertPrefix") + noOfDaysRemaining + ResourceManager.getValue("pos.layawayMaxExpiryAlertSuffix"));
					layawayJSON.maximumExpirationDaysAllowedForExpiration = layawayConfig.maximumExpirationDaysAllowedForExpiration;
				}
			}

			if (layawayConfig.isPaymentRequiredEveryXDays != undefined && layawayConfig.isPaymentRequiredEveryXDays != null &&
				layawayConfig.isPaymentRequiredEveryXDays === 1) {
				if (layawayConfig.paymentRequiredEveryXDays != null) {
					alerts.push(ResourceManager.getValue("pos.layawayPaymentRequiredAlertPrefix") + layawayConfig.paymentRequiredEveryXDays + ResourceManager.getValue("pos.layawayPaymentRequiredAlertSuffix"));
					layawayJSON.paymentRequiredEveryXDays = layawayConfig.paymentRequiredEveryXDays;
				}
			}
			if (tranObj.getLayawayBalance() != null) {
				alerts.push(ResourceManager.getValue("pos.layawayBalanceAlertPrefix") + StringUtils.numberToCurrencyString(tranObj.getLayawayBalance(), 2, true) + ResourceManager.getValue("pos.layawayBalanceAlertSuffix"));
			}
			if (tranObj.isLayawayFinalize()) {
				alerts.push(ResourceManager.getValue("pos.layawayFinalizeSuccessAlert"));
			}


			return alerts;
		}

		function getLayawayPromotionsAlerts(tranObj) {
			if (!tranObj.isLayaway()) {
				return [];
			}
			var alerts = [];
			var expiredPromotionsArray = tranObj.getExpiredPromotions();
			if (expiredPromotionsArray.length > 0) {
				for (var i = 0; i < expiredPromotionsArray.length; i++) {
					alerts.push(expiredPromotionsArray[i].alert);
				}
			}

			return alerts;
		}

	});

return deferred.promise;
