var removeIdsArr = [];
var disableIdsArr = [];
var paramsJson = {};

var uObj = localStorage.getObject(username);

var isTester = false;
for (var i = 0; i < uObj.roles.length; i = i + 1) {
	if (uObj.roles[i].id == "-999") {
		isTester = true;
	}
}

var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var Constants = require("generic/Constants");

if (!isTester) {
	removeIdsArr.push("displayReportsMenuBtn");
	removeIdsArr.push("changeServerIPMenuBtn");

	if (currentTranObj.getTotalItems() > 0 || currentTranObj.getTotalRefundItems() > 0) {
		disableIdsArr.push("cashMgmtMenuBtn");
		disableIdsArr.push("postVoidMenuBtn");
		disableIdsArr.push("TrainingModeBtn");
		disableIdsArr.push("syncDataBtn");
		
		disableIdsArr.push("payInTranMenuBtn");
		disableIdsArr.push("payOutTranMenuBtn");
		disableIdsArr.push("payInCorrTranMenuBtn");
		disableIdsArr.push("payOutCorrTranMenuBtn");
	}
	else if(currentTranObj.getTranTypeId() == Constants.TX_TY_PAYINTRAN ||
			currentTranObj.getTranTypeId() == Constants.TX_TY_PAYOUTTRAN ||
			currentTranObj.getTranTypeId() == Constants.TX_TY_PAYINCORRTRAN ||
			currentTranObj.getTranTypeId() == Constants.TX_TY_PAYOUTCORRTRAN){
		disableIdsArr.push("cashMgmtMenuBtn");
		disableIdsArr.push("payInTranMenuBtn");
		disableIdsArr.push("payOutTranMenuBtn");
		disableIdsArr.push("payInCorrTranMenuBtn");
		disableIdsArr.push("payOutCorrTranMenuBtn");
	}
}

var trainingModeAllowed = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").allowTrainingMode;
var isTrainingOn = (trainingModeAllowed && trainingModeAllowed != null && trainingModeAllowed === 1);
if (!isTrainingOn) {
	removeIdsArr.push("TrainingModeBtn");
}

var showDBQueryTool = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").showDBQueryTool;
var isDbQueryToolOn = (showDBQueryTool && showDBQueryTool != null && showDBQueryTool === 1);
if (!isDbQueryToolOn) {
	removeIdsArr.push("queryDBMenuBtn");
}

return {
	menuId: 'posMClient/pos_manager_key.ovcmnu',
	isScrollable: 0,
	removeIdsArr: removeIdsArr,
	disableIdsArr: disableIdsArr,
	paramsJson: paramsJson
};
