var loyaltyTranObjs = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var hardReserveLayaway  = require("ovc/ConfigManager").getConfigObject("posMClient/Quotes.ovccfg").inventoryHardReserveForLayaways;
if(hardReserveLayaway == 0){
	loyaltyTranObjs._GH8H43GT56 = false;
}
var taxExemptInfo =  inputParams.taxExemptInfo;

if(taxExemptInfo == null){
	taxExemptInfo = {"taxId":inputParams.taxId};
}
var loyaltyTranItem  = loyaltyTranObjs.setLoyaltyId(inputParams.loyaltyId, inputParams.loyaltyFName, inputParams.loyaltyLName, inputParams.loyaltyEmail, inputParams.numberOfLayaways,inputParams.storeCreditBalance, inputParams.arAccountNumber, inputParams.phone,taxExemptInfo);
require('dojo/dom').byId('loyaltyUserLbl').innerHTML = require("generic/ResourceManager").getValue("pos.customerLabel");
var tranTypeId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getTranTypeId();
if (tranTypeId == "quote") 
	require('dojo/dom').byId('loyaltyUserLbl').innerHTML = require("generic/ResourceManager").getValue("pos.quoteCustomer");

var dispName = (inputParams.loyaltyFName + ' ' + inputParams.loyaltyLName);
var maxCustomerNameLengthinVR 	  = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').maxCustomerNameLengthinVR;

var shortName = dispName;
if(maxCustomerNameLengthinVR && maxCustomerNameLengthinVR!=null &&
	maxCustomerNameLengthinVR > 0 &&
	dispName.length>maxCustomerNameLengthinVR){
	shortName = dispName.substring(0,maxCustomerNameLengthinVR) + "...";
}


var contentStr = "";
var loyaltyUserItemIdx;
if(typeof loyaltyTranItem != undefined && loyaltyTranItem != null){
	loyaltyUserItemIdx = loyaltyTranItem.getItemIdx();
}


var deleteCustomerConfirmation 	  = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').deleteCustomerConfirmation;    
contentStr = "<img  width=\"45\" height=\"45\" onclick=\"require('ovc/ProcessEngine').invokeProcess('posMClient/OpenReasonCodeDialogWithOutTextBox.ovcprc',{ invokeProcess: 'posMClient/RemoveLoyalty.ovcprc', params:{loyaltyId: '"+inputParams.loyaltyId+"', refItemIdx : "+loyaltyUserItemIdx+"}, reasonCodeType: 'removeCustomer',dialogTitle: require('generic/ResourceManager').getValue('pos.dialogTitleRemoveCustomer'),dialogMsg: require('generic/ResourceManager').getValue('pos.dialogMsgRemoveCustomer'),yesBtnLabel : require('generic/ResourceManager').getValue('pos.yesBtnLabelRemoveCustomer'),noBtnLabel : require('generic/ResourceManager').getValue('pos.noBtnLabelRemoveCustomer'),showConfirmation : '"+deleteCustomerConfirmation+"',confirmationMsg: require('generic/ResourceManager').getValue('pos.confirmationMsgRemoveCustomer'),dialogMsgNoReasonCode: require('generic/ResourceManager').getValue('pos.dialogMsgNoReasonCodeRemoveCustomer')});\" src="+base + "/../../dynamicblob/posMClient/voidIcon.png>";

if(shortName && shortName !=null && shortName!=""){
	require('dojo/dom').byId('loyaltyUserVoid').innerHTML = contentStr;
} 
require('dojo/dom').byId('loyaltyUserName').innerHTML = shortName; 

if(inputParams.taxId &&  inputParams.taxId !==null){
	require('dojo/dom').byId('taxid').innerHTML = require("generic/ResourceManager").getValue("pos.TaxIdLabel") + inputParams.taxId;
	require("dojo/dom-style").set(require('dojo/dom').byId('taxid'), "display", "");
}else{
	require("dojo/dom-style").set(require('dojo/dom').byId('taxid'), "display", "none");
}
require('dojo/dom').byId('loyaltyIdLabel').innerHTML = inputParams.loyaltyId;
require('dojo/dom').byId('loyaltyEmailLabel').innerHTML = inputParams.loyaltyEmail;

return {};
