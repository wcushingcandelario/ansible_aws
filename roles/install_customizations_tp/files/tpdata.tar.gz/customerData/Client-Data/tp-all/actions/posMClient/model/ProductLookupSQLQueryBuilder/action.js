
function applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper){
	if(needsWhere){
		sqlQuery = sqlQuery + ' where ';
		needsWhere = false;
	}
	if (needsConditionalOper) {
		sqlQuery = sqlQuery + ' ' + conditionalOper+' ';
	}
	return sqlQuery;
}

var sqlQuery = "select distinct ps.sku sku, ps.name name, p.productCode productCode, p.style style, p.productType productType, psb.barcode barcode, ";
sqlQuery += "ps.stockLevel, ps.imageURL, p.propertiesJson propertiesJson, GROUP_CONCAT(DISTINCT mg.name) department "
sqlQuery += "from product_tbl p ";
sqlQuery += "INNER JOIN product_merchandise_group_tbl pmg on (p.id = pmg.productId) ";
sqlQuery += "INNER JOIN merchandise_group_tbl mg on (pmg.mmgroupId = mg.id) ";
sqlQuery += "INNER JOIN product_sku_barcode_tbl psb on (p.id = psb.productId) ";
sqlQuery += "INNER JOIN product_sku_tbl ps on (ps.productId = p.id and ps.sku = psb.sku and ps.productId = psb.productId and ps.sku = psb.sku and p.id = psb.productId) ";
//sqlQuery += "LEFT JOIN product_props_tbl ppt on (ppt.sku = ps.sku) ";
sqlQuery += "where mg.groupType = '1' ";

var needsConditionalOper = true;
var conditionalOper = inputParams.contionalOper;
var needsWhere = false;

if (inputParams.sku != null && inputParams.sku.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);
	
	sqlQuery = sqlQuery + ' psb.sku like \'%' + inputParams.sku.toLowerCase() + '%\'';
	needsConditionalOper = true;
}
if (inputParams.name != null && inputParams.name.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' ps.name like \'%' + inputParams.name.toLowerCase() + '%\'';
	needsConditionalOper = true;
}
if (inputParams.department != null && inputParams.department.length > 0 
		&& inputParams.department !== 'default')  {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' (mg.id like \'%' + inputParams.department.toLowerCase() + '%\'';
	if (inputParams.allDepartments != null) {
		for (var i=0; i<inputParams.allDepartments.length; i=i+1) {
			sqlQuery = sqlQuery + ' or mg.id like \'%' + inputParams.allDepartments[i].groupId + '%\'';
		}
	}
	sqlQuery = sqlQuery + ')';

	needsConditionalOper = true;
}
/*if (inputParams.isbn != null && inputParams.isbn.length > 0) {
	if(needsWhere){
		sqlQuery = sqlQuery + ' where ';
		needsWhere = false;
	}
	if (needsConditionalOper) {
		sqlQuery = sqlQuery + ' ' + conditionalOper+' ';
	}
	sqlQuery = sqlQuery + ' (p.productCode like \'%' + inputParams.isbn.toLowerCase() + '%\')';
	needsConditionalOper = true;
}*/
if (inputParams.style != null && inputParams.style.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' (p.style like \'%' + inputParams.style.toLowerCase() + '%\')';
	needsConditionalOper = true;
}
if (inputParams.productCode != null && inputParams.productCode.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' (p.productCode like \'%' + inputParams.productCode.toLowerCase() + '%\')';
	needsConditionalOper = true;
}
if (inputParams.barcode != null && inputParams.barcode.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' (psb.barcode like \'%' + inputParams.barcode.toLowerCase() + '%\')';
	needsConditionalOper = true;
}
if (inputParams.productType != null && inputParams.productType.length > 0) {
	sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

	sqlQuery = sqlQuery + ' (p.productType like \'%' + inputParams.productType.toLowerCase() + '%\')';
	needsConditionalOper = true;
}
//add the productType check by default
sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);

sqlQuery = sqlQuery + ' (p.productType NOT IN (\'Fees\',\'GiftCertificate\'))';
needsConditionalOper = true;

//add the filterSkusArray check at the end only if present.
if (inputParams.filterSkusArray != null && inputParams.filterSkusArray.length > 0) {
	 var skuCheckStr ="";
	
	_.forEach(inputParams.filterSkusArray, function (item) {
		if(skuCheckStr == ""){
			skuCheckStr =  ' psb.sku  like \''+ item + '\'';
		}else{
			skuCheckStr = skuCheckStr +' OR  psb.sku  like \''+ item + '\'';
		}

	});
	sqlQuery = sqlQuery + ' and  (' +skuCheckStr + ' )';	
}

//add properties filtering
//var propsLength = 0;
//
//if(inputParams.properties && inputParams.properties!=null){
//	//find valid properties length - not null, not empty
//	_.forEach(inputParams.properties, function(propValue, propId){
//		if(propValue && propValue.length > 0){
//			propsLength++;
//		}
//	});
//	
//	//loop through the properties to build where clause
//	var i = 0;
//	_.forEach(inputParams.properties, function(propValue, propId){
//		if(propValue && propValue.length > 0){
//			if(i==0){
//				sqlQuery = applyCondition(sqlQuery,conditionalOper,needsWhere,needsConditionalOper);
//				sqlQuery += '(';
//			}
//			sqlQuery = sqlQuery + ' (ppt.propertyId = \''+propId+'\' and ppt.propertyValue like \'%'+propValue+'%\') ';
//			if(i == (propsLength-1)){
//				sqlQuery += ')';
//			}else{
//				sqlQuery += ' OR ';
//			}
//			i++;
//		}
//	});
//	//properties filter end
//}

sqlQuery = sqlQuery +" group by 1,2,3";

var limit = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").searchCenterProductLimit;

if(limit && limit > 0)
	sqlQuery = sqlQuery + ' LIMIT '+limit;
else
	sqlQuery = sqlQuery + ' LIMIT 20';

var outputParams = {};
outputParams.sqlQuery = sqlQuery;

//console.log('lookup query::::'+sqlQuery);

return outputParams;
