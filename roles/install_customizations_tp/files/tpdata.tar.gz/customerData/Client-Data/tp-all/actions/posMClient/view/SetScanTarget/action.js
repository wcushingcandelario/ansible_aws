// This action is wrapped by the SetScanTarget process (@see OVCPosMainMenu/widget._productLookup() for an example)

scannedBarcodeTarget = {};

console.log("SetScanTarget action: called with page:" + inputParams.page);

if (inputParams.page == 'pos'  ) {
	// called from processes:
	//   OpenGetEmailDialog
	//   OpenPostVoidDialog
	//   OpenRefundDialog
	//   OpenRefundWithReceiptDialog

 	scannedBarcodeTarget.targetFunction = function (barcode) {
		return when(require('ovc/ProcessEngine').invokeProcess(
			'posMClient/receipt/AddItemByRetailerIdAndCodeOrSKU.ovcprc',
			{
				productId: barcode,
				quantity: 1,
				isScanned: 1
			})).then(
			function (result) {
				console.log("SetScanTarget action: called process AddItemByRetailerIdAndCodeOrSKU with productId: " + barcode + ", quantity: 1, isScanned: 1, result:", result);
			},
			function (e) {
				console.log("SetScanTarget action: called process AddItemByRetailerIdAndCodeOrSKU with productId: " + barcode + ", quantity: 1, isScanned: 1, error:", e);
			});

	};
} 
//else if (inputParams.page == 'productLookup') {
//	// called from:
//	//   OVCPosMainMenu/widget._productLookup() via process SetScanTarget
//// TODO: MODIFY TO BE CONFIGURABLE?!?!?
//	scannedBarcodeTarget.widgetId = null;
//
//	scannedBarcodeTarget.targetFunction = function (barcode) {
//		require('posmclient/ProductLookup').clearLookUpPage();
//
//		if (require('dijit/registry').byId("upcTextBox")) {
//			require('dijit/registry').byId("upcTextBox").set('value', barcode);
//			console.log("SetScanTarget action: setting ProductLookup.upcTextBox with barcode: " + barcode);
//
//			return when(pageMemory.doLookup(1)).then(
//				function (result) {
//					console.log("SetScanTarget action: called ProductLookup.doLookup() with isScanned: 1, result:", result);
//				},
//				function (e) {
//					console.log("SetScanTarget action: called ProductLookup.doLookup() with isScanned: 1, error:", e);
//				});
//		}
//	};
//} 
else if (inputParams.page == 'refund') {
	// called from processes:
	//   OpenRefundDialog
	//   OpenRefundWithReceiptDialog
	scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting refund.textBoxDialogTextBox with barcode: " + barcode);

		var deferred = new Deferred();
		window.setTimeout(function () {
			document.getElementById("isScanned").value = "1";
			deferred.resolve();
		}, 100);
		return deferred.promise;
	};
} else if (inputParams.page == 'postVoid') {
	// called from processes:
	//   OpenPostVoidDialog
	scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting postVoid.textBoxDialogTextBox with barcode: " + barcode);

		var deferred = new Deferred();
		window.setTimeout(function () {
			document.getElementById("isScanned").value = "1";
			deferred.resolve();
		}, 100);
		return deferred.promise;
	};
} else if (inputParams.page == 'eReceipt') {
	// called from processes:
	//   OpenGetEmailDialog
	scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting eReceipt.textBoxDialogTextBox with barcode: " + barcode);
	};
} else if (inputParams.page == 'giftCert') {
	// called from processes:
	scannedBarcodeTarget.widgetId = "giftcertentrytxt";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		if (require('dijit/registry').byId("giftcertentrytxt")) {
			require('dijit/registry').byId("giftcertentrytxt").set('value', barcode);
			console.log("SetScanTarget action: setting giftcertentrytxt with barcode: " + barcode);

		}
	};
} else if (inputParams.page == 'alertCenter') {
	var widgetId = require('dijit/registry').byId('alertCenterView');
	widgetId = widgetId.getChildren()[0].allAlerts._alertSearch.id;
	scannedBarcodeTarget.widgetId = widgetId;

	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting alertCenter.textBoxDialogTextBox with barcode: " + barcode);
	};
} else if (inputParams.page == 'appointmentScheduler') {
	//scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting appointmentScheduler.??? with barcode: " + barcode);
	};
} else if (inputParams.page == 'calendarSettings') {
	//scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting calendarSettings.??? with barcode: " + barcode);
	};
} else if (inputParams.page == 'searchCenterView') {
	scannedBarcodeTarget.widgetId = "textBoxDialogTextBox";
	if (require("dijit/registry").byId("Products").domNode.style.display != "none"){
		scannedBarcodeTarget.widgetId = "txtSKU"; //"ProductsSearchBox";
	}
	else if (require("dijit/registry").byId("Orders").domNode.style.display != "none") {
		scannedBarcodeTarget.widgetId = "txtBarcode"; //"OrdersSearchBox";
	}
	else if (require("dijit/registry").byId("Customers").domNode.style.display != "none") {
		scannedBarcodeTarget.widgetId = "txtCustomerId"; //"CustomersSearchBox";
	}
	scannedBarcodeTarget.targetFunction = function (barcode) {
		console.log("SetScanTarget action: setting searchCenterView.??? with barcode: " + barcode);
	};
} else if (inputParams.page == 'returnWithoutReceipt') {
			scannedBarcodeTarget.widgetId = null;
 			scannedBarcodeTarget.targetFunction = function (barcode) {
 				require('posmclient/OVCPosSubMenu.widget').setTextBox(barcode, true);
 			};
}
else if (inputParams.page == 'returnWithReceipt') {
	scannedBarcodeTarget.widgetId = null;
	scannedBarcodeTarget.targetFunction = function (barcode) {
		var textBoxArray = require("dojo/query")(".scanTargetReturnTxtBx");
		for(i in textBoxArray){ 
			if (require('dijit/registry').byId(textBoxArray[i].id)) { 
				require('dijit/registry').byId(textBoxArray[i].id).set('value', barcode);  
				require("dijit/registry").byId('txtBarcode').set("value", barcode)
			    searchButtonClicked((require("generic/ResourceManager").getValue("searchCenter.ordersSearchType")));
				console.log("SetScanTarget action: setting objectSearchBox with barcode: " + barcode);
			}
		}

		var formsArray = require("dojo/query")(".OVCFormDialog");
		for(i in formsArray){ 
			if (require('dijit/registry').byId(formsArray[i].id)) { 
				require('dijit/registry').byId(formsArray[i].id).hide(); 
				require(["dojo/dom-construct"], function(domConstruct){
					  // Destroy a node byId:
						domConstruct.empty(formsArray[i].id);
					    domConstruct.destroy(formsArray[i].id);
				});
				
 				console.log("hiding the widget " + formsArray[i].id);
			}
		}
	};

}
else if (inputParams.page == 'employeeDiscountPopup') {
	scannedBarcodeTarget.widgetId = "scanTargetemployeeIdTxBx";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		if (require('dijit/registry').byId("scanTargetemployeeIdTxBx")) {
			require('dijit/registry').byId("scanTargetemployeeIdTxBx").set('value', barcode);
			console.log("SetScanTarget action: setting textbox2 with barcode: " + barcode);
		}
	};

}
else if (inputParams.page == 'assignSalesPerson') {		
	scannedBarcodeTarget.targetFunction = function (barcode) {
		
		var itemIdx = require("dijit/registry").byId("receiptGrid").getController().getSelectedTranItemIdx();
		require('ovc/ProcessEngine').invokeProcess(
				'posMClient/SalesPerson/AddSalesPerson.ovcprc',
				{
					itemIdx: itemIdx,
					salesPersonId: barcode
				});
				
		dijit.byId('SalesPersonSelect').hide();
		dijit.byId('SalesPersonSelect').destroy();
		var clickableImage = require("dojo/dom").byId("headingLogoLeft");
		
		if(clickableImage && clickableImage.activeView === "searchCenterView") {
			require('ovc/ProcessEngine').invokeProcess("posMClient/CloseAlertCenter.ovcprc", { prompt: false });
		} else  {
			require('ovc/ProcessEngine').invokeProcess('posMClient/SetScanTarget.ovcprc', {page: 'pos'});
		}
};
}
else if (inputParams.page == 'giftCardPopup') {
	scannedBarcodeTarget.widgetId = "txtSerialNumber";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		if (require('dijit/registry').byId("txtSerialNumber")) {
			require('dijit/registry').byId("txtSerialNumber").set('value', barcode);
			require('dijit/registry').byId("txtSerialNumber").valid = true;
			console.log("SetScanTarget action: setting objectSearchBox with barcode: " + barcode);
		}
	};
}
else if (inputParams.page == 'giftCardEnquiryPopup') {
	scannedBarcodeTarget.widgetId = "txtSerialNumberEnquiry";
	scannedBarcodeTarget.targetFunction = function (barcode) {
		if (require('dijit/registry').byId("txtSerialNumberEnquiry")) {
			require('dijit/registry').byId("txtSerialNumberEnquiry").set('value', barcode);
			require('dijit/registry').byId("txtSerialNumberEnquiry").valid = true;
			console.log("SetScanTarget action: setting objectSearchBox with barcode: " + barcode);
		}
	};
}
else if(inputParams.page == 'stopScan'){
	console.log("SetScanTarget action: " + inputParams.page);
	if (require("dojo/_base/lang").exists("window.barcodePlugin")) { 
		console.log("SetScanTarget action: Stopping the scanner during checkout ");
 		scannedBarcodeTarget.targetFunction = null; 
		scannedBarcodeTarget.widgetId = null;
	}
}
else {
	console.log("SetScanTarget action: unsupported page: " + inputParams.page);
}
return {};
