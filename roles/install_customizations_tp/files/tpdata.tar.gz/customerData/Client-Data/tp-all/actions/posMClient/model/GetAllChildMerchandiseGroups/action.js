var groupIds = inputParams.groupIds;
	var resultSet = [];
    if (groupIds.indexOf("") !== -1) {
        resultSet.push("ROOT");
    } 
    else if (groupIds.indexOf("ROOT") !== -1) {
        resultSet.push("100-000-000-000", "200-000-000-000");
    }
    else{
    	resultSet = inputParams.groupIds
    }
    return {resultSet : resultSet };