define(["dojo/_base/declare", "generic/db/DBUtil", "dojo/when", "generic/ResourceManager", "generic/Constants"],
	function (declare, DBUtil, when, ResourceManager, Constants) {

		var dbUtil = new DBUtil();

		var sqlQuery = 'SELECT id, description,propertiesJson FROM tender_type_tbl WHERE tenderType IS NOT NULL AND isActive = 1';

		function filterTendersForLayaway(tranObj, tenders, json) {

			if (tranObj.isLayawaySale() || tranObj.isLayawayPayment()) {
				var layawayTenders = [];
				for (var i = 0; i < tenders.length; i++) {
					var tender = tenders[i];

					//Layaway tender filtering

					var layawayConfig = require("ovc/ConfigManager").getConfigObject("posMClient/layaway.ovccfg");
					var allowedLayawayTenders = [];

					var configuredTenders = null;
					if (layawayConfig) {
						if (tranObj.isLayawayPayment()) {
							configuredTenders = layawayConfig.allowedLayawayPaymentTenders;
						} else {
							configuredTenders = layawayConfig.allowedLayawayTenders;
						}
					}

					if (configuredTenders && configuredTenders != null && configuredTenders.length > 0) {
						allowedLayawayTenders = configuredTenders.split(',');
					}

					if (allowedLayawayTenders != null && allowedLayawayTenders.indexOf(tender.id) == -1) {
						continue; //skip this tender as it is not configured for Layaway...
					} else {
						layawayTenders.push(tender);
					}

					//enabling the completeDepositMenuButton in layaway mode
					json['enableCompleteButton'] = true;
					//removeIdsArr.splice(removeIdsArr.indexOf("completeDepositMenuButton"),1);
				}
				return layawayTenders;
			} else {
				return tenders;
			}
		}

		function filterTendersForReturn(tranObj, tenders, paymentConfig, isStoreCreditAllowed, forceSCinReturn) {
			// If this is a refund, remove tender types for which we don't support refunds.
			// leverage refund tenders for payout and payout correction tran also (TP only)
			if ((tranObj.getBalance() < 0 && tranObj.getTotalRefundItems() > 0) ||
				(tranObj.getTranTypeId() == Constants.TX_TY_PAYOUTTRAN || tranObj.getTranTypeId() == Constants.TX_TY_PAYINCORRTRAN)
			) {

				if(localStorage.getObject("origTendersForReturn") != undefined &&
						localStorage.getObject("origTendersForReturn") != null && localStorage.getObject("origTendersForReturn").length > 0 ){
						//return with receipt so use applicable return tenders set in the tender type itself.
						
						var tempOrigTendersWDetails =[];
							//build list of original tenders from the tenderTypetable so we have enough information to determine return tenders.
						for(var j = 0; j < tenders.length; j++){
							_.forEach(localStorage.getObject("origTendersForReturn"), function(purchaseTender){
								
								if(typeof purchaseTender.tenderDetails == "string"){
									purchaseTender.tenderDetails = JSON.parse(purchaseTender.tenderDetails);
								}
								
								if(purchaseTender.tenderDetails.id.indexOf(tenders[j].id) != -1 ){
									tempOrigTendersWDetails.push(tenders[j]);
								}
								
							});
						}
						var returnTenders = [];
						
						for(var i = 0; i < tenders.length; i++){
							_.forEach(tempOrigTendersWDetails, function(purchaseTender){
								
								var tenderPropertiesJson = JSON.parse(purchaseTender.propertiesJson);
								
								if(tenderPropertiesJson && 
										tenderPropertiesJson.applicableReturnTypes != undefined && 
										tenderPropertiesJson.applicableReturnTypes != null){
										if(tenderPropertiesJson.applicableReturnTypes.indexOf(tenders[i].id) != -1){
											if(returnTenders.indexOf(tenders[i]) < 0){
												returnTenders.push(tenders[i]);
											}
										}
									}
									else{
										//forcing to cash only if applicable tenders not set up for a tender
										if(tenders[i].id == Constants.ITEM_TY_CASH_TENDER){
											if(returnTenders.indexOf(tenders[i])<0){
												returnTenders.push(tenders[i]);
											}
										}
									}
							});
						}
						return returnTenders;
					}
				else{
					//return without receipt, use the allowed return tenders config.
					var returnTenders = [];
					for (var i = 0; i < tenders.length; i++) {
						var tender = tenders[i];

						if (paymentConfig.allowedRefundTenders && paymentConfig.allowedRefundTenders != null &&
							paymentConfig.allowedRefundTenders.indexOf(tender.id) == -1) {
							continue; //skip this tender as it is not configured for return...
						} else {
							if(tender.id === "giftCard" && paymentConfig.minAmountToReturnToGiftCard &&
								paymentConfig.minAmountToReturnToGiftCard != null &&
								((0 - tranObj.getBalance()) < paymentConfig.minAmountToReturnToGiftCard)){
								// if the return amount is less than the configured min amount that can be
								// put into a gift card, do not show the gift card tender. ** Only TP **
								continue;
							}
							returnTenders.push(tender);
						}
					}

					var retVal = [];
					if (isStoreCreditAllowed && isStoreCreditAllowed === 1) {
						if (forceSCinReturn && forceSCinReturn === 1) {
							//return just storecredit Tender...
							for (var i = 0; i < returnTenders.length; i++) {
								var returnTender = returnTenders[i];
								if (returnTender.id == Constants.ITEM_TY_STORECREDIT_TENDER) {
									retVal.push(returnTender);
									break;
								}
							}
						} else {
							retVal = returnTenders;
						}
					} else {
						for (var i = 0; i < returnTenders.length; i++) {
							var returnTender = returnTenders[i];
							if (returnTender.id !== Constants.ITEM_TY_STORECREDIT_TENDER) {
								retVal.push(returnTender);
							}
						}
					}
					return retVal;
				}
			} else {
				return tenders;
			}
		}

		function removeStoreCreditTenderFromMenu(tenders){
			var index = -1;
			for (var tenderIdx = 0, length = tenders.length; tenderIdx < length; tenderIdx++) {
				//use id
				if (tenders[tenderIdx].id == Constants.ITEM_TY_STORECREDIT_TENDER) {
					//tenders.splice(tenderId, 1);
					index = tenderIdx;
					break;
				}
			}

			if (index != -1){
				tenders.splice(index, 1);
			}
			return tenders;
		}

		function checkIfManualCardEntryAllowed(tranObj, tenders) {
			var itemCount = 0;
			for(var i=0; i<tranObj.getTranItems().length; i++){
				if(tranObj.getTranItems()[i].getItemType() == Constants.ITEM_TY_DELIVERY_OPTION ||
						tranObj.getTranItems()[i].getItemType() == Constants.ITEM_TY_STORE_COLLECT_OPTION){
					itemCount = 1; 
				}
				else if(tranObj.getTranItems()[i].getItemType() == Constants.ITEM_TY_DELIVERY_VOID_ITEM) {
					itemCount = 0;
				}
			}
			if(itemCount === 0){
				tenders = removeManualCardEntryTenderFromMenu(tenders);
			}
			return tenders;
		}

		function removeManualCardEntryTenderFromMenu(tenders){
			var index = -1;
			for (var tenderIdx = 0, length = tenders.length; tenderIdx < length; tenderIdx++) {
				//use id
				if (tenders[tenderIdx].id == Constants.ITEM_TY_MANUAL_CARD_ENTRY_TENDER) {
					//tenders.splice(tenderId, 1);
					index = tenderIdx;
					break;
				}
			}

			if (index != -1){
				tenders.splice(index, 1);
			}
			return tenders;
		}

		function filterTendersForForceStoreCredit(tranObj, tenders, isStoreCreditAllowed, useSCIfPresent) {

			//If this is a refund, remove tender types for which we don't support refunds.
			if(isStoreCreditAllowed != undefined && isStoreCreditAllowed != null && isStoreCreditAllowed == 1){
				if (tranObj.getLoyaltyUser() != undefined && tranObj.getLoyaltyUser() != null) {
					var scBal = tranObj.getLoyaltyUser().storeCreditBalance;
					var currentlyUsedSCBal = tranObj.getUsedStoreCreditBalance();

					if(tranObj.getBalance() >= 0){
						//customer is paying. So check if they have SC balance.
						if (scBal == undefined || scBal <= 0 || ((scBal - currentlyUsedSCBal) <= 0)){
							return removeStoreCreditTenderFromMenu(tenders);
						}
					}

					if(useSCIfPresent != undefined && useSCIfPresent != null && useSCIfPresent == 1){
						var returnTenders = [];
						for(var i=0; i<tenders.length; i++) {

							if(tenders[i].id == Constants.ITEM_TY_STORECREDIT_TENDER){
								returnTenders.push(tenders[i]);
								break;
							}
						}
						return returnTenders;
					} else {
						return tenders;
					}
				}else{
					return tenders;
				}
			}else{
				return removeStoreCreditTenderFromMenu(tenders);
			}

		}

		function getPaymentTenderTypeMenuJson() {
			return when(dbUtil.executeQuery(sqlQuery)).then(function (tenders) {
				var menu = [];
				var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
				var isStoreCreditAllowed = require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").isStoreCreditAllowed;
				var paymentConfig = require("ovc/ConfigManager").getConfigObject("posMClient/payment.ovccfg");
				var forceSCinReturn = require("ovc/ConfigManager").getConfigObject("posMClient/payment.ovccfg").forceToStoreCreditWhenReturnWithoutReceipt;
				var useSCIfPresent = require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").useStoreCreditBalanceIfPresent;

				var json = { //made to mimic pos_checkout.ovcmnu
					menuId: "posCheckoutMenuView",
					title: "Checkout",
					backViewId: "mainMenuView",
					backTransition: "slide",
					menu: menu, 
			        onBackFunction : function(){
			        	require("ovc/ProcessEngine").invokeProcess("posMClient/SetScanTarget.ovcprc", {page:'pos'});
			        },
					completeProcess: {
						label: "RSRC(menus.checkout.completeDeposit)",
						invokeProcess: "posMClient/Checkout/CompleteLayawayDeposit.ovcprc",
						inputParams: "{}"
					}
				};
				tenders = filterTendersForLayaway(tranObj, tenders, json);
				tenders = filterTendersForReturn(tranObj, tenders, paymentConfig, isStoreCreditAllowed, forceSCinReturn);

				tenders = filterTendersForForceStoreCredit(tranObj, tenders, isStoreCreditAllowed, useSCIfPresent);
				tenders = checkIfManualCardEntryAllowed(tranObj, tenders);

				for(var i=0; i<tenders.length; i++) {

					var tender = tenders[i];

					//look into this for the money orders and travelers checks tenders
					if (tender.description === "specialPayment") {
						menu.push({
							id: tender.id,
							viewPermission: "viewTender" + tender.id,
							executePermission: "executeTender" + tender.id,
							label: "RSRC(menus.checkout." + tender.description + ")",
							invokeProcess: "posMClient/OpenReasonCodeMenuView.ovcprc",
							inputParams: "{ overRideCloseBtn : 'back', moveFromId: 'posCheckoutMenuView', moveToId: 'specialPaymentReasonCodesView', viewTitle: 'Special', listTitle: 'Reason:', completeLabel: 'Close', reasonCodeType: 'specialPayment', scopeType: '2', targetProcess: 'posMClient/Checkout/CheckoutWithSpecialPayment.ovcprc' }"
						})
					}
					else if (tender.description === "3rdPartyCheck") {
						menu.push({
							id: tender.id,
							viewPermission: "viewTender" + tender.id,
							executePermission: "executeTender" + tender.id,
							label: "RSRC(menus.checkout." + tender.description + ")",
							invokeProcess: "posMClient/OpenReasonCodeMenuView.ovcprc",
							inputParams: "{ overRideCloseBtn : 'back', moveFromId: 'posCheckoutMenuView', moveToId: '3rdPartyCheckReasonCodesView', viewTitle: '3rd Party Check', listTitle: 'Reason:', completeLabel: 'Close', reasonCodeType: '3rdPartyCheck', scopeType: '2', targetProcess: 'posMClient/Checkout/CheckoutWith3rdPartyCheck.ovcprc' }"
						})
					}
					else if (tender.description === "storeCredit") {
						var storeCreditClicked = require('posmclient/OVCPosSubMenu.states').setTenderId(tender.id);

						menu.push({
							id: tender.id,
							viewPermission: "viewTender" + tender.id,
							executePermission: "executeTender" + tender.id,
							label: "RSRC(menus.checkout." + tender.description + ")",
							invokeProcess: "posMClient/Checkout/Checkout.ovcprc",
							inputParams: "{ tenderType: '" + tender.id + "', isStoreCreditClicked:true }"
						});
					}
					else if (tender.description === "debit" || tender.description === "manualCardEntry" ) {
						var isPaymentDeviceReady = require('posmclient/OVCPosSubMenu.states').isPaymentDeviceReady();
						if(isPaymentDeviceReady){
							menu.push({
								id: tender.id,
								viewPermission: "viewTender" + tender.id,
								executePermission: "executeTender" + tender.id,
								label: "RSRC(menus.checkout." + tender.description + ")",
								invokeProcess: "posMClient/Checkout/Checkout.ovcprc",
								inputParams: "{ tenderType: '" + tender.id + "' }"
							});
						}
					}
					else if (tender.description === "change") {
						return;
					}
					else {
						menu.push({
							id: tender.id,
							viewPermission: "viewTender" + tender.id,
							executePermission: "executeTender" + tender.id,
							label: "RSRC(menus.checkout." + tender.description + ")",
							invokeProcess: "posMClient/Checkout/Checkout.ovcprc",
							inputParams: "{ tenderType: '" + tender.id + "' }"
						});
					}
				}
				return json;
			});
		}

		var checkout = declare(null, {
			getPaymentTenderTypeMenuJson: getPaymentTenderTypeMenuJson
		});

		return new checkout();
	});
