// This module serves as a home for unique JavaScript utilites that don't easily fit into their own module,
// such as StringUtils. If several related methods end up here, they should be split out into their own module.
define(['dojo/_base/declare','dojo/Deferred'], function(declare,Deferred) {
	
	var actionPermissions = {
			"addProduct":"executeAddProduct",
			"lookup":"executeLookup",
			"refund":"executeReturn",
			"discount":"executeDiscount",
			"void":"executeVoid",
			"itemModifiers":"executeItemModifiers",
			"feeItem" : "executeFeeItem",
			"resumeTransaction":"executeResumeTransaction",
			"suspendTransaction":"executeSuspendTransaction",
			"noSale":"executeNoSale",
			"layaway":"executeLayaway",
			"site":"executeSite",
			"loyalty":"executeLoyalty",
			"createQuote":"executeCreateQuote",
			"deleteQuote":"executeDeleteQuote",
			"managerKey":"executeManagerKey",
			"tandAManager":"executeTandAManager",
			"taxExemption":"executeTaxExempt",
			"giftCertificate":"executeGiftCert",
			"signOut":"executeSignOut",
			"checkOut":"executeCheckout",
			"retrieveQuote" : "executeRetrieveQuote",
			"lockTill" : "executeLockTill",
			"giftCard" : "executeGiftCard",
			"deliveryOption" : "executeDeliveryOption",
			"orderSearch" : "executeOrderSearch"
	};

	var freeActions = ["signOut", "addProduct", "setTaxExemptClicked", "isTaxExemptClicked"];

	var theRolePermissionsUtils = declare("generic.RolePermissionsUtils", null, {

		validateExecutePermission: function (actionId, actionPermId) {
			var deferred = new Deferred();

			if (freeActions.indexOf(actionId) != -1) {
				deferred.resolve(true);
			} else {
				if (typeof actionPermId == 'undefined') {
					actionPermId = actionPermissions[actionId];
				}
				//using a global variable logged in userObject(uObj) to fetch permissions
				if (uObj.permissions && actionPermId && typeof (uObj.permissions)[actionPermId] != 'undefined') {
					deferred.resolve(true);
				} else {
					console.log('Executing action:' + actionId);

					/*var processPromise = require("ovc/ProcessEngine").invokeProcess("posMClient/CheckIfNeedAuthorization.ovcprc", {
					 permissionId: actionPermId
					 });*/
					var authorizationFlag = false;

					require(["dojo/when"], function (when) {

						when(require("ovc/ProcessEngine").invokeProcess(
							'posMClient/CheckIfNeedAuthorization.ovcprc',
							{
								permissionId: actionPermId
							}, function (res) {
								console.log('Finish method' + res.isApproved);
								if (res.loginFailure == false && (typeof res.isApproved == 'undefined' || !res.isApproved)) {
									require("ovc/ProcessEngine").invokeProcess("generic/Alert.ovcprc", {
										message: 'You are not authorized to perform this function.'
									});
								}
								deferred.resolve(res.isApproved);
							})).then(function () {
						});
					});

				}
			}
			return deferred.promise;
		},
		doesLoggerInUserHaveExecutePermission: function(permId){
			if(permId && permId.indexOf("execute")==0 && uObj.permissions && typeof (uObj.permissions)[permId] != 'undefined'){
				return true;
			}
			return false;
		},
		
		doesLoggerInUserHaveViewPermission: function(permId){
			if(permId && permId.indexOf("view")==0 && uObj.permissions && typeof (uObj.permissions)[permId] != 'undefined'){
				return true;
			}
			return false;
		}

	});
	
	return new theRolePermissionsUtils();
});
