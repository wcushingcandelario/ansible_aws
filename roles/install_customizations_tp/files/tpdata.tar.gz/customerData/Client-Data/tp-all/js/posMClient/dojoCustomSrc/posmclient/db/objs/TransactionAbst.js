define(["dojo/_base/declare",
		"dojo/date/locale",
		"dojo/Deferred",
		"generic/db/objs/Record",
		"ovc/Util",
		'generic/GenericUtils',
		"ovc/ConfigManager",
		"dojox/uuid/generateRandomUuid",
		"posmclient/db/objs/TransactionItem",
		"posmclient/lib/ovcPromotionEngine.min",
		"generic/db/DBUtil",
		"generic/Constants",
		"dojo/when",
		"dojo/json",
		"posmclient/db/objs/dto/promotion/Basket",
		"posmclient/db/objs/dto/promotion/BasketItem",
		"posmclient/db/objs/dto/promotion/Discount",
		"posmclient/db/objs/dto/promotion/ItemDiscount",
		"generic/StringUtils"
	],

	function (declare, locale, Deferred, Record, util, GenericUtils, ConfigManager, generateRandomUuid, TransactionItem, promoEngine, DBUtil, Constants, when, json, Basket, BasketItem, Discount, ItemDiscount, StringUtils) {
		return declare("posmclient.db.objs.TransactionAbst", Record, {

			_TABLE_NAME: 'tran_tbl',
			_COLUMN_WITH_TYPES: {
				'id': '', //0
				'tranNo': '', //1
				'userId': '', //2
				'retailerId': '', //3
				'storeId': '', //4
				'deviceId': '', //5
				'drawerId': '', //6
				'tillId': '', //7
				'loyaltyId': '', //8
				'customerEmail': '', //9
				'tranTypeId': '', //10
				'isTranVoid': '', //11
				'totalItems': '', //12
				'merchTotal': '', //13
				'promoTotal': '', //14
				'tax': '', //15
				'total': '', //16
				'totalVAT': '', //17
				'tranDate': 'DATETIME', //18
				'barcode': '', //19
				'training': '', //20
				'receiptJSON': '', //21
				'layawayObj': '', //22
				'currencyId': '', //23
				'BBASSavingsMap': ''//24
			},
			_UNIQUE_COLUMNS: [],
			_PK_COLUMNS: ['id'],

			_GH8H43GT56: null, // isLocked

			_id: null,
			_tranNo: null,
			_userId: null,
			_retailerId: null,
			_storeId: null,
			_deviceId: null,
			_drawerId: null,
			_tillId: null,

			_customerType: null,
			_loyaltyId: null,
			_loyaltyUser: null,
			_customerEmail: null,

			_tranTypeId: null,
			_isTranVoid: null,

			_totalItems: null,
			_totalRefundItems: null,
			_merchTotal: null,
			_tax: null,
			_addOnVATTax:null,
			_total: null,
			_totalVAT: null,
			_promoTotal: null,

			_calculatedTranItems: null,
			_calculatedTranItemsHistory: null,
			_calculatedPromos: null,
			_calculatedAlerts: null,
			_discrepancy: null,
			_isTaxExempt: null,
			_TaxExemptReasonCode: null,
			_quoteId: null,

			_tranTimestamp: null,
			_barcode: null,
			_training: null,
			_receiptJSON: {},
			_layawayObj: {},
			_currencyId: null,
			_totalBBASSavings: null,
			_expiredPromos: [],
			_currentMode: 0,
			_dirtyFlags: null,

			// actual transaction data members
			_A3G5J2RT67: null, // tran items
			_J67DE5GC89: null, // tran items history

			//in memory only
			_gcbalanceMap: null,

			constructor: function () {
				try {
					this._GH8H43GT56 = false;
					this._dirtyFlags = [false, false, false, false, false, false, false, false, false, false,
						false, false, false, false, false, false, false, false, false, false,
						false, false, false, false, false];

					this.setId(generateRandomUuid());
					this.setUserId(localStorage.getObject(username).id);
					this.setRetailerId(this.getDefaultRetailerId());
					this.setTranTypeId(Constants.TX_TY_REGULAR_SALE);

					if (localStorage.getObject("trainingMode") && localStorage.getObject("trainingMode") == true) {
						this.setTraining(1);
					} else {
						this.setTraining(0);
					}

					var paymentConfig = ConfigManager.getConfigObject("posMClient/payment.ovccfg");
					if (paymentConfig &&
						paymentConfig != null &&
						paymentConfig.defaultCurrency &&
						paymentConfig.defaultCurrency != null) {
						this.setCurrencyId(paymentConfig.defaultCurrency);
					}

					// only log when in training mode
					if (this.getTraining() > 0) {
						console.log("Transaction " + this.getId() + " of " + this.getTranTypeId() + " getting created with training mode : " + this.getTraining());
					}

					var dvcObj = localStorage.getObject(dUUID);
					this.setStoreId(dvcObj.storeId);
					this.setDeviceId(dvcObj.id);

					/**Till is guaranteed to be stored when the user login is successful
					 * It will have one of the following values depending on the property 'promptForTillNew' from app.ovccfg
					 * 1. value collected from the user through login page
					 * 1. value read from the config 'defaultTillId' app.ovccfg
					 */
					this.setTillId(localStorage.getObject('till'));
					this._totalItems = 0;
					this._merchTotal = 0;
					this._tax = 0;
					this._addOnVATTax = 0;
					this._total = 0;
					this._totalVAT = 0;
					this._promoTotal = 0;
					this._receiptJSON = {};
					this._layawayObj = {};

					this._calculatedTranItems = [];
					this._calculatedTranItemsHistory = {};
					this._calculatedPromos = {};
					this._calculatedAlerts = {};

					this._A3G5J2RT67 = [];
					this._J67DE5GC89 = {};
					this._gcbalanceMap = {};

					require(["posmclient/CometdDemo"], function (Cometd) {
						Cometd.clearUser();
					});

				} catch (e) {
					throw util.rethrow(e, 'Transaction.construct');
				}
			},

			// Private methods
			_isLocked: function () {
				return this._GH8H43GT56;
			},

			// Public methods
			lock: function () {
				if (!this._isLocked()) {
					var timeStamp = this.getTranTimestamp();
					if(timeStamp == undefined || timeStamp == null){
						this.setTranTimestamp((new Date()).getTime());
						timeStamp = this.getTranTimestamp();
					}
					this.setBarcode(this.generateBarcode(new Date(timeStamp).getTime().toString(), false));
					this.setQuoteId(this.generateBarcode(new Date(timeStamp).getTime().toString(), true));

					this._GH8H43GT56 = true;
				}
			},

			getId: function () {
				return this._id;
			},

			setId: function (id) {
				try {
					if (this._isLocked()) {
						throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setId1']);
					} else {
						this._id = id;
						this._dirtyFlags[0] = true;
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.setId');
				}
			},

			getTranNo: function () {
				return this._tranNo;
			},

			setTranNo: function (tranNo) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTranNo']);
				} else {
					this._tranNo = tranNo;
					this._dirtyFlags[1] = true;
				}
			},

			getUserId: function () {
				return this._userId;
			},

			setUserId: function (userId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setUserId']);
				} else {
					this._userId = userId;
					this._dirtyFlags[2] = true;
				}
			},

			getCurrencyId: function () {
				return this._currencyId;
			},

			setCurrencyId: function (currencyId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCurrencyId']);
				} else {
					this._currencyId = currencyId;
					this._dirtyFlags[23] = true;
				}
			},

			getBBASSavingsMap: function () {
				return this._BBASSavingsMap;
			},

			setBBASSavingsMap: function (BBASSavingsMap) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotalBBASSavings']);
				} else {
					this._BBASSavingsMap = BBASSavingsMap;
					this._dirtyFlags[24] = true;
				}
			},

			calcBBASSavings: function(){
				var totalSavings = 0;
				for (var key in this._BBASSavingsMap) {
					if (this._BBASSavingsMap.hasOwnProperty(key)) {
						totalSavings += this._BBASSavingsMap[key];
					}
				}
				return totalSavings;
			},

			getRetailerId: function () {
				return this._retailerId;
			},

			setRetailerId: function (retailerId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setRetailerId']);
				} else {
					this._retailerId = retailerId;
					this._dirtyFlags[3] = true;
				}
			},

			getStoreId: function () {
				return this._storeId;
			},

			setStoreId: function (storeId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setStoreId']);
				} else {
					this._storeId = storeId;
					this._dirtyFlags[4] = true;
				}
			},

			getDeviceId: function () {
				return this._deviceId;
			},

			setDeviceId: function (deviceId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setDeviceId']);
				} else {
					this._deviceId = deviceId;
					this._dirtyFlags[5] = true;
				}
			},

			getDrawerId: function () {
				return this._drawerId;
			},

			setDrawerId: function (drawerId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setDrawerId']);
				} else {
					this._drawerId = drawerId;
					this._dirtyFlags[6] = true;
				}
			},

			getTillId: function () {
				if (this._tillId == null || this._tillId == '') {
					this._tillId = localStorage.getObject('till');
				}
				return this._tillId;
			},

			setTillId: function (tillId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTillId']);
				} else {
					this._tillId = tillId;
					this._dirtyFlags[7] = true;
				}
			},

			getCurrentMode: function () {
				return this._currentMode;
			},

			setCurrentMode: function (currentMode) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCurrentMode']);
				} else {
					this._currentMode = currentMode;
				}
			},

			getCustomerType: function () {
				return this._customerType;
			},

			setCustomerType: function (customerType) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCustomerType']);
				} else {
					this._customerType = customerType;
				}
			},

			getLoyaltyId: function () {
				return this._loyaltyId;
			},

			setLoyaltyId: function (loyaltyId, loyaltyFName, loyaltyLName, loyaltyEmail, numberOfLayaways, storeCreditBalance, arAccountNumber, phone, taxExemptInfo) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setLoyaltyId']);
				} else {
					this._loyaltyId = loyaltyId;
					require(["posmclient/CometdDemo"], function (Cometd) {
						Cometd.setUser(loyaltyId);
					});
					this._dirtyFlags[8] = true;
					this._loyaltyUser = {
						'loyaltyId': loyaltyId,
						'loyaltyFName': loyaltyFName,
						'loyaltyLName': loyaltyLName,
						'loyaltyEmail': loyaltyEmail,
						'numberOfLayaways': numberOfLayaways,
						'storeCreditBalance': storeCreditBalance,
						'arAccountNumber': arAccountNumber,
						'phone': phone,
						'taxExemptInfo': taxExemptInfo
					};

					try {
						// Create tranItem and add to transaction
						var tranItem = new TransactionItem();
						tranItem.setTranId(this._id);

						tranItem.setItemType(Constants.ITEM_TY_LOYALTY_ID);

						var tranItemLoyaltyUser = this.convertToTranItemLoyaltyUser(loyaltyId, loyaltyFName, loyaltyLName, loyaltyEmail, this._id, null, taxExemptInfo);
						tranItem.setLoyaltyUser(tranItemLoyaltyUser);

						// Add to transaction
						tranItem = this.addItemToTransaction(tranItem);

						this._recalcTransaction();

						return tranItem;
					} catch (e) {
						throw util.rethrow(e, 'Transaction.setLoyaltyId');
					}
				}
			},

			removeLoyalty: function (loyaltyId, refItemIdx, reasonCodeId, isResume) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setLoyaltyId']);
				} else {
					//Undo or void this set user - Todo
					this._loyaltyId = null;
					require(["posmclient/CometdDemo"], function (Cometd) {
						Cometd.setUser(loyaltyId);
					});
					this._dirtyFlags[8] = false;
					this._loyaltyUser = null;

					try {
						// Create tranItem and add to transaction
						var voidCustomer = new TransactionItem();
						voidCustomer.setTranId(this._id);
						voidCustomer.setItemType(Constants.ITEM_TY_VOID_LOYALTY_ID);
						voidCustomer.setRefItemIdx(refItemIdx);
						voidCustomer.setReasonCodeId(reasonCodeId);

						// Add to transaction
						voidCustomer = this.addItemToTransaction(voidCustomer);

						_.forEach(this.getAllItemsHistoryIdxArray(), function (itemHistory) {
							var tranItem = this.getTranItemByIdx(itemHistory);
							if (!this.isItemVoidByIdx(itemHistory) && tranItem.getProduct().getPickupOrderId() == null) {
								// revert to the old tax rate and percentage if it was changed....
								_.forEach(tranItem.getProduct().getTaxRates(), function (productTaxRate) {
									if (productTaxRate.prevTaxRateId) {
										productTaxRate.setTaxRateId(productTaxRate.prevTaxRateId);
									}
									if (productTaxRate.prevPercentage) {
										productTaxRate.setPercentage(productTaxRate.prevPercentage);
									}
								});
							}
						}, this);

						//if it is layaway and not resume, after removing the customer reset to regular sale mode
						if (!isResume && this.isLayaway() && this.countProductsThatCanBeVoided() <= 0) {
							this.setTranTypeId(Constants.TX_TY_REGULAR_SALE);
						}

						this._recalcTransaction();

						return voidCustomer;
					} catch (e) {
						throw util.rethrow(e, 'Transaction.removeLoyalty');
					}
				}
			},

			getLoyaltyUser: function () {
				return this._loyaltyUser;
			},
			
			isCustomerTaxExempt : function(){
				return (this.getLoyaltyUser() != null && this.getLoyaltyUser().taxExemptInfo != null && 
						this.getLoyaltyUser().taxExemptInfo.taxId != null && this.getLoyaltyUser().taxExemptInfo.taxId != '');
			},
			
			getCustomerEmail: function () {
				return this._customerEmail;
			},

			setCustomerEmail: function (customerEmail) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCustomerEmail']);
				} else {
					this._customerEmail = customerEmail;
					this._dirtyFlags[9] = true;
				}
			},

			getTranTypeId: function () {
				return this._tranTypeId;
			},

			setTranTypeId: function (tranTypeId) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTranTypeId']);
				} else {
					this._tranTypeId = tranTypeId;
					this._dirtyFlags[10] = true;
				}
			},

			getIsTranVoid: function () {
				return this._isTranVoid;
			},

			setIsTranVoid: function (isTranVoid) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setIsTranVoid']);
				} else {
					this._isTranVoid = isTranVoid;
					this._dirtyFlags[11] = true;
				}
			},

			getTotalItems: function () {
				return this._totalItems;
			},

			setTotalItems: function (totalItems) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotalItems']);
				} else {
					this._totalItems = parseInt(totalItems);
					this._dirtyFlags[12] = true;
				}
			},

			getTotalRefundItems: function () {
				return this._totalRefundItems;
			},

			setTotalRefundItems: function (totalRefundItems) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotalRefundItems']);
				} else {
					this._totalRefundItems = parseInt(totalRefundItems);
					this._dirtyFlags[13] = true;
				}
			},

			getMerchTotal: function () {
				return this._merchTotal;
			},

			setMerchTotal: function (merchTotal) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setMerchTotal']);
				} else {
					this._merchTotal = parseFloat(merchTotal);
					this._dirtyFlags[14] = true;
				}
			},

			getPromoTotal: function () {
				return this._promoTotal;
			},

			setPromoTotal: function (promoTotal) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotal']);
				} else {
					this._promoTotal = parseFloat(promoTotal);
					this._dirtyFlags[15] = true;
				}
			},

			getTax: function () {
				return this._tax;
			},

			getAddonVATTax: function () {
				return this._addOnVATTax;
			},


			calculateAddOnVATTax: function (taxRatesJson) {
				var totalAddOnTax = 0;
				// sum up all non VAT taxes from all tax rates
				_.forEach(taxRatesJson, function (taxRate) {
					if(taxRate.addOnVATTaxTotal != undefined && taxRate.addOnVATTaxTotal != null){
						totalAddOnTax += taxRate.addOnVATTaxTotal;
					}
				});

				return totalAddOnTax;
			},

			calculateTax: function (taxRatesJson) {
				var totalTax = 0;

				// sum up all non VAT taxes from all tax rates
				_.forEach(taxRatesJson, function (taxRate) {
					totalTax += taxRate.taxTotal;
				});

				return totalTax;
			},

			calculateDeliveryOption: function () {
				var totalDelivery = 0;
				_.forEach(this.getTranItems(), function (tranItem) {
					if (tranItem.getItemType() == Constants.ITEM_TY_DELIVERY_OPTION ||
						tranItem.getItemType() == Constants.ITEM_TY_STORE_COLLECT_OPTION) {
						if(tranItem.getRefItemIdx() != -1){
							totalDelivery += tranItem.getAmount(); 
						}
					}  
				}, this);

				return totalDelivery;
			},

			calculateTaxExempt: function (taxRatesJson) {
				var totalTax = 0;

				// sum up all non VAT taxes from all tax rates
				_.forEach(taxRatesJson, function (taxRateId) {
					totalTax += taxRateId.taxExemptTotal;
				});

				return totalTax;
			},

			getTaxRates: function (getOnlyNonDiscountableItems) {
				var taxRatesResultsJson = {};

				// loop over all items
				_.forEach(this.getAllItemsHistoryIdxArray(), function (itemHistoryIdx, i) {
					var tranItem = this.getTranItemByIdx(itemHistoryIdx);
					if (getOnlyNonDiscountableItems && !(tranItem.getItemType() === Constants.ITEM_TY_REFUND_PRODUCT ||
						tranItem.getItemType() === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
						tranItem.getItemType() === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT)) {
						return; // continue with _.forEach loop
					}

					if (!this.isItemVoidByIdx(itemHistoryIdx) &&
						tranItem.getProduct().getPickupOrderId() == null) {
						var tranItemProduct = tranItem.getProduct();
						var amountToApplyTaxOn = this.getSpecificItemHistory(itemHistoryIdx).calcUnitPrice * tranItem.getQty();

						// Deduct prorated promos value
						var calculatedTranItemsHistory = this.getCalculatedTranItemsHistory();
						var calculatedTranItemHistory = calculatedTranItemsHistory[i];
						if (calculatedTranItemHistory) {
							_.forEach(calculatedTranItemHistory.history, function (historyItem) {
								if (historyItem.isPromo &&
									historyItem.qtyPromosAccountedFor > 0) {
									amountToApplyTaxOn = amountToApplyTaxOn + historyItem.promoAmount;
								}
							});
						}

						var productTaxRatesArr = tranItemProduct.getTaxRates();
						
						// loop over all item's tax rates
						_.forEach(productTaxRatesArr, function (productTaxRate) {
							if (productTaxRate.getIsVAT() == 0/*false*/) {
								var taxRateResultJson = taxRatesResultsJson[productTaxRate.getTaxRateId()];

								var additionalTax = Math.round((productTaxRate.getPercentage() * amountToApplyTaxOn / 100) * 100) / 100;
								if (taxRateResultJson == null) {
									taxRateResultJson = {taxTotal: 0, taxExemptTotal: 0};
								}

								if (tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT) {
									taxRateResultJson.taxTotal = taxRateResultJson.taxTotal - additionalTax;
								} else {
									var taxExempt = this.isCustomerTaxExempt();

									if (taxExempt != null && taxExempt == true && productTaxRate.getTaxRateId() === this.getDefaultTaxRate()) {
										additionalTax = Math.round((parseInt(productTaxRate._displayCode) * amountToApplyTaxOn / 100) * 100) / 100;
										taxRateResultJson.taxExemptTotal = taxRateResultJson.taxExemptTotal + additionalTax;
										taxRateResultJson.taxTotal = taxRateResultJson.taxTotal + additionalTax;
									} else {
										taxRateResultJson.taxTotal = taxRateResultJson.taxTotal + additionalTax;
									}
								}
								taxRatesResultsJson[productTaxRate.getTaxRateId()] = taxRateResultJson;
							}else if (productTaxRate.getIsVAT() == 2/*Addon VAT*/) {
								var taxRateResultJson = taxRatesResultsJson[productTaxRate.getTaxRateId()];

								var additionalTax = Math.round((productTaxRate.getPercentage() * amountToApplyTaxOn / 100) * 100) / 100;
								if (taxRateResultJson == null) {
									taxRateResultJson = {taxTotal: 0, addOnVATTaxTotal:0, taxExemptTotal: 0};
								} 
								
								var taxExempt = ( 
									this.getLoyaltyUser() != null &&
									this.getLoyaltyUser().taxId !== undefined &&
									this.getLoyaltyUser().taxId != ''
								);

								if (taxExempt && productTaxRate.getTaxRateId() === this.getDefaultTaxRate()) {
									additionalTax = Math.round((parseInt(productTaxRate._displayCode) * amountToApplyTaxOn / 100) * 100) / 100;
									taxRateResultJson.taxExemptTotal = taxRateResultJson.taxExemptTotal + additionalTax;
									if(tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT)
										taxRateResultJson.addOnVATTaxTotal = taxRateResultJson.addOnVATTaxTotal - additionalTax;
									else 
										taxRateResultJson.addOnVATTaxTotal = taxRateResultJson.addOnVATTaxTotal + additionalTax;
								} else { 
									if(tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT)
										taxRateResultJson.addOnVATTaxTotal = taxRateResultJson.addOnVATTaxTotal - additionalTax;
									else 
										taxRateResultJson.addOnVATTaxTotal = taxRateResultJson.addOnVATTaxTotal + additionalTax;
								}  
								
								 
								taxRatesResultsJson[productTaxRate.getTaxRateId()] = taxRateResultJson;
							}
						}, this);
					}
				}, this);

				return taxRatesResultsJson;
			},

			getDefaultTaxRate: function () {
				return ConfigManager.getConfigObject('posMClient/taxValidator.ovccfg').defaultTaxRate;
			},

			getDefaultTaxPercentage: function () {
				return ConfigManager.getConfigObject('posMClient/taxValidator.ovccfg').defaultTaxRatePercent;
			},

			setAddOnVATTax: function (tax) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setAddOnVATTax']);
				} else {
					this._addOnVATTax = parseFloat(tax);
				}
			},

			setTax: function (tax) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTax']);
				} else {
					this._tax = parseFloat(tax);
				}
			},

			getQuoteId: function () {
				return this._quoteId;
			},

			setQuoteId: function (barCode) {
				this._quoteId = barCode;
			},

			getQuoteRefTranId: function () {
				var quoteRefTranId = null;
				_.forEach(this.getCalculatedTranItems(), function (calculatedTranItem) {
					if (calculatedTranItem.getItemType() == Constants.ITEM_TY_RESUME_QUOTE_TXN) {
						quoteRefTranId = calculatedTranItem.getRefTranId();
					}
				});
				return quoteRefTranId;
			},

			setQuote: function () {
				this._receiptJSON._quoteId = this._quoteId;
				this.setTranTypeId(Constants.TX_TY_QUOTE);
				this._dirtyFlags[21] = true;
			},

			getTaxExempt: function () {
				return this._taxExemptValue;
			},

			setTaxExempt: function (tax) {
				this._receiptJSON._taxExemptValue = parseFloat(tax);
				this._taxExemptValue = parseFloat(tax);
				this._receiptJSON._taxCertificateId = this.getLoyaltyUser().taxExemptInfo.taxId;
				this._dirtyFlags[21] = true;
			},

			/**
			 * _isTaxExempt can take 3 different values which mean the following
			 * undefined - the the tax Exemption has not been attempted at all
			 * true - the the tax Exemption has been attempted and the user has been successfully validated
			 */
			getCustomerTaxExempt: function () {
				return this._isTaxExempt;
			},

			setCustomerTaxExempt: function (isTaxExempt) {
				this._receiptJSON._isTaxExempt = isTaxExempt;
				this._isTaxExempt = isTaxExempt;
				this._dirtyFlags[21] = true;
			},

			getCustomerTaxExemptReasonCode: function () {
				return this._TaxExemptReasonCode;
			},

			setCustomerTaxExemptReasonCode: function (taxExemptReasonCode) {
				this._receiptJSON._TaxExemptReasonCode = taxExemptReasonCode;
				this._TaxExemptReasonCode = taxExemptReasonCode;
				this._dirtyFlags[21] = true;
			},


			getTotal: function () {
				return this._total;
			},

			setTotal: function (total) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotal']);
				} else {
					this._total = parseFloat(total);
					this._dirtyFlags[17] = true;
				}
			},

			getTotalVAT: function () {
				return this._totalVAT;
			},

			setTotalVAT: function (totalVAT) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTotalVAT']);
				} else {
					this._totalVAT = parseFloat(totalVAT);
					this._dirtyFlags[18] = true;
				}
			},

			getTranTimestamp: function () {
				return this._tranTimestamp;
			},

			setTranTimestamp: function (tranTimestamp) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTranTimestamp']);
				} else {
					this._tranTimestamp = tranTimestamp;
					this._dirtyFlags[19] = true;
				}
			},

			getBarcode: function () {
				return this._barcode;
			},

			setBarcode: function (barcode) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setBarcode']);
				} else {
					this._barcode = barcode;
					this._dirtyFlags[20] = true;
				}
			},

			getDiscrepancy: function () {
				return this._discrepancy;
			},

			setDiscrepancy: function (discrepancy) {
				this._discrepancy = discrepancy;
				this._receiptJSON._discrepancy = discrepancy;
//				console.log("_discrepancy = "+this._receiptJSON._discrepancy);
				this._dirtyFlags[22] = true;
			},

			getTraining: function () {
				return this._training;
			},

			setTraining: function (training) {
				this._training = training;
				this._dirtyFlags[21] = true;
			},

			getReceiptJSON: function () {
				return this._receiptJSON;
			},

			getStringifyReceiptJSON: function () {
				return JSON.stringify(this.getReceiptJSON());
			},

			getStringifyLayawayJSON: function () {
				return JSON.stringify(this.getLayawayJSON());
			},

			setReceiptJSON: function (receiptJSON) {
				var dUUIDObj = localStorage.getObject(dUUID);
				if (dUUIDObj) {
					receiptJSON.deviceAlias = dUUIDObj.alias;
				}
				var userObj = localStorage.getObject(username);
				if (userObj) {
					receiptJSON.userName = userObj.firstName + " " + userObj.lastName;
				}

				this._receiptJSON = receiptJSON;
				this._receiptJSON._discrepancy = this._discrepancy;
				this._receiptJSON._isTaxExempt = this._isTaxExempt;
				this._receiptJSON._taxExemptValue = this._taxExemptValue;
				this._receiptJSON._addOnVATTax = this._addOnVATTax;
				this._receiptJSON._taxCertificateId = this._taxCertificateId;
				this._receiptJSON._TaxExemptReasonCode = this._TaxExemptReasonCode;
				this._receiptJSON._quoteId = this._quoteId;

				this._dirtyFlags[22] = true;
			},

			getLayawayJSON: function () {
				return this._layawayObj;
			},

			setLayawayJSON: function (layawayObj) {
				if (!layawayObj.id) {
					layawayObj.id = generateRandomUuid();
				}
				this._layawayObj = layawayObj;
				this._dirtyFlags[23] = true;
			},

			setLayawayBalance: function (balance) {
				if (balance != undefined && balance != null) {
					if (balance < 0) {
						this._layawayObj.balance = 0;
					} else {
						this._layawayObj.balance = balance;
					}
				}
			},

			setLayawayDeposit: function (deposit) {
				this._layawayObj.deposit = deposit;
			},

			getLayawayBalance: function () {
				if (this._isLocked() && this._layawayObj.balance) {
					return this._layawayObj.balance;
				} else {
					return null;
				}
			},

			isLayaway: function () {
				return (this._tranTypeId === Constants.TX_TY_LAYAWAY_SALE ||
				this._tranTypeId === Constants.TX_TY_LAYAWAY_PAY ||
				this._tranTypeId === Constants.TX_TY_LAYAWAY_RETURN ||
				this._tranTypeId === Constants.TX_TY_LAYAWAY_FINALIZE );
			},

			isLayawayDiscountable: function () {
				var isLayawayDiscountable = ConfigManager.getConfigObject("posMClient/layaway.ovccfg").enableDiscountsInLayaways;

				return !(
				this.isLayaway() &&
				isLayawayDiscountable !== undefined &&
				isLayawayDiscountable != null &&
				isLayawayDiscountable == 0);
			},

			isLayawaySale: function () {
				return (this._tranTypeId === Constants.TX_TY_LAYAWAY_SALE);
			},

			isLayawayPayment: function () {
				return (this._tranTypeId === Constants.TX_TY_LAYAWAY_PAY);
			},

			isLayawayRefund: function () {
				return (this._tranTypeId === Constants.TX_TY_LAYAWAY_RETURN);
			},

			isLayawayFinalize: function () {
				return (this._tranTypeId === Constants.TX_TY_LAYAWAY_FINALIZE);
			},

			getLayawayMinimum: function () {
				var layawayConfig = ConfigManager.getConfigObject('posMClient/layaway.ovccfg');
				// The config name could be misleading.
				// overrideDownPaymentRequirement = Down Payment Required (boolean Yes/No). So, if Yes, include the
				// down payment values else, no minimum deposit required.
				if (layawayConfig.overrideDownPaymentRequirement != null && layawayConfig.overrideDownPaymentRequirement === 1) {
					//return minimum value or percentage based on Config
					if (layawayConfig.minimumValueDown && layawayConfig.minimumValueDown > 0) {
						return layawayConfig.minimumValueDown;
					} else if (layawayConfig.minimumPercentageDown && layawayConfig.minimumPercentageDown > 0) {
						return Math.round(this.getTotal() * layawayConfig.minimumPercentageDown) / 100;
					}
					//by default return total amount
					return this.getTotal();
				} else {
					return 0;
				}
			},

			// Calculated setters/getters
			generateBarcode: function (barcode, isQuote) {
				var lastTranNoDigit = this.getTranNo();
				if (lastTranNoDigit > 9) {
					lastTranNoDigit = lastTranNoDigit.toString();
					lastTranNoDigit = lastTranNoDigit.substring(lastTranNoDigit.length - 1);
				}

				// Grab the last 2 chars of the user ID and convert to a 2-digit number.
				var userIdentifier = username;
				if(userIdentifier.length < 3) {
					userIdentifier = generateRandomUuid();
				}

				var idLen = userIdentifier.length;
				var lastCharASCIICode = userIdentifier.charCodeAt(idLen - 1);
				var secondToLastCharASCIICode = userIdentifier.charCodeAt(idLen - 2);
				var lastCharAsSingleDigitInt = lastCharASCIICode % 10;
				var secondToLastCharAsSingleDigitInt = secondToLastCharASCIICode % 10;

				var returnValue = "";
				if (isQuote) {
					returnValue = "q";
				}
				returnValue += barcode.substring(2) +
					secondToLastCharAsSingleDigitInt +
					lastCharAsSingleDigitInt +
					lastTranNoDigit;

				return returnValue;
			},

			getBalance: function (transformedResults) {
				if(!transformedResults){
					transformedResults = {
						calculatedTranItems : this.getTranItems()
					}
				}
				var tendersSum = this.getTendersSum(transformedResults);
				var balance = 0;

				if (this.isLayawayRefund()) {
					balance = -((tendersSum) * 100) / 100;
				} else {
					balance = Math.round((this.getTotal() - tendersSum) * 100) / 100;
				}

				//var balance = Math.round((this.getTotal() - tendersSum) * 100) / 100;
				if (this.isLayaway()) {
					this.setLayawayBalance(balance);
					if (this.isLayawaySale()) {
						if (this.getLayawayMinimum() > 0) {
							this.setLayawayDeposit(tendersSum);
						} else {
							this.setLayawayDeposit(0);
						}
					}
				}
				return balance;
			},

			getTendersSum: function (transformedResults) {
				var tendersSum = 0;
				//if this func is called without a argument, get default tranItems...
				if(!transformedResults){
					transformedResults = {
							calculatedTranItems : this.getTranItems()
					}
				}
				_.forEach(transformedResults.calculatedTranItems, function (currentItem) {
					var itemType = currentItem.getItemType();

						// Should handle the rest of these with Electronic Internal
						if (itemType == Constants.ITEM_TY_PHYSICAL_TENDER ||
							itemType == Constants.ITEM_TY_EINTEGRATED_TENDER ||
							itemType == Constants.ITEM_TY_EINTERNAL_TENDER ||
							itemType == Constants.ITEM_TY_UNKNOWN_TENDER ||
							itemType == Constants.ITEM_TY_PENNY_ROUNDING_TENDER ||
							itemType == Constants.ITEM_TY_CHECK_TENDER || 
							itemType == Constants.ITEM_TY_EEXTERNAL_TENDER) {

							tendersSum = tendersSum + currentItem.getAmount();
						}
					});
				
				return tendersSum;
			},

			getCalculatedTranItems: function () {
				return this._calculatedTranItems;
			},

			isTransactionEmpty: function () {
				var calculatedTranItems = this.getCalculatedTranItems();
				return !(calculatedTranItems != null && calculatedTranItems.length > 0);
			},

			_setCalculatedTranItems: function (calculatedTranItems) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCalculatedTranItems']);
				} else {
					this._calculatedTranItems = calculatedTranItems;
				}
			},

			getCalculatedTranItemsHistory: function () {
				return this._calculatedTranItemsHistory;
			},

			_setCalculatedTranItemsHistory: function (calculatedTranItemsHistory) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCalculatedTranItemsHistory']);
				} else {
					this._calculatedTranItemsHistory = calculatedTranItemsHistory;
				}
			},

			getCalculatedPromos: function () {
				return this._calculatedPromos;
			},

			_setCalculatedPromos: function (calculatedPromos) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCalculatedPromos']);
				} else {
					this._calculatedPromos = calculatedPromos;
				}
			},

			getCalculatedAlerts: function () {
				return this._calculatedAlerts;
			},

			_setCalculatedAlerts: function (calculatedAlerts) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setCalculatedAlerts']);
				} else {
					this._calculatedAlerts = calculatedAlerts;
				}
			},

			/* in memory only */
			getCurrentGCBalance: function (giftCertNum) {
				if (this._gcbalanceMap[giftCertNum]) {
					return this._gcbalanceMap[giftCertNum];
				} else {
					return null;
				}
			},

			setGcBalanceMap: function (giftCertNum, balance) {
				if (giftCertNum) {
					this._gcbalanceMap[giftCertNum] = balance;
				}
				console.log("this._gcbalanceMap:::" + this._gcbalanceMap);
			},

			getOrigTenderDetails: function () {
				var tenderDetailsArray = [];
				_.forEach(this.getTranItems(), function (tranItem) {
					if (tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT || tranItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND) {
						var tenderDetails = tranItem.getTenderDetails();
						if (tenderDetails && tenderDetails!=null && tenderDetails.origTenderDetails){
							tenderDetailsArray.push(tenderDetails.origTenderDetails);
						}
					}
				});
				return tenderDetailsArray;
			},

			toJson: function () {
				var jsonObj = {};
				if (this.getId() != null) {
					jsonObj.id = this.getId();
				}
				if (this.getTranNo() != null) {
					jsonObj.tranNo = this.getTranNo();
				}
				if (this.getUserId() != null) {
					jsonObj.userId = this.getUserId();
				}
				if (this.getRetailerId() != null) {
					jsonObj.retailerId = this.getRetailerId();
				}
				if (this.getStoreId() != null) {
					jsonObj.storeId = this.getStoreId();
				}
				if (this.getDeviceId() != null) {
					jsonObj.deviceId = this.getDeviceId();
				}
				if (this.getDrawerId() != null) {
					jsonObj.drawerId = this.getDrawerId();
				}
				if (this.getTillId() != null) {
					jsonObj.tillId = this.getTillId();
				}
				if (this.getLoyaltyId() != null) {
					jsonObj.loyaltyId = this.getLoyaltyId();
				}
				if (this.getCustomerEmail() != null) {
					jsonObj.customerEmail = this.getCustomerEmail();
				}
				if (this.getTranTypeId() != null) {
					jsonObj.tranTypeId = this.getTranTypeId();
				}
				if (this.getIsTranVoid() != null) {
					jsonObj.isTranVoid = this.getIsTranVoid();
				}
				if (this.getTotalItems() != null) {
					jsonObj.totalItems = this.getTotalItems();
				}
				if (this.getMerchTotal() != null) {
					jsonObj.merchTotal = this.getMerchTotal();
				}
				if (this.getCalculatedPromos().totalValue != null) {
					jsonObj.promoTotal = this.getPromoTotal();
				}
				if (this.getTax() != null) {
					jsonObj.tax = this.getTax();
				}
				if (this.getAddonVATTax() != null) {
					jsonObj.addonTax = this.getAddonVATTax();
				}
				if (this.getTotal() != null) {
					jsonObj.total = this.getTotal();
				}
				if (this.getTotalVAT() != null) {
					jsonObj.totalVAT = this.getTotalVAT();
				}
				if (this.getTranTimestamp() != null) {
					jsonObj.tranDate = this.getTranTimestamp();
				}
				if (this.getBarcode() != null) {
					jsonObj.barcode = this.getBarcode();
				}
				if (this.getTraining() != null) {
					jsonObj.training = this.getTraining();
				}
				if (this.getReceiptJSON() != null) {
					jsonObj.receiptJSON = this.getReceiptJSON();
				}
				if (this.getLayawayJSON() != null) {
					jsonObj.layawayObj = this.getLayawayJSON();
				}
				if (this.getCurrencyId() != null) {
					jsonObj.currencyId = this.getCurrencyId();
				}
				return jsonObj;
			},

			toJsonString: function () {
				return JSON.stringify(this.toJson());
			},

			getSubObjectsArr: function () {
				return this._calculatedTranItems;
			},

			getInsertArray: function () {
				var recordArray = [];
				recordArray[0] = this.getId();
				recordArray[1] = this.getTranNo();
				recordArray[2] = this.getUserId();
				recordArray[3] = this.getRetailerId();
				recordArray[4] = this.getStoreId();
				recordArray[5] = this.getDeviceId();
				recordArray[6] = this.getDrawerId();
				recordArray[7] = this.getTillId();
				recordArray[8] = this.getLoyaltyId();
				recordArray[9] = this.getCustomerEmail();
				recordArray[10] = this.getTranTypeId();
				recordArray[11] = this.getIsTranVoid();
				recordArray[12] = this.getTotalItems();
				recordArray[13] = this.getMerchTotal();
				recordArray[14] = this.getPromoTotal();
				recordArray[15] = this.getTax();
				recordArray[16] = this.getTotal();
				recordArray[17] = this.getTotalVAT();
				recordArray[18] = locale.format(new Date(this.getTranTimestamp()), {
					selector: "date",
					datePattern: 'yyyy-MM-dd HH:mm:ss.SSS'
				});
				recordArray[19] = this.getBarcode();
				recordArray[20] = this.getTraining();
				recordArray[21] = this.getStringifyReceiptJSON();
				recordArray[22] = this.getStringifyLayawayJSON();
				recordArray[23] = this.getCurrencyId();

				return recordArray;
			},

			getDefaultRetailerId: function () {
				// TODO: SHOULD RETURN DEFAULT RETAILER ONCE WE ADD ISDEFAULT FLAG TO LOC_RETAILER_TBL ON SERVER AND
				//       SYNC RETAILERS TO CLIENT FOR ITS CURRENT LOCATION
				return 'defaultRetailer';
			},

			getTranItemsCount: function () {
				try {
					return this._A3G5J2RT67.length;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemsCount');
				}
			},

			getTranItems: function () {
				try {
					return this._A3G5J2RT67;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItems');
				}
			},

			setTranItems: function (tranItems) {
				try {
					this._A3G5J2RT67 = tranItems;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.setTranItems');
				}
			},

			getTranItemByIdx: function (itemIdx) {
				try {
					var tranItem = null;
					if (itemIdx != null) {
						tranItem = this._A3G5J2RT67[itemIdx];
					}
					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemByIdx');
				}
			},

			updateItemToTransaction: function (tranItem) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.updateItemToTransaction']);
				} else {
					this._A3G5J2RT67[tranItem.getItemIdx()] = tranItem;
				}
			},

			addItemToTransaction: function (tranItem) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.addItemToTransaction']);
				} else {
					try {
						var itemIdx = this._A3G5J2RT67.length;
						tranItem.setItemIdx(itemIdx);
						var tranItemProduct = tranItem.getProduct();
						if (tranItemProduct) {
							tranItemProduct.setItemIdx(itemIdx);
							var taxRates = tranItemProduct.getTaxRates();
							if (taxRates) {
								_.forEach(taxRates, function (taxRate) {
									taxRate.setItemIdx(itemIdx);
								});
							}
						}

						if (tranItem.getLoyaltyUser()) {
							tranItem.getLoyaltyUser().setItemIdx(itemIdx);
						}

						if (!(tranItem.getItemDate() && tranItem.getItemDate() != null)) {
							tranItem.setItemDate((new Date()).getTime());
						}
						if (tranItem.getRefItemIdx() == null) {
							tranItem.setRefItemIdx(-1);
						}

						this._A3G5J2RT67.push(tranItem);

						return tranItem;
					} catch (e) {
						throw util.rethrow(e, 'Transaction.addItemToTransaction');
					}
				}
			},

			isItemVoidByIdx: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					var isVoid = false;

					if (tranItem == null) {
						return isVoid;
					}

					var tranItemType = tranItem.getItemType();
					if (tranItemType == Constants.ITEM_TY_ADD_PRODUCT ||
						tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
						tranItemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
						tranItemType == Constants.ITEM_TY_REFUND_PRODUCT ||
						tranItemType == Constants.ITEM_TY_APPOINTMENT) {
						isVoid = this.getSpecificItemHistory(itemIdx).isVoid;
					}
					else if(tranItemType == Constants.ITEM_TY_DISCOUNT_TXN ||
						tranItemType == Constants.ITEM_TY_GIFTCERT_TENDER ||
						tranItemType == Constants.ITEM_TY_GIFT_CARD_SALE ||
						tranItemType == Constants.ITEM_TY_GIFT_CARD_TOPUP ||
						tranItemType == Constants.ITEM_TY_GIFT_CARD_REFUND)
					{
						isVoid = tranItem.getRefItemIdx() != -1;
					}
					else if (tranItemType == Constants.ITEM_TY_DISCOUNT_ITEM) {
						//Function to identify whether the item discount is voided or not
					}
					else {
						if (tranItem.getRefItemIdx() > -1 &&
							this.getSpecificItemHistory(tranItem.getRefItemIdx()) !== undefined) {
							isVoid = this.getSpecificItemHistory(tranItem.getRefItemIdx()).isVoid;
						}
					}

					return isVoid;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.isItemVoidByIdx');
				}
			},
			
			isLoyaltyVoidByIdx: function(itemIdx){
				for(var i=0; i<this.getTranItemsCount(); i++){
					var tranItem = this.getTranItemByIdx(itemIdx);
					if(tranItem.getItemType() == Constants.ITEM_TY_VOID_LOYALTY_ID && tranItem.getRefItemIdx() == itemIdx){
						return true;
					}
				}
				return false;
			},

			isItemPickupByIdx: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					var isPickup = false;

					if (tranItem == null) {
						return isPickup;
					}

					var tranItemType = tranItem.getItemType();
					if (tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT) {
						isPickup = true;
					} else {
						isPickup = false;
					}

					return isPickup;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.isItemVoidByIdx');
				}
			},

			getProductCountById: function () {
				var skuCountMap = {};
				_.forEach(this.getTranItems(), function (tranItem) {
					var tranItemType = tranItem.getItemType();
					// check which ones were product add
					if (tranItemType == Constants.ITEM_TY_ADD_PRODUCT ||
						tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
						tranItemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
						tranItemType == Constants.ITEM_TY_REFUND_PRODUCT ||
						tranItemType == Constants.ITEM_TY_APPOINTMENT) {
						if (!this.isItemVoidByIdx(tranItem.getItemIdx())) {
							var itemSku = tranItem.getSku();
							if (skuCountMap[itemSku]) {
								skuCountMap[itemSku] = skuCountMap[itemSku] + 1;
							} else {
								skuCountMap[itemSku] = 1;
							}
						}
					}
				}, this);
				return skuCountMap;
			},

			getSkuToQtyMap: function() {
				var skuToQtyMap = {};
				_.forEach(this.getTranItems(), function (item) {
					skuToQtyMap[item.getSku()] = item.getQty();
				});
				return skuToQtyMap;
			},

			countTranItemsThatCanBeVoided: function () {
				try {
					var recordCnt = 0;
					_.forEach(this.getTranItems(), function (tranItem) {
						var tranItemType = tranItem.getItemType();
						// check for items valid for void
						if (tranItemType == Constants.ITEM_TY_ADD_PRODUCT ||
							tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
							tranItemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
							tranItemType == Constants.ITEM_TY_REFUND_PRODUCT ||
							tranItemType == Constants.ITEM_TY_GIFT_CARD_REFUND ||
							tranItemType == Constants.ITEM_TY_DISCOUNT_ITEM ||
							tranItemType == Constants.ITEM_TY_DISCOUNT_TXN ||
							tranItemType == Constants.ITEM_TY_APPOINTMENT) {
							// check if the item is already voided
							if (
								(tranItemType == Constants.ITEM_TY_ADD_PRODUCT ||
								tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
								tranItemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
								tranItemType == Constants.ITEM_TY_APPOINTMENT) && !this.isItemVoidByIdx(tranItem.getItemIdx())
							) {
								recordCnt += 1;
							} else if (
								(tranItemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
								tranItemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
								tranItemType == Constants.ITEM_TY_APPOINTMENT) && !this.isItemVoidByIdx(tranItem.getRefItemIdx())
							) {
								recordCnt += 1;
							} else {
								// Do nothing / don't add to count
							}
						}
					}, this);

					return recordCnt;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.countTranItemsThatCanBeVoided');
				}
			},

			countProductsThatCanBeVoided: function () {
				try {
					var productCnt = 0;
					_.forEach(this.getTranItems(), function (tranItem) {
						var itemType = tranItem.getItemType();
						if ((itemType == Constants.ITEM_TY_ADD_PRODUCT ||
							itemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
							itemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
							itemType == Constants.ITEM_TY_APPOINTMENT ||
							itemType == Constants.ITEM_TY_DISCOUNT_TXN ||
							itemType == Constants.ITEM_TY_DISCOUNT_ITEM ) && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							productCnt += productCnt;
						}
					}, this);

					return productCnt;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.countProductsThatCanBeVoided');
				}
			},

			countProductsForGiftReceipt: function () {
				try {
					var productCnt = 0;
					_.forEach(this.getTranItems(), function (tranItem) {
						var itemType = tranItem.getItemType();
						if ((itemType === Constants.ITEM_TY_ADD_PRODUCT ||
							itemType === Constants.ITEM_TY_APPOINTMENT) && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							productCnt = productCnt + 1;
						}
					}, this);

					return productCnt;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.countProductsForGiftReceipt');
				}
			},

			hasGiftCertificate: function () {
				try {
					_.forEach(this.getTranItems(), function (tranItem) {
						if (tranItem.getItemType() === Constants.ITEM_TY_EINTERNAL_TENDER && 
							tranItem.getTenderDetails().giftCertNum && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							return true;
						}
					}, this);

					return false;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasGiftCertificate');
				}
			},

			getTranItemIdxForLoyaltyUser: function (loyaltyId) {
				try {
					_.forEachRight(this.getTranItems(), function (tranItem) {
						var loyaltyUser = tranItem.getLoyaltyUser();
						if (tranItem.getItemType() == Constants.ITEM_TY_LOYALTY_ID &&
							loyaltyUser != null) {
							if (loyaltyId) {
								if (loyaltyUser.getLoyaltyId() == loyaltyId) {
									return tranItem.getItemIdx();
								}
							} else {
								return tranItem.getItemIdx();
							}
						}
					});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemIdxForLoyaltyUser');
				}
				return -1;
			},

			getRecordCntForDiscount: function () {
				try {
					var recordCnt = 0;
					_.forEach(this.getTranItems(), function (tranItem) {
						// check for items valid for discount
						var itemType = tranItem.getItemType();
						if ((itemType == Constants.ITEM_TY_ADD_PRODUCT ||
							itemType == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
							itemType == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT ||
							itemType == Constants.ITEM_TY_APPOINTMENT) &&
							this.isItemVoidByIdx(tranItem.getItemIdx()) == false) {
							recordCnt += 1;
						}
					}, this);

					return recordCnt;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getRecordCntForDiscount');
				}
			},

			// Item history functions
			createItemHistory: function (tranItem, price) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.createItemHistory']);
				} else {
					try {
						tranItem.setAmount(price);
						tranItem.setCalcAmount(price);
						this._J67DE5GC89[tranItem.getItemIdx()] = {
							calcUnitPrice: price,
							isVoid: false,
							isLocked: false,
							history: []
						};
					} catch (e) {
						throw util.rethrow(e, 'Transaction.createItemHistory');
					}
				}
			},


			addToItemsHistory: function (itemHistory, newItemIdx, isVoid) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.addToItemsHistory']);
				} else {
					if (itemHistory == null) {
						throw util.ovcException('OVCException', 'itemHistory is null', ['Transaction.addToItemsHistory1']);
					} else if (newItemIdx == null) {
						throw util.ovcException('OVCException', 'newItemIdx is null', ['Transaction.addToItemsHistory2']);
					}

					try {
						itemHistory.history.push({
							itemIdxKey: newItemIdx
						});
						if (isVoid) {
							itemHistory.isVoid = isVoid;
						}
					} catch (e) {
						throw util.rethrow(e, 'Transaction.addToItemsHistory');
					}
				}
			},

			addToAllItemsHistory: function (newItemIdx, isVoid) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.addToAllItemsHistory']);
				} else {
					try {
						_.forEach(this._J67DE5GC89, function (itemHistory) {
							this.addToItemsHistory(itemHistory, newItemIdx, isVoid);
						}, this);
					} catch (e) {
						throw util.rethrow(e, 'Transaction.addToAllItemsHistory');
					}
				}
			},

			getAllItemsHistoryIdxArray: function () {
				try {
					var idxArr = [];
					_.forEach(this._J67DE5GC89, function (itemHistory, itemIdx) {
						idxArr.push(itemIdx);
					});
					return idxArr;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getAllItemsHistoryIdxArray');
				}
			},

			addRefVoidItemsToItemsHistory: function (itemHistoryIdx, refItemIdx) {
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.addRefVoidItemsToItemsHistory']);
				} else {
					if (itemHistoryIdx == null) {
						throw util.ovcException('OVCException', 'itemHistoryIdxis null', ['Transaction.addRefVoidItemsToItemsHistory1']);
					} else if (refItemIdx == null) {
						throw util.ovcException('OVCException', 'refItemIdx is null', ['Transaction.addRefVoidItemsToItemsHistory2']);
					}

					try {
						var itemHistory = this._J67DE5GC89[itemHistoryIdx];

						_.forEach(this.getTranItems(), function (tranItem, i) {
							if (tranItem.getRefItemIdx() == refItemIdx &&
								tranItem.getItemType() !== Constants.ITEM_TY_VOID_ITEM) {
								if (this._J67DE5GC89[i] !== undefined &&
									this._J67DE5GC89[i] !== null) {
									itemHistory = this._J67DE5GC89[i];
									var voidItemIdx = tranItem.getItemIdx();
									itemHistory.history.push({
										itemIdxKey: voidItemIdx
									});
									itemHistory.isVoid = true;
								}
							}
						}, this);
					} catch (e) {
						throw util.rethrow(e, 'Transaction.addRefVoidItemsToItemsHistory');
					}
				}
			},


			getSpecificItemHistory: function (itemHistoryIdx) {
				if (itemHistoryIdx == null) {
					throw util.ovcException('OVCException', 'itemHistoryIdx null', ['Transaction.getSpecificItemHistory1']);
				}

				try {
					return this._J67DE5GC89[itemHistoryIdx];
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getspecificItemHistory');
				}
			},

			cloneTranItemsHistory: function () {
				try {
					var clonedTranItemsHistory = {};

					_.forEach(this._J67DE5GC89, function (itemHistory, itemIdxKey) {
						clonedTranItemsHistory[itemIdxKey] = util.cloneJson(this._J67DE5GC89[itemIdxKey]);
					}, this);

					return clonedTranItemsHistory;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.cloneTranItemsHistory');
				}
			},

			calcPromoValue: function (originalPrice, promoJson) {
				var promoValue = 0;
				if (promoJson.amountType == 1) {
					promoValue = -parseFloat(promoJson.amountValue);
				} else if (promoJson.amountType == 2) {
					promoValue = Math.round(-originalPrice * parseFloat(promoJson.amountValue)) / 100;
				} else if (promoJson.amountType == 3) {
					promoValue = Math.round(-originalPrice * parseFloat(promoJson.amountValue) * 100) / 100;
				}

				return promoValue;
			},

			setExpiredPromotions: function (expiredPromo) {
				this._expiredPromos.push(expiredPromo);
			},

			getExpiredPromotions: function () {
				return this._expiredPromos;
			},

			removePromotions: function (expiredPromos, specificPromoJson, promosJson) {
				_.forEach(expiredPromos, function (expiredPromo) {
					delete promosJson[expiredPromo];

					_.forEach(specificPromoJson, function (removedPromo) {
						var index = specificPromoJson[removedPromo].indexOf(expiredPromo);
						if (index > -1) {
							specificPromoJson[removedPromo].splice(index, 1);
						}
					});
				});
			},

			_recalcTransaction: function () {
				try {
					// Copy entire tranItemsHistory
					var calculatedTranItemsHistory = this.cloneTranItemsHistory();

					// Create total sku unit count map and calc total before tax/promos
					var productRefundCountMap = {};
					var productPickupCountMap = {};
					var totalItemCount = 0;
					var totalRefundItemCount = 0;
					var totalBeforePromosAndTax = 0;
					var perSkuMetadata = {};
					var tempTranItemNonAndAccountedQty = {};

					try {
						_.forEach(calculatedTranItemsHistory, function (calculatedTranItemHistory, i) {
							if (!this.isItemVoidByIdx(i)) {
								var tranItem = this.getTranItemByIdx(i);

								if (!tempTranItemNonAndAccountedQty[i]) {
									tempTranItemNonAndAccountedQty[i] = {
										"nonAccounted": 0,
										"accountedForItem": []
									};
								}
								tempTranItemNonAndAccountedQty[i].nonAccounted = tempTranItemNonAndAccountedQty[i].nonAccounted + tranItem.getQty();


								if (!perSkuMetadata[tranItem.getSku()]) {
									perSkuMetadata[tranItem.getSku()] = {
										productTotalBeforePromosAndTax: 0,
										productTotalPromos: 0
									};
								}

								var calcUnitPrice = calculatedTranItemHistory.calcUnitPrice;

								var curCountMap;
								if (tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT) {
									curCountMap = productRefundCountMap;
								} else if (tranItem.getItemType() == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT) {
									curCountMap = productPickupCountMap;
								} else {
									curCountMap = {};
								}

								// From Commerce Site Should be handled differently by splitting items that are not in store
								if (tranItem.getIsScanned() != 2 && tranItem.getIsScanned() != 6) { // I guess tranItem.getIsScanned(): 2 means added from commerce site?!?
									if (curCountMap[tranItem.getSku()] == null) {
										var curProductTaxRates = tranItem.getProduct().getTaxRates();
										var curIsVAT = false;
										if (curProductTaxRates) {
											_.forEach(curProductTaxRates, function (curProductTaxRate) {
												if (curProductTaxRate.getIsVAT() == 1/*true*/) {
													curIsVAT = true;
												}
											});
										}

										curCountMap[tranItem.getSku()] = {
											initialPrice: tranItem.getProduct().getInitialPrice(),
											costPrice: tranItem.getProduct().getCostPrice(),
											qty: parseInt(tranItem.getQty()),
											mmGroupId: tranItem.getProduct().getMMGroupId(),
											isVAT: curIsVAT
										};
									} else {
										curCountMap[tranItem.getSku()].qty = curCountMap[tranItem.getSku()].qty + parseInt(tranItem.getQty());
									}
								}

								if (tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT || tranItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND) {
									totalRefundItemCount = totalRefundItemCount + parseInt(tranItem.getQty());
									totalBeforePromosAndTax = totalBeforePromosAndTax - calcUnitPrice * tranItem.getQty();
								} else {
									totalItemCount = totalItemCount + parseInt(tranItem.getQty());
									if (tranItem.getProduct().getPickupOrderId() == null) {
										totalBeforePromosAndTax = totalBeforePromosAndTax + calcUnitPrice * tranItem.getQty();
										perSkuMetadata[tranItem.getSku()].productTotalBeforePromosAndTax = perSkuMetadata[tranItem.getSku()].productTotalBeforePromosAndTax + calcUnitPrice * tranItem.getQty();
									}
								}
							}
						}, this);
					} catch (e) {
						throw util.rethrow(e, 'Transaction._recalcTransaction1');
					}

					// Get promotion configuration for layaways
					var enablePromotionsInLayaways = ConfigManager.getConfigObject("posMClient/layaway.ovccfg").enablePromotionsInLayaways;

					/*
					 * **********************************************
					 * 		Start of the Promotion Engine
					 * **********************************************
					 */
					function transformForPromoEngine() {
						var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
						var basket = new Basket();
						var basketItems = [];
						var coupons = [];

						_.forEach(tranObj.getTranItems(), function (tranItem) {
							if (
								tranItem.getSku() != null && !tranObj.isItemVoidByIdx(tranItem.getItemIdx()) &&
								tranItem.getItemType() !== Constants.ITEM_TY_REFUND_PRODUCT
							) {
								_.times(tranItem.getQty(), function () {
									var basketItem = new BasketItem();
									basketItem.setId(tranItem.getSku());
									basketItem.setTranItemIdx(tranItem.getItemIdx());
									if (tranItem.getProduct() != null) {
										basketItem.setGroups(tranItem.getProduct().getMMGroupId());
										basketItem.setOriginalPrice(tranItem.getProduct().getInitialPrice());
									}
									basketItems.push(basketItem);
								});
							} else if (tranItem.getItemType() === Constants.ITEM_TY_COUPON) {
								coupons.push(tranItem.getReasonCodeId());
							}
						});

						basket.setItems(basketItems);

						basket.setCoupons(coupons);

						var requestedManualDiscounts = [];

						_.forEach(tranObj.getTranItems(), function(tranItem) {
							var discount = null;
							if (tranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_ITEM) {
								discount = new ItemDiscount();
								if (tranItem.getDiscType() == Constants.DISC_TYPE_PERCENT) {
									discount.setEffectType(promoEngine.effects.PERCENTAGE_OFF);
								}
								else if(tranItem.getDiscType() == Constants.DISC_TYPE_AMOUNT){
									discount.setEffectType(promoEngine.effects.FIXED_PRICE_EACH_ITEM);
								}
								discount.setItemIndex(tranItem.getItemIdx());
							} else if (tranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN) {
								discount = new Discount();

								if(tranItem.getDiscType() == Constants.DISC_TYPE_PERCENT){
									discount.setEffectType(promoEngine.effects.PERCENTAGE_OFF);
								}
								else if(tranItem.getDiscType() == Constants.DISC_TYPE_AMOUNT){
									discount.setEffectType(promoEngine.effects.FIXED_PRICE_TOTAL);
								}
							}
							if(discount != null){
								discount.setIdentifier(require("dojox/uuid/generateRandomUuid")());
								discount.setEffectAmount(tranItem.getDiscValue());

								requestedManualDiscounts.push(discount);
							}
						});

						basket.setRequestedManualDiscounts(requestedManualDiscounts);

						return basket;
					}

					function isLastPromoInstance(itemsToCheck, identifier, key) {
						for(var i = itemsToCheck.length - 1; i > -1; i--) {
							if (itemsToCheck[i].discounts[0].identifier === identifier) {
								return i === key;
							}
						}
					}

					function transformFromPromoEngine(results, tranItems) {

						var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

						var bundleSku = {};
						var promoJson = {};
						var noOfTimesToApply = {};
						var alertKeys = {};


						// calculate noOfTimes a promotion has to be applied on a single tranItem...
						_.forEach(results.items, function (item) {
							if (item.discounts && item.discounts[0] != undefined && item.discounts[0] != null) {
								if (noOfTimesToApply[item.tranItemIdx + "-" + item.id + "-" + item.discounts[0].nameKey] != undefined && noOfTimesToApply[item.tranItemIdx + "-" + item.id + "-" + item.discounts[0].nameKey] != null) {
									noOfTimesToApply[item.tranItemIdx + "-" + item.id + "-" + item.discounts[0].nameKey] = ++noOfTimesToApply[item.tranItemIdx + "-" + item.id + "-" + item.discounts[0].nameKey];
								}
								else {
									noOfTimesToApply[item.tranItemIdx+ "-" + item.id + "-" + item.discounts[0].nameKey] = 1;
								}
							}
						});

						//deactivating the existing promotions before reapplying them ...
						var tranItem = tranObj.getTranItems();
						for (var i = 0; i<tranItem.length; i++) {
							if (tranItem[i]._itemType == Constants.ITEM_TY_PROMO && tranItem[i].getPromotion()) {
								if (tranItem[i]._itemIdx !== -1 && (results.discounts && results.discounts.length > 0)) {
									tranItem.splice(tranItem[i]._itemIdx, 1);
								}
							}
						}

						var calculatedTranItems = tranObj.getTranItems();
						var promoItems = [];
						var itemsForWhichPromoIsApplied = {};
						var remainingPromoAmounts = {};

						// Handling Item level promotions...
						_.forEach(results.items, function (item, index) {

							var uniquePromos = _.reduce(results.items, function(uniquePromos, uniquePromoItem) {
								var identifier = _.get(uniquePromoItem, 'discounts[0].identifier');
								var tranItemIdx = item.tranItemIdx;
								var check = {identifier: identifier, tranItemIdx: tranItemIdx};
								if ( identifier && uniquePromoItem.tranItemIdx === tranItemIdx && !_.some(uniquePromos, check)) {
									uniquePromos.push(check);
								}
								return uniquePromos;
							}, []);


							if (item.discounts) {
								var isLastPromoInstanceBoolean = isLastPromoInstance(results.items, item.discounts[0].identifier, index);
								if (!isLastPromoInstanceBoolean) {
									var remainingPromoAmount = remainingPromoAmounts[item.discounts[0].identifier];
									if (remainingPromoAmounts[item.discounts[0].identifier] || remainingPromoAmount === 0) {
										remainingPromoAmounts[item.discounts[0].identifier] -= StringUtils.to2DecimalsRounded(item.discounts[0].itemValue);
									}
									else {
										remainingPromoAmounts[item.discounts[0].identifier] = StringUtils.to2DecimalsRounded(item.discounts[0].value) - StringUtils.to2DecimalsRounded(item.discounts[0].itemValue);
									}
								} else {
									remainingPromoAmounts[item.discounts[0].identifier] = GenericUtils.getDecimalValue(item.discounts[0].itemValue);
								}
							}

							if (item.discounts && item.discounts[0] != undefined && item.discounts[0] != null) {
								promoJson = buildPromoJson(item.discounts[0]);

								//calculated TranItems need to be updated...
								var noOfTimesPromoApplied = noOfTimesToApply[item.tranItemIdx + "-" + item.id + "-" + item.discounts[0].nameKey];

								if (noOfTimesPromoApplied && noOfTimesPromoApplied > 0 && !itemsForWhichPromoIsApplied[item.tranItemIdx + "-" + item.id]) {
									var tranItemObj = new TransactionItem();

									tranItemObj.setTranId(tranObj.getId());
									tranItemObj.setItemIdx(calculatedTranItems.length);
									tranItemObj.setItemType(Constants.ITEM_TY_PROMO);
									if (item.discounts && isLastPromoInstance(results.items, item.discounts[0].identifier, index)) {
										tranItemObj.setCalcAmount(remainingPromoAmounts[item.discounts[0].identifier]);
										promoJson.amountValue = remainingPromoAmounts[item.discounts[0].identifier];
									} else {
										tranItemObj.setCalcAmount(promoJson.amountValue);
									}
									tranItemObj.setPromotion(tranObj.convertToTranItemPromotion(promoJson, tranObj.getId(), calculatedTranItems.length));
									tranItemObj.setQty(noOfTimesPromoApplied);
									tranItemObj.setItemDate((new Date()).getTime());
									tranItemObj.setRefItemIdx(item.tranItemIdx);

									promoItems.push(tranItemObj);
									calculatedTranItems.push(tranItemObj);


									//calculated Tran Items History needs to be updated...

									_.forEach(calculatedTranItemsHistory, function (specificTranItemHistory, itemIdx) {
										if (itemIdx == item.tranItemIdx) {
											var tranItem = tranObj.getTranItemByIdx(itemIdx);

											specificTranItemHistory.history.push({
												isPromo: true,
												promoJson: promoJson,
												promoAmount: promoJson.amountValue,
												qtyPromosAccountedFor: noOfTimesPromoApplied,
												timesKickedInAfterThisTranItem: uniquePromos.length,
												savingsAmount: promoJson.amountValue
											});
										}
									}, this);

									//itemsForWhichPromoIsApplied[item.tranItemIdx + "-" + item.id] = 1;
								}

							}
							_.forEach(item.alerts, function (alert) {
								alertKeys[alert] = true;
							});
						});

						//Handling Transaction level Promotions..
						if(results.discounts && results.discounts.length>0){
							_.forEach(results.discounts, function (tranDisc) {

								if(tranDisc.nameKey){
									promoJson = buildPromoJson(tranDisc);

									var tranItemObj = new TransactionItem();

									tranItemObj.setTranId(tranObj.getId());
									tranItemObj.setItemIdx(calculatedTranItems.length);
									tranItemObj.setItemType(Constants.ITEM_TY_PROMO);
									tranItemObj.setCalcAmount(promoJson.amountValue);
									tranItemObj.setPromotion(tranObj.convertToTranItemPromotion(promoJson, tranObj.getId(), calculatedTranItems.length));
									tranItemObj.setQty(1);
									tranItemObj.setItemDate((new Date()).getTime());
									tranItemObj.setRefItemIdx(-1);

									promoItems.push(tranItemObj);
									calculatedTranItems.push(tranItemObj);

									var lastTranItemHistory = {};
									_.forEach(calculatedTranItemsHistory, function (tranItemHistory) {
										if(!tranItemHistory.isVoid){
											lastTranItemHistory = tranItemHistory;
										}
									}, this);

									if(lastTranItemHistory.history){
										lastTranItemHistory.history.push({
											isPromo: true,
											promoJson: promoJson,
											promoAmount: promoJson.amountValue,
											qtyPromosAccountedFor: 1,
											timesKickedInAfterThisTranItem: 1,
											savingsAmount: promoJson.amountValue
										});
									}
								}

							}, this);
						}

						_.forEach(results.alerts, function (alert) {
							alertKeys[alert] = true;
						});

						var calculatedAlerts = _.keys(alertKeys);

						var promoTotal = 0;
						_.forEach(promoItems, function (promoItem) {
							promoTotal +=  Math.round(promoItem.getCalcAmount() * 100) / 100;
						}, this);

						if(!tranObj._isLocked() && promoTotal>0){
							tranObj.setPromoTotal(-promoTotal);
						}

						var calculatedPromos = {
							promoItems : promoItems,
							totalValue : -promoTotal,
							totalPromoFromVATedProducts : 0
						};

						return {
							calculatedPromos: calculatedPromos,
							calculatedAlerts: calculatedAlerts,
							calculatedTranItems: calculatedTranItems
						};
					}

					function buildPromoJson(promoDisc){
						return {
							amountType: calculateDiscountEffectType(promoDisc.effectType),
							description: promoDisc.descriptionKey,
							requireLoyalty: 0,
							amountValue: GenericUtils.getDecimalValue(promoDisc.itemValue || promoDisc.value),
							alert: promoDisc.alertKey,
							id: promoDisc.nameKey
						};
					}

					var calculateDiscountEffectType = function (effectType){

						if(effectType == promoEngine.effects.PERCENTAGE_OFF){
							return Constants.DISC_TYPE_PERCENT;
						}else{
							//TODO: What happens in case of order level FIXED PRICE/CURRENCY OFF discounts
							return Constants.DISC_TYPE_AMOUNT;
						}
					};

					var promosCalculated = _.bind(function (transformedResults) {

						if(!this._isLocked()){
							this._setCalculatedTranItemsHistory(calculatedTranItemsHistory);
						}

						_.forEach(this.getAllItemsHistoryIdxArray(), function (itemHistory) {
							var tranItem = this.getTranItemByIdx(itemHistory);
							if (!this.isItemVoidByIdx(itemHistory) && tranItem.getProduct().getPickupOrderId() == null) {
								var tranItemProduct = tranItem.getProduct();
								var isTaxExecutable = tranItemProduct.isTaxExemptible();
								
								var isTaxRateChanged = false;
								// loop over all item's tax rates
								_.forEach(tranItemProduct.getTaxRates(), function (productTaxRate) {
									if (isTaxExecutable != undefined &&
										isTaxExecutable != null &&
										isTaxExecutable === 1 &&
										this.isCustomerTaxExempt()) {
										if (productTaxRate.getIsVAT() == 0) {
											isTaxRateChanged = true;
											//store the previous values for putting it back when tax exempt is voided
											productTaxRate.prevTaxRateId = productTaxRate.getTaxRateId();
											productTaxRate.prevPercentage = productTaxRate.getPercentage();

											productTaxRate.setTaxRateId(this.getDefaultTaxRate());
											productTaxRate.setPercentage(this.getDefaultTaxPercentage());
										}
									}
								}, this);
							}
						}, this);

						var configPositionValue = ConfigManager.getConfigObject("posMClient/payment.ovccfg").overflowPositionForSplitDiscounts;
						if (configPositionValue != null) {
							var discrepancyTotal = 0;
							var addItemTotalAlone = {};
							if (transformedResults) {
								_.forEach(transformedResults.calculatedTranItems, function (currentItem) {
									if (currentItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT) {
										var itemTotal = currentItem.getCalcAmount() * currentItem.getQty();
										discrepancyTotal += currentItem.getCalcAmount() * currentItem.getQty();
										addItemTotalAlone[currentItem.getItemIdx()] = currentItem.getCalcAmount() * currentItem.getQty();
									}
									else if (currentItem.getItemType() == Constants.ITEM_TY_VOID_ITEM) {
										discrepancyTotal -= addItemTotalAlone[currentItem.getRefItemIdx()];
									}
									else if (currentItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT ||
										currentItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND) {
										var currentTotal = currentItem.getCalcAmount() * currentItem.getQty();
										addItemTotalAlone[currentItem.getItemIdx()] = currentTotal;
										discrepancyTotal -= currentTotal;
									}
								});
							}

							var roundedDifference = Math.round((totalBeforePromosAndTax - discrepancyTotal) * 1000) / 1000;
							if (totalBeforePromosAndTax !== 0 && discrepancyTotal !== 0) {
								this.setDiscrepancy(roundedDifference);
							}
						}

						if (transformedResults && !this._isLocked()) {
							this._setCalculatedTranItems(transformedResults.calculatedTranItems);
							if (transformedResults.calculatedPromos) {
								this._setCalculatedPromos(transformedResults.calculatedPromos);
							}

							var calculatedAlerts = this.getCalculatedAlerts();
							calculatedAlerts.byPromo = transformedResults.calculatedAlerts;
							this._setCalculatedAlerts(calculatedAlerts);
						}
						var taxJson = this.getTaxRates();

						// calc total tax
						var totalTax = this.calculateTax(taxJson);
						if(!this._isLocked()){
							this.setTax(Math.round(totalTax * 100) / 100);
						}

						var addOnVATTaxTotal = this.calculateAddOnVATTax(taxJson);
						if(!this._isLocked()){
							this.setAddOnVATTax(Math.round(addOnVATTaxTotal * 100) / 100);
						}
						var totalTaxExempt = 0;
						// calc total taxExempt
						if (this.isCustomerTaxExempt() && !this._isLocked()) {
							totalTaxExempt = this.calculateTaxExempt(taxJson);
							this.setTaxExempt(Math.round(totalTaxExempt * 100) / 100);
						}
						// Set recalculated transaction values
						var totalDeliveryCharges = 0;
						
						if(!this._isLocked()){
							this.setTotalItems(totalItemCount);
							this.setTotalRefundItems(totalRefundItemCount);

							totalDeliveryCharges = this.calculateDeliveryOption();
							this.setMerchTotal(Math.round((totalBeforePromosAndTax + totalDeliveryCharges) * 100) / 100);
						}

						/*
						 * THIS IS WHERE THE TOTAL IS COMPUTED AND SET
						 */
						var total = Math.round((totalBeforePromosAndTax + totalTax - totalTaxExempt + totalDeliveryCharges + addOnVATTaxTotal) * 100) / 100;

						if(!this._isLocked()){
							if (transformedResults && transformedResults.calculatedPromos) {
								if (this.getBalance(transformedResults) > 0 && (this.isLayawaySale() || this.isLayawayPayment())) {
									this.setLayawayBalance(total);
								}

								if (transformedResults.calculatedPromos.totalValue) {
									this.setTotal(total + transformedResults.calculatedPromos.totalValue);
									this.setMerchTotal((this.getMerchTotal() * 100) / 100);
								} else {
									this.setTotal(total);
								}
							} else {
								this.setTotal(total);
							}
						}

						//Add to balance if PayIn / Payout tran (Travis Perkins Customization)
						if(this.getTranTypeId() == Constants.TX_TY_PAYINTRAN ||
							this.getTranTypeId() == Constants.TX_TY_PAYOUTTRAN ||
							this.getTranTypeId() == Constants.TX_TY_PAYINCORRTRAN ||
							this.getTranTypeId() == Constants.TX_TY_PAYOUTCORRTRAN){

							var tranItems = this.getTranItems();
							_.forEach(tranItems, function(item){
								if(item.getItemType() == Constants.ITEM_TY_PAYIN_SALE ||
									item.getItemType() == Constants.ITEM_TY_PAYIN_CORR_SALE ||
									item.getItemType() == Constants.ITEM_TY_PAYOUT_SALE ||
									item.getItemType() == Constants.ITEM_TY_PAYOUT_CORR_SALE){
									if(item.getAmount() != null){
										var total = this.getTotal() + item.getAmount();
										this.setTotal(total);
										this.setMerchTotal(total);
										this.setTotalItems(this.getTotalItems() + 1);
									}
								}
							}, this);
						}
						else{
							var tranItems = this.getTranItems();

							_.forEach(tranItems, function(item){
								// calculate totals for gift card items.
								if(item.getItemType() == Constants.ITEM_TY_GIFT_CARD_SALE ||
									item.getItemType() == Constants.ITEM_TY_GIFT_CARD_TOPUP){
									if(item.getAmount() != null && item.getItemIdx() != item.getRefItemIdx()){
										this.setTotal(this.getTotal() + item.getAmount());
										this.setMerchTotal(this.getMerchTotal() + item.getAmount());
										this.setTotalItems(this.getTotalItems() + 1);
									}
								}
								else if(item.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND){
									if(item.getAmount() != null && item.getItemIdx() != item.getRefItemIdx()){
										this.setTotal(this.getTotal() - item.getAmount());
										this.setMerchTotal(this.getMerchTotal() - item.getAmount());
										//this.setTotalItems(this.getTotalItems() + 1);
										this.setTotalRefundItems(this.getTotalRefundItems() + 1);
									}
								}
								else if(item.getItemType() == Constants.ITEM_TY_GIFT_CARD_ADJ){
									if(item.getAmount() != null){
										this.setTotal(this.getTotal() + item.getAmount());
										this.setMerchTotal(this.getMerchTotal() + item.getAmount());
									}
								}
							}, this);
						}

						// Calculate and set totalVAT
						// Loop over items' calculated prices and if VAT taxed, add to totalVATedMerchandise;
						var totalVATedMerchandise = 0;
						var vatRate = 0;
						try {
							_.forEach(calculatedTranItemsHistory, function (specificTranItemHistory, propName) {
								// First add item initial to virtualReceipt
								var tranItem = this.getTranItemByIdx(propName);

								var isTranItemVoid = false;
								// Check if item voided ...
								_.forEach(specificTranItemHistory.history, function (historyItem) {
									if (!historyItem.isPromo) {
										var tempTranItem = this.getTranItemByIdx(historyItem.itemIdxKey);

										if (tempTranItem.getItemType() == Constants.ITEM_TY_VOID_ITEM) {
											isTranItemVoid = true;
										}
									}
								}, this);

								// Calculate VAT on "isVAT=true" products and if had promos calculate after promo and VAT spread if group promo
								if (!isTranItemVoid) {
									// Check if product has tax that is included in the price
									var isVAT = false;

									var productTaxRates = tranItem.getProduct().getTaxRates();
									if (productTaxRates) {
										_.forEach(productTaxRates, function (productTaxRate) {
											if (productTaxRate.getIsVAT() == 1/*true*/ &&
												tranItem.getItemType() != Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT &&
												tranItem.getItemType() != Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT) {
												totalVATedMerchandise = totalVATedMerchandise + tranItem.getCalcAmount() * tranItem.getQty();
												vatRate = parseFloat(productTaxRate.getPercentage());
											}
										});
									}
								}
							}, this);
						} catch (e) {
							throw util.rethrow(e, 'Transaction._recalcTransaction5');
						}

						var totalVAT = 0;
						if (transformedResults && transformedResults.calculatedPromos && transformedResults.calculatedPromos.totalPromoFromVATedProducts != undefined) {
							totalVAT = (totalVATedMerchandise + transformedResults.calculatedPromos.totalPromoFromVATedProducts/*This is negative value*/) / (100 + vatRate) * vatRate;
						} else {
							totalVAT = (totalVATedMerchandise / (100 + vatRate) * vatRate);
						}

						if(!this._isLocked()){
							this.setTotalVAT(totalVAT);
						}
						this.updateRecoveryTables();
					}, this);

					var tranItems = this.getTranItems();

					if(!this._isLocked() && this._tranTypeId != 'login' && this._tranTypeId != 'logoff') {
						promoEngine.calculate(transformForPromoEngine(), function (error, results) {
							if (error) {
								// TODO handle promotion engine error
								console.log("error in promo engine!");
								promosCalculated( {
									calculatedPromos: {},
									calculatedAlerts: {},
									calculatedTranItems: tranItems
								});
							} else {
								promosCalculated(transformFromPromoEngine(results, tranItems));
							}
							require("dijit/registry").byId("receiptGrid").getController().renderReceipt(true);
						});
					}

				} catch (ee) {
					throw util.rethrow(ee, 'Transaction._recalcTransaction');
				}
			},

			clearRecoveryTables: function (tx) {
				var dbUtil = new DBUtil();
				// Delete recovery tables and add current transaction
				function clearTable(tx, name) {
					return dbUtil.deleteDBTable(tx, name);
				}

				var deferred = new Deferred();

				function doDelete(tx) {
					when(dbUtil.deleteDBTable(tx, "recovery_tran_item_loyalty_user_tbl"))
						.then(_.partial(clearTable, tx, "recovery_tran_item_product_tax_rate_tbl"))
						.then(_.partial(clearTable, tx, "recovery_tran_item_promotion_tbl"))
						.then(_.partial(clearTable, tx, "recovery_tran_item_product_tbl"))
						.then(_.partial(clearTable, tx, "recovery_tran_item_tbl"))
						.then(_.partial(clearTable, tx, "recovery_tran_tbl"))
						.then(function () {
							deferred.resolve();
						}, function (err) {
							console.error("Error clearing recovery tables: " + err.message);
							deferred.reject(err);
						});
				}

				if (!tx) {
					db.transaction(function (tx) {
						doDelete(tx);
					});
				} else {
					doDelete(tx);
				}
				return deferred.promise;
			},

			updateRecoveryTables: function () {
				var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

				// If this is not a SignIn transaction and Signoff transaction create new recovery tables
				if (tranObj.getTranTypeId() != 'login' && tranObj.getTranTypeId() != 'logoff') {
					var dbUtil = new DBUtil();
					// Delete recovery tables and add current transaction
					db.transaction(_.bind(function (tx) {
						when(this.clearRecoveryTables(tx)).then(function () {
							dbUtil.updateRecoveryDBTable(tranObj);
						}, function (err) {
							console.error("Error updating recovery tables: " + err.message);
						});
					}, this));
				}
			},


			addSalesPerson: function (tranItem, salesPersonId) {
				try {
					var promptForSalesPerson = ConfigManager.getConfigObject("posMClient/app.ovccfg").promptForSalesPerson;
					if (promptForSalesPerson === 1) {
						if (this.salesPersonBgColor === undefined) {
							this.salesPersonBgColor = this.getSalesPersonBgColor();
						}
						if (salesPersonId != 'None') {
							tranItem.setSalesPerson(salesPersonId);
						}
						else {
							tranItem.setSalesPerson('');
						}
						this.salesPersonId = salesPersonId; //This is to keep track of the latest sales person that SA selected and by default we use this value
					}

				} catch (e) {
					throw util.rethrow(e, 'Transaction.addSalesPerson');
				}
			},

			addCommerceSitePickupItem: function (productObj, qty, isScanned, pickupBasePrice, pickupTotalPrice, pickupQuantity, pickupOrderId, pickupId) {
				try {
					if (isScanned == null) {
						isScanned = 0;
					}

					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);

					tranItem.setItemType(Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT);

					var tranItemProd = this.convertToTranItemProduct(productObj, this._id, null, false);
					tranItemProd.setPickupBasePrice(pickupBasePrice);
					tranItemProd.setPickupTotalPrice(pickupTotalPrice);
					tranItemProd.setPickupQuantity(pickupQuantity);
					tranItemProd.setPickupOrderId(pickupOrderId);
					tranItemProd.setPickupId(pickupId);

					tranItem.setProduct(tranItemProd);
					tranItem.setProductId(productObj.id);
					if(productObj.sku){
						tranItem.setSku(productObj.sku);
					}else{
						tranItem.setSku(productObj.id);
					}

					tranItem.setQty(qty);
					tranItem.setIsScanned(isScanned);

					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					// Add to itemsHistory
					this.createItemHistory(tranItem, productObj.price);

					this._recalcTransaction();

					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addCommerceSitePickupItem');
				}
			},

			changeItemQty: function (itemIdx, qty, linkedProduct) {
				try {
					if (itemIdx != null) {
						var selectedTranItem = this.getTranItemByIdx(itemIdx);
						if (selectedTranItem != null) {
							var itemType = selectedTranItem.getItemType();
							if (itemType == Constants.ITEM_TY_ADD_PRODUCT ||
								itemType == Constants.ITEM_TY_REFUND_PRODUCT ||
								itemType == Constants.ITEM_TY_APPOINTMENT) {
								if (this.isItemVoidByIdx(itemIdx) == true) {
									throw util.ovcException('OVCException', 'Item is void. Cannot modify the quantity', ['Transaction.changeItemQty1']);
								}

								if (qty != null) {
									if (isNaN(parseInt(qty)) || !isFinite(qty)) {
										throw util.ovcException('OVCException', 'Quantity must be a number.', ['Transaction.changeItemQty2']);
									} else {
										var currentQty = selectedTranItem.getQty();
										if (currentQty !== qty) {
											//console.log("Transaction.changeItemQty(): old: " + currentQty + ", new: " + qty);

											var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
											var tranObjMode = tranObj.getCurrentMode();

											// only need to recalc if qty changed
											selectedTranItem.setQty(qty);
											if(selectedTranItem.getParentProductIdx() != undefined && selectedTranItem.getParentProductIdx() != null && selectedTranItem.getParentProductIdx() != -1 && !linkedProduct){// Selected product is a child
												if(selectedTranItem.getCascadeQtyChangeToParent() === 1){
													var idxArr = this.getAllItemsHistoryIdxArray();
													for (var j = 0; j < idxArr.length; j = j + 1) {
														var tranItemIdx = idxArr[j];
														var tranItem = this.getTranItemByIdx(tranItemIdx);
														if(!this.isItemVoidByIdx(tranItemIdx) && tranItem.getSku() != null && ((selectedTranItem.getParentProductIdx() === tranItem.getParentProductIdx() && tranItem.getCascadeQtyChange() === 1) || selectedTranItem.getParentProductIdx() === tranItem.getItemIdx())){
															this.changeItemQty(tranItemIdx,qty,true );
														}
													}
												}

												this._recalcTransaction();
												if (tranObjMode == Constants.TRAN_CURRENT_MODE_NORMAL) {
													this.recalcTransDiscount(true);
												}

											} else if(!linkedProduct){ //Selected product is parent
												//Loop through all the items and change quantity of linked products also
												var idxArr = this.getAllItemsHistoryIdxArray();
												var qtyChange = qty - currentQty;
												for (var j = 0; j < idxArr.length; j = j + 1) {
													var tranItemIdx = idxArr[j];
													var tranItem = this.getTranItemByIdx(tranItemIdx);
													if(!this.isItemVoidByIdx(tranItemIdx) && tranItem.getSku() != null && itemIdx === tranItem.getParentProductIdx() && tranItem.getCascadeQtyChange() === 1){
														this.changeItemQty(tranItemIdx,qty,true );
													}
												}

												this._recalcTransaction();
												if (tranObjMode == Constants.TRAN_CURRENT_MODE_NORMAL) {
													this.recalcTransDiscount(true);
												}
											}

										} else {
											console.log("Transaction.changeItemQty(): quantity did not change");
										}
									}
								} else {
									throw util.ovcException('OVCException', 'Quantity is not provided.', ['Transaction.changeItemQty3']);
								}
							} else {
								throw util.ovcException('OVCException', "Item type '" + itemType + "' is not valid to modify quantity", ['Transaction.changeItemQty4']);
							}
						} else {
							// item does not exist in the receipt
							throw util.ovcException('OVCException', "Invalid Item No", ['Transaction.changeItemQty5']);
						}
					} else {
						// item index not specified
						throw util.ovcException('OVCException', "Item index must be specified", ['Transaction.changeItemQty6']);
					}
				} catch (e) {
					//console.log("Transaction.changeItemQty()", e, itemIdx, qty);
					throw util.rethrow(e, 'Transaction.changeItemQty');
				}
			},

			voidItem: function (refItemIdx, reasonCodeId, linkedProduct) {
				try {
					if (refItemIdx != null && this.getTranItemByIdx(refItemIdx) != null) {
						var refTranItem = this.getTranItemByIdx(refItemIdx);
						if (refTranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT ||
							refTranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT ||
							refTranItem.getItemType() == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
							refTranItem.getItemType() == Constants.ITEM_TY_APPOINTMENT) {

							var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
							var tranObjMode = tranObj.getCurrentMode();

							if (this.isItemVoidByIdx(refItemIdx) == true) {
								throw util.ovcException('OVCException', 'Item is already void');
							}

							// Create tranItem and add to transaction
							var voidTranItem = new TransactionItem();
							voidTranItem.setTranId(this._id);// this.getId());

							voidTranItem.setItemType(Constants.ITEM_TY_VOID_ITEM);
							voidTranItem.setRefItemIdx(refItemIdx);
							voidTranItem.setReasonCodeId(reasonCodeId);

							// Add to transaction
							voidTranItem = this.addItemToTransaction(voidTranItem);
							this.addToItemsHistory(this._J67DE5GC89[refTranItem.getItemIdx()], voidTranItem.getItemIdx(), true/* isVoid */);
							this.addRefVoidItemsToItemsHistory(refTranItem.getItemIdx(), refItemIdx);

							//If a child product is voided then void parent product and any linked products in that bundle
							if(refTranItem.getParentProductIdx() != undefined && refTranItem.getParentProductIdx() != null && refTranItem.getParentProductIdx() != -1 && !linkedProduct){

								if(refTranItem.getCascadeVoidToParent() === 1){
									var idxArr = this.getAllItemsHistoryIdxArray();
									for (var j = 0; j < idxArr.length; j = j + 1) {
										var itemIdx = idxArr[j];
										var tranItem = this.getTranItemByIdx(itemIdx);
										if(!this.isItemVoidByIdx(itemIdx) && refTranItem.getSku() != null  && ((/* Identifying the children products */refTranItem.getParentProductIdx() === tranItem.getParentProductIdx() && tranItem.getCascadeVoid() === 1)|| /* Identifying the parent */refTranItem.getParentProductIdx() === tranItem.getItemIdx())){
											this.voidItem(tranItem.getItemIdx(),reasonCodeId, true);
										}
									}
								}
								this._recalcTransaction();
								if (tranObjMode == Constants.TRAN_CURRENT_MODE_NORMAL) {
									this.recalcTransDiscount(true);
								}

							} else if(!linkedProduct){
								//Loop through all the items and void linked products

								var idxArr = this.getAllItemsHistoryIdxArray();
								for (var j = 0; j < idxArr.length; j = j + 1) {
									var itemIdx = idxArr[j];
									var tranItem = this.getTranItemByIdx(itemIdx);
									if(!this.isItemVoidByIdx(itemIdx) && refTranItem.getSku() != null && refItemIdx === tranItem.getParentProductIdx() && tranItem.getCascadeVoid() === 1){
										this.voidItem(tranItem.getItemIdx(),reasonCodeId, true );
									}
								}

								this._recalcTransaction();
								if (tranObjMode == Constants.TRAN_CURRENT_MODE_NORMAL) {
									this.recalcTransDiscount(true);
								}
							}
						}
						else if(refTranItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_SALE ||
							refTranItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_TOPUP ||
							refTranItem.getItemType() == Constants.ITEM_TY_GIFT_CARD_REFUND){
							this.voidGiftCardItem(refTranItem,reasonCodeId, refTranItem.getItemIdx());
						}
						else if (refTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN) {
							var itemType = Constants.ITEM_TY_VOID_DISCOUNT_TXN;
							if (reasonCodeId == "0000") {
								itemType = Constants.ITEM_TY_VOID_DISCOUNT_RECALC_TXN;
							}
							this.voidDiscountTransaction(refItemIdx, refTranItem.getDiscType(), -refTranItem.getDiscValue(), reasonCodeId, itemType);
						}
						else if (refTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_ITEM) {
							this.voidDiscountItem(refTranItem.getRefItemIdx(), refItemIdx, refTranItem.getDiscType(), -refTranItem.getDiscValue(), reasonCodeId, 'Void Item Disc');
						}
						else if (refTranItem.getItemType() == Constants.ITEM_TY_DELIVERY_OPTION) {
							this.voidDeliveryOption(refTranItem, reasonCodeId);
						}
						else if (refTranItem.getItemType() == Constants.ITEM_TY_STORE_COLLECT_OPTION
						) {
							this.voidStoreCollectOption(refTranItem, reasonCodeId);
						} 
						else if(refTranItem.getItemType() == Constants.ITEM_TY_PROMO){
							//TODO handle this case...
						} 
						else if (refTranItem.getItemType() == Constants.ITEM_TY_PRICE_CHANGE
						) {
							this.voidOverrideItemPrice(refTranItem, reasonCodeId);
						}
						else {
							throw util.ovcException('OVCException', "Ref Item key '" + refItemIdx + "' is not valid for Void transaction");
						}
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.voidItem');
				}
			},

			isTransactionLocked: function () {
				return this._isLocked();
			},

			voidTransaction: function (reasonCodeId) {
				try {
					if (this.getTranItemsCount() <= 0 && reasonCodeId !== "0000") {
						throw util.ovcException('OVCException', 'No items in the receipt to void', ['Transaction.voidTransaction1']);
					}

					// Create tranItem and add to transaction
					var voidTranItem = new TransactionItem();
					voidTranItem.setTranId(this._id);
					voidTranItem.setItemType(Constants.ITEM_TY_VOID_TXN);
					voidTranItem.setReasonCodeId(reasonCodeId);

					// Add to transaction
					voidTranItem = this.addItemToTransaction(voidTranItem);

					this.addToAllItemsHistory(voidTranItem.getItemIdx());

					this.setTranTypeId(Constants.TX_TY_CURRENT_TRAN_VOID);
					this.setIsTranVoid(1);
					this._recalcTransaction(true);

					this.lock();

					return this;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.voidTransaction');
				}
			},

			discountItem: function (tranItemIdx, discType, discValue, reasonCodeId, reasonCodeDesc) {
				try {
					var refTranItem = this.getTranItemByIdx(tranItemIdx);

					if (tranItemIdx != null && refTranItem != null) {
						// Create tranItem and add to transaction
						var discountTranItem = new TransactionItem();
						discountTranItem.setTranId(this._id);

						discountTranItem.setItemType(Constants.ITEM_TY_DISCOUNT_ITEM);
						discountTranItem.setRefItemIdx(tranItemIdx);
						discountTranItem.setDiscType(discType);
						discountTranItem.setDiscValue(discValue);
						discountTranItem.setReasonCodeId(reasonCodeId);
						discountTranItem.setReasonCodeDesc(reasonCodeDesc);

						// Add to transaction
						discountTranItem = this.addItemToTransaction(discountTranItem);

						var curCalcUnitPrice = this.getSpecificItemHistory(tranItemIdx).calcUnitPrice;
						discountTranItem.setAmount(curCalcUnitPrice);
						
						var discountedUnitPrice = 0;
						var appliedDiscount = 0;
						if (discType == Constants.DISC_TYPE_AMOUNT) {
							appliedDiscount = discValue / this.getTranItemByIdx(tranItemIdx).getQty();
							discountedUnitPrice = curCalcUnitPrice - appliedDiscount;
						} else {
							appliedDiscount = Math.round(curCalcUnitPrice * discValue) / 100;
							discountedUnitPrice = curCalcUnitPrice - appliedDiscount;
						}
						this.getSpecificItemHistory(tranItemIdx).calcUnitPrice = discountedUnitPrice;

						refTranItem.setCalcAmount(Math.round(discountedUnitPrice * 100) / 100);
						discountTranItem.setNewPrice(Math.round(discountedUnitPrice * 100) / 100);
						discountTranItem.setCalcAmount(appliedDiscount);
						
						this.getSpecificItemHistory(tranItemIdx).isLocked = true;
						this.getSpecificItemHistory(tranItemIdx).history.push({
							itemIdxKey: discountTranItem.getItemIdx(),
							calcAmount: appliedDiscount
						});

						this._recalcTransaction();
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.discountItem');
				}
			},

			voidOverrideItemPrice: function (overridePriceTranItem, reasonCodeId) {
				try {

					if (overridePriceTranItem != null) {
						var refTranItem = this.getTranItemByIdx(overridePriceTranItem.getRefItemIdx());
						if(refTranItem != null){
							/*if (this.isItemVoidByIdx(refTranItem.getItemIdx()) == true) {
							 throw util.ovcException('OVCException', 'Item is already void');
							 }*/
							var voidTranItem = new TransactionItem();
							voidTranItem.setTranId(this._id);// this.getId());

							voidTranItem.setItemType(Constants.ITEM_TY_VOID_OVERRIDE_ITEM);
							voidTranItem.setRefItemIdx(overridePriceTranItem.getItemIdx());
							voidTranItem.setReasonCodeId(reasonCodeId);

							// Add to transaction
							this.addItemToTransaction(voidTranItem);
  							var tenderDetails = overridePriceTranItem.getTenderDetails();
 							if(tenderDetails && tenderDetails != null){
 	 							if(tenderDetails.priceChangeApplied){
	 								refTranItem.setCalcAmount(refTranItem.getCalcAmount()+Number(tenderDetails.priceChangeApplied));
	 								var itemfromHistory = this.getSpecificItemHistory(overridePriceTranItem.getRefItemIdx());
 	 								if (itemfromHistory != null) { 
	 									itemfromHistory.calcUnitPrice = refTranItem.getCalcAmount();
	 								}
 	 							} 
								if (tenderDetails.isVATIncluded != undefined && tenderDetails.isVATIncluded != null
									&& tenderDetails.isVATIncluded == false) {
									var taxArray = refTranItem.getProduct().getTaxRates();

									_.forEach(taxArray, function (value, key) {
										value.setIsVAT(1); 
									});
								}
								tenderDetails.originalRefItemIdx = overridePriceTranItem.getRefItemIdx();
							}

							overridePriceTranItem.setTenderDetails(tenderDetails);
							overridePriceTranItem.setRefItemIdx(-1);
							refTranItem.setIsPriceOverridable("1");

							this._recalcTransaction();

						} else {
							throw util.ovcException('OVCException', 'Invalid Item with no Product Association');
						}
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.voidOverrideItemPrice');
				}
			},

			voidStoreCollectOption: function (refTranItem, reasonCodeId) {
				if (this.isItemVoidByIdx(refTranItem.getItemIdx()) == true) {
					throw util.ovcException('OVCException', 'Item is already void');
				}

				// Create tranItem and add to transaction
				var voidTranItem = new TransactionItem();
				voidTranItem.setTranId(this._id);// this.getId());

				voidTranItem.setItemType(Constants.ITEM_TY_DELIVERY_VOID_ITEM);
				voidTranItem.setRefItemIdx(refTranItem.getItemIdx());
				voidTranItem.setReasonCodeId(reasonCodeId);

				// Add to transaction
				this.addItemToTransaction(voidTranItem);

				refTranItem.setRefItemIdx(-1);
				var refItemTenderDetails = refTranItem.getTenderDetails().propertiesJson.refItemIndices;
				var self = this;
				if (refItemTenderDetails && refItemTenderDetails != null) {
					var splitIndices = refItemTenderDetails.split(",");
					_.forEach(splitIndices, function (index, key) {
						var addedProductInTran = self.getTranItemByIdx(index);
						var addedTenderDetails = addedProductInTran.getTenderDetails();
						if (addedTenderDetails && addedTenderDetails != null) {
							addedTenderDetails.deliveryOptionSet = false;
						} else {
							addedTenderDetails = {deliveryOptionSet: false};
						}
						addedProductInTran.setTenderDetails(addedTenderDetails);
					});
				}
				this._recalcTransaction();
			},

			voidDeliveryOption: function (refTranItem, reasonCodeId) {
				if (this.isItemVoidByIdx(refTranItem.getItemIdx()) == true) {
					throw util.ovcException('OVCException', 'Item is already void');
				}

				// Create tranItem and add to transaction
				var voidTranItem = new TransactionItem();
				voidTranItem.setTranId(this._id);// this.getId());

				voidTranItem.setItemType(Constants.ITEM_TY_DELIVERY_VOID_ITEM);
				voidTranItem.setRefItemIdx(refTranItem.getItemIdx());
				voidTranItem.setReasonCodeId(reasonCodeId);

				// Add to transaction
				this.addItemToTransaction(voidTranItem);

				refTranItem.setRefItemIdx(-1);
				this._recalcTransaction();
			},

			voidDiscountItem: function (refTranItemIdx, discItemIdx, discType, discValue, reasonCodeId) {
				try {
					var refTranItem = this.getTranItemByIdx(refTranItemIdx);

					if (refTranItemIdx != null && refTranItem != null) {
						// Create tranItem and add to transaction
						var voidDiscountTranItem = new TransactionItem();
						voidDiscountTranItem.setTranId(this._id);

						voidDiscountTranItem.setItemType(Constants.ITEM_TY_VOID_DISCOUNT_ITEM);
						voidDiscountTranItem.setRefItemIdx(discItemIdx);
						voidDiscountTranItem.setReasonCodeId(reasonCodeId);

						// Add to transaction
						voidDiscountTranItem = this.addItemToTransaction(voidDiscountTranItem);

						var curCalcUnitPrice = this.getSpecificItemHistory(refTranItemIdx).calcUnitPrice;
						var unitPrice = refTranItem.getAmount();
						var discountedUnitPrice = 0;

						var appliedTransactionDiscount = 0;
						if (this.getSpecificItemHistory(refTranItemIdx).history) {
							_.forEach(this.getSpecificItemHistory(refTranItemIdx).history, function (itemHistory) {
								if (itemHistory.itemIdxKey === discItemIdx)
									appliedTransactionDiscount = itemHistory.calcAmount;
							});
						}

						discountedUnitPrice = curCalcUnitPrice + appliedTransactionDiscount;
						this.getSpecificItemHistory(refTranItemIdx).calcUnitPrice = discountedUnitPrice;

						refTranItem.setCalcAmount(discountedUnitPrice);

						this.getSpecificItemHistory(refTranItemIdx).isLocked = true;
						this.getSpecificItemHistory(refTranItemIdx).history.push({
							itemIdxKey: voidDiscountTranItem.getItemIdx()
						});

						var hist = this.getTranItemByIdx(discItemIdx).getHistory();
						hist.push(voidDiscountTranItem.getItemIdx());
						this.getTranItemByIdx(discItemIdx).setHistory(hist);

						this._recalcTransaction(true);
						var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
						var tranObjMode = tranObj.getCurrentMode();
						if (tranObjMode == Constants.TRAN_CURRENT_MODE_NORMAL) {
							this.recalcTransDiscount(true);
						}
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.discountItem');
				}
			},

			voidGiftCardItem: function (refTranItem, reasonCodeId, itemIdx) {
				if (this.isItemVoidByIdx(refTranItem.getItemIdx()) == true) {
					throw util.ovcException('OVCException', 'Item is already void');
				}

				// Create tranItem and add to transaction
				var voidTranItem = new TransactionItem();
				voidTranItem.setTranId(this._id);// this.getId());

				voidTranItem.setItemType(Constants.ITEM_TY_VOID_GIFTCARD_ITEM);
				voidTranItem.setRefItemIdx(refTranItem.getItemIdx());
				voidTranItem.setReasonCodeId(reasonCodeId);

				// Add to transaction
				voidTranItem = this.addItemToTransaction(voidTranItem);

				refTranItem.setRefItemIdx(itemIdx);
				this._recalcTransaction();
			},

			getSalesPersonBgColor : function () { //This color is used for the sales person background on VR
				try {
					var letters = [
						'FF0000',
						'0000FF',
						'000000',
						'800080',
						'FFA500',
						'008000',
						'EE82EE',
						'A52A2A',
						'FF00FF',
						'333300']; //Set your colors here

					var existingUsers = localStorage.getObject("users") || {};
					var userIds = Object.keys(existingUsers);
					var usersColors = {};
					if (userIds != null && userIds.length > 0) {
						_.forEach(userIds, function (userId) {
							usersColors[userId] = '#' + letters[Math.floor(Math.random() * letters.length)];
						});
					}
					return usersColors;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getSalesPersonBgColor');
				}
			}
		});
	});
