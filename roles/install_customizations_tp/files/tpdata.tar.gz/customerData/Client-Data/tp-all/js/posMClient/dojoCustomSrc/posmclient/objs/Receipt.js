define(["dojo/_base/declare", "ovc/Util", "generic/Constants"],
	function (declare, util, Constants) {
		return declare("posmclient.objs.Receipt", [], {
// TODO: Should add sums, tenders, messages, etc 
			_receiptDetails: {},
			_receiptItems: [],

			constructor: function () {
				this._receiptDetails = {};
				this._receiptItems = [];
			},

			loadReceiptFromTLogTables: function (tranRecord,
			                                     tranItemRecords,
			                                     tranItemProductRecords,
			                                     tranItemProductTaxRateRecords,
			                                     tranItemPromoRecords,
			                                     tranItemReturnRecords) {
				//
				this._receiptDetails.id = tranRecord.id;
				this._receiptDetails.datetime = tranRecord.tranDate;
				this._receiptDetails.storeId = tranRecord.storeId;
				this._receiptDetails.loyaltyId = tranRecord.loyaltyId;
				this._receiptDetails.customerEmail = tranRecord.customerEmail;
				this._receiptDetails.total = tranRecord.total;
				this._receiptDetails.barcode = tranRecord.barcode;
				this._receiptDetails.tenderDetails = [];
				
				if(tranRecord.tranItemLoyaltyUser && tranRecord.tranItemLoyaltyUser.loyaltyId){
					this._receiptDetails.loyaltyUser = tranRecord.tranItemLoyaltyUser;
				}
				
				// Loop through item to find all products and add to _items (CURRENTLY NO REGARD TO VOIDS, DISCOUNTS, ETC.)
				for (var i = 0; i < tranItemRecords.length; i = i + 1) {	
				this._receiptDetails.receiptJSON = tranRecord.receiptJSON;
				var lineNo = 0;
					var tranItemRec = tranItemRecords[i];
					var receiptItem = {};
					if(tranItemRec.productId || tranItemRec.product){
						receiptItem.productId = tranItemRec.productId || tranItemRec.product.productId;
					}
					receiptItem.qty = tranItemRec.qty;
					if(tranItemRec.productType || tranItemRec.product){
						receiptItem.productType = tranItemRec.productType || tranItemRec.product.productType;
					}
					receiptItem.returnQty = 0;
					receiptItem.price = Number(tranItemRec.calcAmount); 
					receiptItem.tranItemIndex = tranItemRec.itemIdx;
					if (tranItemRec.itemType == Constants.ITEM_TY_ADD_PRODUCT || tranItemRec.itemType == Constants.ITEM_TY_DELIVERY_OPTION) {
						for (var j = 0; j < tranItemProductRecords.length; j = j + 1) {
							var tranItemProductRec = tranItemProductRecords[j];
							if (tranItemProductRec.itemIdx == tranItemRec.itemIdx) {
								receiptItem.productName = tranItemProductRec.name;
								receiptItem.sku = tranItemProductRec.sku;
								receiptItem.productType = tranItemProductRec.productType;
								
								//check if certificate was sold...
								receiptItem.isCertificateAttached = this.checkIfCertificateSold(tranItemProductRec, tranItemProductRecords);

								// for fees and gift certificates, do not allow return.
								if(tranItemProductRec.productType == "Fees" || tranItemProductRec.productType == "GiftCertificate"){
									receiptItem.returnQty = receiptItem.qty + 1;
								}
								else{
									receiptItem.lineNo = lineNo+1;
									//for returned items
									for (var l = 0; l < tranItemReturnRecords.length; l = l + 1) {
										var tranItemReturnRec = tranItemReturnRecords[l];
										//This if clause handles mssql resultset TODO: Fix the MSSSQL query
										if (tranItemReturnRec && 
											(tranItemProductRec.sku == tranItemReturnRec.sku || tranItemProductRec.sku == tranItemReturnRec.returnSK) &&
											(tranItemReturnRec.refTranItemIdx == receiptItem.tranItemIndex)	
										) {
											if(receiptItem.returnQty < tranItemRec.qty){
												receiptItem.returnQty = receiptItem.returnQty + tranItemReturnRec.qty;
												//once processed, remove it from the return array...
												//delete tranItemReturnRecords[l];
												
												// Setting qty to 0 so that multiple items with the same SKU are not 
												// grayed out. TODO: Ideal approach is to have a new field in the tran_item_tbl
												// called returnItemIdx, and have it pointed to the itemIdx of the returned 
												// item in the orig transaction. Compare SKU and returnItemIdx to gray out.
												tranItemReturnRecords[l].qty = 0 ;
											}
										}
									}
								}
							}
						}
						//populate tax rates 
						receiptItem.taxRates = [];
						if(tranItemProductTaxRateRecords && tranItemProductTaxRateRecords!=null){
							for (var j = 0; j < tranItemProductTaxRateRecords.length; j = j + 1) {
								var tranItemProductTaxRateRecord = tranItemProductTaxRateRecords[j];
								if (tranItemProductTaxRateRecord.itemIdx == tranItemRec.itemIdx) { 
									receiptItem.taxRates.push(tranItemProductTaxRateRecord);
									break;
								}
							}
						} 
						if(receiptItem.returnQty<0){
							receiptItem.returnQty=0;
						} 
						this._receiptItems.push(receiptItem);
					}else if(parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_EINTEGRATED_TENDER ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_GIFTCERT_TENDER || 
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_PHYSICAL_TENDER ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_EEXTERNAL_TENDER ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_EINTERNAL_TENDER ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_CHANGE_TENDER ){
						this._receiptDetails.tenderDetails.push({amount:tranItemRecords[i].amount, tenderDetails: tranItemRecords[i].tenderDetails});
					}
					else if(parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_GIFT_CARD_SALE || 
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_GIFT_CARD_TOPUP){
							receiptItem.itemType = tranItemRecords[i].itemType;
							receiptItem.qty = 1;
							receiptItem.returnQty = 1; // so that it is grayed out in the order details page.
							receiptItem.tranItemIndex = tranItemRec.itemIdx;
							//receiptItem.price = tranItemRec.calcAmount;
							receiptItem.productName = "Gift Card";
							receiptItem.sku = tranItemRec.reasonCodeId;
							this._receiptItems.push(receiptItem);
					}
					else if(parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_DELIVERY_VOID_ITEM ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_VOID_ITEM ||
							parseInt(tranItemRecords[i].itemType) == Constants.ITEM_TY_VOID_GIFTCARD_ITEM){
							// Handling itemVoid, giftcardVoid, deliveryOptionVoid.
							// loop through receipt items to check if the tranItemIndex = void item's
							// refItemIdx. If so, splice it from the reference.
							var tranItemRec = tranItemRecords[i];
							var receiptItemsWithoutVoids = this._receiptItems;
							_.forEach(this._receiptItems, function (receiptItem) {
								if(receiptItem != undefined && (receiptItem.tranItemIndex == tranItemRec.refItemIdx)){
									receiptItemsWithoutVoids.splice(receiptItemsWithoutVoids.indexOf(receiptItem), 1);
								}
							});
					}
					else if (parseInt(tranItemRecords[i].itemType) === Constants.ITEM_TY_PROMO) {
						if (tranItemRecords[i].refItemIdx !== -1)  {
							var promotionRecord = tranItemRecords[i];
							var currentReceiptItem = null;
							for (var k=0; k<this._receiptItems.length; k++) {
								if (this._receiptItems[k].tranItemIndex === promotionRecord.refItemIdx) {
									currentReceiptItem = this._receiptItems[k];
								}
							}

							if (currentReceiptItem !== null) {
								// get the promotion from the tran item promo records
								_.forEach(tranItemPromoRecords, function(item) {
									if (item.itemIdx === promotionRecord.itemIdx) {
										currentReceiptItem.promoId = item.description;
									}
								});
								if (promotionRecord.qty === currentReceiptItem.qty) {//if the qty is the same as the promo qty
									currentReceiptItem.price -= promotionRecord.calcAmount;
								}
								else {
									// assuming the promo qty is never > item qty (which makes sense)
									// handle the case where the promo is applied to only some items in the record
									currentReceiptItem.splitItems = true;
									currentReceiptItem.promoAmount = promotionRecord.calcAmount; // promo amount needs to be dealt with when splitting the items

								}
							}
						}
					}
				}
			},
			checkIfCertificateSold : function(thisItem, tranItemProducts){
				var isCertificateSold = false;
				_.forEach(tranItemProducts, function(item){
					
					if(typeof item.propertiesJson == "string"){
						item.propertiesJson = JSON.parse(item.propertiesJson);
					}
					
					if(item.propertiesJson && item.propertiesJson.products){
						if(typeof item.propertiesJson.products.parentProductIdx != "undefined" && 
								item.propertiesJson.products.parentProductIdx != null && 
								item.propertiesJson.products.parentProductIdx == thisItem.itemIdx && 
								item.productType == "CERTIFICATE"){
							isCertificateSold = true;
							return true;//break
						}
					}
				});
				return isCertificateSold;
			},

			getAttributeByName: function (name) {
				return this._receiptDetails[name];
			},

			getReceiptDetails: function () {
				return this._receiptDetails;
			},

			getReceiptItemArr: function () {
				return this._receiptItems;
			}
		});
	});