// This module provides constants for the POSMClient.
// Note that many of these duplicate the server constants found here:
// POSMClient-Constants/src/main/java/com/oneview/posmclient/constants/
// POSMClient-Database/src/main/java/com/oneview/posmclient/db/TransactionHelper.java
// Until we're ready to build a unified constants and configuration system, we'll have to take care to keep these
// two homes for constants in sync.

define(["dojo/_base/declare"], function(declare) {
	var theConstants = declare("generic.Constants", null, {

		//******************************************
		// Alerts                                  *
		//******************************************

		// Types
		ALERT_TYPE_APPOINTMENT : 1,
		ALERT_TYPE_PICKUP : 2,
		ALERT_TYPE_RETURN : 3,

		// Statuses
		ALERT_STATUS_DELETED : -2,
		ALERT_STATUS_CANCELLED : -1,
		ALERT_STATUS_NEW : 1,
		ALERT_STATUS_UPDATED : 2,
		ALERT_STATUS_PROCESSING : 10,
		ALERT_STATUS_READY : 50,
		ALERT_STATUS_NOSHOW : 98,      // Applicable to appointments, ?, ...
		ALERT_STATUS_COMPLETED : 99,
		ALERT_STATUS_FULFILLED : 100,   // Applicable to pickups, ?, ...


		//******************************************
		// Transactions                            *
		//******************************************

		TX_TY_REGULAR_SALE: "regularSale",
		TX_TY_LAYAWAY_SALE: "layawaySale",
		TX_TY_LAYAWAY_PAY: "layawayPayment",
		TX_TY_LAYAWAY_RETURN: "layawayReturn",
		TX_TY_LAYAWAY_FINALIZE: "layawayFinalize",
		TX_TY_CURRENT_TRAN_VOID: "currentTransVoid",
		TX_TY_SIGNIN: "login",
		TX_TY_SIGNOFF: "logoff",
		TX_TY_POSTVOID: "postTranVoid",
		TX_TY_RETURN: "regularReturn",
		TX_TY_SUSPENDED: "suspended",
		TX_TY_NO_SALE: "noSale",
		TX_TY_UPDATE_STORECREDIT:"updateStoreCredit",
		TX_TY_QUOTE: "quote",
		TX_TY_INVALID_QUOTE: "expiredQuote",

		TX_TY_PAYIN: "payIn",
		TX_TY_PAYOUT: "payOut",
		TX_TY_CASH_PICKUP: "cashPickup",
		TX_TY_TILL_SPOT_CHECK: "tillSpotCheck",
		TX_TY_STORE_SPOT_CHECK: "storeSpotCheck",
		TX_TY_ZREAD: "zread",
		
		TX_TY_PAYINTRAN: "payInTran",
		TX_TY_PAYOUTTRAN: "payOutTran",
		TX_TY_PAYINCORRTRAN: "payInCorrTran",
		TX_TY_PAYOUTCORRTRAN: "payOutCorrTran",

		ITEM_TY_ADD_PRODUCT : 1,
		ITEM_TY_VOID_ITEM : 2, //Item could be product added/returned or transaction level discount
		ITEM_TY_VOID_TXN : 3,
		ITEM_TY_DISCOUNT_ITEM : 4, //product added/returned
		ITEM_TY_DISCOUNT_TXN : 5,
		ITEM_TY_REFUND_PRODUCT : 6,
		ITEM_TY_REFUND_TXN : 7,
		ITEM_TY_PRICE_CHANGE : 8,
		ITEM_TY_TAX_EXEMPT : 9,
		ITEM_TY_PROMO : 10,
		ITEM_TY_CUSTOMER_TYPE : 11,
		ITEM_TY_POST_VOID : 12,
		ITEM_TY_ADD_SITE_PICKUP_PRODUCT : 13,
		ITEM_TY_ADD_STORE_PICKUP_PRODUCT : 14,
		ITEM_TY_SUSPEND_TXN : 15,
		ITEM_TY_RESUME_TXN : 16,
		ITEM_TY_APPOINTMENT : 17,
		ITEM_TY_LOYALTY_ID : 18,
		ITEM_TY_CASH_TENDER : 20,
		ITEM_TY_CREDIT_TENDER : 21,
		ITEM_TY_CHANGE_TENDER : 22,
		ITEM_TY_DEBIT_TENDER : 23,
		ITEM_TY_CHECK_TENDER : 24,
		ITEM_TY_COUPON_TENDER : 25,
		ITEM_TY_AX_TENDER : 26,
		ITEM_TY_MC_TENDER : 27,
		ITEM_TY_VI_TENDER : 28,
		ITEM_TY_DC_TENDER : 29,

		ITEM_TY_GIFTCERT_TENDER : 32,
		ITEM_TY_PHYSICAL_TENDER : 36,
		ITEM_TY_EINTEGRATED_TENDER : 37,
		ITEM_TY_EEXTERNAL_TENDER : 38,
		ITEM_TY_EINTERNAL_TENDER : 39,
		ITEM_TY_PENNY_ROUNDING_TENDER : 9998,
		ITEM_TY_UNKNOWN_TENDER : 9999,

		ITEM_TY_SIGNIN : 30,
		ITEM_TY_SIGNOFF : 31,

		ITEM_TY_CASH_PAY_IN : 40,
		ITEM_TY_CASH_PAY_OUT : 41,
		ITEM_TY_CASH_FAILED_PAY_OUT : 411,
		ITEM_TY_CASH_PICKUP : 42,
		ITEM_TY_CASH_FAILED_PICKUP : 421,
		ITEM_TY_CASH_TILL_SPOT_CHECK : 43, 
		 
		ITEM_TY_CASH_END_OF_DAY : 44,
		ITEM_TY_CASH_FAILED_END_OF_DAY : 441,
		ITEM_TY_CASH_FORCED_END_OF_DAY : 45,
		ITEM_TY_VOID_DISCOUNT_TXN : 46,
		ITEM_TY_VOID_DISCOUNT_ITEM : 47,
		ITEM_TY_CLOCK_IN_TXN : 48,
		ITEM_TY_CLOCK_OUT_TXN : 49,

		ITEM_TY_NO_SALE : 50, 
		ITEM_TY_STORECREDIT_TENDER : 51,
		 
		ITEM_TY_TAX_EXEMPT : 52,
		ITEM_TY_VOID_DISCOUNT_RECALC_TXN : 54,
		ITEM_TY_STORECREDIT_SALE: 55,        
		ITEM_TY_RESUME_QUOTE_TXN: 56,
		ITEM_TY_VOID_LOYALTY_ID: 57,
		ITEM_TY_DELETE_QUOTE: 58,
		ITEM_TY_MGR_OVERRIDE: 59,
		ITEM_TY_DELIVERY_OPTION: 60,
		ITEM_TY_DEBIT_TILL_SPOT_CHECK : 61,
		ITEM_TY_CREDIT_TILL_SPOT_CHECK : 62,
		ITEM_TY_CHECK_TILL_SPOT_CHECK : 63,
		ITEM_TY_COUPON_TILL_SPOT_CHECK : 64,
		ITEM_TY_STORECREDIT_TILL_SPOT_CHECK : 65,

		ITEM_TY_PAYIN_SALE: 66,
		ITEM_TY_PAYIN_CORR_SALE: 67,
		ITEM_TY_PAYOUT_SALE: 68,
		ITEM_TY_PAYOUT_CORR_SALE: 69,
		
		ITEM_TY_GIFT_CARD_SALE: 70,
		ITEM_TY_VOID_GIFTCARD_ITEM: 71,
		ITEM_TY_GIFT_CARD_TOPUP: 72,
		ITEM_TY_DELIVERY_VOID_ITEM: 73,
		ITEM_TY_STORE_COLLECT_OPTION: 74,
		ITEM_TY_GIFT_CARD_REFUND: 75,
		ITEM_TY_BBAS: 76,
		ITEM_TY_VOID_OVERRIDE_ITEM: 77,
		ITEM_TY_GIFT_CARD_ADJ: 78,
		
		ITEM_TY_MANUAL_CARD_ENTRY_TENDER : "manualCardEntry",

		ITEM_TY_CASH_CURRENCY_PURCHASE : 540,
		ITEM_TY_CASH_FLOAT : 541,
		ITEM_TY_CASH_FAILED_FLOAT : 5411,
		ITEM_TY_CASH_DEPOSIT : 542,
		ITEM_TY_CASH_SAFE_SPOT_CHECK : 543,

		ITEM_TY_COUPON : 80,

		ITEM_TY_SPECIAL_PAYMENT_TENDER : 70,
		ITEM_TY_CASH_STORE_SPOT_CHECK: 544,
		
		ITEM_TY_NET_TAX : 900,
		
		DISC_TYPE_AMOUNT : 1,
		DISC_TYPE_PERCENT : 2,
		DISC_TYPE_EITHER : 3,
		
		TRAN_CURRENT_MODE_NORMAL: 0,
		TRAN_CURRENT_MODE_RECOVERY: 1
		
	});

	return new theConstants();
});
