define(["dojo/_base/declare",
		"dojo/Deferred",
		"ovc/Util",
		"dojo/when",
		"ovc/ConfigManager",
		"generic/db/DBUtil",
		"generic/Constants",
		"generic/GenericUtils",
		"posmclient/PennyRounder",
		"posmclient/db/objs/TransactionAbst",
		"posmclient/db/objs/TransactionItem",
		"posmclient/db/objs/TransactionItemProduct",
		"posmclient/db/objs/TransactionItemLoyaltyUser",
		"posmclient/db/objs/TransactionItemProductTaxRate",
		"posmclient/db/objs/TransactionItemPromo"
	],
	function (declare,
	          Deferred,
	          util,
	          when,
	          ConfigManager,
	          DBUtil,
	          Constants,
	          GenericUtils,
	          pennyRounder,
	          TransactionAbst,
	          TransactionItem,
	          TransactionItemProduct,
	          TransactionItemLoyaltyUser,
	          TransactionItemProductTaxRate,
	          TransactionItemPromo) {

		return declare("posmclient.db.objs.Transaction", TransactionAbst, {

			signIn: function () {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_SIGNIN);
					tranItem = this.addItemToTransaction(tranItem);
					this.addToAllItemsHistory(tranItem.getItemIdx());
					this.setTranTypeId(Constants.TX_TY_SIGNIN);
					this._recalcTransaction();
					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.signIn');
				}
			},

			signOff: function () {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_SIGNOFF);

					tranItem = this.addItemToTransaction(tranItem);

					this.addToAllItemsHistory(tranItem.getItemIdx());

					this.setTranTypeId(Constants.TX_TY_SIGNOFF);

					this._recalcTransaction(true);
					this.lock();

					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.signOff');
				}
			},

			addElectronicIntegratedTender: function (amount, itemDate, tenderDetails, tenderId) {
				try {
					// Create tranItem and add to transaction
					//cardAccountNumber, cardEncryptedToken, authCode, systemTraceAuditNumber,

					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_EINTEGRATED_TENDER);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					tranItem.setTenderId(tenderId);
					tranItem.setTenderDetails(tenderDetails);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}
					
					var adjItemIdx = this.getGiftCardAdjItemIdx();
					if(adjItemIdx != undefined && adjItemIdx != null){
						tranItem.setRefItemIdx(adjItemIdx);
					}
					
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addElectronicIntegratedTender');
				}
			},

			addElectronicExternalTender: function (amount, itemDate, tenderDetails, tenderId) {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_EEXTERNAL_TENDER);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					tranItem.setTenderId(tenderId);
					tranItem.setTenderDetails(tenderDetails);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addElectronicExternalTender');
				}
			},

			addElectronicInternalTender: function (amount, itemDate, tenderDetails, tenderId, isStoreCreditApplied) {
				try {
					// Create tranItem and add to transaction
					//cardAccountNumber, cardEncryptedToken, authCode, systemTraceAuditNumber,
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_EINTERNAL_TENDER);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					tranItem.setTenderId(tenderId);
					tranItem.setTenderDetails(tenderDetails);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}

					if (typeof isStoreCreditApplied != 'undefined' && isStoreCreditApplied != null && tenderId == Constants.ITEM_TY_STORECREDIT_TENDER) {
						tranItem.setIsStoreCreditApplied(isStoreCreditApplied);
					} else if (tenderId == Constants.ITEM_TY_STORECREDIT_TENDER) {
						tranItem.setIsStoreCreditApplied(0);
					}
					
					var adjItemIdx = this.getGiftCardAdjItemIdx();
					if(adjItemIdx != undefined && adjItemIdx != null){
						tranItem.setRefItemIdx(adjItemIdx);
					}
					
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addElectronicInternalTender');
				}
			},

			addPhysicalTender: function (amount, tenderId, tenderDetails, itemDate) {
				try {

					// We can't trust this number between adding the cash tender and recalculating
					var balance = this.getBalance();

					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_PHYSICAL_TENDER);
					tranItem.setTenderId(tenderId);
					tranItem.setTenderDetails(tenderDetails);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}
					var adjItemIdx = this.getGiftCardAdjItemIdx();
					if(adjItemIdx != undefined && adjItemIdx != null){
						tranItem.setRefItemIdx(adjItemIdx);
					}
					
					this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addPhysicalTender');
				}
			},

			addPennyRoundingTender: function (roundedPennies, itemDate) {

				var roundedDollars = roundedPennies / 100;
				var tranItem = new TransactionItem();

				tranItem.setTranId(this._id);
				tranItem.setItemType(Constants.ITEM_TY_PENNY_ROUNDING_TENDER);
				tranItem.setAmount(roundedDollars);
				tranItem.setCalcAmount(roundedDollars);
				tranItem.setTenderDetails({
					description: "rounding"
				});
				if (itemDate && itemDate != null) {
					tranItem.setItemDate(itemDate);
				}
				tranItem = this.addItemToTransaction(tranItem);

			},

			addCouponTender: function (amount, itemDate) {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_COUPON_TENDER);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}
					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addCouponTender');
				}
			},

			addChangeTender: function (amount, minimumDenomination, itemDate) {
				try {
					var recalc = false;
					var roundedInfo = pennyRounder(amount, minimumDenomination);
					var roundedPennies = roundedInfo.penniesRounded;
					var roundedAmount = roundedInfo.roundedAmount;

					if (roundedPennies !== 0) {
						this.addPennyRoundingTender(roundedPennies, itemDate);
						recalc = true;
					}

					if (roundedAmount === 0) {
						recalc && this._recalcTransaction(true);
						return 0;
					}

					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_CHANGE_TENDER);

					tranItem.setAmount(roundedAmount);
					tranItem.setCalcAmount(roundedAmount);
					tranItem.setTenderDetails({
						description: "change"
					});
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}

					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
					return roundedAmount;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addChangeTender');
				}
			},

			addUnknownTender: function (amount, itemDate) {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_UNKNOWN_TENDER);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}
					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addUnknownTender');
				}
			},

			getCreditTenderType: function (creditCardNumber) {

				var cardType = Constants.ITEM_TY_CREDIT_TENDER;

				if (!creditCardNumber || creditCardNumber.length < 4) {
					return cardType;
				}

				var prefix = parseInt(creditCardNumber.substring(0, 4));

				if (prefix >= 3400 && prefix < 3800) {
					cardType = Constants.ITEM_TY_AX_TENDER;
				}
				else if (prefix >= 4000 && prefix < 5000) {
					cardType = Constants.ITEM_TY_VI_TENDER;
				}
				else if (prefix >= 5100 && prefix < 5600) {
					cardType = Constants.ITEM_TY_MC_TENDER;
				}
				else if (prefix == 6011) {
					cardType = Constants.ITEM_TY_DC_TENDER;
				}
				return cardType;

			},

			addCoupon: function (code) {

				try {
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);

					tranItem.setItemType(Constants.ITEM_TY_COUPON);
					tranItem.setReasonCodeId(code);

					this.addItemToTransaction(tranItem);
					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addCoupon');
				}
			},

			addResumeTranItem: function (suspendedTranId) {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();

					tranItem.setTranId(this._id);
					if (this.getTranTypeId() == Constants.TX_TY_QUOTE) {
						tranItem.setItemType(Constants.ITEM_TY_RESUME_QUOTE_TXN);
						this.setTranTypeId(Constants.TX_TY_REGULAR_SALE);
					}
					else {
						tranItem.setItemType(Constants.ITEM_TY_RESUME_TXN);
					}

					tranItem.setRefTranId(suspendedTranId);

					this.addItemToTransaction(tranItem);
					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addResumeTranItem');
				}
			},

			// Actual data methods
			populateTranFromStorage: function (tranId) {
				var thisTranObj = this;

				var deferred = new Deferred();

				var sqlQuery = "select id,tranNo,userId,retailerId,storeId,deviceId,drawerId,tillId,loyaltyId,customerEmail,tranTypeId,isTranVoid,totalItems,merchTotal,promoTotal,tax,total,strftime('%Y/%m/%d %H:%M:%S',tranDate) as tranDate,barcode,training from tran_tbl where id =  ?";

				var paramsArr = [tranId];
				db.transaction(function (tx) {
						tx.executeSql(sqlQuery,
							paramsArr,
							function (tx, results) {
								var len = results.rows.length;
								if (len > 0) {
									for (var i = 0; i < len; i++) {
										var tranRecord = results.rows.item(i);
										thisTranObj.setId(tranRecord.id);
										thisTranObj.setTranNo(tranRecord.tranNo);
										thisTranObj.setTranTimestamp(tranRecord.tranDate);

										sqlQuery = "select * from tran_item_tbl where tranId=?";
										paramsArr = [tranId];

										tx.executeSql(sqlQuery,
											paramsArr,
											function (tx, subResults) {
												var len2 = subResults.rows.length;
												var itemsArr = [];
												for (var j = 0; j < len2; j++) {
													var itemRecord = subResults.rows.item(j);
													itemsArr.push(itemRecord);
												}
												thisTranObj.populateItemsFromStorage(deferred, itemsArr);
											});
									}
								} else {
									deferred.reject({
										name: 'TransactionNotFound',
										message: require("generic/ResourceManager").getValue("errorMessages.transactionNotFound1") +
										tranId +
										require("generic/ResourceManager").getValue("errorMessages.transactionNotFound2")
									});
								}
							});
					},
					function (err) {
						if (err.name == null) {
							err.name = 'SQLError';
						}
						if (err.message == null) {
							err.message = 'SQL Error';
						}
						deferred.reject(err);
					});

				return deferred.promise;
			},

			populateItemsFromStorage: function (deferred, itemsArr) {
				var thisTranObj = this;
				if (itemsArr.length == 0) {
					deferred.resolve();
					return;
				}

				var itemRecord = itemsArr.splice(0, 1)[0];
				if (itemRecord.itemType == Constants.ITEM_TY_ADD_PRODUCT) {
					var dbUtil = new DBUtil();
					when(dbUtil.executeQuery("select * from tran_item_product_tbl where tranId =  ? and itemIdx = ?", [itemRecord.tranId, itemRecord.itemIdx])).then(
						function (result) {
							var productObj = result[0];
							productObj.id = itemRecord.productId; //To be removed
							thisTranObj.addItem(productObj, itemRecord.qty);
							thisTranObj.populateItemsFromStorage(deferred, itemsArr);
						});
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_LOYALTY_ID) {
					var dbUtil = new DBUtil();
					when(dbUtil.executeQuery("select * from tran_item_loyalty_user_tbl where tranId =  ? and itemIdx = ?", [itemRecord.tranId, itemRecord.itemIdx])).then(
						function (result) {
							var loyaltyUserObj = result[0];
							thisTranObj.addItemLoyaltyUser(loyaltyUserObj);
							thisTranObj.populateItemsFromStorage(deferred, itemsArr);
						});
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_PHYSICAL_TENDER) {
					thisTranObj.addPhysicalTender(itemRecord.amount);
					//thisTranObj._recalcTransaction();
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_EINTEGRATED_TENDER) {
					thisTranObj.addElectronicIntegratedTender(itemRecord.amount, itemRecord.tenderId, itemRecord.tenderDetails);
					//thisTranObj._recalcTransaction();
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_EEXTERNAL_TENDER) {
					thisTranObj.addElectronicExternalTender(itemRecord.amount, itemRecord.tenderId, itemRecord.tenderDetails);
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_EINTERNAL_TENDER) {
					thisTranObj.addElectronicInternalTender(itemRecord.amount, itemRecord.tenderId, itemRecord.tenderDetails);
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_CHECK_TENDER) {
					thisTranObj.addCheckTender(itemRecord.amount);
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else if (itemRecord.itemType == Constants.ITEM_TY_PROMO) {
					thisTranObj.populateItemsFromStorage(deferred, itemsArr);
				}
				else {
					alert("Didn't add: " + JSON.stringify(itemRecord));
					this.populateItemsFromStorage(deferred, itemsArr);
				}
			},

			addStoreCreditSale: function (amount, itemDate) {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_STORECREDIT_SALE);
					tranItem.setAmount(amount);
					tranItem.setCalcAmount(amount);
					if (itemDate && itemDate != null) {
						tranItem.setItemDate(itemDate);
					}

					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addStoreCreditSale');
				}
			},

			addPIPOSale: function (amount, itemDate, itemType, reasonCodeId, reasonCodeDesc) {
				try {
						// Create tranItem and add to transaction
						var tranItem = new TransactionItem();
						tranItem.setTranId(this._id);
						if(itemType == Constants.ITEM_TY_PAYIN_SALE){
							tranItem.setItemType(Constants.ITEM_TY_PAYIN_SALE);
						}
						else if(itemType == Constants.ITEM_TY_PAYIN_CORR_SALE){
							tranItem.setItemType(Constants.ITEM_TY_PAYIN_CORR_SALE);
						}
						else if(itemType == Constants.ITEM_TY_PAYOUT_SALE){
							tranItem.setItemType(Constants.ITEM_TY_PAYOUT_SALE);
						}
						else if(itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
							tranItem.setItemType(Constants.ITEM_TY_PAYOUT_CORR_SALE);
						}
						tranItem.setAmount(amount);
						tranItem.setCalcAmount(amount);
						tranItem.setReasonCodeId(reasonCodeId);
						tranItem.setReasonCodeDesc(reasonCodeDesc);
						
						if(itemDate && itemDate!=null){
							tranItem.setItemDate(itemDate);
						}
						// Add to transaction
						tranItem = this.addItemToTransaction(tranItem);
						this._recalcTransaction(true);
						return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addPIPOSale');
				}
			},
			
			addGiftCardRefund: function(serialNumber, amount, itemDate, reasonCodeDesc, origTranId) {
				
				var tranItem = new TransactionItem();
				tranItem.setTranId(this._id);
				
				tranItem.setItemType(Constants.ITEM_TY_GIFT_CARD_REFUND);
				this.setTranTypeId(Constants.TX_TY_RETURN);
				
				tranItem.setAmount(amount);
				tranItem.setCalcAmount(amount);
				tranItem.setReasonCodeId(serialNumber);
				tranItem.setReasonCodeDesc(reasonCodeDesc);
				
				if(itemDate && itemDate!=null){
					tranItem.setItemDate(itemDate);
				}
				//For return tran Items
				if (origTranId != '' && origTranId != null) {
					tranItem.setRefTranId(origTranId);
				}
				tranItem.setQty(1); //can return only one gift card at a time.
				// Add to transaction
				tranItem = this.addItemToTransaction(tranItem);
				//this.createItemHistory(tranItem, amount);
				this._recalcTransaction(true);
				return tranItem;
			},
			
			addGiftCardSale: function (serialNumber, amount, itemDate, reasonCodeDesc, isTopUp) {
				try {
						// Create tranItem and add to transaction
						var tranItem = new TransactionItem();
						
						tranItem.setTranId(this._id);
						if(isTopUp == true){
							tranItem.setItemType(Constants.ITEM_TY_GIFT_CARD_TOPUP);
						}
						else{
							tranItem.setItemType(Constants.ITEM_TY_GIFT_CARD_SALE);
						}
						
						tranItem.setAmount(amount);
						tranItem.setCalcAmount(amount);
						tranItem.setReasonCodeId(serialNumber);
						tranItem.setReasonCodeDesc(reasonCodeDesc);
						
						if(itemDate && itemDate!=null){
							tranItem.setItemDate(itemDate);
						}
						// Add to transaction
						tranItem = this.addItemToTransaction(tranItem);
						//this.createItemHistory(tranItem, amount);
						this._recalcTransaction(true);
						return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addGiftCardSale');
				}
			},
			
			getGiftCardAdjItemIdx: function() {
				var giftCardAdjItemIdx = -1;
				_.forEach(this.getTranItems(), function(item){
					if (item.getItemType() == Constants.ITEM_TY_GIFT_CARD_ADJ){
						giftCardAdjItemIdx = item.getItemIdx();
					}
				});
				return giftCardAdjItemIdx;
			},
			
			addGiftCardAdjustment: function (amount, itemDate) {
				try {
						// Create tranItem and add to transaction
						var tranItem = new TransactionItem();
						
						tranItem.setTranId(this._id);
						tranItem.setItemType(Constants.ITEM_TY_GIFT_CARD_ADJ);
						
						tranItem.setAmount(amount);
						tranItem.setCalcAmount(amount);
						tranItem.setItemDate(itemDate);
						
						// Add to transaction
						tranItem = this.addItemToTransaction(tranItem);
						//this.setTranTypeId();
						this._recalcTransaction(true);
						return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addGiftCardSale');
				}
			},
			
			convertToTranItemProduct: function (prodObj, tranId, itemIdx, isRefund) {
				try {
					var tranItemProd = new TransactionItemProduct();

					if (!tranId && prodObj.tranId) {
						tranId = prodObj.tranId;
					}

					if (!itemIdx && prodObj.itemIdx) {
						itemIdx = prodObj.itemIdx;
					}

					if (tranId != null) {
						tranItemProd.setTranId(tranId)
					}

					if (itemIdx != null && !isNaN(itemIdx)) {
						tranItemProd.setItemIdx(itemIdx)
					}


					tranItemProd.setSku(prodObj.sku);
					tranItemProd.setBarcode(prodObj.barcode);
					tranItemProd.setRetailerId(prodObj.retailerId);
					tranItemProd.setProductType(prodObj.productType);
					tranItemProd.setName(prodObj.name);
					tranItemProd.setDescription(prodObj.description);
					tranItemProd.setBannerId(prodObj.bannerId);
					tranItemProd.setProductURL(prodObj.productURL);
					tranItemProd.setAllowDiscounts(prodObj.allowDiscounts);
					tranItemProd.setBrandId(prodObj.brandId);
					tranItemProd.setMMGroupId(prodObj.mmGroupId);
					tranItemProd.setTaxExemptible(prodObj.isTaxExemptible);
					tranItemProd.setProductJson(prodObj.propertiesJson);

					if ("price" in prodObj) {
						tranItemProd.setInitialPrice(prodObj.price); // TODO: Should be setPrice instead
					} else if ("initialPrice" in prodObj) {
						/**in db price is stored in initialPtice column **/
						tranItemProd.setInitialPrice(prodObj.initialPrice);
					}
					
					if(prodObj.costPrice != null){
						tranItemProd.setCostPrice(prodObj.costPrice);
					}
					
					tranItemProd.setMainImageId(prodObj.mainImageId);
					tranItemProd.setProductId(prodObj.id);
					tranItemProd.setProductCode(prodObj.productCode);

					if (prodObj.taxRates) {
						for (var i = 0; i < prodObj.taxRates.length; i = i + 1) {
							var taxRateJson = prodObj.taxRates[i];
							var isTaxExemptible = prodObj.isTaxExemptible;
							if (isRefund !== undefined && isRefund !== null && isRefund) {
								isTaxExemptible = 0;
							}
							tranItemProd.putTaxRate(this.convertToTranItemProductTaxRate(taxRateJson, tranId, itemIdx, undefined, isTaxExemptible));

						}
					}

					return tranItemProd;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.convertToTranItemProduct');
				}
			},

			convertToTranItemLoyaltyUser: function (loyaltyId, loyaltyFName, loyaltyLName, loyaltyEmail, tranId, itemIdx, taxExemptInfo) {
				try {
					var tranItemLoyaltyUser = new TransactionItemLoyaltyUser();

					tranItemLoyaltyUser.setTranId(tranId);
					tranItemLoyaltyUser.setItemIdx(itemIdx);

					tranItemLoyaltyUser.setLoyaltyId(loyaltyId);
					tranItemLoyaltyUser.setLoyaltyFName(loyaltyFName);
					tranItemLoyaltyUser.setLoyaltyLName(loyaltyLName);
					tranItemLoyaltyUser.setLoyaltyEmail(loyaltyEmail);
					tranItemLoyaltyUser.setTaxExemptInfo(taxExemptInfo);


					return tranItemLoyaltyUser;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.convertToTranItemLoyaltyUser');
				}
			},

			convertToTranItemProductTaxRate: function (taxRateJson, tranId, itemIdx, itemCalcAmount, isProductTaxExempt) {

				var tranItemProdTaxRate = new TransactionItemProductTaxRate();

				if (!tranId && taxRateJson.tranId) {
					tranId = taxRateJson.tranId;
				}

				if (!itemIdx && taxRateJson.itemIdx) {
					itemIdx = taxRateJson.itemIdx;
				}

				if (tranId != null) {
					tranItemProdTaxRate.setTranId(tranId);
				}

				if (itemIdx != null && !isNaN(itemIdx)) {
					tranItemProdTaxRate.setItemIdx(itemIdx);
				}
				//var isTaxExempt = this.getCustomerTaxExempt();
				var isTaxExempt = this.isCustomerTaxExempt();

				//Default Tax Rate and Percent are soft-coded. Ideally, tax rates/percent value should be read from a 3rd Party service
				var percent = taxRateJson.percentage;
				if ((taxRateJson.isVAT == 0 || taxRateJson.isVAT == 2) && isProductTaxExempt == 1 && isTaxExempt !== undefined && isTaxExempt !== null && isTaxExempt == true) {

					var defaultTaxRate = this.getDefaultTaxRate();
					var defaultTaxRatePercent = this.getDefaultTaxPercentage();
					if (defaultTaxRate !== undefined && defaultTaxRate !== null) {
						tranItemProdTaxRate.setTaxRateId(defaultTaxRate);
						tranItemProdTaxRate.setDescription(taxRateJson.percentage);
						percent = defaultTaxRatePercent;
					}
				} else {

					tranItemProdTaxRate.setTaxRateId(taxRateJson.taxRateId);
				}

				tranItemProdTaxRate.setPercentage(percent);
				tranItemProdTaxRate.setDisplayCode(taxRateJson.displayCode);
				tranItemProdTaxRate.setDescription(taxRateJson.description);
				var dt = new Date(taxRateJson.startDate);
				if (dt != 'Invalid Date') {
					tranItemProdTaxRate.setStartDate(dt.getTime());
				} else {
					tranItemProdTaxRate.setStartDate(0);
				}

				tranItemProdTaxRate.setIsVAT(taxRateJson.isVAT);

				/** taxAmount not part of table column
				 * TODO : add as a column instead of calculating everytime
				 */
				if (itemCalcAmount) {
					tranItemProdTaxRate.setTaxAmount(require("generic/StringUtils").numberToCurrencyString(parseFloat((parseFloat(itemCalcAmount) * parseFloat(tranItemProdTaxRate.getPercentage())) / 100)));
				}
				return tranItemProdTaxRate;

			},

			convertToTranItemPromotion: function (promoObj, tranId, itemIdx) {
				try {
					var tranItemPromo = new TransactionItemPromo();

					if (!tranId && promoObj.tranId) {
						tranId = promoObj.tranId;
					}

					if (!itemIdx && promoObj.itemIdx) {
						itemIdx = promoObj.itemIdx;
					}

					if (tranId != null) {
						tranItemPromo.setTranId(tranId)
					}
					if (itemIdx != null && !isNaN(itemIdx)) {
						tranItemPromo.setItemIdx(itemIdx)
					}

					tranItemPromo.setPromoId(promoObj.id);
					tranItemPromo.setPromoType(promoObj.type);
					tranItemPromo.setDescription(promoObj.description);
					tranItemPromo.setAmountType(promoObj.amountType);
					tranItemPromo.setAmountValue(promoObj.amountValue);

					tranItemPromo.setLimitPerTran(promoObj.limitPerTran);
					tranItemPromo.setThresholdType(promoObj.thresholdType);
					tranItemPromo.setThresholdValue(promoObj.thresholdValue);
					tranItemPromo.setThresholdCust(promoObj.thresholdCust);
					tranItemPromo.setThresholdAlert(promoObj.thresholdAlert);
					tranItemPromo.setSkus(promoObj.skus);

					tranItemPromo.setFromDate(promoObj.from);
					tranItemPromo.setTillDate(promoObj.to);
					tranItemPromo.setRequireLoyalty(promoObj.requireLoyalty);
					tranItemPromo.setActive(1);
//					tranItemPromo.setAppliedToLayaway(promoObj.appliedToLayaway);
					return tranItemPromo;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.convertToTranItemPromotion');
				}
			},

			convertToTransaction: function (tranObj) {
				try {
					var transaction = new posmclient.db.objs.Transaction();

					transaction.setId(tranObj.id);
					transaction.setBarcode(tranObj.barcode);
					transaction.setTraining(tranObj.training);
					transaction.setTranNo(tranObj.tranNo);
					transaction.setUserId(tranObj.userId);
					transaction.setRetailerId(tranObj.retailerId);
					transaction.setStoreId(tranObj.storeId);
					transaction.setDeviceId(tranObj.deviceId);
					transaction.setDrawerId(tranObj.drawerId);
					transaction.setTillId(tranObj.tillId);
					transaction.setLoyaltyId(tranObj.loyaltyId);
					transaction.setCustomerEmail(tranObj.customerEmail);
					transaction.setTranTypeId(tranObj.tranTypeId);
					transaction.setIsTranVoid(tranObj.isTranVoid);
					transaction.setTotalItems(tranObj.totalItems);
					transaction.setMerchTotal(tranObj.merchTotal);
					transaction.setTax(tranObj.tax);
					transaction.setTotal(tranObj.total);
					transaction.setPromoTotal(tranObj.promoTotal);
					transaction.setTranTimestamp(tranObj.tranDate);

					return transaction;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.convertToTransaction');
				}
			},

			convertToTransactionItem: function (tranItemObj) {
				try {
					var transactionItem = new TransactionItem();

					transactionItem.setTranId(tranItemObj.tranId);
					transactionItem.setItemIdx(tranItemObj.itemIdx);
					transactionItem.setItemType(tranItemObj.itemType);
					transactionItem.setProductId(tranItemObj.productId);
					transactionItem.setSku(tranItemObj.sku);
					transactionItem.setQty(tranItemObj.qty);
					transactionItem.setRefItemIdx(tranItemObj.refItemIdx);
					transactionItem.setReasonCodeId(tranItemObj.reasonCodeId);
					transactionItem.setDiscType(tranItemObj.discType);
					transactionItem.setDiscValue(tranItemObj.discValue);
					transactionItem.setNewPrice(tranItemObj.newPrice);
					transactionItem.setAmount(tranItemObj.amount);
					transactionItem.setCardAccountNumber(tranItemObj.cardAccountNumber);
					transactionItem.setCardEncryptedToken(tranItemObj.cardEncryptedToken);
					transactionItem.setCardPinBlock(tranItemObj.cardPinBlock);
					transactionItem.setIsScanned(tranItemObj.isScanned);
					transactionItem.setCalcAmount(tranItemObj.calcAmount);
					transactionItem.setItemDate(tranItemObj.itemDate);
					transactionItem.setRefTranId(tranItemObj.refTranId);

					transactionItem.setReasonCodeDesc(tranItemObj.reasonCodeDesc);

					return transactionItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.convertToTransactionItem');
				}
			},

			reloadTransaction: function (tranId) {
				try {
					var dbUtil = new DBUtil();
					var thisObject = this;
					var tranQuery = "select id,tranNo,userId,retailerId,storeId,deviceId,drawerId,tillId,loyaltyId,customerEmail,tranTypeId,isTranVoid,totalItems,merchTotal,promoTotal,tax,total,strftime('%Y/%m/%d %H:%M:%S',tranDate) as tranDate,barcode,training from tran_tbl where id =  ?";
					return when(dbUtil.executeQuery(tranQuery, [tranId])).then(
						function (result) {
							if (result != null && result.length > 0) {
								var transaction = thisObject.convertToTransaction(result[0]);
								return when(thisObject.loadTranItemsFromDB(tranId, dbUtil)).then(
									function (tranItems) {
										transaction.setTranItems(tranItems);
										return transaction;
									},
									function (e) {
										throw util.rethrow(e, 'Transaction.reloadTransaction.0');
									});
							} else {
								alert("Transaction with id " + tranId + " is not found.");
							}
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.reloadTransaction.1');
						}).then(
						function (transaction) {
							return transaction;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.reloadTransaction.2');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.reloadTransaction');
				}
			},

			loadTranItemsFromDB: function (tranId, dbUtil) {
				try {
					if (dbUtil == null) {
						dbUtil = new DBUtil();
					}
					var thisObject = this;

					return when(dbUtil.executeQuery("select ti.*, rc.description as reasonCodeDesc from tran_item_tbl ti left join reason_code_tbl rc on (ti.reasonCodeId = rc.id) where ti.tranId =  ? order by cast(itemIdx as integer)", [tranId])).then(
						function (tranItems) {

							if (tranItems == null || tranItems.length < 1) {
								return [];
							}

							var inputParams = {
								thisObject: thisObject,
								tranItemList: [],
								rawTranItems: tranItems
							};

							var loopFunc = function (tranItemJson, inputParams, Deferred, when, deferred) {
								var tranItem = inputParams.thisObject.convertToTransactionItem(tranItemJson);
								if (tranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT ||
									tranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT) {
									return when(inputParams.thisObject.getTranItemProduct(tranItem.getTranId(), tranItem.getItemIdx(), dbUtil, tranItem.getCalcAmount())).then(
										function (tranItemProduct) {
											tranItem.setProduct(tranItemProduct);

											var itemIdx = tranItem.getItemIdx();
											inputParams.tranItemList[itemIdx] = tranItem;
											deferred.resolve(true);
										},
										function (e) {
											deferred.reject(util.rethrow(e, 'Transaction.loadTranItemsFromDB.1'));
										});
								}
								else {
									if (tranItem.getRefItemIdx() != null && tranItem.getRefItemIdx() != 'null' && tranItem.getRefItemIdx() != -1) { //item level transaction types
										var refTranItem = inputParams.tranItemList[tranItem.getRefItemIdx()];
										var hist = refTranItem.getHistory();
										hist.push(tranItem.getItemIdx());
										refTranItem.setHistory(hist);

										var itemIdx = tranItem.getItemIdx();
										inputParams.tranItemList[itemIdx] = tranItem;
										deferred.resolve(true);
									}
									else {
										// promos and txn level transaction types
										if (tranItem.getItemType() == Constants.ITEM_TY_PROMO) {
											return when(inputParams.thisObject.getTranItemPromotion(tranItem.getTranId(), tranItem.getItemIdx(), dbUtil)).then(
												function (tranItemPromo) {
													tranItem.setPromotion(tranItemPromo);
													//add to last prod tran item
													var lastItemIdx = inputParams.tranItemList.length - 1;
													for (var j = lastItemIdx; j >= 0; j--) {
														var refTranItem = inputParams.tranItemList[j];

														if ((refTranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT || refTranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT)
															&& refTranItem.getProductId() == tranItem.getProductId()
															&& !inputParams.thisObject.isTranItemVoid(inputParams.rawTranItems, refTranItem, false)) {

															var hist = refTranItem.getHistory();
															hist.push(tranItem.getItemIdx());
															refTranItem.setHistory(hist);
															break;
														}
													}
													var itemIdx = tranItem.getItemIdx();
													inputParams.tranItemList[itemIdx] = tranItem;
													deferred.resolve(true);
												},
												function (e) {
													deferred.reject(util.rethrow(e, 'Transaction.loadTranItemsFromDB.2'));
												});
										}
										else if (tranItem.getItemType() == Constants.ITEM_TY_PHYSICAL_TENDER || tranItem.getItemType() == Constants.ITEM_TY_EINTEGRATED_TENDER
											|| tranItem.getItemType() == Constants.ITEM_TY_EEXTERNAL_TENDER || tranItem.getItemType() == Constants.ITEM_TY_EINTERNAL_TENDER
											|| tranItem.getItemType() == Constants.ITEM_TY_MC_TENDER || tranItem.getItemType() == Constants.ITEM_TY_VI_TENDER
											|| tranItem.getItemType() == Constants.ITEM_TY_DC_TENDER || tranItem.getItemType() == Constants.ITEM_TY_AX_TENDER
											|| tranItem.getItemType() == Constants.ITEM_TY_CHECK_TENDER || tranItem.getItemType() == Constants.ITEM_TY_UNKNOWN_TENDER
											|| tranitem.getItemType() == Constants.ITEM_TY_PENNY_ROUNDING_TENDER) {
											var itemIdx = tranItem.getItemIdx();
											inputParams.tranItemList[itemIdx] = tranItem;
											deferred.resolve(true);

										} else {
											//txn level
											var retTranItemsLen = inputParams.tranItemList.length;
											for (var j = 0; j < retTranItemsLen; j++) {
												var refTranItem = inputParams.tranItemList[j];
												if (refTranItem.getItemType() == Constants.ITEM_TY_ADD_PRODUCT || refTranItem.getItemType() == Constants.ITEM_TY_REFUND_PRODUCT) {
													var hist = refTranItem.getHistory();
													hist.push(tranItem.getItemIdx());
													refTranItem.setHistory(hist);
												}
											}
											var itemIdx = tranItem.getItemIdx();
											inputParams.tranItemList[itemIdx] = tranItem;
											deferred.resolve(true);
										}
									}
								}
							};

							return when(util.executeAsyncLoop(tranItems, loopFunc, null, inputParams)).then(
								function (result) {
									return inputParams.tranItemList;
								},
								function (e) {
									throw util.rethrow(e, 'Transaction.loadTranItemsFromDB.3');
								});
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.loadTranItemsFromDB.4');
						}).then(
						function (result) {
							return result;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.loadTranItemsFromDB.5');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.loadTranItemsFromDB');
				}
			},

			getTranItemProduct: function (tranId, itemIdx, dbUtil, itemCalcAmount) {
				try {
					if (!dbUtil) {
						dbUtil = new DBUtil();
					}
					var thisObject = this;
					return when(dbUtil.executeQuery("select * from tran_item_product_tbl where tranId = ? and itemIdx = " + itemIdx, [tranId])).then(
						function (result) {
							if (result && result.length > 0) {

								var tranItemProduct = thisObject.convertToTranItemProduct(result[0]);

								return when(thisObject.getTranItemProductTaxRates(tranId, itemIdx, dbUtil, itemCalcAmount)).then(
									function (taxRatesArr) {
										tranItemProduct.setTaxRates(taxRatesArr);
										return tranItemProduct;
									},
									function (e) {
										throw util.rethrow(e, 'Transaction.getTranItemProduct.0');
									});
							}
							else {
								return null;
							}
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemProduct.1');
						}).then(
						function (result) {
							return result;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemProduct.2');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemProduct');
				}
			},

			getTranItemLoyaltyUser: function (tranId, itemIdx, dbUtil) {
				try {
					if (!dbUtil) {
						dbUtil = new DBUtil();
					}
					var thisObject = this;
					return when(dbUtil.executeQuery("select * from tran_item_loyalty_user_tbl where tranId = ? and itemIdx = " + itemIdx, [tranId])).then(
						function (result) {
							if (result && result.length > 0) {
								var tranItemLoyaltyUser = thisObject.convertToTranItemLoyaltyUser(result[0]);

								return tranItemLoyaltyUser;
							} else {
								return null;
							}
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemLoyaltyUser.1');
						}).then(
						function (result) {
							return result;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemLoyaltyUser.2');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemLoyalty');
				}
			},

			getTranItemProductTaxRates: function (tranId, itemIdx, dbUtil, itemCalcAmount) {
				try {
					if (!dbUtil) {
						dbUtil = new DBUtil();
					}
					var thisObject = this;
					return when(dbUtil.executeQuery("select * from tran_item_product_tax_rate_tbl where tranId = ? and itemIdx = " + itemIdx, [tranId])).then(
						function (result) {

							if (result) {

								var taxRates = [];

								for (var i = 0; i < result.length; i++) {
									taxRates.push(thisObject.convertToTranItemProductTaxRate(result[i], tranId, itemIdx, itemCalcAmount));
								}
								return taxRates;
							}
							else {
								return null;
							}
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemProductTaxRates.1');
						}).then(
						function (result) {
							return result;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemProductTaxRates.2');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemProductTaxRates');
				}
			},

			getTranItemPromotion: function (tranId, itemIdx, dbUtil) {
				try {
					if (!dbUtil) {
						dbUtil = new DBUtil();
					}
					var thisObject = this;

					return when(dbUtil.executeQuery("select * from tran_item_promotion_tbl where tranId =  ? and itemIdx = " + itemIdx, [tranId])).then(
						function (result) {
							if (result && result.length > 0) {
								return thisObject.convertToTranItemPromotion(result[0]);
							}
							else {
								return null;
							}
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemPromotion.1');
						}).then(
						function (result) {
							return result;
						},
						function (e) {
							throw util.rethrow(e, 'Transaction.getTranItemPromotion.2');
						});
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTranItemPromotion');
				}
			},

			isTranItemVoid: function (tranItemList, tranItem, fromHist) {
				try {
					isVoid = false;

					if (tranItemList != null && tranItemList.length > 0) {
						if (fromHist == false) {
							var itemLen = tranItemList.length;
							for (var i = tranItem.getItemIdx() + 1; i < itemLen; i++) {
								var refTranItem = tranItemList[i];
								if ((refTranItem.getRefItemIdx() == tranItem.getItemIdx() ||
									refTranItem.getRefItemIdx() == tranItem.getRefItemIdx()) &&
									refTranItem.getItemType() == Constants.ITEM_TY_VOID_ITEM) {
									isVoid = true;
									break;
								}
							}
						} else {
							// FIXME: history is always empty
							var history = tranItem.getHistory();
							var histLen = history.length;
							for (var i = 0; i < histLen; i++) {
								var refTranItem = tranItemList[history[i]];
								if (refTranItem.getItemType() == Constants.ITEM_TY_VOID_ITEM) {
									isVoid = true;
									break;
								}
							}
						}
					}
					return isVoid;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.isTranItemVoid');
				}
			},

			isLastItemInTxnDisc: function (tranItems, tranItemIdx, txnDiscIndex) {
				try {
					if (tranItems != null && tranItems.length > 0 && tranItems.length > tranItemIdx + 1) {
						for (var i = tranItemIdx + 1; i < tranItems.length; i++) {
							var tranItem = tranItems[i];
							var history = tranItem.getHistory();
							if (history.indexOf(txnDiscIndex) != -1) {
								return false;
							}
						}
					}
					return true;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.isLastItemInTxnDisc');
				}
			},

			refundItem: function (productObj, splitItems, qty, reasonCode, reasonCodeDesc, isScanned, origTranId, origTenderDetails, refTranItemIdx) {
				try {
					// Create tranItem and add to transaction
					if (isScanned == null) {
						isScanned = 0;
					}
					
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);

					tranItem.setItemType(Constants.ITEM_TY_REFUND_PRODUCT);

					var tranItemProd = this.convertToTranItemProduct(productObj, this._id, null, true);

					tranItem.setProduct(tranItemProd);
					tranItem.setProductId(productObj.id);
					if (origTenderDetails) {
						tranItem.setTenderDetails({origTenderDetails: origTenderDetails});
					}
					tranItem.setSku(productObj.sku);
					var configPositionValue = ConfigManager.getConfigObject("posMClient/payment.ovccfg").allowPriceOverride;
					if (configPositionValue != undefined &&
						configPositionValue != null &&
						configPositionValue != "0") {
						var propertiesJson = productObj["propertiesJson"];
						if (propertiesJson && propertiesJson != null && propertiesJson != "") {
							var Json = propertiesJson;
							if(typeof Json == "string"){
								Json = require('dojo/_base/json').fromJson(propertiesJson);
							}
							if (Json && Json != null) {
								var isPriceOverridable = Json.products.isPriceOverridable;
								if (typeof isPriceOverridable === 'undefined') {
									tranItem.setIsPriceOverridable("1");
								} else {
									tranItem.setIsPriceOverridable(isPriceOverridable);
								}
							}
						}
					}
					tranItem.setQty(qty);
					tranItem.setReasonCodeId(reasonCode);
					tranItem.setReasonCodeDesc(reasonCodeDesc);
					tranItem.setIsScanned(isScanned);

					//For return tran Items
					if (origTranId != '' && origTranId != null) {
						tranItem.setRefTranId(origTranId);
					}
					if(refTranItemIdx !== undefined && refTranItemIdx !== '' && refTranItemIdx !== null){
						tranItem.setRefTranItemIdx(refTranItemIdx);
					}

					tranItem._splitItems = splitItems;
					tranItem._promoId = productObj.promoId;
					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					// Add to itemsHistory
					this.createItemHistory(tranItem, productObj.price);

					this.setTranTypeId(Constants.TX_TY_RETURN);

					this._recalcTransaction();
					if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().getCurrentMode() == Constants.TRAN_CURRENT_MODE_NORMAL){ 
						this.recalcTransDiscount(true);
					}
					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.refundItem');
				} 
			},

			recalcTransDiscount: function (skipDiscount) {
				var tranItem;
				var len = this.getTranItemsCount();
				var i = 0;
				var countForTotalDiscount = 0;
				var countForCanceledDiscount = 0;
				var countForVoidTransactionTotal = 0;
				var discountItem = null;
				while (i < len) {
					tranItem = this.getTranItemByIdx(i);
					if (tranItem.getItemType() == Constants.ITEM_TY_VOID_DISCOUNT_TXN) {
						countForVoidTransactionTotal++;
					}
					// check for item is tranDiscount and not void
					if (tranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN) {
						countForTotalDiscount++;
						discountItem = tranItem;
					}
					if (tranItem.getItemType() == Constants.ITEM_TY_VOID_DISCOUNT_RECALC_TXN) {
						countForCanceledDiscount++;
					}
					i = i + 1;
				}
				if (discountItem != null) {
					if (countForCanceledDiscount != 0 && countForCanceledDiscount == (countForTotalDiscount - countForVoidTransactionTotal)) {
						this.discountTransaction(discountItem.getDiscType(), discountItem.getDiscValue(), discountItem.getReasonCodeId(), discountItem.getReasonCodeDesc());
					} else if (countForCanceledDiscount < (countForTotalDiscount - countForVoidTransactionTotal)) {
						this.voidDiscountTransaction(discountItem.getItemIdx(), discountItem.getDiscType(), -discountItem.getDiscValue(), "0000", Constants.ITEM_TY_VOID_DISCOUNT_RECALC_TXN);
						if (skipDiscount)
							this.discountTransaction(discountItem.getDiscType(), discountItem.getDiscValue(), discountItem.getReasonCodeId(), discountItem.getReasonCodeDesc());
					}
				}
			},

			noSale: function (reasonCode, reasonDesc) {
				try {
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_NO_SALE);
					tranItem.setReasonCodeId(reasonCode);
					tranItem.setReasonCodeDesc(reasonDesc);

					tranItem = this.addItemToTransaction(tranItem);

					this.setTranTypeId(Constants.TX_TY_NO_SALE);

					this._recalcTransaction(true);

					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.noSale');
				}
			},

			addManagerOverride: function (userName,refItemIdx) {
				try {
					
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);
					tranItem.setItemType(Constants.ITEM_TY_MGR_OVERRIDE);
					tranItem = this.addItemToTransaction(tranItem);
					tranItem.setReasonCodeId(userName);
					if(refItemIdx != null && refItemIdx != undefined){
						tranItem.setRefItemIdx(refItemIdx);
					}
					
					this._recalcTransaction(true);

					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.managerOverride');
				}
			},
			
			overrideItemPrice: function (tranItemIdx, newUnitPrice, reasonCodeId, reasonCodeDesc, competitorName, isVATIncluded) {
				try {
					var refTranItem = this.getTranItemByIdx(tranItemIdx);
					if (tranItemIdx != null && refTranItem != null) {
						// Create tranItem and add to transaction
						var overridePriceTranItem = new TransactionItem();
						overridePriceTranItem.setTranId(this._id);

						overridePriceTranItem.setItemType(Constants.ITEM_TY_PRICE_CHANGE);
						overridePriceTranItem.setRefItemIdx(tranItemIdx);
						overridePriceTranItem.setNewPrice(newUnitPrice);
						overridePriceTranItem.setReasonCodeId(reasonCodeId);
						overridePriceTranItem.setReasonCodeDesc(reasonCodeDesc); 
						var tenderDetails = { 
								isVATIncluded: isVATIncluded,
								newUnitPrice: newUnitPrice,
								priceChangeApplied:  (refTranItem.getCalcAmount()-newUnitPrice).toFixed(2)
							};
						if(competitorName != null && competitorName != undefined){
							tenderDetails.competitorName = competitorName;
						}

						overridePriceTranItem.setTenderDetails(tenderDetails); 
						// Add to transaction
						overridePriceTranItem = this.addItemToTransaction(overridePriceTranItem);
						var itemfromHistory = this.getSpecificItemHistory(tranItemIdx);
						if (itemfromHistory != null) {
							itemfromHistory.calcUnitPrice = newUnitPrice;
							itemfromHistory.isLocked = true;
							itemfromHistory.history.push({
								itemIdxKey: overridePriceTranItem.getItemIdx()
							});
						}
						refTranItem.setCalcAmount(newUnitPrice);
						refTranItem.setIsPriceOverridable("0");
						if(isVATIncluded != undefined && isVATIncluded != null && isVATIncluded == false){
							var taxArray = refTranItem.getProduct().getTaxRates();
 							_.forEach(taxArray, function(value, key) {
 								if(value.getIsVAT()){
 									//value._oldPercent = value.getPercentage();
 									//value.setPercentage(0);
 									value.setIsVAT(2);
 								} 
							});
							refTranItem.getProduct().setTaxRates(taxArray);
						}


						this._recalcTransaction();
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.overrideItemPrice');
				}
			},
			
			addBulkItemPrice: function (tranItemIdx, newUnitPrice, alertMsg, shouldCallRecalc) {
				try {
					var refTranItem = this.getTranItemByIdx(tranItemIdx);
					var tranItems = this.getTranItems();
					var isAlreadyUpdated;
					
					if (tranItemIdx != null && refTranItem != null) {
						//if the item already has a BBAS item to it, then change the 
						//reasoncode to that BBAS item. Else create BBAS item.
						var itemfromHistory = this.getSpecificItemHistory(tranItemIdx);
						
						_.forEach(tranItems, function (tranItem) {
							if(tranItem.getRefItemIdx() == tranItemIdx && tranItem.getItemType() == Constants.ITEM_TY_BBAS){
								
								if(alertMsg != ""){
									var bbasJSON = {
											origPrice: refTranItem.calcUnitPrice,
											bbasPrice: newUnitPrice,
											isBBAS: true
										};
									refTranItem.setTenderDetails(bbasJSON);
								}
								else{
									var bbasJSON = {
											origPrice: newUnitPrice,
											bbasPrice: newUnitPrice,
											isBBAS: false
										};
									refTranItem.setTenderDetails(bbasJSON);
								}
								
								refTranItem.setNewPrice(newUnitPrice);
								tranItem.setReasonCodeDesc(alertMsg);
								isAlreadyUpdated = true;
								
								if (itemfromHistory != null) {
									itemfromHistory.calcUnitPrice = newUnitPrice;
									itemfromHistory.isLocked = true;
									itemfromHistory.history.push({
										itemIdxKey: tranItem.getItemIdx()
									});
								}
							}
						});
						if(isAlreadyUpdated !== true){
							
							var bbasJSON = {
									origPrice: refTranItem.calcUnitPrice,
									bbasPrice: newUnitPrice,
									isBBAS: true
								};
							refTranItem.setTenderDetails(bbasJSON);
							
							// Create tranItem and add to transaction
							var bbasItem = new TransactionItem();
							bbasItem.setTranId(this._id);
							bbasItem.setItemType(Constants.ITEM_TY_BBAS);
							bbasItem.setRefItemIdx(tranItemIdx);
							if(alertMsg != undefined && alertMsg != null && alertMsg != ""){
								bbasItem.setReasonCodeDesc(alertMsg);
								// Add to transaction
								bbasItem = this.addItemToTransaction(bbasItem);
								if (itemfromHistory != null) {
									itemfromHistory.calcUnitPrice = newUnitPrice;
									itemfromHistory.isLocked = true;
									itemfromHistory.history.push({
										itemIdxKey: bbasItem.getItemIdx()
									});
								}
							}
						}
						
						refTranItem.setCalcAmount(newUnitPrice);
						if(shouldCallRecalc != undefined && shouldCallRecalc != null & shouldCallRecalc == true){
							this._recalcTransaction();
						}
						
					} else {
						throw util.ovcException('OVCException', 'Invalid Item No');
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addBulkItemPrice');
				}
			},
			
			applyCustomerTypeDiscount: function (customerType) {
				try {
					// Create tranItem and add to transaction
					var customerTypeDiscountTranItem = new TransactionItem();
					customerTypeDiscountTranItem.setTranId(this._id);// this.getId());

					customerTypeDiscountTranItem.setItemType(Constants.ITEM_TY_CUSTOMER_TYPE);
					customerTypeDiscountTranItem.setReasonCodeId(customerType);

					// Add to transaction
					customerTypeDiscountTranItem = this.addItemToTransaction(customerTypeDiscountTranItem);

					this.setCustomerType(customerType);

					this._recalcTransaction();
				} catch (e) {
					throw util.rethrow(e, 'Transaction.applyCustomerTypeDiscount');
				}
			},

			postVoid: function (refTranId, reasonCode, isScanned) {
				try {
					if (isScanned == null) {
						isScanned = 0;
					}
					// Create tranItem and add to transaction
					var postVoidTranItem = new TransactionItem();
					postVoidTranItem.setTranId(this._id);// this.getId());

					postVoidTranItem.setItemType(Constants.ITEM_TY_POST_VOID);
					postVoidTranItem.setReasonCodeId(reasonCode);
					postVoidTranItem.setRefTranId(refTranId);
					postVoidTranItem.setIsScanned(isScanned);
					postVoidTranItem.setItemDate((new Date()).getTime());

					// Add to transaction
					postVoidTranItem = this.addItemToTransaction(postVoidTranItem);

					this.setTranTypeId(Constants.TX_TY_POSTVOID);

					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.postVoid');
				}
			},

			createStoreSpotCheckTranItem: function () {
				try {
					// Create tranItem and add to transaction
					var storeSpotCheckTranItem = new TransactionItem();
					storeSpotCheckTranItem.setTranId(this._id);// this.getId());

					storeSpotCheckTranItem.setItemType(Constants.ITEM_TY_CASH_STORE_SPOT_CHECK);

					// Add to transaction
					storeSpotCheckTranItem = this.addItemToTransaction(storeSpotCheckTranItem);

					this.setTranTypeId(Constants.TX_TY_STORE_SPOT_CHECK);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.createStoreSpotCheckTranItem');
				}
			},

			createTillSpotCheckTranItem: function () {
				try {
					// Create tranItem and add to transaction
					var tillSpotCheckTranItem = new TransactionItem();
					tillSpotCheckTranItem.setTranId(this._id);// this.getId());

					tillSpotCheckTranItem.setItemType(Constants.ITEM_TY_CASH_TILL_SPOT_CHECK);

					// Add to transaction
					tillSpotCheckTranItem = this.addItemToTransaction(tillSpotCheckTranItem);

					this.setTranTypeId(Constants.TX_TY_TILL_SPOT_CHECK);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.createTillSpotCheckTranItem');
				}
			},

			zRead: function () {
				try {
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);// this.getId());

					tranItem.setItemType(Constants.ITEM_TY_ZREAD);

					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					this.setTranTypeId(Constants.TX_TY_ZREAD);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.zRead');
				}
			},

			hasAnyItemAndNoTransDiscount: function () {
				try {
					var hasAnyTransactionDiscount = this.hasAnyTranDiscount();
					var atleastOneItemHasDiscount = true;
					if (!hasAnyTransactionDiscount) {
						atleastOneItemHasDiscount = this.hasAnyItemDiscount();
					}

					return (!hasAnyTransactionDiscount && atleastOneItemHasDiscount);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasAnyItemOrTransDiscount');
				}
			},

			hasItemDiscount: function (i) {
				var itemHasDiscount = false;
				var tranItem;
				var len = this.getTranItemsCount();
				tranItem = this.getTranItemByIdx(i);
				if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT) && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
					itemHasDiscount = true;
				} else if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_REFUND_PRODUCT)) {
					var discountAllowedForReturns = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').discountAllowedForReturns;
					if (discountAllowedForReturns == 1) {
						itemHasDiscount = true;
					}
				}
				if (itemHasDiscount && tranItem.getProduct() != null) {
					var propertiesJson = tranItem.getProduct().getProductJson();
					var maxNoOfDiscounts = 1;
					var isDiscountable = false;
					if (propertiesJson && propertiesJson != null &&
						propertiesJson.products && propertiesJson.products != null
					) {
						if (propertiesJson.products.maxNoOfDiscounts && propertiesJson.products.maxNoOfDiscounts != null) {
							maxNoOfDiscounts = parseInt(propertiesJson.products.maxNoOfDiscounts);
						}
						if (propertiesJson.products.isDiscountable != undefined &&
							propertiesJson.products.isDiscountable != null &&
							propertiesJson.products.isDiscountable != "0") {
							isDiscountable = true;
						}
					}

					if (isDiscountable && maxNoOfDiscounts != 0 && this.getTotalItemDiscountByIdx(i) < maxNoOfDiscounts) {
						itemHasDiscount = true;
					} else {
						itemHasDiscount = false;
					}
				}
				return itemHasDiscount;
			},

			hasAnyItemDiscount: function () {
				var atleastOneItemHasDiscount = false;
				var i = 0;
				var tranItem;
				var len = this.getTranItemsCount();
				while (i < len && !atleastOneItemHasDiscount) {
					atleastOneItemHasDiscount = this.hasItemDiscount(i);
					i++;
				}
				return atleastOneItemHasDiscount;
			},

			hasAnyTranDiscount: function () {
				try {
					var hasAnyDiscount = false;

					if (!hasAnyDiscount) {
						var tranItem;
						var len = this.getTranItemsCount();
						var i = 0;
						while (i < len && !hasAnyDiscount) {
							tranItem = this.getTranItemByIdx(i);
							// check for item is tranItem and not void
							if (tranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN && !this.isItemVoidByIdx(tranItem.getItemIdx()) && (tranItem.getHistory() == null || tranItem.getHistory().length == 0)) {
								hasAnyDiscount = true;
							}

							i = i + 1;
						}
					}

					return hasAnyDiscount;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasAnyDiscount');
				}
			},


			isGCItem: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					return (tranItem.getProduct()._productType && tranItem.getProduct()._productType == "GiftCertificate");
				} catch (e) {
					throw util.rethrow(e, 'Transaction.isGCItem');
				}
				return false;
			},

			hasGCOnly: function () {
				try {
					var len = this.getTranItemsCount();
					var i = 0;
					var prodCount = 0;
					var isGCFound = false;
					while (i < len) {
						tranItem = this.getTranItemByIdx(i);
						// check for item is tranItem and not void
						if (tranItem.getProduct() && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							prodCount++;
							if (tranItem.getProduct().getProductType() &&
								tranItem.getProduct().getProductType() == "GiftCertificate") {
								isGCFound = true;
							}
						}
						i = i + 1;
					}
					return (isGCFound && prodCount == 1);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasGCOnly');
				}
				return false;
			},
			
			getCurrentLoyaltyTranItem: function(){
				try {
					for(var i=0; i<this.getTranItemsCount(); i++){
						var tranItem = this.getTranItemByIdx(i);
						if(tranItem.getLoyaltyUser()!=null && tranItem.getItemType() == Constants.ITEM_TY_LOYALTY_ID 
								&& !this.isLoyaltyVoidByIdx(tranItem.getItemIdx())){
							return tranItem;
						}
					}
				}catch (e) {
					throw util.rethrow(e, 'Transaction.getCurrentLoyaltyTranItem');
				}
				return null;
			},
			
			setTaxExemptInfo: function(taxExemptInfo){
				if (this._isLocked()) {
					throw util.ovcException('OVCException', 'Transaction locked', ['Transaction.setTaxExemptInfo']);
				} else {
					this._loyaltyUser.taxExemptInfo = taxExemptInfo;
					var loyaltyUser = this.getCurrentLoyaltyTranItem().getLoyaltyUser();
					loyaltyUser.setTaxExemptInfo(taxExemptInfo);
					this._dirtyFlags[8] = true;
					this._recalcTransaction();
				}
			},
			
			hasItemTranDiscountAppliedByIdx: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					var hasTranDiscount = false;

					if (tranItem != null) {
						var itemHistory = this.getSpecificItemHistory(itemIdx);
						var i = 0;
						while (!hasTranDiscount && i < itemHistory.history.length) {
							var appliedTranItem = this.getTranItemByIdx(itemHistory.history[i].itemIdxKey);
							//if (appliedTranItem != undefined && appliedTranItem != null) {
							if (appliedTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN) {
								hasTranDiscount = true;
							}
							//}
							i = i + 1;
						}
					}

					return hasTranDiscount;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasItemTranDiscountAppliedByIdx');
				}
			},

			getTotalItemDiscountByIdx: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					var j = 0;
					if (tranItem != null) {
						var itemHistory = this.getSpecificItemHistory(itemIdx);
						var i = 0;
						while (i < itemHistory.history.length) {
							var appliedTranItem = this.getTranItemByIdx(itemHistory.history[i].itemIdxKey);
							if (appliedTranItem != undefined && appliedTranItem != null) {
								if ((appliedTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_ITEM &&
									(appliedTranItem.getHistory() == null || appliedTranItem.getHistory().length == 0))
									|| (appliedTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN && appliedTranItem.getRefItemIdx() == -1)) {
									j = j + 1;
								}
							}
							i = i + 1;
						}
					}

					return j;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasItemAnyDiscountAppliedByIdx');
				}
			},


			hasItemAnyDiscountAppliedByIdx: function (itemIdx) {
				try {
					var tranItem = this.getTranItemByIdx(itemIdx);
					var hasAnyDiscount = false;

					if (tranItem != null) {
						var itemHistory = this.getSpecificItemHistory(itemIdx);
						var i = 0;
						while (!hasAnyDiscount && i < itemHistory.history.length) {
							var appliedTranItem = this.getTranItemByIdx(itemHistory.history[i].itemIdxKey);
							//if(appliedTranItem != undefined && appliedTranItem != null){
							if ((appliedTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_ITEM && (appliedTranItem.getHistory() == null || appliedTranItem.getHistory().length == 0))
								|| (appliedTranItem.getItemType() == Constants.ITEM_TY_DISCOUNT_TXN && appliedTranItem.getRefItemIdx() == -1)) {
								hasAnyDiscount = true;
								break;
							}
							//}
							i = i + 1;
						}
					}

					return hasAnyDiscount;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasItemAnyDiscountAppliedByIdx');
				}
			},

			getTranTaxByTaxRateId: function () {

				var taxRatesById = {};
				var tranIems = this.getTranItems();

				for (var i = 0; i < tranIems.length; i++) {
					var tranItem = tranIems[i];
					if (tranItem.getProduct()) {
						var tranItemTaxRates = tranItem.getProduct().getTaxRates();

						if (tranItemTaxRates) {
							for (var j = 0; j < tranItemTaxRates.length; j++) {
								var tranItemTaxRate = tranItemTaxRates[j];

								var tranItemTaxRateJson;
								if (!taxRatesById[tranItemTaxRate.getTaxRateId()]) {
									tranItemTaxRateJson = tranItemTaxRate.toJson();
									delete tranItemTaxRateJson.taxAmount;
									tranItemTaxRateJson.totalTax = tranItemTaxRate.getTaxAmount();
									taxRatesById[tranItemTaxRate.getTaxRateId()] = tranItemTaxRateJson;
								}
								else {
									tranItemTaxRateJson = taxRatesById[tranItemTaxRate.getTaxRateId()];
									tranItemTaxRateJson.totalTax = parseFloat(tranItemTaxRateJson.totalTax) + parseFloat(tranItemTaxRate.getTaxAmount());
								}
							}
						}
					}
				}
				return taxRatesById;
			},
			getTotalLineItemsExceptDiscounts: function () {
				var totalLineItemsExceptDiscount = 0;
				try {
					var tranIems = this.getTranItems();
					for (var i = 0; i < tranIems.length; i++) {
						var tranItem = tranIems[i];
						if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT
							|| tranItem.getItemType() === Constants.ITEM_TY_REFUND_PRODUCT
							|| tranItem.getItemType() === Constants.ITEM_TY_GIFT_CARD_REFUND
							|| tranItem.getItemType() === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT
							|| tranItem.getItemType() === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT
							|| tranItem.getItemType() === Constants.ITEM_TY_APPOINTMENT
							|| tranItem.getItemType() === Constants.ITEM_TY_GIFT_CARD_SALE
							|| tranItem.getItemType() === Constants.ITEM_TY_GIFT_CARD_TOPUP
							|| tranItem.getItemType() === Constants.ITEM_TY_PAYIN_SALE
							|| tranItem.getItemType() === Constants.ITEM_TY_PAYIN_CORR_SALE
							|| tranItem.getItemType() === Constants.ITEM_TY_PAYOUT_SALE
							|| tranItem.getItemType() === Constants.ITEM_TY_PAYOUT_CORR_SALE) && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							totalLineItemsExceptDiscount++;
						}
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.getTotalLineItemsExceptDiscounts');
				}
				return totalLineItemsExceptDiscount;
			},

			getTotalFeeItemsCount: function () {
				var totalFeeItems = 0;
				try {
					var tranIems = this.getTranItems();
					for (var i = 0; i < tranIems.length; i++) {
						var tranItem = tranIems[i];
						if (tranItem != null
							&& !this.isItemVoidByIdx(tranItem.getItemIdx())
							&& (tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT &&
							(tranItem.getProduct().getProductType() && tranItem.getProduct().getProductType() != null && "Fees" == tranItem.getProduct().getProductType()))
						) {
							totalFeeItems++;
						}
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.totalFeeItems');
				}
				return totalFeeItems;
			},

			//Get if there are items in basket except ITEM_TY_REFUND_PRODUCT, ITEM_TY_ADD_SITE_PICKUP_PRODUCT, ITEM_TY_ADD_STORE_PICKUP_PRODUCT. This is to activate the transaction discount link in VR

			hasItemsCanHaveTranDiscount: function () {
				var hasValidItemsThatCanHaveTranDisc = false;
				;
				try {
					var tranIems = this.getTranItems();
					for (var i = 0; i < tranIems.length; i++) {
						var tranItem = tranIems[i];
						if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT) && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
							hasValidItemsThatCanHaveTranDisc = true;
							break;
						} else if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_REFUND_PRODUCT)) {
							var discountAllowedForReturns = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').discountAllowedForReturns;
							if (discountAllowedForReturns == 1) {
								hasValidItemsThatCanHaveTranDisc = true;
								break;
							}
						}
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.hasItemsCanHaveTranDiscount');
				}
				return hasValidItemsThatCanHaveTranDisc;
			},

			getTranTaxArrByTaxRateId: function () {
				var taxRatesArr = [];
				var taxRatesById = this.getTranTaxByTaxRateId();
				if (taxRatesById) {
					_.forEach(taxRatesById, function (taxRateId) {
						taxRatesArr.push(taxRatesById[taxRateId]);
					});
				}
				return taxRatesArr;
			},

			addItem: function (productObj, qty, isScanned, itemType /* optional */, refItemIdx /* optional */, expiryDays /* optional */) {
				try {
					if (isScanned == null) {
						isScanned = 0;
					}
					// Create tranItem and add to transaction
					var tranItem = new TransactionItem();
					tranItem.setTranId(this._id);// this.getId());

					// Set itemType if not passed in.
					itemType = typeof itemType !== 'undefined' ? itemType : Constants.ITEM_TY_ADD_PRODUCT;
					tranItem.setItemType(itemType);

					// set refItemIdx only for non-merchandise group products
					if (productObj.productType && (productObj.productType == "Fees" || productObj.productType == "Non-Merchandise")){
						tranItem.setRefItemIdx(refItemIdx);
					}

					if (productObj.productType == "GiftCertificate") {
						var date = new Date();
						date.setDate(date.getDate() + expiryDays);

						var tenderDetails = {
							giftCertificateNumber: GenericUtils.generate16DigitNumber()+"",
							expiryDate: date.toUTCString()
						};

						tranItem.setTenderDetails(tenderDetails);

					}
					var tranItemProd = this.convertToTranItemProduct(productObj, this._id, null, false);

					tranItem.setProduct(tranItemProd);
					tranItem.setProductId(productObj.id);
					tranItem.setSku(productObj.sku);
					var finalQty = qty;
					var propertiesJson = productObj["propertiesJson"];
					if (propertiesJson && propertiesJson != null && propertiesJson != "") {
						var Json = propertiesJson;
						if(typeof Json == "string"){
							Json = require('dojo/_base/json').fromJson(propertiesJson);
						}
						if (Json && Json != null) {
							var min = parseInt(Json.products.minimum);
							var allowZeroQtyOnVR = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").allowZeroQtyOnVR;
							var allowZeroQtyOnVRProduct = Json.products.allowZeroQtyOnVR;
							var isQuantityEditable = Json.products.isQuantityEditable;
							if(allowZeroQtyOnVRProduct !== undefined && allowZeroQtyOnVRProduct !== null){
								tranItem.setAllowZeroQtyOnVR(allowZeroQtyOnVRProduct);
							}
							if(isQuantityEditable !== undefined && isQuantityEditable !== null){
								tranItem.setIsQuantityEditable(isQuantityEditable);
							}
							if(qty === 0 && allowZeroQtyOnVR === 1 && allowZeroQtyOnVRProduct === '1'){
								finalQty = 0;
							} else if (min && min != null) {
								if (qty < min)
									finalQty = min;
							}
							if (itemType === Constants.ITEM_TY_ADD_PRODUCT || itemType === Constants.ITEM_TY_REFUND_PRODUCT || itemType === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
								itemType === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT) {
								var isPriceOverridable = Json.products.isPriceOverridable;
								if (typeof isPriceOverridable === 'undefined') {
									tranItem.setIsPriceOverridable("1");
								} else {
									tranItem.setIsPriceOverridable(isPriceOverridable);
								}
							}
						}
					}
					tranItem.setQty(finalQty);
					tranItem.setIsScanned(isScanned);
					var hasSalesPerson = false;
					if (typeof productObj.salesPerson != 'undefined' && productObj.salesPerson != null && productObj.salesPerson != 'null') { //Resuming a transaction may have a value for sales person

						if (typeof this.salesPersonBgColor === 'undefined' && productObj.salesPerson != '') {
							this.salesPersonBgColor = this.getSalesPersonBgColor();
						}
						tranItem.setSalesPerson(productObj.salesPerson);
						hasSalesPerson = true;
						this.salesPersonId = productObj.salesPerson;
					}
					if(productObj.parentProductIdx != undefined && productObj.parentProductIdx != -1){
						tranItem.setParentProductIdx(productObj.parentProductIdx);
					}
					
					if(productObj.cascadeVoidToParent != undefined && productObj.cascadeVoidToParent != -1){
						tranItem.setCascadeVoidToParent(productObj.cascadeVoidToParent);
					}
					if(productObj.cascadeVoid != undefined && productObj.cascadeVoid != -1){
						tranItem.setCascadeVoid(productObj.cascadeVoid);
					}
					if(productObj.cascadeQtyChangeToParent != undefined && productObj.cascadeQtyChangeToParent != -1){
						tranItem.setCascadeQtyChangeToParent(productObj.cascadeQtyChangeToParent);
					}
					if(productObj.cascadeQtyChange != undefined && productObj.cascadeQtyChange != -1){
						tranItem.setCascadeQtyChange(productObj.cascadeQtyChange);
					}
					if(productObj.baseQty != undefined && productObj.baseQty != -1){
						tranItem.setBaseQty(productObj.baseQty);
					}
					
					// Add to transaction
					tranItem = this.addItemToTransaction(tranItem);

					//If sales person is already present then add automatically without prompting
					if (!hasSalesPerson && typeof this.salesPersonId != 'undefined' && this.salesPersonId != null && this.salesPersonId != '' && tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT) {
						this.addSalesPerson(tranItem, this.salesPersonId);
					}

					// Add to itemsHistory
					this.createItemHistory(tranItem, productObj.price);
					this._recalcTransaction();
					if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().getCurrentMode() == Constants.TRAN_CURRENT_MODE_NORMAL){ 
						this.recalcTransDiscount(true);
					}
					return tranItem;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addItem');
				}
			},

			getUsedStoreCreditBalance: function () {

				var isStoreCreditAllowed = ConfigManager.getConfigObject("posMClient/app.ovccfg").isStoreCreditAllowed;
				var usedStoreCreditBalance = 0;
				if (isStoreCreditAllowed && isStoreCreditAllowed === 1 && this.getLoyaltyUser()) {
					var calculatedTranItems = this.getCalculatedTranItems();

					for (var i = 0; i < calculatedTranItems.length; i = i + 1) {
						var tenderId = calculatedTranItems[i].getTenderId();
						var tenderDetails = calculatedTranItems[i].getTenderDetails();
						if (tenderId != undefined && tenderId != null && parseInt(tenderId) === Constants.ITEM_TY_STORECREDIT_TENDER &&
							calculatedTranItems[i].getIsStoreCreditApplied() !== 1) {
							usedStoreCreditBalance += calculatedTranItems[i].getAmount();
						}
					}
				}
				return usedStoreCreditBalance;

			},

			discountTransaction: function (discType, discValue, reasonCodeId, reasonCodeDesc,employeeId) { 
				try {
					// Create tranItem and add to transaction
					var discountTranItem = new TransactionItem();
					discountTranItem.setTranId(this._id);

					discountTranItem.setItemType(Constants.ITEM_TY_DISCOUNT_TXN);
					discountTranItem.setDiscType(discType);
					discountTranItem.setDiscValue(discValue);
					discountTranItem.setReasonCodeId(reasonCodeId);
					discountTranItem.setReasonCodeDesc(reasonCodeDesc);

					// Add to transaction
					discountTranItem = this.addItemToTransaction(discountTranItem);
					var totalDiscountGranted = 0;

					// calculate
					var rowsInReceipt = 0;
					var itemsInTran = 0;
					var itemsInTranTotal = 0;
					var idxArr = this.getAllItemsHistoryIdxArray();
					for (var j = 0; j < idxArr.length; j = j + 1) {
						var itemIdx = idxArr[j];
						var tranItem = this.getTranItemByIdx(itemIdx);
						if (this.hasItemDiscount(itemIdx))
							itemsInTranTotal = itemsInTranTotal + tranItem.getQty() * this.getSpecificItemHistory(itemIdx).calcUnitPrice;
					}
					if (itemsInTranTotal <= 0) {
						if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().getCurrentMode() == Constants.TRAN_CURRENT_MODE_NORMAL){ 
							this.recalcTransDiscount(false);
						}
					}
					{
						var disCountedPrice = 0;
						var configPositionValue = ConfigManager.getConfigObject("posMClient/payment.ovccfg").overflowPositionForSplitDiscounts;
						if (discType == Constants.DISC_TYPE_AMOUNT) {
							var i = 0;
							var skipped = 0;
							var idxArr = this.getAllItemsHistoryIdxArray();
							var discountItem;
							for (var j = 0; j < idxArr.length; j = j + 1) {
								var itemIdx = idxArr[j];
								var tranItem = this.getTranItemByIdx(itemIdx);

								if (!this.hasItemDiscount(itemIdx)) {
									skipped++;
								} else if (!this.getSpecificItemHistory(itemIdx).isVoid) {
									this.getSpecificItemHistory(itemIdx).isLocked = true;
									this.getSpecificItemHistory(itemIdx).history.push({
										itemIdxKey: discountTranItem.getItemIdx(),
										calcAmount: discValue * this.getSpecificItemHistory(itemIdx).calcUnitPrice / itemsInTranTotal
									});


									disCountedPrice = this.getSpecificItemHistory(itemIdx).calcUnitPrice - discValue * this.getSpecificItemHistory(itemIdx).calcUnitPrice / itemsInTranTotal;
									totalDiscountGranted = totalDiscountGranted + tranItem.getQty() * Math.round((discValue * this.getSpecificItemHistory(itemIdx).calcUnitPrice / itemsInTranTotal) * 100) / 100;
									this.getSpecificItemHistory(itemIdx).calcUnitPrice = disCountedPrice;
									refTranItem = this.getTranItemByIdx(itemIdx);
									refTranItem.setCalcAmount(Math.round(disCountedPrice * 100) / 100);


									var position = 0;

									if (configPositionValue == "first" && j == skipped) {
										discountItem = refTranItem;
									} else if (configPositionValue == "last") {
										discountItem = refTranItem;
									}
									if (configPositionValue != null && j == idxArr.length - 1) {
										disCountedPrice = discountItem.getCalcAmount();
										if (discValue > totalDiscountGranted) {
											disCountedPrice -= Math.round(((discValue - totalDiscountGranted) * 1000) % 100) / 1000;
										} else if (discValue < totalDiscountGranted) {
											disCountedPrice += Math.round(((discValue - totalDiscountGranted) * 1000) % 100) / 1000;
										}
										discountItem.setCalcAmount(Math.round(disCountedPrice * 100) / 100);

									}

									if (i == rowsInReceipt - 1) {
										this.getSpecificItemHistory(itemIdx).addReason = true;
									}
									i = i + 1;
								}
							}
						} else if (discType == 2/* percent */) {
							var i = 0;
							var idxArr = this.getAllItemsHistoryIdxArray();
							for (var j = 0; j < idxArr.length; j = j + 1) {
								var itemIdx = idxArr[j];
								var tranItem = this.getTranItemByIdx(itemIdx);
								if (!this.getSpecificItemHistory(itemIdx).isVoid && this.hasItemDiscount(itemIdx)) {
									this.getSpecificItemHistory(itemIdx).isLocked = true;
									this.getSpecificItemHistory(itemIdx).history.push({
										itemIdxKey: discountTranItem.getItemIdx(),
										calcAmount: this.getSpecificItemHistory(itemIdx).calcUnitPrice * discValue / 100
									});
									disCountedPrice = this.getSpecificItemHistory(itemIdx).calcUnitPrice - (this.getSpecificItemHistory(itemIdx).calcUnitPrice * discValue / 100);
									totalDiscountGranted = totalDiscountGranted + tranItem.getQty() * Math.round((this.getSpecificItemHistory(itemIdx).calcUnitPrice * discValue / 100) * 100) / 100;
									this.getSpecificItemHistory(itemIdx).calcUnitPrice = disCountedPrice;
									refTranItem = this.getTranItemByIdx(itemIdx);
									refTranItem.setCalcAmount(Math.round(disCountedPrice * 100) / 100);

									if (i == rowsInReceipt - 1) {
										this.getSpecificItemHistory(itemIdx).addReason = true;
									}
									i = i + 1;
								}
							}
						}

						discountTranItem.setCalcAmount(totalDiscountGranted);
						if(employeeId != null && employeeId != ""){
							discountTranItem.setTenderDetails({
								propertiesJson : { 
													employeeId: employeeId,
												 } 
							});
						}
						this.updateItemToTransaction(discountTranItem);

						this._recalcTransaction();
					}
				} catch (e) {
					throw util.rethrow(e, 'Transaction.discountTransaction');
				}
			},
			
			whichDeliveryOptionPresent: function(){
				var hasValidItemsThathasDeliveryOption = null;
				var tranIems = this.getTranItems();
				for (var i = 0; i < tranIems.length; i++) {
					var tranItem = tranIems[i];
					if (tranItem != null && (tranItem.getItemType() === Constants.ITEM_TY_DELIVERY_OPTION || tranItem.getItemType() === Constants.ITEM_TY_STORE_COLLECT_OPTION) && tranItem.getRefItemIdx() != -1) {
						hasValidItemsThathasDeliveryOption = tranItem.getItemType();
						break;
					} 
				}
				return hasValidItemsThathasDeliveryOption;
			},
			 
			isItemTypePresent: function(type){
				var isItemTypePresent = false;
				var tranIems = this.getTranItems();
				for (var i = 0; i < tranIems.length; i++) {
					var tranItem = tranIems[i]; 
					if (tranItem != null && (tranItem.getItemType() === type) && tranItem.getRefItemIdx() != -1) {
						isItemTypePresent = true;
						break;
					} 
				}
				return isItemTypePresent;
			},
			
			hasAddProductsWithoutStoreCollectOption: function(){ 
				var hasAddProductsWithoutStoreCollect = false;
				var tranIems = this.getTranItems();
				for (var i = 0; i < tranIems.length; i++) {
					var tranItem = tranIems[i]; 
					if (tranItem != null && !this.isItemVoidByIdx(tranItem.getItemIdx())) {
						if(tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT){ 
							var addedTenderDetails = tranItem.getTenderDetails(); 
							if(addedTenderDetails == undefined || addedTenderDetails == null || addedTenderDetails.deliveryOptionSet != true){
								hasAddProductsWithoutStoreCollect = true;
								break;
							} 
						}
					} 
				}
				return hasAddProductsWithoutStoreCollect;
			},

			addDeliveryOptionException: function (data, refIdx) {
				try {
					//for (i in data.refItemIdx) {
					var shippingCost = parseFloat(data.refItemIdx[0].shippingCost);
					var deliveryOption = new TransactionItem();
 
					var refItemIndex = this._totalItems + 1;
					if (refIdx != undefined && refIdx != null) {
						refItemIndex = refIdx;
					}
					if(data.productObj && data.productObj!=null){
						var tranItemProd = this.convertToTranItemProduct(data.productObj, this._id, null, false);
						deliveryOption.setProduct(tranItemProd);
						deliveryOption.setSku(data.productObj.sku);
					}
 
					deliveryOption.setTranId(this._id);
					deliveryOption.setRefItemIdx(refItemIndex);
					deliveryOption.setAmount(shippingCost);
					deliveryOption.setQty(1);

					deliveryOption.setCalcAmount(shippingCost); 
					deliveryOption.setItemType(Constants.ITEM_TY_DELIVERY_OPTION);
					var tranAddProductItem = this.getTranItemByIdx(refItemIndex);
					deliveryOption.setTenderDetails({
						propertiesJson : {
							address: data.address,
							deliveryTime: data.deliveryTime,
							deliveryNotes: data.deliveryData
						}
					});

					this.addItemToTransaction(deliveryOption);
					this._deliveryOption = deliveryOption;
					//}
					this._recalcTransaction(true);
					return deliveryOption;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addDeliveryOption');
				}
			},


			addDeliveryOption: function (data, refIdx) {
				try {  
						var shippingCost = parseFloat(data.refItemIdx[0].shippingCost);
						var deliveryOption = new TransactionItem();
						
						var tranItemProd = this.convertToTranItemProduct(data.productObj, this._id, null, false);
						var refItemIndex = this._totalItems + 1;
						if (refIdx != undefined && refIdx != null) {
							refItemIndex = refIdx;
						}

						deliveryOption.setProduct(tranItemProd);
						deliveryOption.setTranId(this._id);
						deliveryOption.setRefItemIdx(refItemIndex);
						deliveryOption.setAmount(shippingCost);
						deliveryOption.setQty(1);

						deliveryOption.setCalcAmount(shippingCost);						
						deliveryOption.setSku(data.productObj.sku);
						deliveryOption.setItemType(Constants.ITEM_TY_DELIVERY_OPTION); 
						var tranAddProductItem = this.getTranItemByIdx(refItemIndex);
						deliveryOption.setTenderDetails({
							propertiesJson : {
												address: data.address,
												deliveryTime: data.deliveryTime,
												deliveryDate: data.deliveryDate,
												deliveryData: data.deliveryData
											 }
						});
						 
						this.addItemToTransaction(deliveryOption);
					this._deliveryOption = deliveryOption;
					this._recalcTransaction(true);
					return deliveryOption;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addDeliveryOption');
				}
			},

			addStoreCollectOption: function (data) {
				try {  
				
					var refItemIndex = "";  
					var skus = ""; 
					var self = this; 
					var deliveryOption = new TransactionItem();
					var lastRefIndex = data.lastRefIndex != null ? data.lastRefIndex : -1; 
					_.forEach(data.refItemIdx, function (refItemIdxItem, key) {
						if(key > 0){
							refItemIndex += ",";
							skus += ","; 
						} 
						if(data.lastRefIndex != -1){
							lastRefIndex = refItemIdxItem.refIdx;
						}
						refItemIndex += refItemIdxItem.refIdx; 
						var addedProductInTran = self.getTranItemByIdx(refItemIdxItem.refIdx);
						skus +=  addedProductInTran.getSku();
						var addedTenderDetails = addedProductInTran.getTenderDetails(); 
						if(addedTenderDetails && addedTenderDetails != null){
							addedTenderDetails.deliveryOptionSet = true;
						}else{
							addedTenderDetails = {deliveryOptionSet: true};
						}
						addedProductInTran.setTenderDetails(addedTenderDetails);
					}); 
					
					deliveryOption.setRefItemIdx(lastRefIndex);
					deliveryOption.setTranId(this._id);
					deliveryOption.setAmount(0);
					deliveryOption.setQty(1);
					
					deliveryOption.setCalcAmount(0); 
					deliveryOption.setItemType(data.type);   
					deliveryOption.setTenderDetails({
						propertiesJson : { 
											address: data.address,
											deliveryDate: data.deliveryTime,
											refItemIndices: refItemIndex,
											skus : skus
										 } 
					});
					 
					this.addItemToTransaction(deliveryOption); 
					this._recalcTransaction(true);
					return deliveryOption;
				} catch (e) {
					throw util.rethrow(e, 'Transaction.addDeliveryOption');
				}
			},

			// Voiding transaction discount
			voidDiscountTransaction: function (refItemIdx, discType, discValue, reasonCodeId, itemType) {
				try {
					// 
					// Create tranItem and add to transaction
					var voidDiscountTranItem = new TransactionItem();
					voidDiscountTranItem.setTranId(this._id);

					voidDiscountTranItem.setItemType(itemType);
					voidDiscountTranItem.setRefItemIdx(refItemIdx);
					voidDiscountTranItem.setReasonCodeId(reasonCodeId);
					voidDiscountTranItem = this.addItemToTransaction(voidDiscountTranItem);
					var discountAllowedForReturns = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').discountAllowedForReturns;//Sar

					var tranDiscItem = this.getTranItemByIdx(refItemIdx);
					if (tranDiscItem != null) {
						//This value is set to track that "discount transaction item" is voided. We use this value while building the receipt object to check if a "discount transaction item" is voided or not.
						//Usually this value is -1 for "discount transaction item" that are not voided.
						tranDiscItem.setRefItemIdx(voidDiscountTranItem.getItemIdx());
					}

					var rowsInReceipt = 0;

					var idxArr = this.getAllItemsHistoryIdxArray();
					for (var j = 0; j < idxArr.length; j = j + 1) {
						var itemIdx = idxArr[j];
						if (!this.getSpecificItemHistory(itemIdx).isVoid) {
							rowsInReceipt = rowsInReceipt + 1;
						}
					}

					var disCountedPrice = 0;
					var configPositionValue = ConfigManager.getConfigObject("posMClient/payment.ovccfg").overflowPositionForSplitDiscounts;
					if (discType == Constants.DISC_TYPE_AMOUNT || discType == 2) {
						var i = 0;
						var idxArr = this.getAllItemsHistoryIdxArray();
						for (var j = 0; j < idxArr.length; j = j + 1) {
							var itemIdx = idxArr[j];
							var tranItem = this.getTranItemByIdx(itemIdx);

							if (this.getTranItemByIdx(itemIdx) != null) {

								if (this.getTranItemByIdx(itemIdx).getItemType() == Constants.ITEM_TY_REFUND_PRODUCT ||
									this.getTranItemByIdx(itemIdx).getItemType() == Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT ||
									this.getTranItemByIdx(itemIdx).getItemType() == Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT || this.isGCItem(itemIdx)) {
									continue;
								} else if (this.getTranItemByIdx(itemIdx).getItemType() == Constants.ITEM_TY_REFUND_PRODUCT) {
									if (discountAllowedForReturns == 0) {
										continue;
									}
								}

								if (!this.getSpecificItemHistory(itemIdx).isVoid) {
									this.getSpecificItemHistory(itemIdx).isLocked = true;
									this.getSpecificItemHistory(itemIdx).history.push({
										itemIdxKey: voidDiscountTranItem.getItemIdx()
									});

									//Go through the history of each item and identify calcAmount corresponding to the selected transaction discount(voided through this method) using the index
									var appliedTransactionDiscount = 0;
									if (this.getSpecificItemHistory(itemIdx).history) {
										for (var k = 0; k < this.getSpecificItemHistory(itemIdx).history.length; k++) {
											if (this.getSpecificItemHistory(itemIdx).history[k].itemIdxKey === refItemIdx) {
												appliedTransactionDiscount = this.getSpecificItemHistory(itemIdx).history[k].calcAmount;
											}
										}
									}
									disCountedPrice = parseFloat(this.getSpecificItemHistory(itemIdx).calcUnitPrice) + appliedTransactionDiscount;

									this.getSpecificItemHistory(itemIdx).calcUnitPrice = disCountedPrice;
									refTranItem = this.getTranItemByIdx(itemIdx);
									refTranItem.setCalcAmount(disCountedPrice);

									if (i == rowsInReceipt - 1) {
										this.getSpecificItemHistory(itemIdx).addReason = true;
									}
									i = i + 1;
								}
							}
						}
					}

					this.updateItemToTransaction(voidDiscountTranItem);
					this._recalcTransaction(true);
				} catch (e) {
					throw util.rethrow(e, 'Transaction.voidDiscountTranItem');
				}
			}


		});
	});

