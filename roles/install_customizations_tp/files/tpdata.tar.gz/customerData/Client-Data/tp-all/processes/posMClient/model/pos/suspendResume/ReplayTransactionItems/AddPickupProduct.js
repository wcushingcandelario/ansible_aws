return { 
	"isScanned": processMem.current.isScanned,
	"productId": processMem.current.productId,
	"pickupBasePrice": inputParams.resultSet[0].pickupBasePrice,
	"pickupTotalPrice": inputParams.resultSet[0].pickupTotalPrice,
	"pickupQuantity": inputParams.resultSet[0].pickupQuantity,
	"pickupOrderId": inputParams.resultSet[0].pickupOrderId,
	"pickupId": inputParams.resultSet[0].pickupId
};