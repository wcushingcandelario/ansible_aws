var reasonCodeId = processMem.current.reasonCodeId;
if(reasonCodeId.indexOf(",") != -1){
	reasonCodeId = reasonCodeId.split(',')[0];
} 
return { "sqlQuery": "select description from reason_code_tbl where id=?",
         "paramsArr": [reasonCodeId] };