var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var reasonCodeDesc = "Gift Card";

var isTopUp = false;
if(inputParams.switchId == require("generic/Constants").ITEM_TY_GIFT_CARD_TOPUP){
	isTopUp = true;
}

tranObj.addGiftCardSale(processMem.current.reasonCodeId, parseFloat(processMem.current.amount), 
						processMem.current.itemDate, reasonCodeDesc, isTopUp);
