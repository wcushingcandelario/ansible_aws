var suspendedTranId = processMem.inputParams.tranId;
return { 
	"tranId": suspendedTranId
};