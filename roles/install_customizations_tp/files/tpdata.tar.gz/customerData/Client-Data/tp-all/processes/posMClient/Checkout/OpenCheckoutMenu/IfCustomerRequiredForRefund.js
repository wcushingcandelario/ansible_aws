var deferred = new Deferred();

var isQuote = (inputParams.isQuote != 'null' && inputParams.isQuote != undefined) ? inputParams.isQuote : false; 

require(['posmclient/RetailTransactionHelper', 'generic/Constants', 'ovc/ConfigManager'],
	function (RetailTransactionHelper, Constants, ConfigManager) {
	checkIfCustomerReqForRefund(RetailTransactionHelper, Constants, ConfigManager, isQuote);
		
});

function checkIfCustomerReqForRefund(RetailTransactionHelper, Constants, ConfigManager, isQuote) {
	var condition = false;
	var tranObj = RetailTransactionHelper.getCurrentTranObj();
	// if return transaction, if config turned on to require customer, and if customer already not added, bring up 
	// customer lookup page.
	var isCustomerRequiredForReturn = ConfigManager.getConfigObject("posMClient/pos.ovccfg").isCustomerRequiredForReturn;
	
	if(isQuote){
		if(tranObj.getLoyaltyUser() == null){
				condition = true;
		}
	}else{
		if(tranObj.getTranTypeId() == Constants.TX_TY_RETURN
			&& isCustomerRequiredForReturn != undefined && isCustomerRequiredForReturn == 1
			&& tranObj.getLoyaltyUser() == null){
				//condition = true;
			condition = checkIfCustomerPOPReq(RetailTransactionHelper);
		}
	}	
	
	deferred.resolve({condition: condition});
}

function checkIfCustomerPOPReq(RetailTransactionHelper){
	var conditions = false;
	var allTranItems = RetailTransactionHelper._currentTranObj._receiptJSON.allItems;
	var lenTran = allTranItems.length;
	for(var i = 0; i < lenTran; i++){
		if(allTranItems[i].reasonCode != null && allTranItems[i].reasonCode != undefined && allTranItems[i].reasonCode != ''){
			if(!allTranItems[i].isVoid){
				conditions = true;
			}
		}
	}
	return conditions;
}

return deferred.promise;