var deferred = new Deferred();
require(["generic/StringUtils"], buildData);
function buildData(StringUtils) {
	var uObj = localStorage.getObject(username);
	var receiptHeading = "";
	if (processMem.inputParams.receiptType == "duplicate"){
		receiptHeading = require("generic/ResourceManager").getValue("printReceipt.duplicate");
	}
	else if (processMem.inputParams.receiptType == "" ){
		processMem.inputParams.receiptType = "regular";
	}
	var storeCreditBalance;
	if(inputParams.response)
		storeCreditBalance = inputParams.response.balance;
	
	//Start: Code  for Store Credit receipt
	var oldStoreCreditBalance = 0;
	var usedStoreCreditBalance = 0;
	var transactionObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
	
	var storeCreditTranTypeId = require("generic/Constants").TX_TY_UPDATE_STORECREDIT;
	if((transactionObj.getTranTypeId()  == storeCreditTranTypeId)&& transactionObj.getLoyaltyUser() && transactionObj.getLoyaltyUser().storeCreditBalance){
		oldStoreCreditBalance = transactionObj.getLoyaltyUser().storeCreditBalance;
		
		var calculatedTranItems = transactionObj.getCalculatedTranItems();
		var usedStoreCredit = 0;
		for (var i = 0; i < calculatedTranItems.length; i = i + 1) {
			if (calculatedTranItems[i].getItemType() == require("generic/Constants").ITEM_TY_STORECREDIT_TENDER) {
				usedStoreCredit += calculatedTranItems[i].getAmount();
			}
		}
		
		usedStoreCreditBalance 	= usedStoreCredit;
		oldStoreCreditBalance  	= storeCreditBalance;
		storeCreditBalance 		= storeCreditBalance - usedStoreCredit;
		
		processMem.receiptObj.firstName 	=	 transactionObj.getLoyaltyUser().loyaltyFName;
		processMem.receiptObj.lastName 	= 	 transactionObj.getLoyaltyUser().loyaltyLName;

	}
	//End:  Code  for Store Credit receipt	//dateString: locale.format(new Date(), { formatLength : "short" }),
	var paramsMap = {
			receiptObj: processMem.receiptObj,
			storeAddress: localStorage.getObject("location"),
			dateString: StringUtils.getLocaleDateFormat(),
			employee: uObj.firstName + " " + uObj.lastName,
			receiptHeading: receiptHeading,
			storeCreditBalance: storeCreditBalance,
			usedStoreCreditBalance: usedStoreCreditBalance,
			oldStoreCreditBalance: oldStoreCreditBalance,
			receiptType: processMem.inputParams.receiptType
		};
	
	console.log(paramsMap);
	deferred.resolve({
		templateSrc: processMem.template,
		paramsMap: paramsMap
	});
}

return deferred.promise;
