if(_.isFinite(processMem.inputParams.price)){
	inputParams.productObj.price = processMem.inputParams.price;
	if(processMem.inputParams.splitItems === true) {
		if (processMem.inputParams.itemQty !== processMem.inputParams.quantity) {
			inputParams.productObj.price = 0;
		}
	}

}
inputParams.productObj.promoId = processMem.inputParams.promoId;
inputParams.productObj.taxRates = processMem.inputParams.taxRates;
return {
	"isScanned": processMem.inputParams.isScanned,
	"splitItems": processMem.inputParams.splitItems,
	"productObj": inputParams.productObj,
	"quantity": processMem.inputParams.quantity,
	"reasonCode": processMem.inputParams.reasonCode,
	"origTranId": processMem.inputParams.origTranId,
	"origTranTenderDetails": processMem.inputParams.tenderDetails,
		 "reasonCodeDesc": processMem.inputParams.reasonCodeDesc,
		 "adjustmentDetails": processMem.inputParams.adjustmentDetails,
		 "adjustmentSummary": processMem.inputParams.adjustmentSummary,
		 "refTranItemIdx": processMem.inputParams.refTranItemIdx
};