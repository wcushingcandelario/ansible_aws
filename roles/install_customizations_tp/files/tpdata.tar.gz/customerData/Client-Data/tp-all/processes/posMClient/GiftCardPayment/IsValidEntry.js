var condition = true;
var ResourceManager = require("generic/ResourceManager");
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

processMem.giftCardAmount = inputParams.value.txtAmount;
processMem.giftCardSerialNumber = inputParams.value.txtSerialNumber;
processMem.inputParams.tenderDetails.giftCardSerialNumber = processMem.giftCardSerialNumber;

if(isNaN(inputParams.value.txtAmount) || (currentTranObj.getBalance() >= 0 && parseFloat(inputParams.value.txtAmount) < 0)){
	processMem.alertUser = ResourceManager.getValue("giftCard.enterValidAmount");
	condition = false;
}
else if(currentTranObj.getBalance() < 0 && parseFloat(inputParams.value.txtAmount) < currentTranObj.getBalance()){
	processMem.alertUser = ResourceManager.getValue("giftCard.amountMoreThanBalance");
	condition = false;
}
else if(currentTranObj.getBalance() > 0 && parseFloat(inputParams.value.txtAmount) > currentTranObj.getBalance()){
	processMem.alertUser = ResourceManager.getValue("giftCard.amountMoreThanBalance");
	condition = false;
}


return {condition: condition};