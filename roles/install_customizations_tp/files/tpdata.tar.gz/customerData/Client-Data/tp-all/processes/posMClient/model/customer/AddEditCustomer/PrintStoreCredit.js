return {
	loyaltyId : processMem.inputParams.customerDetails.loyaltyId,
	firstName : processMem.inputParams.customerDetails.firstName,
	lastName : processMem.inputParams.customerDetails.lastName,
	balance : processMem.storeCreditBalance
};
