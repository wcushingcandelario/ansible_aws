return { giftCardItems: processMem.giftCardItems
		};