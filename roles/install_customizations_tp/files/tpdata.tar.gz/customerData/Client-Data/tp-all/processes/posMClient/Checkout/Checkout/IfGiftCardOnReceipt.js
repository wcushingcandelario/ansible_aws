processMem.tranObjToFinishTran = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var tranItems = processMem.tranObjToFinishTran.getReceiptJSON().nonVoidItems;
var condition = false;
var giftCardItems = [];

for(var i=0; i<tranItems.length; i++){
	if(tranItems[i].itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_SALE ||
		tranItems[i].itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_TOPUP){
		condition = true;
		giftCardItems.push(tranItems[i]);
	}
}

processMem.giftCardItems = giftCardItems;

var gcAdj = _.find(processMem.tranObjToFinishTran.getTranItems(), function(obj) {
	return obj.getItemType() == require("generic/Constants").ITEM_TY_GIFT_CARD_ADJ 
});

if(gcAdj != undefined && gcAdj != null){
	// If gift card adjustment, then the card is faulty or partly topped up.
	// do not send the same card to savvy again, return the customer the 
	// adjustment amount.
	condition = false;
}

return {condition: condition};
