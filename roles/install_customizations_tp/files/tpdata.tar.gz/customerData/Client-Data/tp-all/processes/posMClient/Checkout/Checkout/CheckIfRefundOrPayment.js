// Save the output params from PromptForAmount
processMem.amount = inputParams.amount;
processMem.changeAmt = inputParams.changeAmt;
processMem.penniesRounded = inputParams.penniesRounded;

// Set up condition to check if this transaction is a refund.
return { condition : (processMem.balance < 0) };
