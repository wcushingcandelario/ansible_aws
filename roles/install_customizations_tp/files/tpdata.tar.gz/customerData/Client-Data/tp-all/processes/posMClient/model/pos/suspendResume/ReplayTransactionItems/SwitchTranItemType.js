processMem.current = inputParams.current;
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
if(processMem.inputParams.tranTypeId && processMem.inputParams.tranTypeId != null){
	currentTranObj.setTranTypeId(processMem.inputParams.tranTypeId);
}

processMem.tenderReasonCode = null;
if(currentTranObj.getLayawayJSON() && currentTranObj.getLayawayJSON()!=null){
	if(currentTranObj.getLayawayJSON().deposit > 0 && currentTranObj.getTendersSum() < currentTranObj.getLayawayJSON().deposit){
		processMem.tenderReasonCode = "deposit";
	}
}

return { "switchCase": processMem.current.itemType };
