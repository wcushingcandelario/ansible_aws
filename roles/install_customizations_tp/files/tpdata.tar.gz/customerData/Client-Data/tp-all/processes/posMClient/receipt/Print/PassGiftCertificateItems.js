return { giftCertificateItems: processMem.giftCertificateItems,
		 receiptObj: processMem.receiptObj
};