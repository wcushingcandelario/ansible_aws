processMem.quoteTranId = inputParams.tranId;
processMem.quoteResultSet = inputParams.tranItems;

return {
	condition: (inputParams.tranId != null)
};