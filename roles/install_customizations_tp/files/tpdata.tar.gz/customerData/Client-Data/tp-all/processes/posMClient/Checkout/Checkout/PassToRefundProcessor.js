var tenderType = processMem.tenderDetails.tenderType;
var processName = "posMClient/Checkout/Refund" + tenderType.charAt(0).toUpperCase() + tenderType.substr(1) + ".ovcprc";
var amount = processMem.amount;

if(processMem.tenderDetails.id == "giftCard"){
	processName = "posMClient/GiftCardPayment.ovcprc"
	processMem.tenderDetails.giftCardRequestId = require("dojox/uuid/generateRandomUuid")();
	if(processMem.giftCardAmount == null || processMem.giftCardAmount == undefined){
		processMem.giftCardAmount = parseFloat(0);
	}
	
	if(processMem.amount != null && processMem.amount != undefined){
		processMem.giftCardAmount += parseFloat(processMem.amount);
	}
	else if(processMem.balance != null && processMem.balance != undefined){
		processMem.giftCardAmount += parseFloat(processMem.balance);
	}
	
	amount = processMem.giftCardAmount;
}

return {
	id : processName,
	processInputParams : {
		balance : processMem.balance,
		amount : amount,
		changeAmt : processMem.changeAmt,
		tenderDetails : processMem.tenderDetails
	}
};
