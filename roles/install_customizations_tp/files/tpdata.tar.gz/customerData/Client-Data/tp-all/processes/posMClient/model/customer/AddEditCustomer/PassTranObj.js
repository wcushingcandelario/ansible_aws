 //In PassTranObj of AddEditCustomer.
var clickableImage = require("dojo/dom").byId("headingLogoLeft");
require("dijit/registry").byId(clickableImage.activeView).performTransition("posView", -1, "slidev");
clickableImage.activeView = "posView";

var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

var storeCredittranTypeId = require("generic/Constants").TX_TY_UPDATE_STORECREDIT;
var itemDate = require("dojo/date/locale").format(new Date(currentTranObj.getTranTimestamp()), {
	selector: "date",
	datePattern: 'yyyy-MM-dd HH:mm:ss.SSS'
});

//currentTranObj.addStoreCreditTender(processMem.amount,processMem.itemDate);
//currentTranObj.addStoreCreditTender(-processMem.amount,(new Date()).getTime());

//Tenders have been abstracted. This method of adding storecredit is not the ideal process and should be changed in the future.
//The if else clause below is used to figure out the actual type of tender storeCredit is and to add it to the current transaction.
var tenderDetails = inputParams.resultSet[0];

if (tenderDetails.tenderType == "physical") {
	currentTranObj.addPhysicalTender(
			-processMem.amount,
		    inputParams.itemDate,
		    tenderDetails,
		    require("generic/Constants").ITEM_TY_STORECREDIT_TENDER+""
		);
   }
else if(tenderDetails.tenderType == "electronicInternal") {
	currentTranObj.addElectronicInternalTender(
			-processMem.amount,
		    inputParams.itemDate,
		    tenderDetails,
		    require("generic/Constants").ITEM_TY_STORECREDIT_TENDER+""
		);
}
else if(tenderDetails.tenderType == "electronicIntegrated") {
	currentTranObj.addElectronicIntegratedTender(
			-processMem.amount,
		    inputParams.itemDate,
		    tenderDetails,
		    require("generic/Constants").ITEM_TY_STORECREDIT_TENDER+""
		);
	
}
else if(tenderDetails.tenderTyp == "electronicExternal") {
	currentTranObj.addElectronicExternalTender(
			-processMem.amount,
		    inputParams.itemDate,
		    tenderDetails,
		    require("generic/Constants").ITEM_TY_STORECREDIT_TENDER+""
		);
}




  
var customerDetail = processMem.inputParams.customerDetails; 
currentTranObj.setLoyaltyId(customerDetail["loyaltyId"], customerDetail["firstName"], 
							customerDetail["lastName"], 
							customerDetail["email"], 
							customerDetail["numberOfLayaways"], 
							processMem.storeCreditBalance, "", customerDetail["mobilePhone"], {});

//require("posmclient/RetailTransactionHelper").getCurrentTranObj().setLoyaltyId(inputParams.loyaltyId, inputParams.loyaltyFName, inputParams.loyaltyLName, inputParams.loyaltyEmail, inputParams.numberOfLayaways,inputParams.storeCreditBalance, inputParams.arAccountNumber, inputParams.phone,inputParams.taxId);

currentTranObj.setTranTypeId(storeCredittranTypeId);
return {
    tranObj: currentTranObj,
    fromMainMenu:true
};