var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
tranObj.customerDetails = processMem.inputParams.customerDetails;
return {};
