return {
	sqlQuery: "SELECT tenderType, description, propertiesJson FROM tender_type_tbl WHERE id = ?",
	paramsArr: [processMem.inputParams.tenderType]
};
