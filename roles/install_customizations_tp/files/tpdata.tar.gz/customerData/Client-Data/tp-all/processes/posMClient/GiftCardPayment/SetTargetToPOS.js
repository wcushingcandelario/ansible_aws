var response = null;
if(inputParams.response && inputParams.response.response){
	response = JSON.parse(inputParams.response.response);
	processMem.returnData.push(response);
}

if(response == undefined || response == null){
	processMem.tenderSuccessful = false;
}
else if(response.errorCode != '0' && response.errorCode != '00'){ //0 or 00 is OK.
	processMem.tenderSuccessful = false;
}
else{
	processMem.tenderSuccessful = true;
}

require("ovc/UI").hideBlocker();
if(dijit.byId('txtSerialNumber')){
	dijit.byId('txtSerialNumber').destroy();
}
return { page: 'pos' };