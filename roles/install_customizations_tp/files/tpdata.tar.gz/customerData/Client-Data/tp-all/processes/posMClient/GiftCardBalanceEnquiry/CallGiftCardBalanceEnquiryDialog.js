var res = require("generic/ResourceManager");
var formControlsArray = [
	               {"type": "TextBox",
	            	"id": "txtSerialNumberEnquiry",
	            	"name": "txtSerialNumberEnquiry",
	            	"label": res.getValue("giftCard.pleaseScan"),
	            	"value": processMem.serialNumber || "",
	            	"options": { "placeHolder": "Serial Number", "required": true}
	               }
               ];

return {
			formControlsArray: formControlsArray,
			dialogTitle: res.getValue("giftCard.balanceEnquiry"),
			doLbl: res.getValue("pos.yesBtnLabel"),
			cancelLbl: res.getValue("pos.noBtnLabel")
		};