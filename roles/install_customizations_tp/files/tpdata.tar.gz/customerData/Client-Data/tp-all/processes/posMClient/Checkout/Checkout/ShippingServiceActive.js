var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();


var active = false;
//TODO
//Removing call to DayOfChoice service during checkout since not needed for SingleStorePilot for TP.
//Need to revisit once pilot goes through.
/*
if (tranObj._deliveryOption && tranObj._deliveryOption != null) {
	var props = tranObj._deliveryOption._tenderDetails.propertiesJson;

	if (props.deliveryData && props.deliveryData != null) {
		active = true;
	}
}
*/

return {
	condition: active
};