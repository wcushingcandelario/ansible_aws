var resultMap = processMem.resultMap;

if (inputParams.response != null) {
	var resultList = inputParams.response.resultSet;
	if (resultList != null) {
		for (var i=0; i<resultList.length; i=i+1) {
			resultMap[resultList[i].id] = resultList[i];
		}
	}
}

var resultSet = [];
_.forEach(resultMap, function (value,key) {
	resultSet.push(resultMap[key]);
});

return { "resultSet": resultSet };