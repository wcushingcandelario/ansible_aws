var tenderDetails = processMem.current.tenderDetails;
if(typeof tenderDetails == "string"){
	tenderDetails = require('dojo/_base/json').fromJson(tenderDetails);
}

return {
	"itemDate": processMem.current.itemDate,
	"tenderId": processMem.current.tenderId,
	"tenderDetails": tenderDetails,
	"amount": -(processMem.current.amount)
};