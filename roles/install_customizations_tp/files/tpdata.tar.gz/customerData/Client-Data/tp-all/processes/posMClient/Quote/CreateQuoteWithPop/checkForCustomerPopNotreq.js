
	var needCustomer = inputParams.needCustomer ? inputParams.needCustomer : false;
	var showInventoryStatusPop = inputParams.showInventoryStatusPop ? inputParams.showInventoryStatusPop : false;
	
	processMem.skipCustomerValidation = inputParams.skipCustomerValidation;
	var noCustomer = needCustomer;  
	if(needCustomer){
		var loyaltyId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getLoyaltyId();
		if(loyaltyId === null || loyaltyId === '') {
			noCustomer = true;
		}else{
			noCustomer = false;
		};
		processMem.loyaltyId = loyaltyId;
	}
return { condition : noCustomer };