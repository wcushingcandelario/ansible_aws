localStorage.setObject("returnData", null);
localStorage.setObject("giftCardObj", null);
return {};