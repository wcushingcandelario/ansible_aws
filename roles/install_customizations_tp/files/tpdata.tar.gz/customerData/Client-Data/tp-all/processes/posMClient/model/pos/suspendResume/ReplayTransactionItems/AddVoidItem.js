return { 
	"refItemIdx": processMem.current.refItemIdx,
	"reasonCode": processMem.current.reasonCodeId
};