return {
	"tranId": processMem.quoteTranId,
	"tranItems": processMem.quoteResultSet,
	"tranTypeId": require("generic/Constants").TX_TY_QUOTE
};