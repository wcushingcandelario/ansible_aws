processMem.reasonCodeDesc = (inputParams.resultSet[0])?inputParams.resultSet[0].description:processMem.current.reasonCodeId;
var productId = processMem.current.productId || processMem.current.product.productId;
var sku = processMem.current.sku || processMem.current.product.sku;
if(sku == undefined || 
 sku == "" ||
 sku == "null" ||
 sku == null){
 	sku = productId;
 }

if (processMem.current.refTranId == null){
	return { "productId": sku,
			"fetchLowestPrice": 1};
}
else{
	return { "productId": sku};
}
