return { 
	"productId": processMem.current.productId,
	"quantity": processMem.current.qty,
	"isScanned": processMem.current.isScanned,
	"itemType": require("generic/Constants").ITEM_TY_APPOINTMENT
};