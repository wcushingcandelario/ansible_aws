require("posmclient/RetailTransactionHelper").getCurrentTranObj().getTranItems()[0]._reasonCodeId = processMem.inputParams.reasonCodes;
return {};
