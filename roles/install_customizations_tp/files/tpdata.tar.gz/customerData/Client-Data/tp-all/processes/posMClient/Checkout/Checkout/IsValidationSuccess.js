processMem.tenderDetails.gcbalance = inputParams.gcbalance;
processMem.tenderDetails.giftCertNum = inputParams.giftCertNum;

return {
	condition : inputParams.isValidAndLoaded && inputParams.isValidAndLoaded==1 &&
				processMem.tenderDetails.gcbalance>0
};