var Constants = require("generic/Constants");
var condition = false;
if(inputParams.itemType != null && inputParams.itemType != undefined &&
		(parseFloat(inputParams.itemType) == Constants.ITEM_TY_GIFT_CARD_SALE || 
		parseFloat(inputParams.itemType) == Constants.ITEM_TY_GIFT_CARD_TOPUP)
	){
	condition = true;
}
return { condition: condition }; 