return {
		giftCardItems: processMem.giftCardItems,
		requestId: localStorage.getObject("giftCardRequestId")
	};