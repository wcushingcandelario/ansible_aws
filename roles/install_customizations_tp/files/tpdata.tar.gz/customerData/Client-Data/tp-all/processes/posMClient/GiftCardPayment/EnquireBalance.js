var requestId = require("dojox/uuid/generateRandomUuid")();
var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");

return { 
	"data": {
			"requestId": requestId,
			"panNumber": processMem.giftCardSerialNumber,
			"cardCustCommId": posConfig.CardCustCommerceId,
			"mid": posConfig.SavvyMid,
			"encryptionKey": posConfig.EncyptionKey,
			"endPointUrl": posConfig.SavvyEndPoint
		},
	"service": 'GiftCardBalanceEnquiry' 
	};