require("ovc/UI").hideBlocker();
processMem.tenderSuccessful = false;

var message = processMem.returnData[0].errorMsg + " - " + processMem.returnData[0].panNumber;
if(processMem.returnData[0].errorCode != undefined && processMem.returnData[0].errorCode != null){
	message = processMem.resourceManager.getValue("giftCard.errorCodes." + processMem.returnData[0].errorCode);
}

return {
	title: processMem.resourceManager.getValue("giftCard.savvyValidation"),
	message: message
};