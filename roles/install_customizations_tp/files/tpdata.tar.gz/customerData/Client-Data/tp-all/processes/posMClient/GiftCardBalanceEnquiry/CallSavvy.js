require("ovc/UI").showBlocker("Validating Gift Card with Savvy...", true);
processMem.giftCertNum = inputParams.value.txtSerialNumberEnquiry;
var requestId = require("dojox/uuid/generateRandomUuid")();
var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");

return { 
	"data": {
			"requestId": requestId,
			"panNumber": processMem.giftCertNum,
			"cardCustCommId": posConfig.CardCustCommerceId,
			"mid": posConfig.SavvyMid,
			"encryptionKey": posConfig.EncyptionKey,
			"endPointUrl": posConfig.SavvyEndPoint
		},
	"service": 'GiftCardBalanceEnquiry' 
	};