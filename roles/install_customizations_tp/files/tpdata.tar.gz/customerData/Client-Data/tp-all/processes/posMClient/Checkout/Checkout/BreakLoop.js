processMem.amount = inputParams.amount;
return { "break": true}
