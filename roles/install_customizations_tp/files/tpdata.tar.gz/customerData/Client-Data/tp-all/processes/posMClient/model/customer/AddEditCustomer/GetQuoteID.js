return {
	quoteId: processMem.customerQuoteIdList[0]
};

