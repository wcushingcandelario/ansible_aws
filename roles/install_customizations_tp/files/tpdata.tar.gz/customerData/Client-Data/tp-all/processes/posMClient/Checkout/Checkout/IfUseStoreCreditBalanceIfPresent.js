var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var isStoreCreditAllowed =  require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").isStoreCreditAllowed;
var useStoreCreditBalanceIfPresent =  require("ovc/ConfigManager").getConfigObject("posMClient/app.ovccfg").useStoreCreditBalanceIfPresent;
var condition = false;
if(isStoreCreditAllowed && isStoreCreditAllowed === 1 && useStoreCreditBalanceIfPresent && useStoreCreditBalanceIfPresent === 1 && tranObj.getLoyaltyUser() != null && tranObj.getLoyaltyUser().storeCreditBalance != null &&  tranObj.getLoyaltyUser().storeCreditBalance > 0)
	condition =  true;
return { condition : (condition) };