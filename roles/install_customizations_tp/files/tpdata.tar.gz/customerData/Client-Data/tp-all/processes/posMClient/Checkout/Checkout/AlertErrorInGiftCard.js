var message = "Error in processing Gift Card. ";
var adjustmentAmount = 0;
for(var i=0; i<processMem.returnData.length; i++){
	if(processMem.returnData[i].response == undefined || processMem.returnData[i].response == null){
		message = "Internal Error in processing Gift Card.";
		// Can happen if not reaching Savvy. So return all gift cards' value to customer.
		_.forEach(processMem.giftCardItems, function(gc){
			adjustmentAmount += parseFloat(gc.amount);
		});
	}
	else{
		var response = JSON.parse(processMem.returnData[i].response);
		if(response.errorCode != '0' && response.errorCode != '00'){
			message += response.panNumber + " - " + response.errorMsg + ". ";
			// find the gift card that was not (fully) topped up, and get the intended top up value.
			var erroneousGC = _.find(processMem.giftCardItems, function(obj) { return obj.itemNum == response.panNumber });
			adjustmentAmount += parseFloat(erroneousGC.price) - parseFloat(response.adjustedAmount);
		}
	}
}
processMem.adjustmentAmount = 0 - parseFloat(adjustmentAmount);

return {
	title: "Gift Card",
	message: message
};