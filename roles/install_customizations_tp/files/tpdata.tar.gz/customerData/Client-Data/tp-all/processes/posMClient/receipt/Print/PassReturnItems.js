inputParams.receiptObj = processMem.receiptObj;
return { returnItems: processMem.returnItems,
		 receiptObj: processMem.receiptObj,
		 extraReceiptItems: processMem.extraReceiptItems
};