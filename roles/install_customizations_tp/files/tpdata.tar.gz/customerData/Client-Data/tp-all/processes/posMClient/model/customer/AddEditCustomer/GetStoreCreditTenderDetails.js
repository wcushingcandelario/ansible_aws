return {
	sqlQuery: "SELECT tenderType, description, propertiesJson FROM tender_type_tbl WHERE id = ?",
	paramsArr: [require("generic/Constants").ITEM_TY_STORECREDIT_TENDER+""]
};
