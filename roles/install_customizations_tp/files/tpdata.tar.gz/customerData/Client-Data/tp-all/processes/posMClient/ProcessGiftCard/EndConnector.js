require("ovc/UI").hideBlocker();
processMem.returnData.push(inputParams.response);
var response = JSON.parse(inputParams.response.response);
if(response.errorCode != "0" && response.errorCode != "00" ){
	processMem.isAllGiftCardsOk = false;
}
else{
	if((processMem.isAllGiftCardsOk == undefined || processMem.isAllGiftCardsOk == null) || 
		(processMem.isAllGiftCardsOk != undefined && processMem.isAllGiftCardsOk != null && 
			processMem.isAllGiftCardsOk != false)){
		processMem.isAllGiftCardsOk = true;
	}
}

return {
	isAllGiftCardsOk: processMem.isAllGiftCardsOk,
	returnData: processMem.returnData
}

