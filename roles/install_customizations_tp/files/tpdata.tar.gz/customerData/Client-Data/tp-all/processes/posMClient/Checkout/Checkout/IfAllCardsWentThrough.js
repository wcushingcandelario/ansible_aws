processMem.returnData = inputParams.returnData;

if(localStorage.getObject("returnData") == undefined || localStorage.getObject("returnData") == null){
	localStorage.setObject("returnData", processMem.returnData);
	var obj = [];
	for(var i=0; i<inputParams.returnData.length; i++){
		if(inputParams.returnData[i].response != undefined && inputParams.returnData[i].response != null){
			var temp = JSON.parse(inputParams.returnData[i].response);
			temp.giftCardRequestId = localStorage.getObject("giftCardRequestId");
			obj.push(temp);
		}
	}
}
else{
	var obj;
	obj = localStorage.getObject("returnData");
	if(processMem.returnData != undefined && processMem.returnData != null){
		for(var i=0; i<processMem.returnData.length; i++){
			var temp = JSON.parse(processMem.returnData[i].response);
			temp.giftCardRequestId = localStorage.getObject("giftCardRequestId");
			obj.push(temp);
		}
		localStorage.setObject("returnData", obj);
	}
}
var condition = true;

if(inputParams.isAllGiftCardsOk != undefined && inputParams.isAllGiftCardsOk != null 
		&& inputParams.isAllGiftCardsOk == false){
	condition = false;
}
else if (inputParams.isAllGiftCardsOk == undefined || inputParams.isAllGiftCardsOk == null){
	condition = false;
}

return {condition: condition};