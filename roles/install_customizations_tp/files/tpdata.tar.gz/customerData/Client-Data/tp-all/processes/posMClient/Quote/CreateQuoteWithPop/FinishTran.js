var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
 tranObj.setQuote();

return {
	tranObj: tranObj,
	fromMainMenu: true
};