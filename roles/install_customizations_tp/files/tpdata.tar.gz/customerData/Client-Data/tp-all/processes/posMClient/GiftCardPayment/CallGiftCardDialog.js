var res = require("generic/ResourceManager");
var prepopulatebalanceatcheckout = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').prepopulatebalanceatcheckout;
var amount = "";
if(prepopulatebalanceatcheckout !== undefined && prepopulatebalanceatcheckout !== null && prepopulatebalanceatcheckout == 1){
	if(processMem.inputParams.amount !== undefined && processMem.inputParams.amount !== null){
		amount = processMem.inputParams.amount.toFixed(2);
	}
}

var formControlsArray = [
	               {"type": "TextBox", 
	            	"id": "txtSerialNumber",
	            	"name": "txtSerialNumber",
	            	"label": res.getValue("giftCard.pleaseScan"),
	            	"value": processMem.giftCardSerialNumber || "",
	            	"options": { "placeHolder": "Serial Number", "required": true}
	               },
	               {"type": "TextBox", 
		            "name": "txtAmount",
		            "value": amount,
		            "options": { "placeHolder": "Amount", "required": true, "type": "text", "amountValidation": true}
		            }
               ];

return {
			formControlsArray: formControlsArray,
			dialogTitle: res.getValue("pos.giftCard"),
			doLbl: res.getValue("pos.yesBtnLabel")
		};