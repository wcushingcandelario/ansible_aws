return {
	tenderSuccessful: processMem.tenderSuccessful,
	userEnteredValidAmount: processMem.userEnteredValidAmount
}
