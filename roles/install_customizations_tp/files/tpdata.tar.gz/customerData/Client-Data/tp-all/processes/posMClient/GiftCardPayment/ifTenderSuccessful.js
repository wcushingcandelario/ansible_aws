
return {condition: processMem.tenderSuccessful == true};