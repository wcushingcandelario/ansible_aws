var customerInfoMap = {};
var ovcType = "OVCCustomer";
var customerMap = processMem.inputParams.customerDetails;

if (processMem.inputParams.customerDetails == null || 
		(processMem.inputParams.customerDetails != null && processMem.inputParams.customerDetails.loyaltyId == undefined)
	){
	// creating customer
	if(undefined == inputParams.value.email || inputParams.value.email == null){
		inputParams.value.email = require("dojox/uuid/generateRandomUuid")();
	}
	customerInfoMap.isCustomerCreateRequired = 1;
}
else{ 
	// editing customer
	customerInfoMap.loyaltyId = processMem.inputParams.customerDetails.loyaltyId;
	customerInfoMap.isCustomerCreateRequired = 0;
}
customerInfoMap.firstName = inputParams.value.firstName;
customerInfoMap.lastName = inputParams.value.lastName;
customerInfoMap.email = inputParams.value.email;
customerInfoMap.phone1 = inputParams.value.mobilePhone;
customerInfoMap.addressLine1 = inputParams.value.addressLine1;
customerInfoMap.addressLine2 = inputParams.value.addressLine2;
customerInfoMap.phoneMobile = inputParams.value.phoneMobile;
customerInfoMap.town = inputParams.value.town;
customerInfoMap.postalCode = inputParams.value.postalCode;

if (inputParams.value.arAccountNumber && inputParams.value.arAccountNumber != null)
{
	customerInfoMap.arAccountNumber = inputParams.value.arAccountNumber;
}  
   
var isTaxExemptClicked = require('posmclient/OVCPosMainMenu.actions').executeAction('isTaxExemptClicked'); 
if(isTaxExemptClicked != undefined && isTaxExemptClicked == true){
	isTaxExemptClicked = undefined;  
	require('posmclient/OVCPosMainMenu.actions').executeAction('setTaxExemptClicked',false);
	require('ovc/ProcessEngine').invokeProcess('posMClient/model/customer/GetCustomerTaxExemptionInfo.ovcprc', {
		customerDetails: customerInfoMap
	});
}   
 
var storeCreditClicked = require('posmclient/OVCPosSubMenu.states').isStoreCreditClicked();
if(storeCreditClicked != undefined && storeCreditClicked == true){ 
	var tenderId = require('posmclient/OVCPosSubMenu.states').getStoreCreditTenderId();
	require('posmclient/OVCPosSubMenu.states').setStoreCreditClicked(false);   
	require('ovc/ProcessEngine').invokeProcess("posMClient/Checkout/Checkout.ovcprc", {tenderType:tenderId, isStoreCreditClicked: true});
} 

var isCreateQuoteClicked = require('posmclient/OVCPosSubMenu.states').isCreateQuoteClicked();
if(isCreateQuoteClicked != undefined && isCreateQuoteClicked){ 
	require('posmclient/OVCPosSubMenu.states').setCreateQuoteClicked(false); 
	require('ovc/ProcessEngine').invokeProcess("posMClient/Quote/CreateQuote.ovcprc", { needCustomer: false });
}

if(processMem.inputParams.customerDetails != undefined){
	if(processMem.inputParams.customerDetails.VRcustomerPOP != undefined){
		customerInfoMap.VRcustomerPOP = processMem.inputParams.customerDetails.VRcustomerPOP;
	}
}

return customerInfoMap;