require("ovc/UI").showBlocker("", true);

var isExistingCustomer = false;
if (processMem.inputParams.customerDetails != undefined && 
		processMem.inputParams.customerDetails != null && 
		processMem.inputParams.customerDetails.loyaltyId != null)
	{
		isExistingCustomer = true;
	}

return {
	condition: isExistingCustomer
};