
return { 
	productId: processMem.inputParams.productId,
	isDeliveryOption: processMem.inputParams.isDeliveryOption,
	retailerId: "defaultRetailer"
};