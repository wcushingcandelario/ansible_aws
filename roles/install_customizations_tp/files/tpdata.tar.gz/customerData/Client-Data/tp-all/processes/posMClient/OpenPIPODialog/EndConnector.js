processMem.pipoAmount = inputParams.amount;
return {pipoAmount:processMem.pipoAmount};