processMem.isPartialPayment = true;

return {
	title: processMem.resourceManager.getValue("giftCard.giftCardBalance"),
	message: processMem.resourceManager.getValue("giftCard.insufficientBalance") + 
			processMem.resourceManager.getValue("currency.symbol") + parseFloat(processMem.availableBalance).toFixed(2).toString() 
				+ " " + processMem.resourceManager.getValue("giftCard.useDiffCard"),
    yesBtnLabel: processMem.resourceManager.getValue("giftCard.yesBtn"),
	noBtnLabel:  processMem.resourceManager.getValue("giftCard.noBtn")
};