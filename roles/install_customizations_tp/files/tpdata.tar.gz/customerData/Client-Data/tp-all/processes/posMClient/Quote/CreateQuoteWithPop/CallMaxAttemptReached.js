var loyaltyId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getLoyaltyId();
return {loyaltyId: loyaltyId
};