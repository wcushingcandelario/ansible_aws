var moveFromId = 'mainMenuView';
if(processMem.inputParams.moveFromId!=null){
	moveFromId = processMem.inputParams.moveFromId;
}
return { moveFromId: moveFromId,
                   moveToId: inputParams.moveToId,
	               transitionDir: 1,
	               transition: 'slide'
                 };
