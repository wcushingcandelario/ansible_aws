var itemDate = new Date().getTime();

var tranItem = require("posmclient/RetailTransactionHelper").getCurrentTranObj().addGiftCardRefund(processMem.current.reasonCodeId, 
		processMem.current.amount, 
		processMem.current.itemDate,
		"Gift Card",
		processMem.current.refTranId);

