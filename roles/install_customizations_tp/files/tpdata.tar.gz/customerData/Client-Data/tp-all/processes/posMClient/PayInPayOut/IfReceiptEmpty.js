processMem.processInputParams = inputParams;
var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var condition;
if(tranObj.getCalculatedTranItems().length > 0){
	condition = false;
}
else{
	condition = true;
}
return {condition:condition}