var deferred = new Deferred();

require(['generic/Constants', 'generic/ResourceManager', 'generic/StringUtils', 'ovc/ConfigManager', 'posmclient/RetailTransactionHelper'], function (Constants, ResourceManager, StringUtils, ConfigManager, RetailTransactionHelper) {
	// For each paramsMap.receiptObj.nonVoidItems we want to check the itemType (a ITEM_TY constant),
	// and set the itemTypeString that we'll show in the receipt. For refunds we'll put the string "[REFUND]", for
	// other types, we'll leave it as a blank string for now.

	var paramsMap = processMem.inputParams.paramsMap;
	var nonVoidItems = paramsMap.receiptObj.nonVoidItems;
	var summary = paramsMap.receiptObj.summary;
	var tenders = paramsMap.receiptObj.tenders;

	//checks for sign of currency applies negative sign if needed before the currency symbol
	var signedCurrency = function(number) {
		var currencySymbol = ResourceManager.getValue("currency.symbol");

		if (number != undefined){

			var numberStr = number.toString();
			if(numberStr.indexOf(currencySymbol) > -1){
				number = numberStr.replace(currencySymbol, "");
			}
			var negativeStr = number < 0 ? "-" : "";
			return negativeStr + StringUtils.numberToCurrencyString(Math.abs(number), 2, true);
		}
	};

	if (summary) {
		summary.merchTotal = signedCurrency(summary.merchTotal);
		summary.merchTotalWithoutDiscount = signedCurrency(summary.merchTotalWithoutDiscount);
		summary.total = signedCurrency(summary.total);
		summary.totalPayment = signedCurrency(summary.totalPayment);
		if(summary.change){
			summary.change = signedCurrency(summary.change);
		}
		if(summary.layawayBalance){
			summary.layawayBalance = signedCurrency(summary.layawayBalance);
		}
		for (var i = 0; i < summary.taxes.length; i++) {
			summary.taxes[i].amount = signedCurrency(summary.taxes[i].amount);
		}
	}

	if (summary && summary.promoSavings) {
		summary.promoSavings = signedCurrency(summary.promoSavings);
	}
	
	if (summary && summary.totalDiscount) {
		summary.totalDiscount = signedCurrency(summary.totalDiscount);
	}

	if (tenders){
		for (var i = 0; i < tenders.length; i++) {
			tenders[i].amount = signedCurrency(tenders[i].amount);
		}
	}

	paramsMap.currency = ResourceManager.getValue("currency.symbol");

	if (nonVoidItems){
	for (var i = 0; i < nonVoidItems.length; i++) {

		nonVoidItems[i].itemTypeString = "";

		nonVoidItems[i].price = signedCurrency(nonVoidItems[i].price);
		nonVoidItems[i].origPrice = signedCurrency(nonVoidItems[i].origPrice);
		nonVoidItems[i].unitPrice = signedCurrency(nonVoidItems[i].unitPrice);

		if (nonVoidItems[i].itemType === Constants.ITEM_TY_REFUND_PRODUCT) {
			nonVoidItems[i].itemTypeString = ResourceManager.getValue("printReceipt.refund");
			if(nonVoidItems[i].price.search("-") < 0)
			nonVoidItems[i].price = "-" + nonVoidItems[i].price;
		}

		if (nonVoidItems[i].itemType === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT) {
			nonVoidItems[i].itemTypeString = "[PICKUP]";
		}

		if (nonVoidItems[i].itemType === Constants.ITEM_TY_NO_SALE) {
			paramsMap.receiptObj.noSale = true;
			nonVoidItems[i].noSale = true;
		}

		var discounts = "";

		if (nonVoidItems[i].discounts) {
			discounts = nonVoidItems[i].discounts;
		}

		if (discounts !== "") {
			for (var j = 0; j < discounts.length; j++) {
				if ( parseInt(discounts[j].discType) === Constants.DISC_TYPE_AMOUNT ) {
					discounts[j].discValue = signedCurrency(discounts[j].discValue);

				}
				else if ( parseInt(discounts[j].discType) === Constants.DISC_TYPE_PERCENT ) {
					discounts[j].discValue = discounts[j].discValue + "%";
				}
			}
		}

		if (nonVoidItems[i].itemType === Constants.ITEM_TY_DISCOUNT_TXN) {

			nonVoidItems[i].txnDiscount = true;

			if ( parseInt( nonVoidItems[i].discType ) === Constants.DISC_TYPE_AMOUNT ) {
				nonVoidItems[i].discValue = signedCurrency(nonVoidItems[i].discValue);
			}

			else if ( parseInt( nonVoidItems[i].discType ) === Constants.DISC_TYPE_PERCENT ) {
				nonVoidItems[i].discValue = nonVoidItems[i].discValue + "%";
			}
		}

		if (nonVoidItems[i].promos != null) {
			for (var promotionMap in nonVoidItems[i].promos) {
				if (nonVoidItems[i].promos.hasOwnProperty(promotionMap)) {
					var promotionItem = nonVoidItems[i].promos[promotionMap];

					if (promotionItem.totalValue != null) {
						promotionItem.totalValue = signedCurrency(promotionItem.totalValue);
					}
				}
			}
		}
		
		if(parseInt( nonVoidItems[i].itemType ) === Constants.ITEM_TY_GIFT_CARD_SALE || 
			parseInt( nonVoidItems[i].itemType ) === Constants.ITEM_TY_GIFT_CARD_TOPUP){
			nonVoidItems[i].itemNum = "****" +
			nonVoidItems[i].itemNum.substring(nonVoidItems[i].itemNum.length - 4, 
									nonVoidItems[i].itemNum.length);
		}
		
		//add fsc flag to the item
		if(nonVoidItems[i].itemType == Constants.ITEM_TY_ADD_PRODUCT ){
			var certificationsMetFlag = nonVoidItems[i].propertiesJson.products.certificationsMet;
				if(certificationsMetFlag != undefined && certificationsMetFlag != ''){
					nonVoidItems[i].fsc = ""+nonVoidItems[i].propertiesJson.products.certificationsMet;
				}else{
					nonVoidItems[i].fsc = "";
				}
			}
		
		if(nonVoidItems[i].BBASEntries != null && nonVoidItems[i].BBASEntries != undefined && nonVoidItems[i].BBASEntries.length > 0){
			nonVoidItems[i].isBBASEntry = true;
			nonVoidItems[i].reasonCodeDesc = nonVoidItems[i].BBASEntries[0].reasonCodeDesc;
		}
	}
	
	paramsMap.receiptObj.nonVoidItems = nonVoidItems;
	
	if (paramsMap.receiptObj.tranTypeId == Constants.TX_TY_SUSPENDED){
		// resource bundle for Parked Tran Receipt
		paramsMap.receiptObj.parkedTranHeader = ResourceManager.getValue("printReceipt.parkedTranHeader");
		paramsMap.receiptObj.parkedTranInstr = ResourceManager.getValue("printReceipt.parkedTranInstr");
		paramsMap.receiptObj.parkedTranTotal = ResourceManager.getValue("printReceipt.parkedTranTotal");
		paramsMap.receiptObj.parkedTranNoOfItems = ResourceManager.getValue("printReceipt.parkedTranNoOfItems");
	}
	else if (paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYINTRAN){
		paramsMap.receiptObj.pipoText = ResourceManager.getValue("printReceipt.payInTotal");
	}
	else if (paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYOUTTRAN){
		paramsMap.receiptObj.pipoText = ResourceManager.getValue("printReceipt.paidOutTotal");
	}
	else if (paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYINCORRTRAN){
		paramsMap.receiptObj.pipoText = ResourceManager.getValue("printReceipt.payInCorrTotal");
	}
	else if (paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYOUTCORRTRAN){
		paramsMap.receiptObj.pipoText = ResourceManager.getValue("printReceipt.payOutCorrTotal");
	}
	
	
	if(paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYINTRAN || 
			paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYOUTTRAN || 
			paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYINCORRTRAN ||
			paramsMap.receiptObj.tranTypeId == Constants.TX_TY_PAYOUTCORRTRAN){
		for(var i =0; i < paramsMap.receiptObj.nonVoidItems.length; i++){
				currencySymbol = ResourceManager.getValue("currency.symbol");
				if(paramsMap.receiptObj.nonVoidItems[i].amount && paramsMap.receiptObj.nonVoidItems[i].amount != null){
					if(!(paramsMap.receiptObj.nonVoidItems[i].amount.indexOf(currencySymbol) > -1) ){
						if(parseFloat(paramsMap.receiptObj.nonVoidItems[i].amount)<0){
							paramsMap.receiptObj.nonVoidItems[i].amount = paramsMap.receiptObj.nonVoidItems[i].amount.replace("-", "");
							paramsMap.receiptObj.nonVoidItems[i].amount = "-" + currencySymbol + paramsMap.receiptObj.nonVoidItems[i].amount;
						}
						else{
							paramsMap.receiptObj.nonVoidItems[i].amount = currencySymbol + paramsMap.receiptObj.nonVoidItems[i].amount;
						}
					}
				}
			}
		}
	
	//resource bundle for backdoor receipt
	var isBackdoor = ConfigManager.getConfigObject("posMClient/sales.ovccfg").allowBackdoorDelivery;
	if (isBackdoor != undefined && isBackdoor != null && isBackdoor == 1){
		paramsMap.receiptObj.backGateCollection = ResourceManager.getValue("printReceipt.backDoorReceipt.backGateCollection");
		paramsMap.receiptObj.customerInstructions = ResourceManager.getValue("printReceipt.backDoorReceipt.customerInstructions");
		paramsMap.receiptObj.backDoorInstr = ResourceManager.getValue("printReceipt.backDoorReceipt.backDoorInstr");
		paramsMap.receiptObj.goodsCollection = ResourceManager.getValue("printReceipt.backDoorReceipt.goodsCollection");
		paramsMap.receiptObj.receivedGoods = ResourceManager.getValue("printReceipt.backDoorReceipt.receivedGoods");
	}

	// Exchange receipt conditions:
	var isExchangeReceiptOn = ConfigManager.getConfigObject("posMClient/sales.ovccfg").allowExchangeReceipt;
	if(isExchangeReceiptOn != undefined && isExchangeReceiptOn != null && isExchangeReceiptOn == 1){ //if exchange receipt config is on.
		if(paramsMap.receiptObj.summary.total == signedCurrency(0)){ // proceed if total amount of tran is 0
			var refundItemsCount = 0;
			var saleItemsCount = 0;
			for (var i = 0; i < paramsMap.receiptObj.nonVoidItems.length; i++){ // loop items to count refunds and sale
				if(paramsMap.receiptObj.nonVoidItems[i].itemType == Constants.ITEM_TY_ADD_PRODUCT){
					saleItemsCount += 1;
				}
				else if (paramsMap.receiptObj.nonVoidItems[i].itemType == Constants.ITEM_TY_REFUND_PRODUCT){
					refundItemsCount += 1;
				}
			}
			
			if(refundItemsCount > 0 && saleItemsCount > 0){ // proceed if atleast one refund item, and one product added
				paramsMap.receiptObj.exchangeText = ResourceManager.getValue("printReceipt.exchangeText");
				paramsMap.receiptObj.exchangeNoCash = ResourceManager.getValue("printReceipt.exchangeNoCash");
			}
		}
	}
}
	if(paramsMap.storeCreditBalance === 0 || paramsMap.storeCreditBalance > 0) {
		paramsMap.storeCreditBalance = signedCurrency(paramsMap.storeCreditBalance);
	}
	
	paramsMap.usedStoreCreditBalance = StringUtils.numberToCurrencyString(Math.abs(paramsMap.usedStoreCreditBalance), 2, true);
	
	if(paramsMap.oldStoreCreditBalance === 0 || paramsMap.oldStoreCreditBalance > 0)
		paramsMap.oldStoreCreditBalance = signedCurrency(paramsMap.oldStoreCreditBalance);

	//build the store details 
	paramsMap.storeName = localStorage.getObject("location").displayName;
	paramsMap.storeAddress = localStorage.getObject("location").streetNumber+", "+localStorage.getObject("location").streetName;
	paramsMap.storeTown = localStorage.getObject("location").town+"       "+localStorage.getObject("location").postalCode;
	paramsMap.storeTel = localStorage.getObject("location").phone;
	paramsMap.storeVat = localStorage.getObject("location").taxIdentifier;
	
	//build the custom attributes
	// customer signature line on receipt based on config
	var receiptsConfig = ConfigManager.getConfigObject("posMClient/receipts.ovccfg");
	var rType = processMem.inputParams.receiptType;
	if(rType == null){
		rType = processMem.rType;
	}
	var isCustomerSignReq = 0;
	if(receiptsConfig[rType] != undefined && receiptsConfig[rType] != null){
		isCustomerSignReq = receiptsConfig[rType].isCustomerSignRequired;
	}
	if(isCustomerSignReq != undefined &&  isCustomerSignReq != null && isCustomerSignReq ==1){
		paramsMap.receiptObj.customerSign = ResourceManager.getValue("printReceipt.customerSign");
		paramsMap.receiptObj.isCustomerSignRequired = true;
	}
	if(processMem.receiptIdentifier == "customerCopy"){
		paramsMap.receiptObj.customerCopy = ResourceManager.getValue("printReceipt.customerCopy");
		paramsMap.receiptObj.isCustomerCopy = true;
		paramsMap.receiptObj.isStoreCopy = false;
		// never have customer sign on the customer copy. Only on the 
		// store copy. If store copy needs customer sign, we need to 
		// implement a new config, and expose in dashboard.
		paramsMap.receiptObj.isCustomerSignRequired = false; 
	}
	else if (processMem.receiptIdentifier == "storeCopy"){
		paramsMap.receiptObj.storeCopy = ResourceManager.getValue("printReceipt.storeCopy");
		paramsMap.receiptObj.isStoreCopy = true;
		paramsMap.receiptObj.isCustomerCopy = false;
	}
	
	var receiptHeader =  localStorage.getObject("location").receiptHeader;
	if(receiptHeader == null){
		receiptHeader = ResourceManager.getValue("printReceipt.visitUsAt")+"\r"+
				ResourceManager.getValue("printReceipt.website");
	}

	var receiptFooter =  localStorage.getObject("location").receiptFooter;
	if(receiptFooter == null){
		receiptFooter = ResourceManager.getValue("printReceipt.thanksForShopping");
	}
	
	paramsMap.receiptObj.receiptHeader = receiptHeader;
	paramsMap.receiptObj.receiptFooter = receiptFooter;
	
//	paramsMap.receiptObj.visitUsAt = ResourceManager.getValue("printReceipt.visitUsAt");
//	paramsMap.receiptObj.website = ResourceManager.getValue("printReceipt.website");
	paramsMap.receiptObj.telephone = ResourceManager.getValue("printReceipt.telephone");
	paramsMap.receiptObj.vatNumber = ResourceManager.getValue("printReceipt.vatNumber");
	paramsMap.receiptObj.associate = ResourceManager.getValue("printReceipt.associate");
	paramsMap.receiptObj.amountTendered = ResourceManager.getValue("printReceipt.amountTendered");
//	paramsMap.receiptObj.thanksForShopping = ResourceManager.getValue("printReceipt.thanksForShopping");
	paramsMap.receiptObj.saleText = ResourceManager.getValue("printReceipt.saleText");
	paramsMap.receiptObj.refundText = ResourceManager.getValue("printReceipt.refundText");

	paramsMap.receiptObj.customerDetails = ResourceManager.getValue("printReceipt.customerDetails");
	paramsMap.receiptObj.name = ResourceManager.getValue("printReceipt.name");
	paramsMap.receiptObj.storeCreditBalance = ResourceManager.getValue("printReceipt.storeCreditBalance");
	paramsMap.receiptObj.additionalCredit = ResourceManager.getValue("printReceipt.additionalCredit");
	paramsMap.receiptObj.newStoreCreditBalance = ResourceManager.getValue("printReceipt.newStoreCreditBalance");
	paramsMap.receiptObj.previous = ResourceManager.getValue("printReceipt.previous");
	paramsMap.receiptObj.subtotal = ResourceManager.getValue("printReceipt.subtotal");
	paramsMap.receiptObj.items = ResourceManager.getValue("printReceipt.items");
	paramsMap.receiptObj.discountSavings = ResourceManager.getValue("printReceipt.discountSavings");
	paramsMap.receiptObj.promoSavings = ResourceManager.getValue("printReceipt.promoSavings");
	paramsMap.receiptObj.gcBalance = ResourceManager.getValue("printReceipt.gcBalance");
	paramsMap.receiptObj.totalPayment = ResourceManager.getValue("printReceipt.totalPayment");
	paramsMap.receiptObj.change = ResourceManager.getValue("printReceipt.change");
	paramsMap.receiptObj.layawayBalance = ResourceManager.getValue("printReceipt.layawayBalance");
	paramsMap.receiptObj.issueDate = ResourceManager.getValue("printReceipt.issueDate");
	paramsMap.receiptObj.amountText = ResourceManager.getValue("printReceipt.amountText");
	paramsMap.receiptObj.validUntil = ResourceManager.getValue("printReceipt.validUntil");
	paramsMap.receiptObj.operatorSignature = ResourceManager.getValue("printReceipt.operatorSignature");
	paramsMap.receiptObj.supervisorSignature = ResourceManager.getValue("printReceipt.supervisorSignature");
	paramsMap.receiptObj.paidOutTotal = ResourceManager.getValue("printReceipt.paidOutTotal");
	paramsMap.receiptObj.totalVAT = ResourceManager.getValue("printReceipt.totalVAT");
	paramsMap.receiptObj.pipoPaid = ResourceManager.getValue("printReceipt.pipoPaid");
	paramsMap.receiptObj.customername = ResourceManager.getValue("printReceipt.customerName");
	var bbasSavings = RetailTransactionHelper.getCurrentTranObj().calcBBASSavings();
	if(bbasSavings != null && bbasSavings != undefined && parseFloat(bbasSavings) > 0){
		paramsMap.receiptObj.isBBAS = true;
		paramsMap.receiptObj.bbasSavings = ResourceManager.getValue("pos.bbas.bbasSavingsOnTran") + ResourceManager.getValue("currency.symbol") + parseFloat(bbasSavings).toFixed(2);
	}
	
	deferred.resolve({
		templateSrc: processMem.inputParams.templateSrc,
		paramsMap: paramsMap
	});

});

return deferred.promise;
