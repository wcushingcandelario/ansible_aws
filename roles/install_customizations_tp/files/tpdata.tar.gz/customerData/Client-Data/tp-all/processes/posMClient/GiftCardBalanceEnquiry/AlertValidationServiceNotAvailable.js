require("ovc/UI").hideBlocker();
processMem.tenderSuccessful = false;

return {
	title: processMem.resourceManager.getValue("giftCard.savvyValidation"),
	message: processMem.resourceManager.getValue("giftCard.savvyUnavailable")
};