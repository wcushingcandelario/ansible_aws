var res = require("generic/ResourceManager");
var prepopulatebalanceatcheckout = require("ovc/ConfigManager").getConfigObject('posMClient/pos.ovccfg').prepopulatebalanceatcheckout;
var amount = "";
if(prepopulatebalanceatcheckout !== undefined && prepopulatebalanceatcheckout !== null && prepopulatebalanceatcheckout == 1){
	if(processMem.amount !== undefined && processMem.amount !== null){
		amount = processMem.amount;
	}
}
var formControlsArray = [
	               {"type": "TextBox",
	            	"id": "txtSerialNumber",
	            	"name": "txtSerialNumber",
	            	"value": processMem.serialNumber || "",
	            	"label": res.getValue("giftCard.pleaseScan"),
	            	"options": { "placeHolder": "Serial Number", "required": true}
	               },
	               {"type": "TextBox", 
		            "name": "txtAmount",
		            "value": amount,
		            "options": { "placeHolder": "Amount", "required": true, "type": "text", "amountValidation": true}
		            }
               ];



return {
			formControlsArray: formControlsArray,
			dialogTitle: res.getValue("pos.giftCard"),
			doLbl: res.getValue("pos.yesBtnLabel"),
			cancelLbl: res.getValue("pos.noBtnLabel")
		};