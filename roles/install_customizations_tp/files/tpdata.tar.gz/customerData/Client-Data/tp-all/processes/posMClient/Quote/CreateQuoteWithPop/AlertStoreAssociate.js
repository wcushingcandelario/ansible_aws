require('posmclient/OVCPosSubMenu.states').setCreateQuoteClicked(true);
return {isQuote: "true"};