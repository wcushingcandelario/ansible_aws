	
	var iscustomerReq = inputParams.needCustomer ? inputParams.needCustomer : false;
	var needCustomer = iscustomerReq ? iscustomerReq : false;
	
	processMem.skipCustomerValidation = processMem.inputParams.skipCustomerValidation;
	var noCustomer = needCustomer;  
	if(needCustomer){
		var loyaltyId = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getLoyaltyId();
		if(loyaltyId === null || loyaltyId === '') {
			noCustomer = true;
		}else{
			noCustomer = false;
		};
		processMem.loyaltyId = loyaltyId;
	}
return { condition : noCustomer };