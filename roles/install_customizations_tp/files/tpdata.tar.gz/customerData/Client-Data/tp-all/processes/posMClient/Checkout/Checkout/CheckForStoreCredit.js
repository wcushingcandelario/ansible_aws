var storeCreditClicked = processMem.inputParams.isStoreCreditClicked;
processMem.inputParams.isStoreCreditClicked = false;
require('posmclient/OVCPosSubMenu.states').setStoreCreditClicked(false);

return {
	condition: (storeCreditClicked === true)
};