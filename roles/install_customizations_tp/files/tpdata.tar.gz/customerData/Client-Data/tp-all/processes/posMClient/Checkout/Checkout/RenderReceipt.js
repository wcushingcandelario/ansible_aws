if(processMem.amount == undefined || processMem.amount == null){
	processMem.amount = inputParams.processOutputParams.giftCardAmount;
}
if(processMem.penniesRounded == undefined || processMem.penniesRounded == null){
	processMem.penniesRounded = 0;
}
if(processMem.changeAmt == undefined || processMem.changeAmt == null){
	processMem.changeAmt = 0;
}
if(processMem.returnData == undefined || processMem.returnData == null){
	processMem.returnData = inputParams.processOutputParams.returnData;
	if((localStorage.getObject("returnData") == null || localStorage.getObject("returnData") == undefined) &&
		(processMem.returnData != undefined && processMem.returnData !== null)){
		localStorage.setObject("returnData", processMem.returnData);
	}
	else{
		var returnData;
		returnData = localStorage.getObject("returnData");
		if(processMem.returnData != undefined){
			returnData.push(processMem.returnData[0]);
			localStorage.setObject("returnData", returnData);
		}
	}
}
else{
	processMem.returnData.push(inputParams.processOutputParams.returnData);
}
processMem.tenderSuccessful = inputParams.processOutputParams.tenderSuccessful;
processMem.userEnteredValidAmount = inputParams.processOutputParams.userEnteredValidAmount;
return {};
