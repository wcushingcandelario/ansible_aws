return { 
	"amount": processMem.current.discValue,
	"amountTypes": processMem.current.discType+'',
	"itemIdx": processMem.current.refItemIdx,
	"reasonCodeDesc": (inputParams.resultSet[0])?inputParams.resultSet[0].description:processMem.current.reasonCodeId,
	"reasonCodes": processMem.current.reasonCodeId,
	"selectedAmountType": processMem.current.discType
};