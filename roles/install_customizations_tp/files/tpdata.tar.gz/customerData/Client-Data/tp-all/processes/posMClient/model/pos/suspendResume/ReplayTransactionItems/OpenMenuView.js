var LayawayUtil = require("posmclient/LayawayUtil");
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var locationId;
if (processMem.inputParams.storeId && processMem.inputParams.storeId != null){
	locationId = processMem.inputParams.storeId;
}

return { 
	"menuId": "posMClient/pos_layaway.ovcmnu",
	"removeIdsArr" : LayawayUtil.getRemoveMenuArrayForLayaway(locationId),
	"amount": processMem.current.amount
};