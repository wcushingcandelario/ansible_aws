function endCondition(outputParams) {
	return (!outputParams["break"] && outputParams.tenderSuccessful && !outputParams.userEnteredValidAmount);
}

processMem.balance = inputParams.balance;
return {
	endCondition: endCondition
};
