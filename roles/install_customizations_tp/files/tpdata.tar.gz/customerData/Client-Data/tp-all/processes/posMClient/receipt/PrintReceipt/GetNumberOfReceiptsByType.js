var rType = processMem.inputParams.receiptType;
if(rType == null){
	rType = processMem.inputParams.paramsMap.receiptType;
}
var receiptTypeConfigs =  require("ovc/ConfigManager").getConfigObject("posMClient/receipts.ovccfg")[rType];
var numberOfStoreCopies = 1;
if(receiptTypeConfigs != undefined && receiptTypeConfigs != null){
	numberOfStoreCopies = receiptTypeConfigs.noOfStoreCopies;
}

var printNumberArr = [];
for(i=1; i <=numberOfStoreCopies;i++){
	printNumberArr.push("printCopy"+i);
}
if(printNumberArr != []){
	processMem.receiptIdentifier = "storeCopy";
}

return{dataArr : printNumberArr};