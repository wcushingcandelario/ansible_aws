return {
	"tranId": processMem.current.tranId,
	"itemIdx": processMem.current.itemIdx
};