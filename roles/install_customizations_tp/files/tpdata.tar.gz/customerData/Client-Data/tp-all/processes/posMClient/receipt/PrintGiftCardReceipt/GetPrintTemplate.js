var printTemplate = 'posMClient/printer/giftCardReceipt.handlebars';
processMem.template = printTemplate;

if(window.printerPlugin != null)
{
    var dvcObj = localStorage.getObject(dUUID);
    var printer = null;
    var printerVersion = null;
    if (dvcObj != null && dvcObj.peripherals != null) {
		for(var index in dvcObj.peripherals){
			var peripheral = dvcObj.peripherals[index];
			if(peripheral.deviceCategory === 'Printer'){
				printerVersion = peripheral.deviceVersion;
				break;
			}
		}
    }
    
    printTemplate = "posMClient/printer/giftCardReceipt.handlebars";
}

return { id: printTemplate };
