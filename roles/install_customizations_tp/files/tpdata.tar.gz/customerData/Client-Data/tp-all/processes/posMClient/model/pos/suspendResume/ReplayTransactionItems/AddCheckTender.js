return {
	"itemDate": processMem.current.itemDate,
	"amount": processMem.current.amount,
	"frankType": processMem.current.frankType,
	"frankValue": processMem.current.frankValue
};