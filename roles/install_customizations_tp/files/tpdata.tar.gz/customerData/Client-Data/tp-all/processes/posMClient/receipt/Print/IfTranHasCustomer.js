var hasCustomer = false;
var transactionObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();


var loyaltyId = transactionObj.getLoyaltyId();
if(loyaltyId === null || loyaltyId === '') {
	hasCustomer = false;
}
else {
	hasCustomer = true;
	processMem.loyaltyId = loyaltyId;
}

return { condition : (hasCustomer) };