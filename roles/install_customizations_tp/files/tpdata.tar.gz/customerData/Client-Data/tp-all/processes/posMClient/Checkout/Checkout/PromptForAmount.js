var balance = processMem.balance;
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

if(currentTranObj.isLayawaySale()){
	balance = Math.max(currentTranObj.getLayawayMinimum() - currentTranObj.getTendersSum(),0);
	if(balance===0 && currentTranObj.getLayawayMinimum()!==0){
		balance = processMem.balance;
	}
}

if(processMem.tenderDetails.description && processMem.tenderDetails.description === 'giftCert'){
	if(processMem.tenderDetails.gcbalance && processMem.tenderDetails.gcbalance <= balance){
		balance = processMem.tenderDetails.gcbalance;
	}
}
if(processMem.tenderDetails.id && processMem.tenderDetails.id == require('generic/Constants').ITEM_TY_STORECREDIT_TENDER){
	var scBal = currentTranObj.getLoyaltyUser().storeCreditBalance;
	var currentlyUsedSCBal = currentTranObj.getUsedStoreCreditBalance();
	var finalSCBal = 0;
	
	if(scBal && scBal != null){
		finalSCBal = scBal - currentlyUsedSCBal; 
		balance = Math.min(finalSCBal, balance); 
	}
}

return {
	codeType : processMem.inputParams.tenderType,
	balance : balance,
	tenderDetails : processMem.tenderDetails
};
