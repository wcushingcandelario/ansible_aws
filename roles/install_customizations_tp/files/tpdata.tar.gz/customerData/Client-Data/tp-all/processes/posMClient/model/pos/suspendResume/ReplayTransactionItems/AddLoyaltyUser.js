//processMem.customerObj.resumeLayaway = 1;
if(processMem.customerObj.taxExemptInfo != null && typeof processMem.customerObj.taxExemptInfo == 'string'){
	processMem.customerObj.taxExemptInfo = JSON.parse(processMem.customerObj.taxExemptInfo);
}

return {
	"customerObj": processMem.customerObj,
	"loyaltyEmail": processMem.customerObj.loyaltyEmail,
	"loyaltyFName": processMem.customerObj.loyaltyFName,
	"loyaltyId": processMem.customerObj.loyaltyId,
	"loyaltyLName": processMem.customerObj.loyaltyLName,
	"taxId":(processMem.customerObj.taxExemptInfo)?processMem.customerObj.taxExemptInfo.taxId:null,
	"taxExemptInfo":processMem.customerObj.taxExemptInfo,
	"resumeLayaway":1
	};
