var avlBal = parseFloat(processMem.availableBalance).toFixed(2).toString();
return {condition: avlBal == "0.00"}