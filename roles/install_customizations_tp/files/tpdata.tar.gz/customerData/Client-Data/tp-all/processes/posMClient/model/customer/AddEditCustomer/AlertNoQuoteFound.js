var outputParams = {
	messageType: 1,
	message: require("generic/ResourceManager").getValue("errorMessages.QuotesLookupError"),
	width: '30%'
};

return outputParams;