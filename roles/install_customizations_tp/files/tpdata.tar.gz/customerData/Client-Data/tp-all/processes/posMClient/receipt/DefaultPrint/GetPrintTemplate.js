var receiptTemplate = 'posMClient/printer/receipt2.handlebars';
if (window.printerPlugin != null) {
	var dvcObj = localStorage.getObject(dUUID);
	var printer = null;
	var printerVersion = null;
	if (dvcObj != null && dvcObj.peripherals != null) {
		for (var index = 0, length = dvcObj.peripherals.length; index < length; index++) {
			var peripheral = dvcObj.peripherals[index];
			if(peripheral.deviceCategory === 'Printer'){
				printerVersion = peripheral.deviceVersion;
				break;
			}
		}
    }
	
    receiptTemplate = "posMClient/printer/receipt2.handlebars";
}
else {
	receiptTemplate = 'posMClient/printer/receipt2.handlebars';
}

//Code to pass Store credit receipt
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

var storeCredittranTypeId = require("generic/Constants").TX_TY_UPDATE_STORECREDIT;
var suspendedTranTypeId = require("generic/Constants").TX_TY_SUSPENDED;
var currentTranObjTranType = currentTranObj.getTranTypeId();

if (currentTranObjTranType == storeCredittranTypeId)
{
	receiptTemplate = 'posMClient/printer/storeCreditReceipt.handlebars';
}
else if (currentTranObjTranType == suspendedTranTypeId){
	receiptTemplate = 'posMClient/printer/suspendReceipt.handlebars';
}
else if (currentTranObjTranType == require("generic/Constants").TX_TY_PAYINTRAN || 
		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYOUTTRAN || 
		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYINCORRTRAN ||
		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYOUTCORRTRAN
		){
	receiptTemplate = 'posMClient/printer/pipoReceipt.handlebars';
}

return { id: receiptTemplate };
