
var productId = processMem.current.productId || processMem.current.product.productId;
var isGC = (productId.indexOf("GC")==0 && (processMem.current.gcData.giftCertNum) && (processMem.current.gcData.giftCertNum)!=null);
 var sku = processMem.current.sku || processMem.current.product.sku;
if(sku == undefined || 
 sku == "" ||
 sku == "null" ||
 sku == null){
 	sku = productId;
 }
return {
	"productId": sku,
	"quantity": processMem.current.qty,
	"isScanned": processMem.current.isScanned,
	"salesPerson": processMem.current.salesPerson,
	"productTypes": (isGC)?["GiftCertificate"]:[processMem.current.productType],
	"gcAmount": processMem.current.amount,
	"forceAdd": 1,
	"fromReplayTran" : true,
	"propertiesJson" : processMem.current.propertiesJson
};