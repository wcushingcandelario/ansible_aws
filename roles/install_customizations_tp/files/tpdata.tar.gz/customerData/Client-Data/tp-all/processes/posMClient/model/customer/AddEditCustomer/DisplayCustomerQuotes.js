//
//
//
require(["posmclient/OVCSearchCenter.controller"], function (controller) {
	function getQuoteViewGrid() {
		var searchCenterViews = require("dijit/registry").byId('searchCenter').views;
		_.forEach(searchCenterViews, function (type) {
			var view = searchCenterViews[type];

			if (type === (require("generic/ResourceManager").getValue("searchCenter.quoteSearchType"))) {
				return view.grid;
			}
		});
	}

	controller.successfulQuoteLookup(getQuoteViewGrid(), inputParams);

});


// This needs to be put in an action as this is not what connectors are for
// grab the controller to populate the quotes table in the search center
//  var controller =

return {};