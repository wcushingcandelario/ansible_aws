var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var itemDate = new Date().getTime();
var amount;
if(processMem.isPartialPayment == true){
	if(parseFloat(processMem.availableBalance) > parseFloat(processMem.giftCardAmount)){
		amount = processMem.giftCardAmount;
	}
	else{
		amount = processMem.availableBalance;
	}
}
else{
	amount = processMem.giftCardAmount;
}

tranObj.addElectronicInternalTender(amount, itemDate, processMem.inputParams.tenderDetails, 
		processMem.inputParams.tenderDetails.id, false);