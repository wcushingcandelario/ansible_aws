var giftCardObj = [];
var response;
var returnData;
if(localStorage.getObject("returnData") != undefined || localStorage.getObject("returnData") != null){
	returnData = localStorage.getObject("returnData");
}

if(returnData != undefined && returnData != null){
	for(var i = 0; i < returnData.length; i++){
		if(returnData[i] != undefined){
			if(returnData[i].response){ //gc as item
				response = JSON.parse(returnData[i].response);
				response.giftCardRequestId = localStorage.getObject("giftCardRequestId");
			}
			else{ // gc as tender
				response = returnData[i];
				response.giftCardRequestId = require("dojox/uuid/generateRandomUuid")();
			}
		}
		//response.giftCardRequestId = localStorage.getObject("giftCardRequestId");
		giftCardObj.push(response);
	}
}
localStorage.setObject("giftCardObj", giftCardObj);

return {tranObj: inputParams.tranObj
		};