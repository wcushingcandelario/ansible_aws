return {
	moveFromId : "subMenuView",
	moveToId : "mainMenuView"
};
