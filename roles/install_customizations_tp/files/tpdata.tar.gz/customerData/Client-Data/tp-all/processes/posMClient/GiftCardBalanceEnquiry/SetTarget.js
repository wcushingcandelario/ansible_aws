processMem.resourceManager = require("generic/ResourceManager");
if(dijit.byId('txtSerialNumberEnquiry')){
	dijit.byId('txtSerialNumberEnquiry').destroy();
}
return { page: 'giftCardEnquiryPopup' };