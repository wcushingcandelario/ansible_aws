require('posmclient/OVCPosSubMenu.widget').closeSubMenu();
return {};