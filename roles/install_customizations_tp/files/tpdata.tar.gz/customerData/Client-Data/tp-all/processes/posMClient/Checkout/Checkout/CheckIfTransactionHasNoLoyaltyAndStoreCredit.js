processMem.inputParams = inputParams;
var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var storeCreditClicked = inputParams.isStoreCreditClicked;
require('posmclient/OVCPosSubMenu.states').setStoreCreditClicked(storeCreditClicked);
var conditionVal = (tranObj.getLoyaltyUser() == null && storeCreditClicked != undefined && storeCreditClicked == true) || 
	(tranObj.getLoyaltyUser() == null && tranObj.isLayaway());
if(localStorage.getObject("giftCardRequestId") == undefined || localStorage.getObject("giftCardRequestId") == null){
	localStorage.setObject("giftCardRequestId", require("dojox/uuid/generateRandomUuid")());
}

// check for loyalty even after coming to tenders page.
// possible that the customer was voided after adding
var isCustomerRequiredForReturn = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg").isCustomerRequiredForReturn;
if(tranObj.getTranTypeId() == require("generic/Constants").TX_TY_RETURN
	&& isCustomerRequiredForReturn != undefined && isCustomerRequiredForReturn == 1
	&& tranObj.getLoyaltyUser() == null){
	//conditionVal = true;
	conditionVal = checkIfCustomerPOPReq(tranObj);
}


function checkIfCustomerPOPReq(tranObj){
	var conditions = false;
	var allTranItems = tranObj._receiptJSON.allItems;
	var lenTran = allTranItems.length;
	for(var i = 0; i < lenTran; i++){
		if(allTranItems[i].reasonCode != null && allTranItems[i].reasonCode != undefined && allTranItems[i].reasonCode != ''){
			if(!allTranItems[i].isVoid){
				conditions = true;
			}
		}
	}
	return conditions;
}

return {
	condition: conditionVal
};