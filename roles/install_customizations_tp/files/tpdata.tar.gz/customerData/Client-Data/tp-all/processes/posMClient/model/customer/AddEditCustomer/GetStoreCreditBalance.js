var data = null;
if (processMem.inputParams.customerDetails && processMem.inputParams.customerDetails != null){
	data = processMem.inputParams.customerDetails.loyaltyId;
}

return { "data": { loyaltyId: data 
  				},
  		"service": 'GetCustomerStoreCreditBalance' 
	};