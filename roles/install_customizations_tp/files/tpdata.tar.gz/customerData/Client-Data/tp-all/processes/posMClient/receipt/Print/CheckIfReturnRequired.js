processMem.tranObj = inputParams.tranObj;     
  		  return { tranObj: processMem.tranObj };