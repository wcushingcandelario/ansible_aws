return { "data": { loyaltyId: processMem.loyaltyId
  				},
  		"service": 'GetCustomerStoreCreditBalance' 
	};