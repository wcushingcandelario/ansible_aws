var receiptTemplate = 'posMClient/printer/receipt2.handlebars';
var receiptType = inputParams.receiptType;

if (window.printerPlugin != null) {
	var dvcObj = localStorage.getObject(dUUID);
	var printer = null;
	var printerVersion = null;
	if (dvcObj != null && dvcObj.peripherals != null) {
		for (var index = 0, length = dvcObj.peripherals.length; index < length; index++) {
			var peripheral = dvcObj.peripherals[index];
			if(peripheral.deviceCategory === 'Printer'){
				printerVersion = peripheral.deviceVersion;
				break;
			}
		}
    }
    //Code for StoreCreditReceipt.Should consider creating an inputParam
    var storeCreditTranTypeId = require("generic/Constants").TX_TY_UPDATE_STORECREDIT;
    var currentTranObjTranType = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getTranTypeId();
	if (currentTranObjTranType == storeCreditTranTypeId) {
    	receiptType = "storeCredit";
    	inputParams.receiptType = receiptType;
    	processMem.inputParams.receiptType = receiptType;
    }
    else if (currentTranObjTranType == require("generic/Constants").TX_TY_SUSPENDED){
    	receiptTemplate = 'posMClient/printer/suspendReceipt.handlebars';
    	receiptType = "suspended";
    	processMem.inputParams.receiptType = "suspended";
    }
    else if (currentTranObjTranType == require("generic/Constants").TX_TY_PAYINTRAN || 
    		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYOUTTRAN || 
    		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYINCORRTRAN ||
    		 currentTranObjTranType == require("generic/Constants").TX_TY_PAYOUTCORRTRAN
    		){
    	receiptTemplate = 'posMClient/printer/pipoReceipt.handlebars';
    	receiptType = "pipo";
    	processMem.inputParams.receiptType = "pipo";
    }
    
    
    //end
    if (receiptType == "gift"){
    	receiptTemplate = "posMClient/printer/giftReceipt.handlebars";
    }
 	else if (receiptType == "duplicate"){
    	receiptTemplate = "posMClient/printer/duplicateReceipt2.handlebars";
    }
 	else if (receiptType == "storeCredit"){
    	receiptTemplate = "posMClient/printer/storeCreditReceipt.handlebars";
    }
 	else if (receiptType == "backdoor"){
 		receiptTemplate = "posMClient/printer/backDoorReceipt.handlebars";
 	}
 	else if (receiptType == ""){
 		receiptType = "regular";
    	processMem.inputParams.receiptType = "regular";
 	}

}
else {
	receiptTemplate = 'posMClient/printer/receipt2.handlebars';
}

return { id: receiptTemplate };
