var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

return { 
	"itemDate": processMem.current.itemDate,
	"amount": processMem.current.amount,
	"isStoreCreditApplied": (currentTranObj.isLayaway())?1:0
};