var response;
if(inputParams.response && inputParams.response.response){
	response = JSON.parse(inputParams.response.response);
}
processMem.availableBalance = response.balance;
return {condition: parseFloat(processMem.availableBalance) >= parseFloat(processMem.giftCardAmount)}//processMem.inputParams.amount}