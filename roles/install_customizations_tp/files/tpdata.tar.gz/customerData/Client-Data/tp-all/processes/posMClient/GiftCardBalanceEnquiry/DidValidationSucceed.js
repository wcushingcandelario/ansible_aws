require("ovc/UI").hideBlocker();
var response = inputParams.response.response;
response = JSON.parse(response);
var balance = parseFloat(response.balance).toFixed(2);
var PanNumber = response.panNumber;

var message;
if(response.errorCode == "0" || response.errorCode == "00"){
	message = "The balance for Gift Card " + PanNumber + " is: " + processMem.resourceManager.getValue("currency.symbol") + balance;
}
else{
	message = processMem.resourceManager.getValue("giftCard.errorCodes." + response.errorCode);
	if(message == undefined || message == null){
		message = response.errorMsg;
	}
}
return {
	title: processMem.resourceManager.getValue("giftCard.balanceEnquiry"),
	messageType: 3,
	message: message
};