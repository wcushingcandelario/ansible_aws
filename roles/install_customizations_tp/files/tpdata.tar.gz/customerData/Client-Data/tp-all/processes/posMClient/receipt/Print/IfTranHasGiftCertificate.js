var hasGiftCertificate = false;
var allItems = processMem.receiptObj.allItems;
var giftCertificateItems = [];

if(allItems != null) {
	for(var i = 0; i < allItems.length; i++) {
		if (allItems[i].isGC && allItems[i].cardAccountNumber != -1) {
			giftCertificateItems.push(allItems[i]);
			hasGiftCertificate = true;
		}
	}
	processMem.giftCertificateItems = giftCertificateItems;
}
//processMem.receiptObj = inputParams.receiptObj;
return { condition : (hasGiftCertificate) };