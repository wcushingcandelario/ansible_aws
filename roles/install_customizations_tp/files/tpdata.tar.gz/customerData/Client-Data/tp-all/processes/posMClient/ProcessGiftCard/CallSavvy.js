require("ovc/UI").showBlocker("Validating Gift Card with Savvy...", true);

processMem.giftCardAmount = inputParams.current.price;
processMem.giftCardSerialNumber = inputParams.current.itemNum;
if(processMem.returnData == undefined || processMem.returnData == null){
	processMem.returnData = [];
}

var Constants = require("generic/Constants");
var giftCardAmount = processMem.giftCardAmount;
var serviceName = "";

if(inputParams.current.itemType == Constants.ITEM_TY_GIFT_CARD_SALE){
	// new card, so activate
	serviceName = "GiftCardActivate";
}
else if(inputParams.current.itemType == Constants.ITEM_TY_GIFT_CARD_TOPUP){
	// refunding to a giftCard (putting money into a gift card / TopUp a gift card)
	serviceName = "GiftCardTopUp";
}

giftCardAmount = giftCardAmount.toString();

var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");

return { 
	"data": {
			"requestId": processMem.inputParams.requestId,
			"panNumber": processMem.giftCardSerialNumber,
			"amount": giftCardAmount,
			"cardCustCommId": posConfig.CardCustCommerceId,
			"mid": posConfig.SavvyMid,
			"encryptionKey": posConfig.EncyptionKey,
			"endPointUrl": posConfig.SavvyEndPoint
		},
	"service": serviceName 
	};