for (var i=0; i<processMem.formControlsArray.length; i++) {
	var name = processMem.formControlsArray[i].name;
	if (inputParams.value[name]) {
		processMem.formControlsArray[i].value = inputParams.value[name];
	}
}

return {
	customerDetails: inputParams.value
};