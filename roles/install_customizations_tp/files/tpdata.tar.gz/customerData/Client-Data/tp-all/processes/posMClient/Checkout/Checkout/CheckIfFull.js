var deferred = new Deferred;

require(["generic/GenericUtils", "posmclient/OVCPosMainMenu.widget"], function (GenericUtils, OVCPosMainMenu) {
	
	// When coming from PromptForTenderAmount, in the switchId="closed" case, we don't
	// call ProcessPayment, which doesn't connect through RenderReceipt, who puts tenderSuccessful in processMem. So,
	// we need to make sure it isn't undefined here.
	if (typeof processMem.tenderSuccessful == 'undefined') {
		processMem.tenderSuccessful = false;
	}
	if (typeof processMem.userEnteredValidAmount == 'undefined') {
		processMem.userEnteredValidAmount = false;
	}

	// Penny rounding, when enabled in payment.ovccfg, complicates the "is full" check. If the balance is $1.52, penny
	// rounding is enabled, and the user is paying cash; then the prompt amount will have been $1.50, we'll have a -2 value
	// for 'penniesRounded', and we have to take that into consideration.
	// If it weren't for penny rounding, it would be sufficient to check processMem.amount == processMem.balance.
	var dollarsRounded = GenericUtils.penniesToDollars(processMem.penniesRounded);
	var amountCoversBalance = 0;
	if(processMem.balance < 0){
		amountCoversBalance = (Math.abs(processMem.amount) >= Math.abs(GenericUtils.currencyRound(processMem.balance + dollarsRounded)));
	}else{
		amountCoversBalance = (processMem.amount >= GenericUtils.currencyRound(processMem.balance + dollarsRounded));
	}
	
	var changeNeeded = processMem.changeAmt != 0;

	var theCondition = false;
	var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
	theCondition = processMem.tenderSuccessful && amountCoversBalance && processMem.userEnteredValidAmount;
	console.log("full condition::::"+theCondition);
	if(!theCondition){
		OVCPosMainMenu.enableDisablePOSButtons();
	}
	deferred.resolve({
		condition : theCondition
	});
	
});

return deferred;