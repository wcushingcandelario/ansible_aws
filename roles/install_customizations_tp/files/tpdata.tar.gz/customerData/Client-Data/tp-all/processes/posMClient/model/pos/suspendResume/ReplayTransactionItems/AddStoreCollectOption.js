 var tenderDetails = {};
try{
	tenderDetails = JSON.parse(processMem.current.tenderDetails);
}catch(e){
	if(processMem.current.tenderDetails.propertiesJson != null){
		tenderDetails = processMem.current.tenderDetails;
	} 
}



var data = {
				address: tenderDetails.propertiesJson.address,
				deliveryTime: tenderDetails.propertiesJson.deliveryDate, 
				skus : tenderDetails.propertiesJson.skus,
				type : processMem.current.itemType,
				lastRefIndex: processMem.current.refItemIdx
			};					
 
	if(tenderDetails.propertiesJson.refItemIndices && tenderDetails.propertiesJson.refItemIndices != null){
		var refItemIndices =  tenderDetails.propertiesJson.refItemIndices.split(",");
		data.refItemIdx = [];
		_.forEach(refItemIndices, function (refItemIdxItem, key) { 
			data.refItemIdx.push({refIdx : refItemIdxItem});
		})
	}			 
 
      
return {
	"data": data 
};