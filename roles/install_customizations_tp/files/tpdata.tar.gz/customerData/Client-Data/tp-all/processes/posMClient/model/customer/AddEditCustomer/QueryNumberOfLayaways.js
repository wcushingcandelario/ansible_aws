processMem.storeCreditBalance = inputParams.response.balance;

return { "data": { loyaltyId: processMem.inputParams.customerDetails.loyaltyId },
  		"service": 'GetNumberOfLayawaysByLoyaltyId' 
	};