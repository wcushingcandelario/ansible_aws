var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
 
 for(i in processMem.productMapping){
 	tranObj.voidItem(processMem.productMapping[i], "0000");
}
tranObj.setQuote();

return {
	tranObj: tranObj,
	fromMainMenu: true
};