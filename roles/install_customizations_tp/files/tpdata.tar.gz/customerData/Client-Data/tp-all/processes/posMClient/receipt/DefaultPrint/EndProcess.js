var receiptObj = inputParams.receiptObj;
var Constants = require("generic/Constants");
var configManager = require("ovc/ConfigManager");
var ResourceManager = require("generic/ResourceManager");

if (receiptObj.tranTypeId == Constants.TX_TY_SUSPENDED){
	// resource bundle for Parked Tran Receipt
	receiptObj.parkedTranHeader = ResourceManager.getValue("printReceipt.parkedTranHeader");
	receiptObj.parkedTranInstr = ResourceManager.getValue("printReceipt.parkedTranInstr");
	receiptObj.parkedTranTotal = ResourceManager.getValue("printReceipt.parkedTranTotal");
	receiptObj.parkedTranNoOfItems = ResourceManager.getValue("printReceipt.parkedTranNoOfItems");
}
else if (receiptObj.tranTypeId == Constants.TX_TY_PAYINTRAN){
	receiptObj.pipoText = ResourceManager.getValue("printReceipt.payInTotal");
}
else if (receiptObj.tranTypeId == Constants.TX_TY_PAYOUTTRAN){
	receiptObj.pipoText = ResourceManager.getValue("printReceipt.paidOutTotal");
}
else if (receiptObj.tranTypeId == Constants.TX_TY_PAYINCORRTRAN){
	receiptObj.pipoText = ResourceManager.getValue("printReceipt.payInCorrTotal");
}
else if (receiptObj.tranTypeId == Constants.TX_TY_PAYOUTCORRTRAN){
	receiptObj.pipoText = ResourceManager.getValue("printReceipt.payOutCorrTotal");
}

if(receiptObj.tranTypeId == Constants.TX_TY_PAYINTRAN || 
	receiptObj.tranTypeId == Constants.TX_TY_PAYOUTTRAN || 
	receiptObj.tranTypeId == Constants.TX_TY_PAYINCORRTRAN ||
	receiptObj.tranTypeId == Constants.TX_TY_PAYOUTCORRTRAN){
for(var i =0; i < receiptObj.nonVoidItems.length; i++){
		currencySymbol = ResourceManager.getValue("currency.symbol");
		if(receiptObj.nonVoidItems[i].amount && receiptObj.nonVoidItems[i].amount != null){
			if(!receiptObj.nonVoidItems[i].amount.indexOf(currencySymbol) > -1 ){
				if(parseFloat(receiptObj.nonVoidItems[i].amount)<0){
					receiptObj.nonVoidItems[i].amount = receiptObj.nonVoidItems[i].amount.replace("-", "");
					receiptObj.nonVoidItems[i].amount = "-" + currencySymbol + receiptObj.nonVoidItems[i].amount;
				}
				else{
					receiptObj.nonVoidItems[i].amount = currencySymbol + receiptObj.nonVoidItems[i].amount;
				}
			}
		}
	}
}
//resource bundle for backdoor receipt
var isBackdoor = configManager.getConfigObject("posMClient/sales.ovccfg").allowBackdoorDelivery;
if (isBackdoor != undefined && isBackdoor != null && isBackdoor == 1){
	receiptObj.backGateCollection = ResourceManager.getValue("printReceipt.backDoorReceipt.backGateCollection");
	receiptObj.customerInstructions = ResourceManager.getValue("printReceipt.backDoorReceipt.customerInstructions");
	receiptObj.backDoorInstr = ResourceManager.getValue("printReceipt.backDoorReceipt.backDoorInstr");
	receiptObj.goodsCollection = ResourceManager.getValue("printReceipt.backDoorReceipt.goodsCollection");
	receiptObj.customerSign = ResourceManager.getValue("printReceipt.backDoorReceipt.customerSign");
	receiptObj.receivedGoods = ResourceManager.getValue("printReceipt.backDoorReceipt.receivedGoods");
}

// Exchange receipt conditions:
var isExchangeReceiptOn = configManager.getConfigObject("posMClient/sales.ovccfg").allowExchangeReceipt;
if(isExchangeReceiptOn != undefined && isExchangeReceiptOn != null && isExchangeReceiptOn == 1){ //if exchange receipt config is on.
	if(receiptObj.summary.total == 0){ // proceed if total amount of tran is 0
		var refundItemsCount = 0;
		var saleItemsCount = 0;
		for (var i = 0; i < receiptObj.nonVoidItems.length; i++){ // loop items to count refunds and sale
			if(receiptObj.nonVoidItems[i].itemType == Constants.ITEM_TY_ADD_PRODUCT){
				saleItemsCount += 1;
			}
			else if (receiptObj.nonVoidItems[i].itemType == Constants.ITEM_TY_REFUND_PRODUCT){
				refundItemsCount += 1;
			}
		}
		
		if(refundItemsCount > 0 && saleItemsCount > 0){ // proceed if atleast one refund item, and one product added
			receiptObj.exchangeText = ResourceManager.getValue("printReceipt.exchangeText");
			receiptObj.exchangeNoCash = ResourceManager.getValue("printReceipt.exchangeNoCash");
		}
	}
}

//add fsc flag to the item
for(var i =0; i < receiptObj.nonVoidItems.length; i++){
	if(receiptObj.nonVoidItems[i].itemType == Constants.ITEM_TY_ADD_PRODUCT){
	var certificationsMetFlag = receiptObj.nonVoidItems[i].propertiesJson.products.certificationsMet;
		if(certificationsMetFlag != undefined && certificationsMetFlag != ''){
			receiptObj.nonVoidItems[i].fsc = ""+receiptObj.nonVoidItems[i].propertiesJson.products.certificationsMet;
		}else{
			receiptObj.nonVoidItems[i].fsc = "";
		}
	}
}
var receiptHeader =  localStorage.getObject("location").receiptHeader;
if(receiptHeader == null){
	receiptHeader = ResourceManager.getValue("printReceipt.visitUsAt")+"\r"+
			ResourceManager.getValue("printReceipt.website");
}

var receiptFooter =  localStorage.getObject("location").receiptFooter;
if(receiptFooter == null){
	receiptFooter = ResourceManager.getValue("printReceipt.thanksForShopping");
}
receiptObj.receiptHeader = receiptHeader;
receiptObj.receiptFooter = receiptFooter;
//receiptObj.website = ResourceManager.getValue("printReceipt.website");
receiptObj.telephone = ResourceManager.getValue("printReceipt.telephone");
receiptObj.vatNumber = ResourceManager.getValue("printReceipt.vatNumber");
receiptObj.associate = ResourceManager.getValue("printReceipt.associate");
receiptObj.amountTendered = ResourceManager.getValue("printReceipt.amountTendered");
//receiptObj.thanksForShopping = ResourceManager.getValue("printReceipt.thanksForShopping");
receiptObj.saleText = ResourceManager.getValue("printReceipt.saleText");
receiptObj.customerDetails = ResourceManager.getValue("printReceipt.customerDetails");
receiptObj.name = ResourceManager.getValue("printReceipt.name");
receiptObj.storeCreditBalance = ResourceManager.getValue("printReceipt.storeCreditBalance");
receiptObj.additionalCredit = ResourceManager.getValue("printReceipt.additionalCredit");
receiptObj.newStoreCreditBalance = ResourceManager.getValue("printReceipt.newStoreCreditBalance");
receiptObj.previous = ResourceManager.getValue("printReceipt.previous");
receiptObj.subtotal = ResourceManager.getValue("printReceipt.subtotal");
receiptObj.items = ResourceManager.getValue("printReceipt.items");
receiptObj.discountSavings = ResourceManager.getValue("printReceipt.discountSavings");
receiptObj.promoSavings = ResourceManager.getValue("printReceipt.promoSavings");
receiptObj.gcBalance = ResourceManager.getValue("printReceipt.gcBalance");
receiptObj.totalPayment = ResourceManager.getValue("printReceipt.totalPayment");
receiptObj.change = ResourceManager.getValue("printReceipt.change");
receiptObj.layawayBalance = ResourceManager.getValue("printReceipt.layawayBalance");
receiptObj.issueDate = ResourceManager.getValue("printReceipt.issueDate");
receiptObj.amountText = ResourceManager.getValue("printReceipt.amountText");
receiptObj.validUntil = ResourceManager.getValue("printReceipt.validUntil");
receiptObj.operatorSignature = ResourceManager.getValue("printReceipt.operatorSignature");
receiptObj.supervisorSignature = ResourceManager.getValue("printReceipt.supervisorSignature");
receiptObj.paidOutTotal = ResourceManager.getValue("printReceipt.paidOutTotal");
receiptObj.totalVAT = ResourceManager.getValue("printReceipt.totalVAT");
receiptObj.pipoPaid = ResourceManager.getValue("printReceipt.pipoPaid");

return { 
		template : processMem.template,
		receiptObj: receiptObj
	};