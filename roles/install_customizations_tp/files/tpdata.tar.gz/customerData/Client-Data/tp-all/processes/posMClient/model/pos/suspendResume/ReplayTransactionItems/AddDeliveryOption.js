var tenderDetails = {};
try{
	tenderDetails = JSON.parse(processMem.current.tenderDetails);
}catch(e){
	if(processMem.current.tenderDetails.propertiesJson != null){
		tenderDetails = processMem.current.tenderDetails;
	} 
}

var data = {
				address: tenderDetails.propertiesJson.address,
				deliveryData: tenderDetails.propertiesJson.deliveryData,
				deliveryTime: tenderDetails.propertiesJson.deliveryTime,
				deliveryDate: tenderDetails.propertiesJson.deliveryDate,
				productObj: processMem.current
			};					
data.refItemIdx = [{refIdx:processMem.current.refItemIdx, shippingCost: processMem.current.amount}];
data.type = processMem.current.itemType;					 

return {
	"data": data,
	"refIdx": processMem.current.refItemIdx
};