// if promotion in transaction treat this as a recovery
var isPromotion = false;
_.forEach(processMem.inputParams.tranItems, function(tranItem) {
	if (tranItem.itemType === require("generic/Constants").ITEM_TY_PROMO) {
		isPromotion = true;
	}
});
return {condition: (processMem.inputParams.resumeType != null && processMem.inputParams.resumeType != "RECOVERY" && isPromotion === false)};
