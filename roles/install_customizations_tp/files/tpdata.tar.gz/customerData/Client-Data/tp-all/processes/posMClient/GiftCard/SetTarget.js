if(dijit.byId('txtSerialNumber')){
	dijit.byId('txtSerialNumber').destroy();
}

return { page: 'giftCardPopup' };