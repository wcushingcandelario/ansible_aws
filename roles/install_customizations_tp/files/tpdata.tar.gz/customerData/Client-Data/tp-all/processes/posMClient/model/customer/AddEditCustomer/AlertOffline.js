return {
	messageType: 2,
	message: require("generic/ResourceManager").getValue("customers.limitedDetails")
};