
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj(); 

processMem.amount = inputParams.amount;
processMem.itemDate = inputParams.itemDate;

return {
	amount: -inputParams.amount
};