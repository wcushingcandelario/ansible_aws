var condition = true;
var ResourceManager = require("generic/ResourceManager");
var paymentConfig = require("ovc/ConfigManager").getConfigObject("posMClient/payment.ovccfg");
var StringUtils = require('generic/StringUtils');
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

processMem.serialNumber = inputParams.value.txtSerialNumber;
processMem.amount = inputParams.value.txtAmount;

if(processMem.maxGiftCardsInTran != undefined && processMem.maxGiftCardsInTran != null &&
		processMem.maxGiftCardValue != processMem && processMem.maxGiftCardValue != null){
	if (processMem.amount > processMem.maxGiftCardValue){
		processMem.alertUser = ResourceManager.getValue("pos.maxGiftCardValue") + " " + processMem.maxGiftCardValue;
		condition = false;
	}
}
var nonVoidItems = [];
if(currentTranObj.getReceiptJSON().nonVoidItems != undefined){
	nonVoidItems = currentTranObj.getReceiptJSON().nonVoidItems;
}

// Check for invalid entry
if(isNaN(inputParams.value.txtAmount) || (parseFloat(inputParams.value.txtAmount) <= 0)){
	processMem.alertUser = ResourceManager.getValue("giftCard.enterValidAmount");
	condition = false;
}
else if(paymentConfig.minAmountToReturnToGiftCard != null &&
		paymentConfig.minAmountToReturnToGiftCard != undefined &&
		((parseFloat(inputParams.value.txtAmount) < paymentConfig.minAmountToReturnToGiftCard))){
		
		var decimalPrecision = ResourceManager.getValue("currency.precision");
		processMem.alertUser = ResourceManager.getValue("giftCard.enterMoreThanMinAmount") + " " + 
			StringUtils.numberToCurrencyString(paymentConfig.minAmountToReturnToGiftCard, 2, true);
		
		condition = false;
}
else{
	// do not allow same card to be added to the receipt more than once 
	for(var i = 0; i < nonVoidItems.length; i++){
		if(processMem.serialNumber == nonVoidItems[i].itemNum){
			processMem.alertUser = ResourceManager.getValue("giftCard.cardAlreadyAdded");
			condition = false;
			break;
		}
	}
}

return {condition: condition};