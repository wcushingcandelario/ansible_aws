var message = require("generic/ResourceManager").getValue('checkout.zeroStoreCredit');
processMem.inputParams.isStoreCreditClicked = false;
return {
	message: message
};