var tranItems =  processMem.inputParams.tranItems;
processMem.customerObj = null;
var count;
if (inputParams.loyaltyId && inputParams.loyaltyId == "unknown" &&
	processMem.inputParams.tranItems && processMem.inputParams.tranItems.length > 0) {
	//skipping the display of voided Customers for internal recalc
	var customerItemIdx = [];
	count = 0;
	while (count < tranItems.length) {
		if (tranItems[count].itemType == require('generic/Constants').ITEM_TY_VOID_LOYALTY_ID) {
			customerItemIdx.push(tranItems[count].refItemIdx);
			customerItemIdx.push(tranItems[count].itemIdx);
		}
		count++;
	}  
	var pos = 0;
	var customerObj = null;
	if (customerItemIdx.length > 0) {
		_.forEach(tranItems, function (tranItem) {
			//skipping the display of voidCustomer Marker items and Voided customer items 
			if ((-1 == customerItemIdx.indexOf(tranItem.itemIdx)) &&
				(tranItem.itemType == require('generic/Constants').ITEM_TY_LOYALTY_ID)) {
				processMem.customerObj = {
					"loyaltyId": tranItem.loyaltyId,
					"loyaltyFName": tranItem.loyaltyFName,
					"loyaltyLName": tranItem.loyaltyLName,
					"loyaltyEmail": tranItem.loyaltyEmail,
					"taxExemptInfo": tranItem.taxExemptInfo
				};
			}
		});
	} else {
		count = 0;
		var customerItem = null;
		while(count < tranItems.length){ 
			if(tranItems[count].itemType == require('generic/Constants').ITEM_TY_LOYALTY_ID ){   
				customerItem = tranItems[count];	
				break;			 
			}
			count++;
		}  
		processMem.customerObj = {
			"loyaltyId": customerItem.loyaltyId,
			"loyaltyFName": customerItem.loyaltyFName,
			"loyaltyLName": customerItem.loyaltyLName,
			"loyaltyEmail": customerItem.loyaltyEmail,
			"taxExemptInfo": customerItem.taxExemptInfo
		};
	}
} else {
	processMem.customerObj = {
		"loyaltyId": inputParams.loyaltyId || processMem.current.loyaltyId,
		"loyaltyFName": inputParams.loyaltyFName || processMem.current.loyaltyFName,
		"loyaltyLName": inputParams.loyaltyLName || processMem.current.loyaltyLName,
		"loyaltyEmail": inputParams.loyaltyEmail || processMem.current.loyaltyEmail,
		"taxExemptInfo": inputParams.taxExemptInfo || processMem.current.taxExemptInfo
	};
}


var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
return {
	condition: (processMem.customerObj != null && currentTranObj.isLayaway())
};