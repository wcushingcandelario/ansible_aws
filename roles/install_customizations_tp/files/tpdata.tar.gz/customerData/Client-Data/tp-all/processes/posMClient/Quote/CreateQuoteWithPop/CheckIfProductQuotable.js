processMem.productMapping = [];
	var noQuoteProductInTran = false;
	var Constants = require("generic/Constants");
	var productStockDetailsStr = "<br>" +  require("generic/ResourceManager").getValue("pos.QuoteNotAvailable");
	productStockDetailsStr += "<br><table width=100% border=1>";
	var tran = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
	var tranIems = tran.getTranItems();
	var totalNonQuotableProductsCount = 0;
	var totalProductsCount = 0;
	for (var i = 0; i < tranIems.length; i++) {
		var tranItem = tranIems[i]; 
 		if(tranItem != null  && tranItem.getProduct() != null && (tranItem.getItemType() === Constants.ITEM_TY_ADD_PRODUCT 
				|| tranItem.getItemType() === Constants.ITEM_TY_REFUND_PRODUCT 
				|| tranItem.getItemType() === Constants.ITEM_TY_ADD_SITE_PICKUP_PRODUCT 
				|| tranItem.getItemType() === Constants.ITEM_TY_ADD_STORE_PICKUP_PRODUCT 
				|| tranItem.getItemType() === Constants.ITEM_TY_APPOINTMENT) && !tran.isItemVoidByIdx(tranItem.getItemIdx()))
		{
			totalProductsCount++;
			var propertiesJson =  tranItem.getProduct().getProductJson(); 
			if(propertiesJson && propertiesJson != null &&
				propertiesJson.products && propertiesJson.products != null
			){  
				
			   	productStockDetailsStr += "<tr style=\"margin:10%;top:10% !important\">";
				productStockDetailsStr += "<td width=\"80%\" align=\"center\">";
				productStockDetailsStr += tranItem.getProduct().getName();
				productStockDetailsStr += "</td>";
				
			   	 if(propertiesJson.products.isQuotable !=undefined && 
			   			propertiesJson.products.isQuotable != null && 
			   			propertiesJson.products.isQuotable != "1"){
			   	  	noQuoteProductInTran = true; 
			   	  	processMem.productMapping.push(tranItem.getItemIdx());
			   		productStockDetailsStr += "<td width=\"20%\" align=\"center\">No</td>"; 
			   		totalNonQuotableProductsCount++;
			   	}else{
			   		productStockDetailsStr += "<td width=\"20%\" align=\"center\">Yes</td>"; 
				}
				productStockDetailsStr += "</tr>";
			}  
		}
	}
	
if(totalNonQuotableProductsCount == 1 && totalProductsCount == 1){
	processMem.onlyOneProduct = true;
}	 

productStockDetailsStr += "</table>";
processMem.productStockDetailsStr = productStockDetailsStr;
return { condition : noQuoteProductInTran };