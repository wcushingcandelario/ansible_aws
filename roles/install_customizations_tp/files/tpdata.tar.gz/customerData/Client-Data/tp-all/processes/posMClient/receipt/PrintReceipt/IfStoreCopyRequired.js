var rType = processMem.inputParams.receiptType;
if(rType == null){
	rType = processMem.inputParams.paramsMap.receiptType;
	processMem.rType = rType;
}
var receiptTypeConfigs =  require("ovc/ConfigManager").getConfigObject("posMClient/receipts.ovccfg")[rType];
var condition = true;
if(receiptTypeConfigs != undefined && receiptTypeConfigs != null){
	condition = receiptTypeConfigs.isStoreCopyRequired;
}
return { condition: condition };
