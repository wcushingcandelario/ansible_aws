//inputParams.paramsJson = {"backViewId":processMem.inputParams.moveFromId};
//
//if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().isLayawayPayment()){
//	inputParams.paramsJson.labelChanges = {"completeDepositMenuButton":"RSRC(menus.checkout.completepayment)"};
//}
return inputParams;