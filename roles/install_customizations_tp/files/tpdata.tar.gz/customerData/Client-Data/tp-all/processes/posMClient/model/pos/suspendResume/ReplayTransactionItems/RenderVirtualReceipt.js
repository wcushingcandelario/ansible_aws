require("posmclient/RetailTransactionHelper").getCurrentTranObj().setCurrentMode(require("generic/Constants").TRAN_CURRENT_MODE_NORMAL);
return {};