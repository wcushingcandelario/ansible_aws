for (var i=0; i<processMem.formControlsArray.length; i++) {
	var name = processMem.formControlsArray[i].name;
	if (inputParams.value[name]) {
		processMem.formControlsArray[i].value = inputParams.value[name];
	}
}
inputParams.value.VRcustomerPOP = true;

return {
	customerDetails: inputParams.value
};