require("ovc/UI").showBlocker("Validating Gift Card with Savvy...", true);
/*processMem.giftCardAmount = inputParams.value.txtAmount;
processMem.giftCardSerialNumber = inputParams.value.txtSerialNumber;
processMem.inputParams.tenderDetails.giftCardSerialNumber = processMem.giftCardSerialNumber;*/
if(processMem.returnData == undefined || processMem.returnData == null){
	processMem.returnData = [];
}
var giftCardAmount;
var serviceName = "";
if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().getBalance() > 0){
	// paying for goods
	serviceName = "GiftCardPayForGoods";
	if(processMem.isPartialPayment == true){
		if(parseFloat(processMem.availableBalance) > parseFloat(processMem.giftCardAmount)){
			giftCardAmount = processMem.giftCardAmount;
		}
		else{
			giftCardAmount = processMem.availableBalance;
		}
	}
	else{
		giftCardAmount = processMem.giftCardAmount;
	}
}
else{
	// refunding to a giftCard (putting money into a gift card / TopUp a gift card)
	serviceName = "GiftCardTopUp";
	if(processMem.isPartialPayment == true){
		giftCardAmount = 0 - processMem.availableBalance;
	}
	else{
		giftCardAmount = 0 - processMem.giftCardAmount;
	}
}

giftCardAmount = giftCardAmount.toString();

var posConfig = require("ovc/ConfigManager").getConfigObject("posMClient/pos.ovccfg");

return {
	"data": {
		"requestId": processMem.inputParams.tenderDetails.giftCardRequestId,
		"panNumber": processMem.giftCardSerialNumber,
		"amount": giftCardAmount,
		"cardCustCommId": posConfig.CardCustCommerceId,
		"mid": posConfig.SavvyMid,
		"encryptionKey": posConfig.EncyptionKey,
		"endPointUrl": posConfig.SavvyEndPoint
		},
	"service": serviceName 
	};