var deliverServiceCallBlocker = require("generic/ResourceManager").getValue("menus.deliveryOptions.shippingSearch");
require("posmclient/OVCDynamicDialog.widget").showBlocker(deliverServiceCallBlocker, true);

var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var postCode = "";

_.forEach(processMem.address, function(address) {
	if (address.name === "postalCode") {
		postCode = address.value;
	}
});

var products = [];
var productAttributes = {};
_.forEach(tranObj._calculatedTranItems, function(tranItem) {
	var productData = tranItem._productObj._propertiesJson.products;
	productAttributes.qty = tranObj._calculatedTranItems[j]._qty;
	productAttributes.fulfilmentType = productData.fulfilmentType;
	productAttributes.gpid = productData.gpid;

});

var data = {
	brand: "wickes",
	deliveryPostcode: postCode,
	total: tranObj._total * 100,
	dateTime: new Date(),
	entries: [{
		gpid: productAttributes.gpid,//"1000491768", //in proplerties json productAttributes.qty productAttributes.gpid
		fulfilmentType: productAttributes.fulfilmentType,//"BIG_AND_BULKY", // in properties json productAttributes.fulfilmentType
		qty: productAttributes.qty
	}]
};

return {
	"data": {
		"data":data
	},
	"service": "DayOfChoice"
};