var deferred = new Deferred();
inputParams.template = processMem.template;
var paramsMap = {};

require(["generic/StringUtils", "generic/ResourceManager"], function(StringUtils, ResourceManager){

	var uObj = localStorage.getObject(username);
	paramsMap.storeName = localStorage.getObject("location").displayName;
	paramsMap.storeAddress = localStorage.getObject("location").streetNumber+", "+localStorage.getObject("location").streetName;
	paramsMap.storeTown = localStorage.getObject("location").town+"       "+localStorage.getObject("location").postalCode;
	paramsMap.storeTel = localStorage.getObject("location").phone;
	paramsMap.storeVat = localStorage.getObject("location").taxIdentifier;
	paramsMap.telephone = ResourceManager.getValue("printReceipt.telephone");
	paramsMap.vatNumber = ResourceManager.getValue("printReceipt.vatNumber");
	paramsMap.trainingMode = localStorage.getObject("trainingMode");
	paramsMap.visitUsAt = ResourceManager.getValue("printReceipt.visitUsAt");
	paramsMap.website = ResourceManager.getValue("printReceipt.website");
	paramsMap.dateString = StringUtils.getLocaleDateFormat();
	paramsMap.associate = ResourceManager.getValue("printReceipt.associate");
	paramsMap.employee = uObj.firstName + " " + uObj.lastName;
	paramsMap.receiptHeading = ResourceManager.getValue("printReceipt.giftCardReceiptHeader");
	if((inputParams.current.itemNum != undefined && inputParams.current.itemNum != null) ||
		(inputParams.current.properties.panNumber != undefined && inputParams.current.properties.panNumber != null)){
		var panNum;
		if(inputParams.current.properties != undefined && inputParams.current.properties.panNumber != undefined){
			panNum = inputParams.current.properties.panNumber;
		}
		else{
			panNum = inputParams.current.itemNum;
		}
		paramsMap.panNumber = "************" + 
		panNum.substring(panNum.length - 4, panNum.length);
	}
	
	
	paramsMap.giftCardNumberText = ResourceManager.getValue("printReceipt.giftCarNumber");
	paramsMap.purchaseValue = ResourceManager.getValue("printReceipt.purchaseValue");
	

	if(parseFloat(inputParams.current.price)<0){
		inputParams.current.price = inputParams.current.price.toString().replace("-", "");
		inputParams.current.price = "-" + ResourceManager.getValue("currency.symbol") + parseFloat(inputParams.current.price).toFixed(2).toString();
	}
	else{
		inputParams.current.price = ResourceManager.getValue("currency.symbol") + parseFloat(inputParams.current.price).toFixed(2).toString();
	}
	
	
	paramsMap.giftCardAmount = inputParams.current.price;
	paramsMap.sale = ResourceManager.getValue("printReceipt.sale");
	paramsMap.successful = ResourceManager.getValue("printReceipt.successful");
	paramsMap.balance = ResourceManager.getValue("printReceipt.balance");
	
	
	if(inputParams.current.properties != undefined && inputParams.current.properties != null){
		if(inputParams.current.properties.balance != undefined && inputParams.current.properties.balance != null){
			paramsMap.newBalance = ResourceManager.getValue("currency.symbol") + parseFloat(inputParams.current.properties.balance).toFixed(2).toString();
		}
		if(inputParams.current.properties.giftCardRequestId != undefined && inputParams.current.properties.giftCardRequestId != null){
			paramsMap.giftCardReqId = "************" + 
			inputParams.current.properties.giftCardRequestId.substring(inputParams.current.properties.giftCardRequestId.length - 4, 
															inputParams.current.properties.giftCardRequestId.length);
		}
		if(inputParams.current.properties.authCode != undefined && inputParams.current.properties.authCode != null){
			paramsMap.authCode = inputParams.current.properties.authCode;
		}
	}
	
	
	paramsMap.referenceId = ResourceManager.getValue("printReceipt.referenceId");
	paramsMap.gcAuthCode = ResourceManager.getValue("printReceipt.gcAuthCode");
	paramsMap.thanksForShopping = ResourceManager.getValue("printReceipt.thanksForShopping");
	
	deferred.resolve({
		templateSrc: inputParams.template,
		paramsMap: paramsMap
	});
	
});

return deferred.promise;
