var numberOfQuotes = processMem.customerQuoteIdList;

var switchId = "";
if ( numberOfQuotes && numberOfQuotes.length === 1) {
	switchId = "selectQuote";
} else if ( numberOfQuotes && numberOfQuotes.length > 1) {
	switchId = "showQuoteList";
} else {
	switchId = "noQuotes";
}

return {
	switchCase: switchId
};