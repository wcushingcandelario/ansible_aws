return { 
	"customerType": processMem.current.reasonCodeId
};