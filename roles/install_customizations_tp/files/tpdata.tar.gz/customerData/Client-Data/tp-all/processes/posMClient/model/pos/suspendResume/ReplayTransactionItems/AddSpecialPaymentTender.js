return { 
	"itemDate": processMem.current.itemDate,
	"reasonCodeId" : processMem.tenderReasonCode,
	"amount": processMem.current.amount
};