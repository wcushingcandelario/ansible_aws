require("ovc/UI").hideBlocker();
processMem.tenderSuccessful = false;
if(processMem.returnData != undefined && processMem.returnData != null){
	processMem.returnData.push(inputParams);
}
else{
	processMem.returnData = [];
	processMem.returnData.push(inputParams);
}


return {
	title: processMem.resourceManager.getValue("giftCard.savvyValidation"),
	message: processMem.resourceManager.getValue("giftCard.savvyUnavailable")
};