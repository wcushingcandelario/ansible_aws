var tenderDetails = processMem.current.tenderDetails;
if(typeof tenderDetails == "string"){
	tenderDetails = require('dojo/_base/json').fromJson(processMem.current.tenderDetails);
}

var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

return {
    "itemDate": processMem.current.itemDate,
    "tenderId": processMem.current.tenderId,
    "tenderDetails": tenderDetails,
    "amount": processMem.current.amount,
    "isStoreCreditApplied": (currentTranObj.isLayaway())?1:0
};
