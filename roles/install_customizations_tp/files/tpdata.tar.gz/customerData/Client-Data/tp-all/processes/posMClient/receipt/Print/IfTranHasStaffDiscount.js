//debugger;//IfTranHasStaffDiscount.js
var nonVoidItems = processMem.receiptObj.nonVoidItems;
var returnItems = [];
var hasStaffDiscountItem = false

var salesConfig =  require("ovc/ConfigManager").getConfigObject("posMClient/sales.ovccfg");
var staffDiscountReceiptConfig = salesConfig.isStaffDiscountReceiptRequired;


if(nonVoidItems != null) {
	for(var i = 0; i < nonVoidItems.length; i++) {
		if (nonVoidItems[i].itemType == require("generic/Constants").ITEM_TY_DISCOUNT_TXN && nonVoidItems[i].employeeId != undefined && nonVoidItems[i].employeeId != null) {
			
			if(staffDiscountReceiptConfig == 1){
					returnItems.push(nonVoidItems[i]);
					hasStaffDiscountItem = true;			
			}
		}
		processMem.returnItems = returnItems;
	}
}
return { condition : (hasStaffDiscountItem) };