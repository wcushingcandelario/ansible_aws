return { "sqlQuery": "select name, description from product_tbl where id=?",
         "paramsArr": [processMem.current.productId] };