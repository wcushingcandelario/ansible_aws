var reasonCodeId = processMem.current.reasonCodeId;
var reasonDesc = '';
 if(reasonCodeId === '' || typeof inputParams.resultSet === 'undefined'){
	reasonDesc = require("generic/ResourceManager").getValue('virtualReceipt.tranDiscount');
} else {
	if(inputParams.resultSet.length > 0 &&  (inputParams.resultSet[0] && inputParams.resultSet[0]!=null))
		reasonDesc =  inputParams.resultSet[0].description;
}

var employeeId = "";
if(processMem.current.tenderDetails !== null && processMem.current.tenderDetails !== undefined && processMem.current.tenderDetails !== {}
	&& processMem.current.tenderDetails !== "{}" && processMem.current.tenderDetails !== "null"){
	if(processMem.current.tenderDetails && processMem.current.tenderDetails.propertiesJson){
		employeeId = processMem.current.tenderDetails.propertiesJson.employeeId;
	}
}

return { 
	"amount": processMem.current.discValue,
	"amountTypes": processMem.current.discType+'',
	"reasonCodeDesc": reasonDesc,
	"reasonCodes": processMem.current.reasonCodeId,
	"selectedAmountType": processMem.current.discType,
	"employeeId": employeeId
};