require("ovc/UI").hideBlocker();

var ResourceManager = require("generic/ResourceManager");
var title = "";
var message = "Please specify amount";

if(inputParams.codeType == "PayInTran"){
	title = ResourceManager.getValue("menus.managerFunctions.payInTran");
	message = ResourceManager.getValue("menus.managerFunctions.payInAmount");
}
else if (inputParams.codeType == "PayInCorrTran"){
	title = ResourceManager.getValue("menus.managerFunctions.payInCorrTran");
	message = ResourceManager.getValue("menus.managerFunctions.payInCorrAmount");
}
else if (inputParams.codeType == "PayOutTran"){
	title = ResourceManager.getValue("menus.managerFunctions.payOutTran");
	message = ResourceManager.getValue("menus.managerFunctions.payOutAmount");
}
else if (inputParams.codeType == "PayOutCorrTran"){
	title = ResourceManager.getValue("menus.managerFunctions.payOutCorrTran");
	message = ResourceManager.getValue("menus.managerFunctions.payOutCorrAmount");
}

return {
	title: title,
	message : message,
	allowPeriod: 'true',
    allowZero:   'true',
    amountType:  '1',
    yesBtnLabel: ResourceManager.getValue("menus.discounts.ok"),
    noBtnLabel: ResourceManager.getValue("menus.discounts.cancel")
};