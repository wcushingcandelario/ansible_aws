if(dijit.byId('txtSerialNumberEnquiry')){
	dijit.byId('txtSerialNumberEnquiry').destroy();
}
return { page: 'pos' };