var ResourceManager = require("generic/ResourceManager");
return {message: ResourceManager.getValue("menus.managerFunctions.pleaseFinishTran")};