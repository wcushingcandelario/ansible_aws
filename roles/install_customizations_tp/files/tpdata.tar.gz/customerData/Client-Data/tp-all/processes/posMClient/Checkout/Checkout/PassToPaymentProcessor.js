var tenderType = processMem.tenderDetails.tenderType;
var processName = "posMClient/Checkout/PayWith" + tenderType.charAt(0).toUpperCase() + tenderType.substr(1) + ".ovcprc";
if(processMem.tenderDetails.id == "giftCard"){
	processName = "posMClient/GiftCardPayment.ovcprc"
	processMem.tenderDetails.giftCardRequestId = require("dojox/uuid/generateRandomUuid")();
	processMem.giftCardAmount += processMem.amount || processMem.balance;
}


return {
	id : processName,
	processInputParams : {
		balance : processMem.balance,
		amount : processMem.amount ||  processMem.balance,
		changeAmt : processMem.changeAmt,
		tenderDetails : processMem.tenderDetails
	}
};
