require("ovc/UI").hideBlocker();
processMem.isAllGiftCardsOk = false;
processMem.returnData.push(inputParams.message);

return {
	isAllGiftCardsOk: processMem.isAllGiftCardsOk,
	returnData: processMem.returnData
}
