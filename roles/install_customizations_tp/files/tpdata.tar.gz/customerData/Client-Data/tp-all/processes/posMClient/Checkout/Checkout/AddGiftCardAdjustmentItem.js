var itemDate = new Date().getTime();
require("posmclient/RetailTransactionHelper").getCurrentTranObj().addGiftCardAdjustment(processMem.adjustmentAmount, itemDate);

return {};