
var rType = processMem.inputParams.receiptType;
if(rType == null){
	rType = processMem.inputParams.paramsMap.receiptType;
}
var receiptTypeConfigs =  require("ovc/ConfigManager").getConfigObject("posMClient/receipts.ovccfg")[rType];
var noOfCustomerCopies  = 1;
if(receiptTypeConfigs != undefined && receiptTypeConfigs != null) {
	noOfCustomerCopies = receiptTypeConfigs.noOfCustomerCopies;
}
var printNumberArr = [];
for(i=1; i <=noOfCustomerCopies;i++){
	printNumberArr.push("printCopy"+i);
}
if(printNumberArr != []){
	processMem.receiptIdentifier = "customerCopy";
}

return{dataArr : printNumberArr};