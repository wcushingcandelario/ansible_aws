var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

var props = tranObj._deliveryOption._tenderDetails.propertiesJson;
if (props.deliveryData && props.deliveryData != null) {
	var deliveryData = props.deliveryData;
	var deliveryDate = props.deliveryDate;
}


var data = {
	fulfillmentId: deliveryData.fulfillmentId,
	slotId: deliveryData.id,
	date: new Date(deliveryDate.date)
};

return {
	"data": {
		"data":data
	},
	"service": "DayOfChoiceCheckout"
};