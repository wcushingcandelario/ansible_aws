processMem.tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
return {
	tranObj: processMem.tranObj,
	fromMainMenu: true
};
