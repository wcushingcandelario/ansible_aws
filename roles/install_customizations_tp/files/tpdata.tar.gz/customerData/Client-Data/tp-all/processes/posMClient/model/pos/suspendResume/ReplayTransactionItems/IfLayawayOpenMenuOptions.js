var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var condition = false;
if (processMem.inputParams.tranTypeId && processMem.inputParams.tranTypeId != null && currentTranObj.isLayaway()){
	if (currentTranObj.getReceiptJSON().nonVoidItems.length > 0){
		//navigate to options menu only if there are items added to the receipt: (not just customer)
		//else, stay in main menu.
		condition = true;
	}
}
return {condition:condition}