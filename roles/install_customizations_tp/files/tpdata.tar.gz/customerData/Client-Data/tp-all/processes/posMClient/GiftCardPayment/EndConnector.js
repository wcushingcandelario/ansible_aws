tenderSuccessful = true;
if((processMem.tenderSuccessful == undefined || processMem.tenderSuccessful == null) ||
	(processMem.tenderSuccessful != undefined && processMem.tenderSuccessful != null && processMem.tenderSuccessful == false)
	){
	tenderSuccessful = false;
}
var amount;
if(processMem.isPartialPayment == true){
	if(parseFloat(processMem.availableBalance) > parseFloat(processMem.giftCardAmount)){
		amount = processMem.giftCardAmount;
	}
	else{
		amount = processMem.availableBalance;
	}
}
else{
	amount = processMem.giftCardAmount;
}

return {
	tenderSuccessful: tenderSuccessful,
	userEnteredValidAmount: true,
	giftCardAmount: amount,
	returnData: processMem.returnData
}

