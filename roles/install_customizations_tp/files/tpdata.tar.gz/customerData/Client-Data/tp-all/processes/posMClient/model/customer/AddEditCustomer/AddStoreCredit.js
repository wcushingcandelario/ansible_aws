var tranTypeId = require("generic/Constants").TX_TY_UPDATE_STORECREDIT;

return {
	"amount" : inputParams.amount,
	"tranTypeId" : tranTypeId
};