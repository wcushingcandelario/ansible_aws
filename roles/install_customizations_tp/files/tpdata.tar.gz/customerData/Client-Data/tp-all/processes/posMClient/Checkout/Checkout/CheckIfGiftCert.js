processMem.tenderDetails = inputParams.resultSet[0];
processMem.tenderDetails.propertiesJson = JSON.parse(processMem.tenderDetails.propertiesJson);
processMem.tenderDetails.id = processMem.inputParams.tenderType;
processMem.tenderDetails.reasonCodeType = processMem.inputParams.reasonCodeType;

return {
	condition : inputParams.resultSet[0].description != null && inputParams.resultSet[0].description === 'giftCert'
};