var deliverServiceCallBlocker = require("generic/ResourceManager").getValue("menus.deliveryOptions.shippingSearch");
require("posmclient/OVCDynamicDialog.widget").showBlocker(deliverServiceCallBlocker, false);

var data = JSON.parse(inputParams.response.response);

var dates = [];
var shipments = [];
var dayId = 0;

var formControlsArray = [];
_.forEach(data.days, function(day) {
	if (day.slots.length > 0) {
		var dayData = {
			dayId: dayId,
			date: day.date
		};
		var avaliableSlots = false;
		_.forEach(day.slots, function (slot) {
			if (slot.available === true) {
				avaliableSlots = true;
				var slotData = {
					slotId: dayId,
					id: slot.id,
					price: (slot.price/100).toFixed(2),
					available: slot.available,
					slotDescription: day.date + " " + slot.description + " " + slot.startTime + "-" + slot.endTime + " " +  ResourceManager.getValue("currency.symbol") +
					require("generic/StringUtils").numberToCurrencyString(slot.price/100)
				};
				if (slot.shipments && slot.shipments != null) {
					slotData.fulfillmentId = slot.shipments[0].fulfiller;
					slotData.gpids = slot.shipments[0].gpids;
				}
				shipments.push(slotData);
			}
		});
		if (avaliableSlots === true) {
			dates.push(dayData);
		}
		dayId++;
	}
});

processMem.dates = dates;
processMem.shipments = shipments;

var validDay = false;

var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var deliveryOption = tranObj._deliveryOption;
var props;
if (deliveryOption && deliveryOption.propertiesJson != null) {
	props = deliveryOption.propertiesJson;
}

_.forEach(dates, function(day) {
	if (Date.parse(props.deliveryDate) === Date.parse(day.date)) {
		validDay = true;
	}
});

return {
	condition: validDay
};