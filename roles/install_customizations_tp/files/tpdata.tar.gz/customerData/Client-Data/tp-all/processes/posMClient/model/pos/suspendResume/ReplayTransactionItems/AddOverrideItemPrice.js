var competitorName = null;
var isVATIncluded = true;
var originalRefItemIdx = null;
if(processMem.current.tenderDetails && processMem.current.tenderDetails != null){
	var parsedData = JSON.parse(processMem.current.tenderDetails);
	if(parsedData != undefined){ 
		if(parsedData.competitorName != undefined && parsedData.competitorName != null)
			competitorName = JSON.parse(processMem.current.tenderDetails).competitorName;
 		if(parsedData.isVATIncluded != undefined && parsedData.isVATIncluded != null)
 			isVATIncluded = parsedData.isVATIncluded;
 		if(parsedData.originalRefItemIdx != undefined && parsedData.originalRefItemIdx != null)
 			originalRefItemIdx = parsedData.originalRefItemIdx;
	}
} 
return { 
	"itemIdx": originalRefItemIdx == null ? processMem.current.refItemIdx : originalRefItemIdx,
	"newUnitPrice": processMem.current.newPrice,
	"reasonCodeDesc": (inputParams.resultSet[0])?inputParams.resultSet[0].description:processMem.current.reasonCodeId,
	"reasonCodes": processMem.current.reasonCodeId,
	"competitorName": competitorName,
	"isVATIncluded" : isVATIncluded 
};
