require("ovc/UI").hideBlocker();
if (inputParams.resultSet) {
	processMem.numberOfQuotes = inputParams.resultSet.length;
	processMem.customerQuoteIdList = getQuoteIdList(inputParams.resultSet);
}

function getQuoteIdList(customerDetailsArr) {
	var quoteIDList = [];
	for (var i = 0; i < customerDetailsArr.length; i++) {
		var receiptJSON = JSON.parse(customerDetailsArr[i].receiptJSON);
		quoteIDList.push(receiptJSON._quoteId);
	}
	return quoteIDList;
}

if (inputParams.response) {
	processMem.numberOfLayaways = inputParams.response.numberOfLayaways;
}

var configManager = require("ovc/ConfigManager");
var getResource = require("generic/ResourceManager").getValue;
var customerConfig = configManager.getConfigObject("posMClient/customers.ovccfg");
var isStoreCreditAllowed = configManager.getConfigObject("posMClient/app.ovccfg").isStoreCreditAllowed;
var isAddStoreCreditAllowed = configManager.getConfigObject("posMClient/app.ovccfg").allowManualUpdateOfStoreCredit;
var customerAddEditOptionalFields = configManager.getConfigObject("posMClient/pos.ovccfg").customerAddEditOptionalFields;
var isQuoteHistoryAllowed = configManager.getConfigObject("posMClient/pos.ovccfg").searchCenterSearchByCustomer;
var isAddressLookupAllowed = configManager.getConfigObject("posMClient/pos.ovccfg").customerAddressLookup;
var optionalFields = [];
if (customerAddEditOptionalFields != undefined && customerAddEditOptionalFields != null) {
	optionalFields = customerAddEditOptionalFields.split(",");
}

//If there are items or another customer added to the transaction then do not display the button to Add Store Credit.
var transactionObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var calculatedTranItems = transactionObj.getCalculatedTranItems();

if (calculatedTranItems.length > 0) {
	isAddStoreCreditAllowed = false;
}

var len = 0;

if (processMem.inputParams.customerDetails && processMem.inputParams.customerDetails != null) {
	len = customerConfig.regularCustomerDetailsEdit.length;
}
else {
	len = customerConfig.regularCustomerDetailsAdd.length;
}

if (!processMem.formControlsArray) {
	var formControls = [];
}

var requiredFields = [];
var buttonDefinitions = [];

for (var i = 0; i < len; i++) {

	if (processMem.inputParams.customerDetails && processMem.inputParams.customerDetails != null) {
		//editing the customer. populate custData from inputParams.

		//do not show storeCredit UI if not configured to be shown.
		if (customerConfig.regularCustomerDetailsEdit[i].name === "storeCredit" && isStoreCreditAllowed === 0) {
			continue;
		}

		var control = {
			"type": customerConfig.regularCustomerDetailsEdit[i].type,
			"name": customerConfig.regularCustomerDetailsEdit[i].name,
			"label": customerConfig.regularCustomerDetailsEdit[i].label,
			"value": processMem.inputParams.customerDetails[customerConfig.regularCustomerDetailsEdit[i].name]
		};

		// Display customer's store credit balance.
		if (customerConfig.regularCustomerDetailsEdit[i].name === "storeCredit") {
			control.label += require("generic/StringUtils").numberToCurrencyString(processMem.storeCreditBalance, getResource("currency.precision"), true);
		}

		// Display customer's number of layaways.
		if (customerConfig.regularCustomerDetailsEdit[i].name === "numberOfLayaways") {
			control.label += (processMem.numberOfLayaways) ? processMem.numberOfLayaways : 0;
		}

		// Display customer's number of layaways.
		if (customerConfig.regularCustomerDetailsEdit[i].name === "numberOfQuotes") {
			control.label += (processMem.numberOfQuotes) ? processMem.numberOfQuotes : 0;
		}

		control.options = {
			"placeHolder": customerConfig.regularCustomerDetailsEdit[i].value,
			"required": customerConfig.regularCustomerDetailsEdit[i].required || false
		};

		if (customerConfig.regularCustomerDetailsEdit[i].required == true) {
			requiredFields.push(control);
			formControls.push(control);
		}

		if (inputParams.selectedAddress && inputParams.selectedAddress != undefined) {
			populateCustomerAddressFields(control.name);

			if (optionalFields.indexOf(control.name) != -1) {
				formControls.push(control);
			}
		}
		else {
			// if not required, check if it is turned ON in dashboard config to be displayed
			if (optionalFields.indexOf(control.name) != -1) {
				formControls.push(control);
			}
		}

	}
	else {// adding the customer
		if (!processMem.formControlsArray) {
			var control = {
				"type": customerConfig.regularCustomerDetailsAdd[i].type,
				"name": customerConfig.regularCustomerDetailsAdd[i].name,
				"label": customerConfig.regularCustomerDetailsAdd[i].label
			};
			control.options = {
				"placeHolder": customerConfig.regularCustomerDetailsAdd[i].value || "",
				"required": customerConfig.regularCustomerDetailsAdd[i].required || false
			};

			if (customerConfig.regularCustomerDetailsAdd[i].required == true) {
				requiredFields.push(control);
				formControls.push(control);
			}
			else {
				if (inputParams.selectedAddress && inputParams.selectedAddress != undefined) {
					populateCustomerAddressFields(control.name);

					if (optionalFields.indexOf(control.name) != -1) {
						formControls.push(control);
					}
				} else {
					// if not required, check if it is turned ON in dashboard config to be displayed
					if (optionalFields.indexOf(control.name) != -1) {
						formControls.push(control);
					}
				}
			}
		} else {
			len = processMem.formControlsArray.length;
			if (inputParams.selectedAddress && inputParams.selectedAddress != undefined) {
				var control = processMem.formControlsArray[i];
				populateCustomerAddressFields(control.name);
			}
			formControls = processMem.formControlsArray;
		}
	}
}

for (var j = 0; j < customerConfig.regularCustomerButtonDefinitions.length; j++) {
	if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "submit") {
		customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.SaveButtonLbl");
		buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
	}
	if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "Cancel") {
		customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.CancelButtonLbl");
		buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
	}
	if (isAddressLookupAllowed && isAddressLookupAllowed === 1) {
		if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "AddressLookup") {
			customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.AddressLookup");
			buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
		}
	}
	if (processMem.inputParams.customerDetails && processMem.inputParams.customerDetails != null && isQuoteHistoryAllowed && isQuoteHistoryAllowed === 1) {
		if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "History") {
			customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.quoteHistoryLbl");
			buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
		}
	}

	if (processMem.inputParams.customerDetails && processMem.inputParams.customerDetails != null && isStoreCreditAllowed && isStoreCreditAllowed === 1) {
		// only if editing customer, show the print button
		if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "PrintStoreCredit") {
			customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.PrintStoreCredit");
			buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
		}
		if (isAddStoreCreditAllowed && isAddStoreCreditAllowed === 1) {
			if (customerConfig.regularCustomerButtonDefinitions[j].eventType == "AddStoreCredit") {
				customerConfig.regularCustomerButtonDefinitions[j].label = getResource("customers.AddStoreCredit");
				buttonDefinitions.push(customerConfig.regularCustomerButtonDefinitions[j]);
			}
		}

	}
}


function populateCustomerAddressFields(fieldName) {
	if (fieldName === "addressLine1") {
		control.value = inputParams.selectedAddress.addressLine1;
		return;
	}
	if (fieldName === "addressLine2") {
		control.value = inputParams.selectedAddress.addressLine2;
		return;
	}
	if (fieldName === "town") {
		control.value = inputParams.selectedAddress.town;
		return;
	}
	if (fieldName === "postalCode") {
		control.value = inputParams.selectedAddress.postcode;
		return;
	}
}

processMem.formControlsArray = formControls;

processMem.inputParams.VRcustomerPOP = true;

return {
	dialogTitle: getResource("customers.RegularDialogTitle"),
	formControlsArray: formControls,
	buttonDefinitions: buttonDefinitions,
	requiredFields: requiredFields
};
