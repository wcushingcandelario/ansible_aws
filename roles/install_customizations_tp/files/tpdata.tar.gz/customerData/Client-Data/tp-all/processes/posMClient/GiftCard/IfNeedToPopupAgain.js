var condition;

if(processMem.isMaxReached != undefined && processMem.isMaxReached != null &&
		processMem.isMaxReached == false){
	condition = true;
}
else{
	condition = false;
}
return {condition: condition};