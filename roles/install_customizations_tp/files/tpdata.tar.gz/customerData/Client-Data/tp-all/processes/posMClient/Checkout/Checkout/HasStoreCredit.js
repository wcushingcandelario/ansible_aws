var storeCreditBalance = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getLoyaltyUser().storeCreditBalance;
var transactionBalance = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getTotal();

return {
	condition: ((storeCreditBalance && storeCreditBalance !== 0) || (transactionBalance && transactionBalance < 0))
};