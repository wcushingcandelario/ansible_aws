var quotesConfig = require("ovc/ConfigManager").getConfigObject("posMClient/Quotes.ovccfg");
 return {condition : 
 (processMem.skipCustomerValidation == undefined || (processMem.skipCustomerValidation != undefined && processMem.skipCustomerValidation != true)) &&
 quotesConfig.inventoryHardReserveForLayaways!=null && quotesConfig.inventoryHardReserveForLayaways===1};