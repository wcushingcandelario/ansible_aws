return {
	"itemDate": processMem.current.itemDate,
	"amount": processMem.current.amount
};