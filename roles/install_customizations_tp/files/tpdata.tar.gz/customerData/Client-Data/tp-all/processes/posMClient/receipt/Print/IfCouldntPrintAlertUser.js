return { width: '40%',
                   messageType: 1,
                   message: inputParams.message };