return {
	condition : processMem.tenderDetails.description != null && processMem.tenderDetails.description === 'giftCard'
};