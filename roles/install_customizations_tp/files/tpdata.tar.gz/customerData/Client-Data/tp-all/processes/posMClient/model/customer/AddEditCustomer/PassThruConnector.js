return {
	"resultSet": inputParams
};