var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var amount = tranObj.getBalance();

return {
		amount: amount,
		tenderDetails: processMem.tenderDetails
	};