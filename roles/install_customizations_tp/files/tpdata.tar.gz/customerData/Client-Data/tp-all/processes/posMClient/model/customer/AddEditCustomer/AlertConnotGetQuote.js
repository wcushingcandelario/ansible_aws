var outputParams = {
	messageType: 1,
	message: require("generic/ResourceManager").getValue("errorMessages.errorGettingQuoteFromServer"),
	width: '30%'
};

return outputParams;