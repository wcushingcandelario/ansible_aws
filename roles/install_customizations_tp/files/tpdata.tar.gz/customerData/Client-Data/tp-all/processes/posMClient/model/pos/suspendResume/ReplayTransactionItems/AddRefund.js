var item = processMem.current;
if (item.calcAmount !== (item.amount * item.qty)) {
    inputParams.productObj.splitItems = true;
}
if (processMem.current.amount !== inputParams.productObj.price) {
    inputParams.productObj.price = processMem.current.amount;
}

var reasonCodeDesc = null;
 // PromoDetails are in receiptJSON need to add them to the product for promo to show up on resume 
if(processMem.current.receiptJSON !== undefined && processMem.current.receiptJSON !== null){
	var receiptJSON = JSON.parse(processMem.current.receiptJSON);
 	var nonVoidItem = receiptJSON.nonVoidItems[processMem.current.itemIdx];
	inputParams.productObj.promoId = receiptJSON?nonVoidItem.promoId:null; 
	reasonCodeDesc = nonVoidItem.reasonCodeDesc;
	if(receiptJSON._addOnVATTax !== undefined && receiptJSON._addOnVATTax !== null && receiptJSON._addOnVATTax < 0){
 			if(inputParams.productObj.taxRates !== undefined && inputParams.productObj.taxRates != null){
					_.forEach(inputParams.productObj.taxRates , function(taxRate){
						var vatIndicator = require("generic/ResourceManager").getValue("receipts.taxes.VATAddonIndicator", "VA*");
  						if(taxRate.isVAT === 1 && nonVoidItem.tax === vatIndicator){
							taxRate.isVAT = 2;
						}
					});
				}

		
	}
}  

var refTranId = null;
if(processMem.current.refTranId !== undefined && processMem.current.refTranId !== null && processMem.current.refTranId !== ''
	&& processMem.current.refTranId !== "null"){
	refTranId = processMem.current.refTranId;
}

return {
    "splitItems":  inputParams.productObj.splitItems || false,
	"isScanned": processMem.current.isScanned,
    "productObj": inputParams.productObj,
    "quantity": processMem.current.qty,
    "reasonCode": processMem.current.reasonCodeId,
    "reasonCodeDesc": reasonCodeDesc,
    "origTranId": refTranId,
    "refTranItemIdx": processMem.current.refTranItemIdx
};
