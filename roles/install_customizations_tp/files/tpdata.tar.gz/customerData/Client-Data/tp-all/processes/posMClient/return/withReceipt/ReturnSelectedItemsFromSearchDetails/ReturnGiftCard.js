var itemDate = new Date().getTime();

var tranItem = require("posmclient/RetailTransactionHelper").getCurrentTranObj().addGiftCardRefund(processMem.inputParams.productId, 
		processMem.inputParams.price, 
		itemDate,
		processMem.inputParams.reasonCodeDesc,
		processMem.inputParams.origTranId);

return { keepPosition: false };