//final EndConnector2
require("ovc/UI").hideBlocker();
return {
	isAllGiftCardsOk: processMem.isAllGiftCardsOk,
	returnData: processMem.returnData
}
