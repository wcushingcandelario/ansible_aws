return{
    condition: inputParams.processOutputParams.tenderSuccessful && inputParams.processOutputParams.userEnteredValidAmount
}