//if balance less than 0, return transaction. Hence, handle return menu separately.
return {condition: require("posmclient/RetailTransactionHelper").getCurrentTranObj().getBalance() < 0};