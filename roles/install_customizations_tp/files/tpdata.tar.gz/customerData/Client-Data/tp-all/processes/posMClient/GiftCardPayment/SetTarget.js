if(dijit.byId('txtSerialNumber')){
	dijit.byId('txtSerialNumber').destroy();
}
if(processMem.isPartialPayment == true){
	processMem.inputParams.amount = processMem.availableBalance;
}
processMem.resourceManager = require("generic/ResourceManager");

return { page: 'giftCardPopup' };