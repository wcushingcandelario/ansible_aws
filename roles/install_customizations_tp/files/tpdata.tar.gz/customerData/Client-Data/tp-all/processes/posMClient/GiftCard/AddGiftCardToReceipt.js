var deferred = new Deferred();

require(['posmclient/RetailTransactionHelper', 'generic/Constants'], addItem);

function addItem(RetailTransactionHelper, constants) {
	
	currentTranObj = RetailTransactionHelper.getCurrentTranObj();
	var itemDate = new Date().getTime();
	var reasonCodeDesc = "Gift Card";
	currentTranObj.addGiftCardSale(processMem.serialNumber, parseFloat(processMem.amount), itemDate, reasonCodeDesc, processMem.inputParams.isTopUp);
	
	deferred.resolve({});
}

return deferred.promise;
