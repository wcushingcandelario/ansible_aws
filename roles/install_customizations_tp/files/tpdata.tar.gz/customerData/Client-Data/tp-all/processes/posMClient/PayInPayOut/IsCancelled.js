processMem.pipoAmount = inputParams.pipoAmount;
return {condition:(inputParams.isCancelled && inputParams.isCancelled==1)}