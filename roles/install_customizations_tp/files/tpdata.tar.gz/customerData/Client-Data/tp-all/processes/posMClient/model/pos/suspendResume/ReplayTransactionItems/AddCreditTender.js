return {
	"itemDate": processMem.current.itemDate,
	"amount": processMem.current.amount,
	"cardAccountNumber": processMem.current.cardAccountNumber,
	"cardEncryptedToken": processMem.current.cardEncryptedToken
};