var deferred = new Deferred();
require(["generic/StringUtils"], buildData);

function clone(obj) {
	var copy = JSON.parse( JSON.stringify( obj ) );
    return copy;
}

function buildData(StringUtils) {
	var uObj = localStorage.getObject(username);
	var receiptHeading = "";
	if (processMem.inputParams.receiptType == "gift"){
		receiptHeading = require("generic/ResourceManager").getValue("printReceipt.giftReceiptHeading");
	}
	else if (processMem.inputParams.receiptType == "backdoor"){
		receiptHeading = require("generic/ResourceManager").getValue("printReceipt.backDoorReceiptHeading");
	}
	var paramsMap = {
			receiptObj: clone(processMem.receiptObj),
			storeAddress: localStorage.getObject("location"),
			dateString: StringUtils.getLocaleDateFormat(),
			employee: uObj.firstName + " " + uObj.lastName,
			receiptHeading: receiptHeading,
			receiptType: processMem.inputParams.receiptType
		};
	
	var nonVoidItems = paramsMap.receiptObj.nonVoidItems;
	var giftItems = processMem.inputParams.giftItems;
	var nonVoidGiftItems = [];
	for (var i = 0; i < nonVoidItems.length; i++) {
//		var selectedItem = false;
		if(giftItems != null) {
			for(var j = 0; j < giftItems.length; j++) {
				if(nonVoidItems[i].tranItemIdx == giftItems[j])
					nonVoidGiftItems.push(nonVoidItems[i]);
			}
		}
//		if(!selectedItem)
//			nonVoidItems.splice(i,1);
	}
	paramsMap.receiptObj.nonVoidItems = nonVoidGiftItems;
	deferred.resolve({
		templateSrc: processMem.template,
		paramsMap: paramsMap
	});
}

return deferred.promise;
