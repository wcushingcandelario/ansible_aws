processMem.template = inputParams.template;
var giftCardItems = processMem.inputParams.giftCardItems;
var gcObj = localStorage.getObject("giftCardObj");

// Reverse array because giftCardItems will have the gc as items first and gc as tender next.
// However, gcObj has gc as tenders first. If both arrays in same order, looping over them
// will not cause wrong balances to be picked up and printed in the receipt.
if(gcObj !== undefined && gcObj !== null){
	gcObj = gcObj.reverse();
}

for (var i =0; i < giftCardItems.length; i++){
	for(var j =0; j < gcObj.length; j++){
		if(giftCardItems[i].itemNum != undefined && giftCardItems[i].itemNum != null){//gc as item
			if(giftCardItems[i].itemNum == gcObj[j].panNumber &&
					(giftCardItems[i].properties == undefined || 
						(giftCardItems[i].properties !== undefined && giftCardItems[i].properties.authCode == gcObj[j].authCode)
					)
				){
				giftCardItems[i].properties = gcObj[j];
			}
		}
		else if(giftCardItems[i].giftCardSerialNumber != undefined && giftCardItems[i].giftCardSerialNumber != null){//gc as tender
			if(giftCardItems[i].giftCardSerialNumber == gcObj[i].panNumber && 
				(giftCardItems[i].properties == undefined || 
						(giftCardItems[i].properties !== undefined && giftCardItems[i].properties.authCode == gcObj[i].authCode)
				)
			){
				giftCardItems[i].properties = gcObj[i];
			}
		}
	}
}

return { dataArr: giftCardItems};