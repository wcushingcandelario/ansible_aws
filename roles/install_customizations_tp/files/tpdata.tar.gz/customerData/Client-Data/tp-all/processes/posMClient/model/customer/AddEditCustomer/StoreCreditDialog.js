var getResource = require("generic/ResourceManager").getValue;

var amount = 0;

var title = "";
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var message = getResource("customers.StoreCreditPrompt");

return {
	title: title,
	message: message,
	allowPeriod: 'true',
	allowZero: 0,
	allowNegative:'true',
	amountType: '1',
	amount: amount,
	yesBtnLabel: getResource("customers.StoreCreditSubmit"),
	noBtnLabel: getResource("customers.StoreCreditCancel"),
	submitPrintBtnLabel: getResource("customers.PrintSubmitStoreCredit")
};