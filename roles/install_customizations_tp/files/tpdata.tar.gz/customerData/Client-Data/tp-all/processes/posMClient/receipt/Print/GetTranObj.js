processMem.template = inputParams.template;
return {};