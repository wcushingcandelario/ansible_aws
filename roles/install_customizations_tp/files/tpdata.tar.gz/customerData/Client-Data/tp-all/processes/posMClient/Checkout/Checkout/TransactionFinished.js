localStorage.setObject("giftCardRequestId", null);
require("ovc/UI").hideBlocker(); 
return {};