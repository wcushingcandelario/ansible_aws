return {
	"loyaltyId": inputParams.loyaltyId,
	"refItemIdx" : processMem.current.refItemIdx,
	"reasonCodeId" :  processMem.current.reasonCodeId,
	"isResume" : true
};