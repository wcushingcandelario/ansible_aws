var tenderDetails = processMem.current.tenderDetails;

if(tenderDetails != null && typeof tenderDetails == "string"){
	tenderDetails = JSON.parse(tenderDetails);
}

return {
	"itemDate": processMem.current.itemDate,
	"tenderId": processMem.current.tenderId,
	"tenderDetails": tenderDetails,
	"amount": processMem.current.amount
};
