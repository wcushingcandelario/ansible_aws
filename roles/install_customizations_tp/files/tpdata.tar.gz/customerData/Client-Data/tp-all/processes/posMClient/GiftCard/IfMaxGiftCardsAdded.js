var posConfig = require("ovc/ConfigManager").getConfigObject('posMClient/sales.ovccfg');
var ResourceManager = require("generic/ResourceManager");
processMem.isMaxReached = false;

if(posConfig.maxGiftCardsInTran != undefined && posConfig.maxGiftCardsInTran != null){
	processMem.maxGiftCardsInTran = posConfig.maxGiftCardsInTran;
}
if(posConfig.maxGiftCardValue != undefined && posConfig.maxGiftCardValue != null){
	processMem.maxGiftCardValue = posConfig.maxGiftCardValue;
}

var totalGiftCardItems = 0;
var tranItems = [];
if(require("posmclient/RetailTransactionHelper").getCurrentTranObj().getReceiptJSON().nonVoidItems != undefined){
	tranItems = require("posmclient/RetailTransactionHelper").getCurrentTranObj().getReceiptJSON().nonVoidItems;
}

for(var i = 0; i < tranItems.length; i = i + 1){
	var item = tranItems[i];
	// calculate total number of gift card items
	if(item.itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_SALE ||
			item.itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_TOPUP){
		totalGiftCardItems += 1;
	}
}
if (totalGiftCardItems >= posConfig.maxGiftCardsInTran){
		processMem.alertUser = ResourceManager.getValue("pos.maxGiftCardsReached");
		processMem.isMaxReached = true;
}

return {condition: processMem.isMaxReached};