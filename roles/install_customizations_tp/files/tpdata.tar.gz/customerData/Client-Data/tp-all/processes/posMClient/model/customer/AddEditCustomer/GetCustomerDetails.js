return {
	"loyaltyId": processMem.inputParams.customerDetails.loyaltyId
};