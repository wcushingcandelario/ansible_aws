return {
	"itemDate": processMem.current.itemDate,
	"amount": processMem.current.amount,
	"cardAccountNumber": processMem.current.cardAccountNumber,
	"cardPinBlock": processMem.current.cardPinBlock
};