return { 
	"tranId": processMem.current.tranId
};