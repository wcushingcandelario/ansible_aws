return { moveFromId: 'subMenuView',
         moveToId: "mainMenuView",
	     transitionDir: 1,
	     transition: 'zoomOut'
       };
