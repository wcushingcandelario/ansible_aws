var nonVoidItems = processMem.receiptObj.nonVoidItems;
var returnItems = [];
var extraReceiptItems = [];
var hasReturnItem = false
var salesConfig =  require("ovc/ConfigManager").getConfigObject("posMClient/sales.ovccfg");
var extraReceiptReasonCodes = salesConfig.extraReturnReceiptReasonList.split(',');

if(nonVoidItems != null) {
	for(var i = 0; i < nonVoidItems.length; i++) {
		if (nonVoidItems[i].itemType == require("generic/Constants").ITEM_TY_REFUND_PRODUCT) {
			returnItems.push(nonVoidItems[i]);
			hasReturnItem = true;
			if(extraReceiptReasonCodes.indexOf(nonVoidItems[i].reasonCodeDesc) !== -1){
				extraReceiptItems.push(nonVoidItems[i]);
			}
		}
	}
	processMem.returnItems = returnItems;
	processMem.extraReceiptItems = extraReceiptItems;
}

return { condition : (hasReturnItem) };