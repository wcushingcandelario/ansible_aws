var Constants = require("generic/Constants");
var tranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();

if(processMem.current.itemType == Constants.ITEM_TY_PAYIN_SALE){
	tranObj.setTranTypeId(Constants.TX_TY_PAYINTRAN);
}
else if(processMem.current.itemType == Constants.ITEM_TY_PAYIN_CORR_SALE){
	tranObj.setTranTypeId(Constants.TX_TY_PAYINCORRTRAN);
}
else if(processMem.current.itemType == Constants.ITEM_TY_PAYOUT_SALE){
	tranObj.setTranTypeId(Constants.TX_TY_PAYOUTTRAN);
}
else if(processMem.current.itemType == Constants.ITEM_TY_PAYOUT_CORR_SALE){
	tranObj.setTranTypeId(Constants.TX_TY_PAYOUTCORRTRAN);
}

tranObj.addPIPOSale(processMem.current.amount,processMem.current.itemDate,processMem.current.itemType,
					processMem.current.reasonCodeId,inputParams.resultSet[0].description);