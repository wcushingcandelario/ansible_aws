
return { productObj: inputParams.productObj };