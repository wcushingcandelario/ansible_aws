var ifExtraReceiptReq = false

var refundTypeConfigs =  require("ovc/ConfigManager").getConfigObject("posMClient/sales.ovccfg");

var extraReceiptReq = refundTypeConfigs.extraReceiptRefund;

if(extraReceiptReq == 1){
	ifExtraReceiptReq = true;
}
return { condition : (ifExtraReceiptReq) };