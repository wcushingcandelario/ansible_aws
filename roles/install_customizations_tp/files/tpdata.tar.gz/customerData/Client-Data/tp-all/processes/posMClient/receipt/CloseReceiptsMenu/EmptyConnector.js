
			if(require('dojo/_base/config').small_form_factor){  
				require(["dijit/registry", "dojo/dom", "ovc/ProcessEngine"],
				function (registry, dom, ProcessEngine){
					var clickableImage = dom.byId("headingLogoLeft");
					registry.byId(clickableImage.activeView).performTransition("posView", -1, "slidev");
					clickableImage.activeView = "posView";
					ProcessEngine.invokeProcess('posMClient/SetScanTarget.ovcprc', { page: 'pos' });
				});
			}

return {};