processMem.receiptObj = inputParams.receiptObj;
var isGiftCardItemsPresent = false;
processMem.giftCardItems = [];
var currentTranObj = require("posmclient/RetailTransactionHelper").getCurrentTranObj();
var Constants = require("generic/Constants");
for(var i = 0; i < processMem.receiptObj.nonVoidItems.length; i++) {
	if(processMem.receiptObj.nonVoidItems[i].itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_SALE ||
			processMem.receiptObj.nonVoidItems[i].itemType == require("generic/Constants").ITEM_TY_GIFT_CARD_TOPUP){
		processMem.giftCardItems.push(processMem.receiptObj.nonVoidItems[i]);
		isGiftCardItemsPresent = true;
	}
}

// looping to get details of gift card tender. If paid to a GiftCard or
// paid by using a giftCard, then we need an extra receipt showing 
// details of that gift card.

for(var i=0; i< currentTranObj.getTranItems().length; i++){
	if(currentTranObj.getTranItems()[i].getItemType() == Constants.ITEM_TY_EINTERNAL_TENDER &&
			currentTranObj.getTranItems()[i].getTenderId() == "giftCard"){
		var gcTender = {};
		gcTender.price = currentTranObj.getTranItems()[i].getAmount(); //purchaseValue
		gcTender.giftCardSerialNumber = currentTranObj.getTranItems()[i].getTenderDetails().giftCardSerialNumber;
		processMem.giftCardItems.push(gcTender);
		isGiftCardItemsPresent = true;
	}
}
return {condition: isGiftCardItemsPresent};
