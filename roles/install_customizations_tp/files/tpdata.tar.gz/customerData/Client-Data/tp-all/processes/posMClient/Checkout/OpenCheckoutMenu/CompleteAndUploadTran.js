return { dbObj: processMem.tranObj,
                   opType: 'upSyncTransaction',
                   sendToQueue: 'true' }; 