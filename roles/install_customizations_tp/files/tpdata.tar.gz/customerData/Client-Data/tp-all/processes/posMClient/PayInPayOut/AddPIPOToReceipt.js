var deferred = new Deferred();

require(['posmclient/RetailTransactionHelper', 'generic/Constants'], addItem);

function addItem(RetailTransactionHelper, constants) {
	
	currentTranObj = RetailTransactionHelper.getCurrentTranObj();
	var itemType;
	var date = new Date().getTime();

	if(processMem.inputParams.codeType == "PayInTran"){
		currentTranObj.setTranTypeId(constants.TX_TY_PAYINTRAN);
		itemType = constants.ITEM_TY_PAYIN_SALE;
	}
	else if(processMem.inputParams.codeType == "PayInCorrTran"){
		currentTranObj.setTranTypeId(constants.TX_TY_PAYINCORRTRAN);
		processMem.pipoAmount = 0 - parseFloat(processMem.pipoAmount);
		itemType = constants.ITEM_TY_PAYIN_CORR_SALE;
	}
	else if(processMem.inputParams.codeType == "PayOutTran"){
		currentTranObj.setTranTypeId(constants.TX_TY_PAYOUTTRAN);
		processMem.pipoAmount = 0 - parseFloat(processMem.pipoAmount);
		itemType = constants.ITEM_TY_PAYOUT_SALE;
	}
	else if(processMem.inputParams.codeType == "PayOutCorrTran"){
		currentTranObj.setTranTypeId(constants.TX_TY_PAYOUTCORRTRAN);
		itemType = constants.ITEM_TY_PAYOUT_CORR_SALE;
	}
	currentTranObj.addPIPOSale(processMem.pipoAmount, date, itemType, processMem.inputParams.reasonCodes, processMem.inputParams.reasonCodeDesc);
	
	deferred.resolve({});
}

return deferred.promise;
