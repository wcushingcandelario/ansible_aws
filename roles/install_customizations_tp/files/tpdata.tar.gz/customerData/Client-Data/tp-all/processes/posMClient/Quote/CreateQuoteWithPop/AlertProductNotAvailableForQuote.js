var  confirmTitle    = require("generic/ResourceManager").getValue("pos.QuoteWarning");
var  confirmMessage    = "<br\>" +processMem.productStockDetailsStr;
var  okBtn    = require("generic/ResourceManager").getValue("pos.layawayInventoryProceed");
var  cancelBtn    = require("generic/ResourceManager").getValue("pos.layawayInventoryCancel");
if(processMem.onlyOneProduct && processMem.onlyOneProduct == true){
	okBtn = "";
	cancelBtn = "Ok";
}
return { title: confirmTitle, message: confirmMessage, yesBtnLabel: okBtn, noBtnLabel: cancelBtn};
