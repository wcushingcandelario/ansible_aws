if (inputParams.response) {
	processMem.numberOfLayaways = inputParams.response.numberOfLayaways;
}
return {
	date: "",
	fromAmount: "0",
	toAmount: "9999999",
	tranType: "quote",
	loyaltyId: processMem.inputParams.customerDetails.loyaltyId
};

 