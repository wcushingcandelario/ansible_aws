require("ovc/UI").showBlocker("Validating Gift Card with Savvy...", true);
return {dataArr : processMem.inputParams.giftCardItems};