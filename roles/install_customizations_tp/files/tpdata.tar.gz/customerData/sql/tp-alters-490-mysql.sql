update config_tbl set defaultValue = '4.9.0/1.22.0' where featureId = 'version';	
 