update config_tbl set defaultValue = '20,51,23,giftCard' where featureId = 'allowedRefundTenders' and featureGroup = 'Without Receipt' and moduleId = 'returns';

update config_tbl set defaultValue = '4.7.0/1.20.0' where featureId = 'version'; 
	
 