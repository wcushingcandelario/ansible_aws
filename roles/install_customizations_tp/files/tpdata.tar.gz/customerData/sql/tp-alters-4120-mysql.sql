update config_tbl 
set featureValue = 'en-uk', lastModified =CURRENT_TIMESTAMP 
where featureId = 'lang';

update config_tbl set defaultValue = 'addressLine1,notes,phone,postalCode,town' where featureId = 'customerAddEditOptionalFields' and locationOrGroupId='posMClient-grp-all';

update config_tbl set isPublic = 1 where featureId in ('SavvyEndPoint', 'SavvyMid', 'EncyptionKey', 'CardCustCommerceId');

update config_tbl set featureValue = 1 where featureId = 'VATAlwaysInReceipt';

delete from config_tbl where featureId = 'searchCenterSearchByCustomer';

update config_tbl set defaultValue = '4.12.0/1.25.0' where featureId = 'version';
