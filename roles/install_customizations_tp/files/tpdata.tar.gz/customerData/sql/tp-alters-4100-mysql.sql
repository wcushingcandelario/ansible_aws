update config_tbl 
set featureName = 'Minimum amount that can be credited to a Gift Card', 
	featureDescription = 'Minimum amount that can be credited to a Gift Card',
	lastModified =CURRENT_TIMESTAMP 
where featureId = 'minAmountToReturnToGiftCard';

update config_tbl set defaultValue = '4.10.0/1.23.0' where featureId = 'version';