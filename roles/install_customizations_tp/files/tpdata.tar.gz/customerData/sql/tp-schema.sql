-- CSP-186
INSERT INTO role_permission_tbl (roleId, applicationId, moduleId, permGroup, permId, permValue, access, created, lastModified, isDeleted)
VALUES
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0);
	
INSERT INTO permission_tbl (applicationId, moduleId, permGroup, permId, permName, permDescription, created, lastModified, isDeleted)
VALUES
('pos', 'sale', 'managerFunctions', 'viewPayInTran', 'viewPayInTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayInTran', 'executePayInTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayOutTran', 'viewPayOutTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayOutTran', 'executePayOutTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', 'viewPayInCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayInCorrTran', 'executePayInCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', 'viewPayOutCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', 'executePayOutCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0);
-- CSP-164 Gift card configs:
DELETE FROM permission_tbl WHERE permId in ('viewGiftCard','executeGiftCard','viewGiftCardSale','executeGiftCardSale','viewGiftCardBalance','executeGiftCardBalance');
INSERT INTO permission_tbl (applicationId, moduleId, permGroup, permId, permName, permDescription, created, lastModified, isDeleted)
VALUES
	('pos', 'sale', 'giftCard', 'viewGiftCard', 'View Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCard', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'viewGiftCardSale', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCardSale', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'viewGiftCardBalance', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCardBalance', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0);
	
DELETE FROM role_permission_tbl WHERE roleid in('2','5') and permId in ('viewGiftCard','executeGiftCard','viewGiftCardSale','executeGiftCardSale','viewGiftCardBalance','executeGiftCardBalance');
INSERT INTO role_permission_tbl (roleId, applicationId, moduleId, permGroup, permId, permValue, access, created, lastModified, isDeleted)
VALUES
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0);

DELETE FROM config_tbl WHERE featureId in ('maxGiftCardsInTran','maxGiftCardValue','minAmountToReturnToGiftCard');
INSERT INTO config_tbl (locationOrGroupId, applicationId, moduleId, featureGroup, featureId, featureName, featureDescription, featureType, featureListId, featureValue, displaySeqNumber, defaultValue, isPublic, parentFeatureId, fileName, visibilityExpression, created, lastModified, isDeleted)
VALUES
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'maxGiftCardsInTran', 'Maximum gift cards in a transaction', NULL, 'numeric', NULL, NULL, 102, '5', 1, NULL, 'posMClient/sales.ovccfg', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'maxGiftCardValue', 'Maximum value of a gift card', NULL, 'numeric', NULL, NULL, 102, '500', 1, NULL, 'posMClient/sales.ovccfg', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'minAmountToReturnToGiftCard', 'Minimum amount that can be refunded to a Gift Card', 'Minimum amount that can be refunded to a Gift Card', 'numeric', NULL, NULL, 10, '1', 1, NULL, 'posMClient/payment.ovccfg', NULL, '2015-10-29 18:02:55', '2015-10-29 18:02:55', 0);
-- CSP-343
DELETE FROM config_list_tbl WHERE listId ='tenders' and listName='Tenders' and listKey='giftCard';
INSERT INTO config_list_tbl (listId, listName, listType, listKey, listDescription, created, lastModified, isDeleted)
VALUES
	('tenders', 'Tenders', 'keyValuePair', 'giftCard', 'Gift Card', '2015-11-24 11:27:37', '2015-11-24 11:27:37', 0);
	
UPDATE config_tbl  SET defaultValue='1' WHERE featureId='promptForEmployeeId';update config_tbl set defaultValue = '4.6.0/1.19.0' where featureId = 'version';update config_tbl set defaultValue = '20,51,23,giftCard' where featureId = 'allowedRefundTenders' and featureGroup = 'Without Receipt' and moduleId = 'returns';

update config_tbl set defaultValue = '4.7.0/1.20.0' where featureId = 'version'; 
	
 update config_tbl set defaultValue = '1' where featureId = 'isStaffDiscountReceiptRequired' and featureGroup = 'Employee Discount'; 

 update config_tbl set defaultValue = '4.8.0/1.21.0' where featureId = 'version';	
 update config_tbl set defaultValue = '4.9.0/1.22.0' where featureId = 'version';	
 update config_tbl 
set featureName = 'Minimum amount that can be credited to a Gift Card', 
	featureDescription = 'Minimum amount that can be credited to a Gift Card',
	lastModified =CURRENT_TIMESTAMP 
where featureId = 'minAmountToReturnToGiftCard';

update config_tbl set defaultValue = '4.10.0/1.23.0' where featureId = 'version';

delete from config_list_tbl where listId = 'tranTypes' and listKey in ('payInTran', 'payOutTran', 'payInCorrTran', 'payOutCorrTran');
INSERT INTO config_list_tbl (listId, listName, listType, listKey, listDescription, created, lastModified, isDeleted)
VALUES
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payInTran', 'Pay In Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payOutTran', 'Pay Out Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payInCorrTran', 'Pay In Corr. Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payOutCorrTran', 'Pay Out Corr. Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0);

update config_tbl set defaultValue = 'cashPickup,currentTransVoid,layawayFinalize,layawayPayment,layawayReturn,layawaySale,login,logoff,noSale,payIn,payOut,postTranVoid,regularReturn,regularSale,suspended,tillSpotCheck,zread,payInTran,payOutTran,payInCorrTran,payOutCorrTran' 
where featureId = 'tLogExtractForJMS';

update permission_tbl set permName = 'View Gift Card TopUp' where permId = 'viewGiftCard';
update permission_tbl set permName = 'Execute Gift Card TopUp' where permId = 'executeGiftCard';

update permission_tbl set permName = 'View Gift Card Sale' where permId = 'viewGiftCardSale';
update permission_tbl set permName = 'Execute Gift Card Sale' where permId = 'executeGiftCardSale';

update permission_tbl set permName = 'View Gift Card Bal. Enquiry' where permId = 'viewGiftCardBalance';
update permission_tbl set permName = 'Execute Gift Card Bal. Enquiry' where permId = 'executeGiftCardBalance';

-- CSP-530, deleting unwanted reasonCodes (which are now under price match competitors)
delete from reason_code_tbl where codeType = 'priceChange' and id in ('7001', '7002', '7003');

update config_tbl set defaultValue = '4.11.0/1.24.0' where featureId = 'version';

-- For VAT to show up on the VR.
update tax_rate_nls_tbl set lang = 'en-uk';
update config_tbl set defaultValue = '4.11.1/1.24.1' where featureId = 'version';

update config_tbl 
set featureValue = 'en-uk', lastModified =CURRENT_TIMESTAMP 
where featureId = 'lang';
update config_tbl set defaultValue = 'addressLine1,notes,phone,postalCode,town' where featureId = 'customerAddEditOptionalFields' and locationOrGroupId='posMClient-grp-all';
update config_tbl set isPublic = 1 where featureId in ('SavvyEndPoint', 'SavvyMid', 'EncyptionKey', 'CardCustCommerceId');
update config_tbl set featureValue = 1 where featureId = 'VATAlwaysInReceipt';
delete from config_tbl where featureId = 'searchCenterSearchByCustomer';
update config_tbl set defaultValue = '4.12.0/1.25.0' where featureId = 'version';

	-- required for 4.x t-log format
delete from config_tbl where featureId in ('tLogItemExtractForJMS', 'tLogTranFieldExtractForJMS', 'tLogTranItemFieldExtractForJMS', 'tLogTranItemPromoFieldExtractForJMS', 'tLogTranItemProductTaxRateFieldExtractForJMS','tLogTranItemProductRecordFieldExtractForJMS', 'tLogTranItemLoyaltyUserRecordFieldExtractForJMS');	
INSERT INTO `config_tbl` (`locationOrGroupId`, `applicationId`, `moduleId`, `featureGroup`, `featureId`, `featureName`, `featureDescription`, `featureType`, `featureListId`, `featureValue`, `displaySeqNumber`, `defaultValue`, `isPublic`, `parentFeatureId`, `fileName`, `visibilityExpression`, `created`, `lastModified`, `isDeleted`)
	VALUES
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogItemExtractForJMS', 'TLog tables to be sent to JMS Queue', 'List of transaction types that will be sent to JMS Queue', 'multiSelectList', 'tranItemTypes', NULL, 22, 'tran,tranItem,tranItemPromos,tranItemProductTaxRate,tranItemProduct,tranItemLoyaltyUser', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		( 'posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranFieldExtractForJMS', 'Tran table fields to be sent to JMS Queue', 'List of transaction type fields that will be sent to JMS Queue', 'multiSelectList', 'tranFields', NULL, 23, 'id,tranTypeId,barcode,training,tranNo,userId,retailerId,storeId,deviceId,drawerId,tillId,loyaltyId,customerId,isTranVoid,totalItems,merchTotal,promoTotal,tax,total,totalVat,receiptJSON,layawayJSON,currencyId,tranDate,tranObj', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranItemFieldExtractForJMS', 'TranItem table fields to be sent to JMS Queue', 'List of transaction item type fields that will be sent to JMS Queue', 'multiSelectList', 'tranItemFields', NULL, 24, 'tranId,itemIdx,itemType,productId,qty,refItemIdx,reasonCodeId,discType,discValue,newPrice,amount,cardAccountNumber,cardEncryptedToken,cardPinBlock,cardBalance,authCode,stan,isScanned,calcAmount,promoSavings,itemDate,refTranId,salesPerson', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranItemPromoFieldExtractForJMS', 'TranItemPromos table fields to be sent to JMS Queue', 'List of transaction item type fields that will be sent to JMS Queue', 'multiSelectList', 'tranItemPromosFields', NULL, 25, 'tranId,itemIdx,promoType,description,amountType,amountValue,limitPerTran,thresholdType,thresholdValue,thresholdCust,thresholdAlert,productIds,productQtys,groupIds,fromDate,tillDate,requireLoyalty', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranItemProductTaxRateFieldExtractForJMS', 'TranItemProductTaxRate table fields to be sent to JMS Queue', 'List of transaction item type fields that will be sent to JMS Queue', 'multiSelectList', 'tranItemProductTaxRateFields', NULL, 26, 'tranId,itemIdx,taxRateId,percentage,displayCode,description,startDate,isVAT', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranItemProductRecordFieldExtractForJMS', 'TranItemProductRecord table fields to be sent to JMS Queue', 'List of transaction item type fields that will be sent to JMS Queue', 'multiSelectList', 'tranItemProductRecordFields', NULL, 27, 'tranId,itemIdx,productType,name,description,bannerId,productURL,allowDiscounts,brandId,mmGroupId,initialPrice,taxRateId,mainImageId,productCode,pickupId,pickupOrderId,pickupTranId,pickupBasePrice,pickupTotalPrice,pickupQuantity,sku,retailerId, isTaxExemptible', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0),
		('posMClient-grp-all', 'pos', 'TLog', NULL, 'tLogTranItemLoyaltyUserRecordFieldExtractForJMS', 'TranItemLoyaltyUserRecord table fields to be sent to JMS Queue', 'List of transaction item type fields that will be sent to JMS Queue', 'multiSelectList', 'tranItemLoyaltyUserRecordFields', NULL, 28, 'tranId,itemIdx,loyaltyId,loyaltyFName,loyaltyLName,loyaltyEmail,taxId', 1, NULL, 'posMClient/pos.ovccfg', NULL, '2016-03-31 20:54:39', '2016-03-31 20:54:39', 0);


-- DASH-1315
update user_tbl set passwordLastModified = creationTimestamp where passwordLastModified is NULL;	

update config_tbl set defaultValue = '5.2.0' where featureId = 'version';

