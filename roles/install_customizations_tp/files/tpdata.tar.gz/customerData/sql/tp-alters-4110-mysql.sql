delete from config_list_tbl where listId = 'tranTypes' and listKey in ('payInTran', 'payOutTran', 'payInCorrTran', 'payOutCorrTran');
INSERT INTO config_list_tbl (listId, listName, listType, listKey, listDescription, created, lastModified, isDeleted)
VALUES
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payInTran', 'Pay In Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payOutTran', 'Pay Out Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payInCorrTran', 'Pay In Corr. Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0),
	('tranTypes', 'Transaction Types', 'keyValuePair', 'payOutCorrTran', 'Pay Out Corr. Tran', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0);
	
update config_tbl set defaultValue = 'cashPickup,currentTransVoid,layawayFinalize,layawayPayment,layawayReturn,layawaySale,login,logoff,noSale,payIn,payOut,postTranVoid,regularReturn,regularSale,suspended,tillSpotCheck,zread,payInTran,payOutTran,payInCorrTran,payOutCorrTran' 
where featureId = 'tLogExtractForJMS';


update permission_tbl set permName = 'View Gift Card TopUp' where permId = 'viewGiftCard';
update permission_tbl set permName = 'Execute Gift Card TopUp' where permId = 'executeGiftCard';

update permission_tbl set permName = 'View Gift Card Sale' where permId = 'viewGiftCardSale';
update permission_tbl set permName = 'Execute Gift Card Sale' where permId = 'executeGiftCardSale';

update permission_tbl set permName = 'View Gift Card Bal. Enquiry' where permId = 'viewGiftCardBalance';
update permission_tbl set permName = 'Execute Gift Card Bal. Enquiry' where permId = 'executeGiftCardBalance';

-- CSP-530, deleting unwanted reasonCodes (which are now under price match competitors)
delete from reason_code_tbl where codeType = 'priceChange' and id in ('7001', '7002', '7003');

update config_tbl set defaultValue = '4.11.0/1.24.0' where featureId = 'version';
