update config_tbl set defaultValue = '1' where featureId = 'isStaffDiscountReceiptRequired' and featureGroup = 'Employee Discount'; 

 update config_tbl set defaultValue = '4.8.0/1.21.0' where featureId = 'version';	
 