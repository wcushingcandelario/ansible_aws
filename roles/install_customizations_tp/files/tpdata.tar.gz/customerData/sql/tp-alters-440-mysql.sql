-- CSP-164 Gift card configs:
DELETE FROM permission_tbl WHERE permId in ('viewGiftCard','executeGiftCard','viewGiftCardSale','executeGiftCardSale','viewGiftCardBalance','executeGiftCardBalance');
INSERT INTO permission_tbl (applicationId, moduleId, permGroup, permId, permName, permDescription, created, lastModified, isDeleted)
VALUES
	('pos', 'sale', 'giftCard', 'viewGiftCard', 'View Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCard', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'viewGiftCardSale', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCardSale', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'viewGiftCardBalance', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('pos', 'sale', 'giftCard', 'executeGiftCardBalance', 'Execute Gift Card', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0);
	
DELETE FROM role_permission_tbl WHERE roleid in('2','5') and permId in ('viewGiftCard','executeGiftCard','viewGiftCardSale','executeGiftCardSale','viewGiftCardBalance','executeGiftCardBalance');
INSERT INTO role_permission_tbl (roleId, applicationId, moduleId, permGroup, permId, permValue, access, created, lastModified, isDeleted)
VALUES
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'executeGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'executeGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCard', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCardSale', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('5', 'pos', 'sale', 'giftCard', 'viewGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
	('2', 'pos', 'sale', 'giftCard', 'viewGiftCardBalance', NULL, 1, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0);

DELETE FROM config_tbl WHERE featureId in ('maxGiftCardsInTran','maxGiftCardValue','minAmountToReturnToGiftCard');
INSERT INTO config_tbl (locationOrGroupId, applicationId, moduleId, featureGroup, featureId, featureName, featureDescription, featureType, featureListId, featureValue, displaySeqNumber, defaultValue, isPublic, parentFeatureId, fileName, visibilityExpression, created, lastModified, isDeleted)
VALUES
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'maxGiftCardsInTran', 'Maximum gift cards in a transaction', NULL, 'numeric', NULL, NULL, 102, '5', 1, NULL, 'posMClient/sales.ovccfg', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'maxGiftCardValue', 'Maximum value of a gift card', NULL, 'numeric', NULL, NULL, 102, '500', 1, NULL, 'posMClient/sales.ovccfg', NULL, '2015-10-27 11:35:34', '2015-10-27 11:35:34', 0),
('posMClient-grp-all', 'pos', 'sale', 'Gift Cards', 'minAmountToReturnToGiftCard', 'Minimum amount that can be refunded to a Gift Card', 'Minimum amount that can be refunded to a Gift Card', 'numeric', NULL, NULL, 10, '1', 1, NULL, 'posMClient/payment.ovccfg', NULL, '2015-10-29 18:02:55', '2015-10-29 18:02:55', 0);
