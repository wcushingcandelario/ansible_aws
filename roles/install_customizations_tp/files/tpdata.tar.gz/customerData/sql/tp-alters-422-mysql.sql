-- CSP-186
INSERT INTO role_permission_tbl (roleId, applicationId, moduleId, permGroup, permId, permValue, access, created, lastModified, isDeleted)
VALUES
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayInTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayOutTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayInCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	
	('2', 'pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
	('5', 'pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', NULL, 1, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0);
	
INSERT INTO permission_tbl (applicationId, moduleId, permGroup, permId, permName, permDescription, created, lastModified, isDeleted)
VALUES
('pos', 'sale', 'managerFunctions', 'viewPayInTran', 'viewPayInTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayInTran', 'executePayInTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayOutTran', 'viewPayOutTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayOutTran', 'executePayOutTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayInCorrTran', 'viewPayInCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayInCorrTran', 'executePayInCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'viewPayOutCorrTran', 'viewPayOutCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0),
('pos', 'sale', 'managerFunctions', 'executePayOutCorrTran', 'executePayOutCorrTran', NULL, '2015-10-20 10:23:09', '2015-10-20 10:23:09', 0);
