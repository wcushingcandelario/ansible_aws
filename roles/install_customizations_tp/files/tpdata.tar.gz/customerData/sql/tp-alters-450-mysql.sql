-- CSP-343
DELETE FROM config_list_tbl WHERE listId ='tenders' and listName='Tenders' and listKey='giftCard';
INSERT INTO config_list_tbl (listId, listName, listType, listKey, listDescription, created, lastModified, isDeleted)
VALUES
	('tenders', 'Tenders', 'keyValuePair', 'giftCard', 'Gift Card', '2015-11-24 11:27:37', '2015-11-24 11:27:37', 0);
	
UPDATE config_tbl  SET defaultValue='1' WHERE featureId='promptForEmployeeId';