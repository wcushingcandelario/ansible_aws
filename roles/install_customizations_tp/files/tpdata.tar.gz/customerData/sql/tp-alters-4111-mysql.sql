-- For VAT to show up on the VR.
update tax_rate_nls_tbl set lang = 'en-uk';


update config_tbl set defaultValue = '4.11.1/1.24.1' where featureId = 'version';
