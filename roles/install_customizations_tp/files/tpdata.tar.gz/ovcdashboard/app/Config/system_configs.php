<?php
	/* Please use HTML Code for currency symobol (http://character-code.com/currency-html-codes.php) */

	$config['system_settings'] = array(
		'currency' => '&#36;', // HTML Code for Dollar Synmbol
		'percentage' => '&#37;',
		'php_date_format' => 'm/d/Y',
		'js_date_format' => 'mm/dd/yyyy',
		'PROMOTIONS_LENGTH' => '100',
		'TILLID' => 'Enable',
		'PUNCH_DAYS' => '06',
	);

	$config['sales_type'] = array(
		'regularSale'=>'regularSale',
		'regularReturn'=>'regularReturn',
		'priceLookup'=>'priceLookup','cashPickup'=>'cashPickup',
		'failedCashPickup'=>'failedCashPickup',
		'payIn'=>'payIn',
		'payOut'=>'payOut',
		'failedPayOut'=>'failedPayOut',
		'pickup'=>'pickup',
		'failedFloat'=>'failedFloat',
		'deposit'=>'deposit',
		'failedDeposit'=>'failedDeposit',
		'safeSpotCheck'=>'safeSpotCheck',
		'login'=>'login',
		'logoff'=>'logoff',
		'currentTransVoid'=>'currentTransVoid',
		'tillSpotCheck'=>'tillSpotCheck',
		'endOfDay'=>'endOfDay',
		'failedEndOfDay'=>'failedEndOfDay',
		'noSale'=>'noSale'
	); 

	$config['printers'] = array(
		'TCP' =>'BIXOLON - TCP',
		'A4 - TCP' =>'A4 - TCP',
		'BLUETOOTH' => 'BIXOLON - Bluetooth',
		'POWAPOS' => 'POWAPOS'
	);

	$config['type'] = array(
		'Printer' =>'Printer',
		'Drawer' => 'Drawer',
		'BarcodeScanner' => 'BarcodeScanner',
		'LineDisplay' => 'LineDisplay'
	);
	$config['model'] = array(
		'JPOSPRINTERBRIDGE' =>'JPOSPRINTERBRIDGE',
		'JPOSDRAWERBRIDGE' => 'JPOSDRAWERBRIDGE',
		'JPOSSCANNERBRIDGE' => 'JPOSSCANNERBRIDGE',
		'JPOSLINEDISPLAYBRIDGE' => 'JPOSLINEDISPLAYBRIDGE'
	);
	$config['logicalname'] = array(
		'POSPrinter1' =>'POSPrinter1', 
		'CashDrawerHID 4610-A-POSPrinter1' => 'CashDrawerHID 4610-A-POSPrinter1',
		'Scanner USB Hand held OEM' => 'Scanner USB Hand held OEM',
		'Display1' => 'Display1'
	);
	$config['alias'] = array(
		'JPOSPrinter' =>'JPOSPrinter', 
		'JPOSDrawer' => 'JPOSDrawer',
		'JPOSScanner' => 'JPOSScanner',
		'JPOSLineDisplay' => 'JPOSLineDisplay'
	);
	$config['port'] = array(
		'32041' =>'32041', 
	);
	$config['payment_device'] = array(
		'verifone'=>'Verifone',
		'iSMP'=>'iSMP',
		'TEST'=>'Test', 
		'Ocius2015'=>'Ocius2015 (Verifone)', 
		'Point'=>'Point (Verifone)', 
		'Axept'=>'Axept (Optomany)',
	);
	$config['scanner_model'] = array(
		'verifone'=>'Verifone',
		'iSMP'=>'iSMP',
		'SocketMobile'=>'SocketMobile',
	);
	//$pay_scanner = array('verifone'=>'Verifone','iSMP'=>'iSMP');
	$config['tender_type'] = array(
		'Cash'=>'Cash',
		'credit/debit'=>'credit/debit',
		'cheque'=>'cheque',
		'giftCard'=>'giftCard'
	);

	$config['reason_code'] = array(
		'Cashier error'=>'Cashier error',
		'Acceptable discrepancy'=>'Acceptable discrepancy',
	);

	$config['transit_type'] = array(
		'regularSale'=>'regularSale',
		'regularReturn'=>'regularReturn',
		'pickup'=>'pickup'
	);
	$config['country'] = array(
		'Australia' => 'Australia',
		'France' => 'France',
		'India' => 'India',
		'UAE' => 'UAE',
		'UK' => 'UK',
		'USA' => 'USA',
	);
	$config['order_stat'] = array(
		'pickedUp'=>'pickedUp',
		'returned'=>'returned',
		'expired'=>'expired',
		'returnowing'=>'returnowing',
		'complete'=>'complete',
		'readyForPickup'=>'readyForPickup',
		'inDeliveryToStore'=>'inDeliveryToStore',
		'cancelled'=>'cancelled'
	);
	$config['reason_code_type'] = array(
		'refund'=>'refund',
		'currencyPurchase'=>'currencyPurchase',
		'taxExempt'=>'Tax Exempt',
		'priceChange'=>'priceChange',
		'priceIncrease'=>'priceIncrease',
		'priceDecrease'=>'priceDecrease',
		'layawayPaymentOverride'=>'Layaway Payment Override',
		'noSale'=>'No Sale',
		'discount'=>'discount',
		'void'=>'void',
		'postVoid'=>'postVoid',
		'suspend'=>'suspend',
		'payIn'=>'payIn',
		'payOut'=>'payOut',
		'float'=>'float',
		'deposit'=>'deposit',
		'endOfDayDiscrepancy'=>'endOfDayDiscrepancy',
		'removeCustomer'=>'removeCustomer',
		'deleteQuote'=>'deleteQuote',
		'failReason'=> 'failReason',
		'PayInTran'=>'PayInTran',
		'PayOutTran'=>'PayOutTran',
		'PayInCorrTran'=>'PayInCorrTran',
		'PayOutCorrTran'=>'PayOutCorrTran'
	);
	$config['tender_code_type'] = array(
		'physical' => 'Physical',
		'manualCardEntry' => 'Manual Card Payment',
		'electronicIntegrated'=>'Electronic - Integrated',
		'electronicExternal'=>'Electronic - External',
		'electronicInternal'=>'Electronic - Internal'
	);
	$config['site_name'] = array(
		'siteName'=>'OneView Dashboard'
	);
	$config['merchandise_options']	= array(
		'Mix and Match'=>'Mix and Match',
		'Buy More, Save More'=>'Buy More, Save More',
		'Tiered Pricing'=>'Tiered Pricing',
		'Limited Time Pricing'=>'Limited Time Pricing',
		'Bundled Deal'=>'Bundled Deal'
	);
	$config['sku_options']	= array(
		'bundle'=>'Bundle',
		'custType'=>'Buy X, Get Y',
	);

	$config['credit_rules'] = array(
		'30' => '0-30',
		'60' => '31-60',
		'above60' => '61+',
	);
	$config['status'] = array(
		'Open' => 'Open',
		'Closed' => 'Closed',
		'Expired' => 'Expired',
	);
	$config['product_type'] = array(
		'Merchandise' => 'Merchandise Product',
		'Fees' => 'Fees',
		'StyleSizeColor' => 'Style Size Color Product',
		//'GiftCertificate' => 'Gift Certificate',
	);
	
	$config['config_list'] = array(
		'tenderList' => array('tableName'=>'TenderTypeTbl','fields'=>array('key'=>'id','value'=>'description')),
		'salespersonRoleIds' => array('tableName'=>'RoleTbl','fields'=>array('key'=>'id','value'=>'name')),
		'locations' => array('tableName'=>'LocationAndGroupTbl','fields'=>array('key'=>'id','value'=>'name')),
		'reasonType' => array('tableName'=>'ReasonCodeTbl','fields'=>array('key'=>'codeType','value'=>'codeType')),
	);
	$config['mmgroup_type'] = array(
		'Merchandise' => 'Merchandise',
		'StyleSizeColor' => 'StyleSizeColor',
	);
	// if is_edit is on then we show edit,delete and add features , if its off then we can't
	
	$config['menu_status'] = array(
	
		'dash_status'=>array('status'=>'On','is_edit'=>'On'),
		
		'config_status'=>array('status'=>'On','is_edit'=>'On','tender_status'=>array('status'=>'On','is_edit'=>'On'),'coupon_status'=>array('status'=>'On','is_edit'=>'On'),'reason_status'=>array('status'=>'On','is_edit'=>'On'),'findit_status'=>array('status'=>'Off','is_edit'=>'Off')),
		
		'users_status'=>array('status'=>'On','is_edit'=>'On','role_status'=>array('status'=>'On','is_edit'=>'On'),'permission_status'=>array('status'=>'On','is_edit'=>'On'),'user_status'=>array('status'=>'On','is_edit'=>'On')),
		
		'products_status'=>array('status'=>'On','is_edit'=>'On','product_status'=>array('status'=>'On','is_edit'=>'On'),'price_status'=>array('status'=>'On','is_edit'=>'On'),'price_change_status'=>array('status'=>'On','is_edit'=>'On'),'merchandise_status'=>array('status'=>'On','is_edit'=>'On')),
		
		'locations_status'=>array('status'=>'On','is_edit'=>'On','location_status'=>array('status'=>'On','is_edit'=>'On'),'device_status'=>array('status'=>'On','is_edit'=>'On'),'peripherals_status'=>array('status'=>'On','is_edit'=>'On')),
		
		'label_status'=>array('status'=>'On','is_edit'=>'On'),
		
		'promotion_status'=>array('status'=>'On','is_edit'=>'On'),
		
		'process_status'=>array('status'=>'On','is_edit'=>'On'),
		
		'menu_structure'=>array('status'=>'On','is_edit'=>'On'),
		
		'report_status'=>array('status'=>'On','is_edit'=>'On','POS'=>array('status'=>'On','is_edit'=>'On','child'=>array('Transactions'=>array('status'=>'On','is_edit'=>'On'),'Till_Totals'=>array('status'=>'On','is_edit'=>'On'),'spotcheck_summ'=>array('status'=>'On','is_edit'=>'On'),'sales_summ'=>array('status'=>'On','is_edit'=>'On'),'JDE_extract'=>array('status'=>'On','is_edit'=>'On'),'JDE_items_extract'=>array('status'=>'On','is_edit'=>'On'))),'Cross_Channel'=>array('status'=>'On','is_edit'=>'On','child'=>array('status_report'=>array('status'=>'On','is_edit'=>'On'))),
		'fitting_room'=>array('status'=>'Off','is_edit'=>'off','child'=>array('runner_time'=>array('status'=>'On','is_edit'=>'On'),'dressing_room'=>array('status'=>'On','is_edit'=>'On'),'client_per_sessiOn'=>array('status'=>'On','is_edit'=>'On'))),'time_attendance'=>array('status'=>'On','is_edit'=>'On'),'clock_in_out'=>array('status'=>'On','is_edit'=>'On')),
		
		'system_status'=>array('status'=>'On','is_edit'=>'On','reset_status'=>array('status'=>'On','is_edit'=>'On'),'deploy_changes'=>array('status'=>'On','is_edit'=>'On'),'ecommerce_data'=>array('status'=>'On','is_edit'=>'On'),'deploy_price_change'=>array('status'=>'On','is_edit'=>'On')),		
		
	);	

	$config['currency'] = array(
		'dollar' => 'USD',
	);

	$config['coupon_type'] = array(
		'giftCertificate' => 'Gift Certificate',
	);
	
	$config['promo_status'] = array(
		'in_review' => array(
		'display' => '<i class ="fa fa-circle text-danger"></i>  In-Review',
		'btn' => 'btn-success',
		'to_status' => 'approved',
		'label'=>'approve',
		),
		'approved' => array(
		'display' => '<i class ="fa fa-circle text-success"></i> Approved',
		'btn' => 'btn-danger',
		'to_status' => 'in_review',
		'label' => 'in_review',
		)
	);
	
	$config['defaultLogos'] = array(
		'mainLogo' => 'data:image/gif;base64,R0lGODlhyABkALMAAOfn5+vr69PT0/Hx8fj4+Pz8/Nra2uDg4M/Pz/X19dbW1t3d3e7u7uTk5MzMzP///yH5BAAAAAAALAAAAADIAGQAAAT/8MlJq7046827/2AojmRpnmiqrmzrvnAsz3Rt33iu73zv/8CgcEgsGo/IpHLJbDqf0Kh0Sq1ar9isdsvter/gsHhMLpvP6LR6zW673/C4fE6v2+/4vH7P7/v/gIGCg4SFhoeIiYqLHg4OAhkEjgMYAAuOjwAFII4BIZaYApodDA2YDgYAHaCOopthmJ4Xkg6UFQMCp6eqjQ6yHbi6mLwYBAbCrQkZwcjEXpgIrxW0thMDrcQBCo4Hvb8b15kT2twYCQgOCKMPBAeYyhbhouPbDt1fu7OTFAmOBhfuHDjL0KlDP1QAHQ18UCCXAmnWWlk4+M9CwIVZTkWzQI3CNgUZ/y45IMChIIePIR2RpOBOAEQKAExOQIlB5EourcpN2yeBgcpIOjXIzOBzJFB7FGh9q1AA3QIKRW9yDLpFYS6jSXk+uFQxQ8CXFobWRKjh64SYCDaIpMB1g1mcAsPdm9CRocINRZeG9bWhwF0NeWc6aLABwIFqfgXiFYvl7rFaWSE/OAgvQ2LCQvlqoNzXEebEDEJw1nC5y91wXdnxDOAIrAV0qS8wrsDagesKsCWEq+yh9m0KueHyChhaQl20HbZByqy3AvKTjyT4/pQueXThxiVmlxxz+YZj3jHMhnn9+/XaIrp3AG9asYSAso6X18CeeeH5Geqjt/BYlyz1HNRXlf97DKHjkmrc4YeBchuMd5aCFzD4wHQV9HfKfxBaIOGAzsSkmHwOdJBLbHs1R16IHIyomyO8iaeZhyKSxSEFTaVTQF27dTZYg5otw6KOnzlSnH0P5EiaZ+0NVFsDddVo4gSBEWkZOk/2JNM2mBHp5GI9avEXBVeFU01bZbXGY5USkOmVmRKYEp6Lv6iJwVsz0uaPVkbqg9SZHOQ51Z7boSmTnzsBWmeFp1TzwDEgjYWVlPQ50OgFNlXgDgJS2dkloyk9eigF4WjFTnCWfglpJKSyZKoEDT3SogQedklAqhNchA+BiIpaJDb0UHWqj+JIV89c01zVQGUAXOXAAi/Jk82CsGCsShcmikqQgLK6YOQiMphMhG0+lomEjAJDVnAtt9pmhGupklnASjoAZMojt45UIq468l6QAADoYFPtBe/iy8jABBds8MEIJ6zwwgw37PDDEEcs8cQUV2zxxRhnrPHGHHfs8ccghyzyyCSXbPLJKKes8sost+zyyzDHLPPMNO8QAQA7',
		'logo_resolution' => 'Preferred Logo Resolution is 200 x 40 ( Or ) 300 x 62',
	);
	
	
?>
